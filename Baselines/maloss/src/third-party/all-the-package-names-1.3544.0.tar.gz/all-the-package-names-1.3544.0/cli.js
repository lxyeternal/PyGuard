#!/usr/bin/env node

process.stdout.write(require('.').join('\n'))
