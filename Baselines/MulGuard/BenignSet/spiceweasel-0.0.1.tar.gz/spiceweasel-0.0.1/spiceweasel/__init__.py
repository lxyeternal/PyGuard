from importlib.metadata import version

__license__ = 'MIT'
__author__ = 'Kevin Walchko'
__version__ = version("spiceweasel")