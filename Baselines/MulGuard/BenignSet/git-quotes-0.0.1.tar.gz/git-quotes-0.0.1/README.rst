Git Quotes
==========

Add beautiful quotes to your commits!

Installation
------------

.. code:: console

    $ pip install git-quotes

Features
--------

-  [x] Default global status (on/off)
-  [x] Pip installable
-  [x] Colorful cli thanks to crayons
-  [ ] Localization English / Spanish

   -  [ ] Quotes
   -  [ ] Cli

-  [ ] Set custom category or author for quotes.
