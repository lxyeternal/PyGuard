## License

burningalice is licensed under the [SSPL license](./LICENSE).
