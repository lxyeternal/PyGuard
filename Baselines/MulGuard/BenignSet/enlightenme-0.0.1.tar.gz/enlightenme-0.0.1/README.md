# Enlighten Me

[![Build Status](https://travis-ci.com/singhgarima/enlightenme.svg?branch=master)](https://travis-ci.com/singhgarima/enlightenme)

A simple python CLI for curating and reading news/updates from your favorite
channels.
