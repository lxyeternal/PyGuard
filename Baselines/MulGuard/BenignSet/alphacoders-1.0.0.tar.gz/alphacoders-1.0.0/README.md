# Alphacoders

```
pip install alphacoders
python3 -m alphacoders -h
```