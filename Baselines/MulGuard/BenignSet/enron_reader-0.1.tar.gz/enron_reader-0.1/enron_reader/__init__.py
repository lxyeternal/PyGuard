"""This package makes it easy to work with the Enron email dataset.
"""

from .Mailbox import Mailbox
from .EnronReader import EnronReader