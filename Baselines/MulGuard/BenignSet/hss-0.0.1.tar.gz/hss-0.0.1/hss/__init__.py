__author__ = "Bruno Rodrigues Silva"
__version__ = "0.1.0"