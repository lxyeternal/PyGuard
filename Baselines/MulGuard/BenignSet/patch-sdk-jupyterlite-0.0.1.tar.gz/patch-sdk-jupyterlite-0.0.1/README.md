# A Cognite SDK fixer for Jupyterlite

