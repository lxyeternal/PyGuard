# RIFL (ReDiMe and isoTOP Filter Library)

## Term definitions

Experiment: results from a single run on a mass spectrometry intrument
Dataset: a set of experimental replicates 

## Example usage

