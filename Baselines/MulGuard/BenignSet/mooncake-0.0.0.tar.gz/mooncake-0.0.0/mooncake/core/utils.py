
def dummy_ops():
    print('hi')