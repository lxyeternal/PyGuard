# InfomaniakNewsletterClient
Integration of Infomaniak Newsletter API in Python
https://newsletter.infomaniak.com/docs/index.html

### Usage
```
pip install infomaniakclient
```

You'll find some examples in the examples.py file in this github's repo:
https://github.com/Potrac/InfomaniakNewsletterClient