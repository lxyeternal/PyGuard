from infomaniakclient.api import Client
from infomaniakclient.api import Action

name = 'infomaniakclient'