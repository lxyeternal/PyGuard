from setuptools import setup

setup(name='dist_ex5',
      version='1.0',
      description='Gaussian and Binomial distributions',
      packages=['dist_ex5'],
      author = 'Amr Gharib',
      author_email = 'amriagharib@gmail.com',
      zip_safe=False)
