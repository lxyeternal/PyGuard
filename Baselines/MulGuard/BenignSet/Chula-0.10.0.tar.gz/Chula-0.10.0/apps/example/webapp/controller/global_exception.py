"""
This module cannot be imported because raises an exception a the
global scope, which happens during import
"""

print variable_not_defined
