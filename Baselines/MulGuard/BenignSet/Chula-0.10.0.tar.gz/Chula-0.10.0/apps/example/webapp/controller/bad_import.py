"""
This module cannot be imported because it should itself raise an
import error.
"""

import intentionally_non_existent_module
