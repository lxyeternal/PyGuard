from chula.www import controller

class Syntax_exception(controller.Controller):
    def index(self):
        for missing_colon_in_expression in xrange(5)
            pass

        return 'This will never get called'
