from chula.www import controller

class Controller(controller.Controller):
    def render(self, template):
        """
        Add your (Mako, Mustache, Cheetah) logic here
        """

        return template
