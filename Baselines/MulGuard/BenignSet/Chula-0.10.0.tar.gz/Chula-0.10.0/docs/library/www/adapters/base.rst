:mod:`chula.www.adapters.base` -- Base adapter
==============================================

.. index::
   single: adapter
   pair: base; adapter

.. automodule:: chula.www.adapters.base
   :members:
