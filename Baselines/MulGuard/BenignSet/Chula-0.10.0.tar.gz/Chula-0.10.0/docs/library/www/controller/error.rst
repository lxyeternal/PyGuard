:mod:`chula.www.controller.error` -- Error controller
=====================================================

.. index::
   pair: error; controller

.. automodule:: chula.www.controller.error

.. autoclass:: Error
  :members:

  .. automethod:: _crappy_static_server
