:mod:`chula.guid` -- Globally unique identifier
===============================================

.. index::
   single: guid

.. automodule:: chula.guid
   :members:
