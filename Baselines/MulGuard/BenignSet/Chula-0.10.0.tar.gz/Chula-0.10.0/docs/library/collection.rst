:mod:`chula.collection` -- Collection package
=============================================

.. index::
   single: chula.colllection
   single: collection

:mod:`chula.data.base`
++++++++++++++++++++++

.. automodule:: chula.collection.base
   :members:

:mod:`chula.data.restricted`
++++++++++++++++++++++++++++

.. automodule:: chula.collection.restricted
   :members:

:mod:`chula.data.ubound`
++++++++++++++++++++++++

.. automodule:: chula.collection.ubound
   :members:
