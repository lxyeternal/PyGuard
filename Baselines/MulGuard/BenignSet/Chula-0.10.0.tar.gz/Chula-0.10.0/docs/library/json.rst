:mod:`chula.json` -- Wrapper for json support
=============================================

.. index::
   single: json

.. automodule:: chula.json
   :members:
