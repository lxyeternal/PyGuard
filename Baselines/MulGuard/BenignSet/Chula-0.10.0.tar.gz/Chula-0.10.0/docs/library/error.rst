:mod:`chula.error` -- Custom exceptions
=======================================

.. index::
   single: exceptions
   single: errors
   pair: exception; handling

.. automodule:: chula.error
   :members:
