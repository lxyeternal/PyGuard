import unittest

from chula.www.controller import base

class Test_base_controller(unittest.TestCase):
    doctest = base
