import unittest

from chula.www.controller import error

class Test_error_controller(unittest.TestCase):
    doctest = error
