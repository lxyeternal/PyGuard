import unittest

from chula.nosql import couch

class Test_couch(unittest.TestCase):
    doctest = couch
