import unittest

from chula import ecalendar

class Test_ecalendar(unittest.TestCase):
    doctest = ecalendar
