import unittest

from chula import singleton

class Test_singleton(unittest.TestCase):
    doctest = singleton
