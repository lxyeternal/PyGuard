"""Chula database package, a simple db abstraction layer"""

from functions import *

# For now support legacy style acess (for now)
from datastore import DataStoreFactory as DataStore
