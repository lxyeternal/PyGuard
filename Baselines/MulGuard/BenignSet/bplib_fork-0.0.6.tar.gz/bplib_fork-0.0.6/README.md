# bplib
A bilinear pairing library for petlib

Documentation: http://bplib.readthedocs.io/en/latest/

Pypi package: https://pypi.python.org/pypi/bplib

Based on Diego Aranha's OpenPairing: https://github.com/dfaranha/OpenPairing
