"""Package that contains the command-line interface."""

from pjt.cli import application
from pjt.cli import commands
