cmu_auth
========

Simple Python methods for authenticating to CMU services. See ``auth.py`` for usage.

Registering with PyPi
---------------------

This is mostly for maintainers, to document how to submit a package to PyPi: ::

    # after bumping the version number in setup.py:
    $ python setup.py register sdist upload

License
-------

MIT License. See LICENSE.
