def red(s):
    return f"\x1b[31m{s}\x1b[0m"


def green(s):
    return f"\x1b[32m{s}\x1b[0m"


def blue(s):
    return f"\x1b[34m{s}\x1b[0m"


def yellow(s):
    return f"\x1b[33m{s}\x1b[0m"


def grey(s):
    return f"\x1b[90m{s}\x1b[0m"
