

# INF = float("inf")
INF = 1e6
