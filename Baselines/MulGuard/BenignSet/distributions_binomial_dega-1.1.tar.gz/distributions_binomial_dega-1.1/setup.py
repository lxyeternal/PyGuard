from setuptools import setup

setup(name='distributions_binomial_dega',
      version='1.1',
      description='Gaussian and Binomial distributions',
      packages=['distributions_binomial_dega'],
      author='Sverige Gewoon',
      author_email='sverige.gewoon@pass.com',
      zip_safe=False)
