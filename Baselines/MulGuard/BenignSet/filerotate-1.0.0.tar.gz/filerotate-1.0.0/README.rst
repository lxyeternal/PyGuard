==========
filerotate
==========

Rotate filenames similar to logrotate. Operates via adding an integer suffix
to filenames if not present or increment it by one.

Install through PyPI with either ``pip install filerotate`` or 
``easy_install filerotate``.

Invoke with ``filerotate -h``.
