def helloWorld():
    print('Hello World')