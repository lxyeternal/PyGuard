from pyrthon._console import PyrsistentConsole

PyrsistentConsole().interact('Pyrsistent data structures enabled')