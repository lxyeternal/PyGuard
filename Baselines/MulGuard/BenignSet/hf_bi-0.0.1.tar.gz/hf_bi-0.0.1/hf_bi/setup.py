from setuptools import setup

setup(name='hf_bi',
      version='0.0.1',
      description='HelloFresh BI library',
      url='https://github.com/welfare520/hf_bi.git',
      author='He Zhang',
      author_email='hz@hellofresh.com',
      license='MIT',
      packages=['hf_bi'],
      zip_safe=False)