import hf_bi 

print hf_bi.test() 