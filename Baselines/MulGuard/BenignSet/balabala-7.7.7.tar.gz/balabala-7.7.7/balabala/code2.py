'''
@File       :   code2.py
@Author     :   Jiang Fubang
@Time       :   2019-10-28 17:17
@Version    :   1.0
@Contact    :   luckybang@163.com
@Dect       :   None
'''