from rich.console import Console

# Create a shared console instance for the application
console = Console()
