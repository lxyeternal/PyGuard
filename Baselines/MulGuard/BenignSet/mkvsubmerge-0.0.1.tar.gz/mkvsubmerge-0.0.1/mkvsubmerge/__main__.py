# -*- coding: utf-8 -*-
 
"""mkvsubmerge.__main__: executed when mkvsubmerge directory is called as script."""
 
from .mkvsubmerge import main
main()

