"""pytest-cov: avoid already-imported warning: PYTEST_DONT_REWRITE."""
__version__ = "__version__ = '2.10.1'"
