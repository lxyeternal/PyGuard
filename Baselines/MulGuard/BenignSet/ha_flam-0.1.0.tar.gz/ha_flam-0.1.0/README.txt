# FLAM
#FreeLanceAssetManager  - Personal Project
#
#Simple Asset management for freelance projects. 
#Initially will be built to purely manage/organize assests and 
#then branch into softerware package intergration.
