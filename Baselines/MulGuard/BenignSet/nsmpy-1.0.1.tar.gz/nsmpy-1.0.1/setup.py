from setuptools import setup

setup(
	name="nsmpy",
	version="1.0.1",
	scripts=['nsmpy.py'])
