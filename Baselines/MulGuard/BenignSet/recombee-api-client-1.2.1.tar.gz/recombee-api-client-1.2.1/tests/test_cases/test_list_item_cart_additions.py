#
# This file is auto-generated, do not edit
#

from tests.test_cases.list_item_interactions import ListItemInteractionsTest
from recombee_api_client.api_requests import *

class ListItemCartAdditionsTestCase (ListItemInteractionsTest):

    def create_request(self, item_id):
        return ListItemCartAdditions(item_id)
