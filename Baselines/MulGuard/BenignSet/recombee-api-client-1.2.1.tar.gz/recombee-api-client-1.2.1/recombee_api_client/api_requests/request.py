class Request:
    """
    Base class for all the requests
    """
    pass