manhattan formatters
====================

A set of functions and utilties that perform common data format task for
manhattan.

How to install
--------------

`pip install manhattan_secure`