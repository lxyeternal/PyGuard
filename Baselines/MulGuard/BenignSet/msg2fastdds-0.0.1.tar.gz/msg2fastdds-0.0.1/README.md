# msg2idl

```bash
pip install msg2fastdds
```

## Docker

```bash
docker build -t msg2fastdds .
docker run --rm -v $PWD/package_dir:/msg2fastdds/package_dir -v $PWD/output_dir:/msg2fastdds/output_dir msg2fastdds
```
