=====
Usage
=====

To use microwave in a project::

    import microwave
