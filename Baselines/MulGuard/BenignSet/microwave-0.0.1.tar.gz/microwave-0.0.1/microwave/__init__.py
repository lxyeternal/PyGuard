# -*- coding: utf-8 -*-

"""Top-level package for microwave."""

__author__ = """Jaewon Chung"""
__email__ = 'j1c@jhu.edu'
__version__ = '0.0.1'
