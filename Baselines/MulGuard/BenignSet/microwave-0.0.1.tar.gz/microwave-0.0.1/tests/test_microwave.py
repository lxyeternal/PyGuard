#!/usr/bin/env python
# -*- coding: utf-8 -*-

"""Tests for `microwave` package."""


import unittest

from microwave import microwave


class TestMicrowave(unittest.TestCase):
    """Tests for `microwave` package."""

    def setUp(self):
        """Set up test fixtures, if any."""

    def tearDown(self):
        """Tear down test fixtures, if any."""

    def test_000_something(self):
        """Test something."""
