=========
microwave
=========


.. image:: https://img.shields.io/pypi/v/microwave.svg
        :target: https://pypi.python.org/pypi/microwave

.. image:: https://img.shields.io/travis/j1c/microwave.svg
        :target: https://travis-ci.org/j1c/microwave

.. image:: https://readthedocs.org/projects/microwave/badge/?version=latest
        :target: https://microwave.readthedocs.io/en/latest/?badge=latest
        :alt: Documentation Status




heats


* Free software: Apache Software License 2.0
* Documentation: https://microwave.readthedocs.io.


Features
--------

* TODO

Credits
-------

This package was created with Cookiecutter_ and the `audreyr/cookiecutter-pypackage`_ project template.

.. _Cookiecutter: https://github.com/audreyr/cookiecutter
.. _`audreyr/cookiecutter-pypackage`: https://github.com/audreyr/cookiecutter-pypackage
