from setuptools import setup

setup(name='neha_probability_distribution',
        version="1.0", 
        description='Gaussian and Binomial distributions',
        packages=['neha_probability_distribution'],
        author='Neha Kalbande',
        author_email='neha.leenaharsh@gmail.com', 
    zip_safe=False)