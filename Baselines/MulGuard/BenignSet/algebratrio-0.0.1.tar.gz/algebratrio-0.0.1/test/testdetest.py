import __init__ as al


a=[5,-3]
b=[6,7]
resultado=al.Determinante(a,b)
print("El determinate de la matriz es: ",resultado)
#salchicha