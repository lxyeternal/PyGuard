# Ontology Change Language

This repo includes schema and code for an Ontology Change Language.

For full documentation, see:

[http://cmungall.github.io/knowledge-graph-change-language](http://cmungall.github.io/knowledge-graph-change-language)

