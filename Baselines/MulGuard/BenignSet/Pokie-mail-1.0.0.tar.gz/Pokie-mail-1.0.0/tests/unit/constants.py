TPL_1_NAME = "template_1_label"
TPL_2_NAME = "template_2_label"
TPL_LOCALE = "en"
