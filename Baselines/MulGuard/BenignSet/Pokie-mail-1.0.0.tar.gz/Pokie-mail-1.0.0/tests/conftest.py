# Load SecureShare fixtures for all tests
pytest_plugins = [
    "tests.unit.fixtures",
]
