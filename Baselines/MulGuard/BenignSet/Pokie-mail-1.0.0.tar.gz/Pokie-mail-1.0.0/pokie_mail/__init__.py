from .constants import get_version

__version__ = get_version()
