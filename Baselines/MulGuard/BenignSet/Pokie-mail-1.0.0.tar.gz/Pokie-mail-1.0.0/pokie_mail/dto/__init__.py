from .records import MessageQueueRecord, MessageTemplateRecord
