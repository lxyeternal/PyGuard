# countdown-sleep

Sleep and print countdown.

## Installation

```
$ pip install countdown-sleep
```

## Usage

```
$ countdown_sleep --help
usage: countdown_sleep [-h] second

Sleep and print countdown.

positional arguments:
  second      sleep seconds

optional arguments:
  -h, --help  show this help message and exit
```

```
$ countdown_sleep 10
# <sleep and print countdown>
```
