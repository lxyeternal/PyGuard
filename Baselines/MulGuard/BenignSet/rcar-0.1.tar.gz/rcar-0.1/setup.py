from setuptools import setup, find_packages

setup(
    name="rcar",
    version="0.1",
    packages=find_packages(),
    author="Robert Valassi",
    description="This is a class for cars2",
    install_requires=[
        # List the dependencies your package requires
    ],
)
