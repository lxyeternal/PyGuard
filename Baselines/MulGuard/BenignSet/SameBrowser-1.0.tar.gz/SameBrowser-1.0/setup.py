from setuptools import setup

setup(
    name='SameBrowser',
    version='1.0',
  	author='Ariel Selig',
  	author_email='support@samebrowser.com',
  	url='https://samebrowser.com',
    packages=['samebrowser',],
    long_description='SameBrowser',
)
