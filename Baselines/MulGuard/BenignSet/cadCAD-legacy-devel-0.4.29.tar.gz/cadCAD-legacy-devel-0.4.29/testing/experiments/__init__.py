from cadCAD.configuration import Experiment

exp_param_sweep = Experiment()
exp_policy_agg = Experiment()