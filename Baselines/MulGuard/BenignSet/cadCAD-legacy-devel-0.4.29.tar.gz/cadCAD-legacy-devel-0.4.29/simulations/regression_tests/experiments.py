from cadCAD.configuration import Experiment

multi_exp = Experiment()