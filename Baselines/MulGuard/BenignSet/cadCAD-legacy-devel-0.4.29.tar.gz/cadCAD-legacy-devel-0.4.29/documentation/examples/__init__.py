from cadCAD.configuration import Experiment

system_model_AB_exp = Experiment()
