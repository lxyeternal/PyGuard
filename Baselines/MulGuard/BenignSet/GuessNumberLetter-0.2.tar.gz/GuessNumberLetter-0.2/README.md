# Guess-number
Example of Object Orientede Programming in Python - Package that choose a number o letter random and you have to guess what is the correct number or letter.
