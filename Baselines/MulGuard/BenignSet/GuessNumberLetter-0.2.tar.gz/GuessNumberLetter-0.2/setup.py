from setuptools import setup

setup(name='GuessNumberLetter',
      version='0.2',
      description='Guess Number or letter',
      packages=['GuessNumberAndLetter'],
      zip_safe=False)