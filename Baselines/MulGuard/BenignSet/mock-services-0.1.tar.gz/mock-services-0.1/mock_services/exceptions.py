# -*- coding: utf-8 -*-


class Http400(Exception):
    pass


class Http401(Exception):
    pass


class Http403(Exception):
    pass


class Http404(Exception):
    pass


class Http405(Exception):
    pass


class Http409(Exception):
    pass


class Http500(Exception):
    pass
