from typing import Union, List 

Interpretation = List[Union[str, List[str]]]
