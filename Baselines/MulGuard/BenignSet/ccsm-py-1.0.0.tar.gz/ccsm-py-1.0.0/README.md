# ccsm-py

Install package:
pip install ccsm-py
or
easy_install sssm-py

Requirement:

* common-utils package

pip install common-utils
or
easy_install common-utils


Usage:

```
    >>> print('hello world')
    ['default', 'test']
```