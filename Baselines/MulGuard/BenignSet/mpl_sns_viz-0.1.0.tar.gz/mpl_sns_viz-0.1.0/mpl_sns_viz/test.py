import numpy as np
import matplotlib.pyplot as plt 

np.random.seed(42)

data = np.random.rand(10,2)

print(data)