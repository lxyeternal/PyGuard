# Import libaries
import matplotlib.pyplot as plt 

class Viz():

	def __init__(self):

		'''Generic Viz class for creating subplots.
		
		Attributes:
			plot_num (int): number of plots needed in visualization 
		'''
		
	


