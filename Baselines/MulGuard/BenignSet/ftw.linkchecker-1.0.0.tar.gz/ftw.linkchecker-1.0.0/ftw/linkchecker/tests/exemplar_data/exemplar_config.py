config_file = {
    "/plone": {
        "email": "hugo.boss@4teamwork.ch",
        "base_uri": "http://example1.ch",
        "timeout_config": "1",
        "upload_location": "/plone/content-page/file-listing-block"
    },
    "/plone2": {
        "email": "berta.huber@gmail.com",
        "base_uri": "http://example2.ch",
        "timeout_config": "1"
    }
}
