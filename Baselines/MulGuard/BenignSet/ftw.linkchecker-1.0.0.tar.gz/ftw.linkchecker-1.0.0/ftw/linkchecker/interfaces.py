from zope.interface import Interface


class IFtwLinkcheckerLayer(Interface):
    """Request layer for ftw.linkchecker"""
