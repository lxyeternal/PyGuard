from setuptools import setup

setup(name='distributions_hairong',
      version='0.1',
      description='Gaussian distributions',
      packages=['distributions_hairong'],
      zip_safe=False)
