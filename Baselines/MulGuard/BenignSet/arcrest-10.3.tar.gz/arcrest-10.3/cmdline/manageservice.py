#! python
import arcrest.admin

arcrest.admin.cmdline.manageservice()
