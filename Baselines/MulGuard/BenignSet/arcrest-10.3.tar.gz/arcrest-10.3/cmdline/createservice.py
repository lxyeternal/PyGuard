#! python
import arcrest.admin

arcrest.admin.cmdline.createservice()
