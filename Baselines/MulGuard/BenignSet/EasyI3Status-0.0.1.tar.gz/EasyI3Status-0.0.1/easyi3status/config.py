[jiraIssues]
# API address without quotes
API = http://atlassian:8080/rest/api/2/
# Username without quotes
username = USERNAME
# Password without quotes
password = PASSWORD
# Project and status lists with quotes
projects = ["SOME_PROJECT", "SOME_OTHER_PROJECT"]
statuses = ["status!=resolved","status!=closed"]
