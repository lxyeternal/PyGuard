# helga-flip

A helga plugin to flip words

## License

Copyright (c) 2014 Shaun Duncan

Licensed under the [GPL](https://github.com/shaunduncan/helga-flip/blob/master/LICENSE).
