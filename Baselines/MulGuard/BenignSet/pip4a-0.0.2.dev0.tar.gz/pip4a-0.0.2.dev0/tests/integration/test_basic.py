"""Basic smoke tests."""


def test() -> None:
    """Basic smoke test."""
    assert True
