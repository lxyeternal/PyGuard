# -*- coding: utf-8 -*-

"""
Version module
This module contains the version information about the project that
is intended to be reused in multiple places.
"""

__version__ = '1.0.0'