from __future__ import division
from __future__ import print_function
from __future__ import unicode_literals

__import__('pkg_resources').declare_namespace(__name__)
