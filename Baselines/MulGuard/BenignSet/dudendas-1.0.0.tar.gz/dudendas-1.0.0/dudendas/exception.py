class DudendasException(Exception):
    pass


class DudendasArgumentException(DudendasException):
    pass
