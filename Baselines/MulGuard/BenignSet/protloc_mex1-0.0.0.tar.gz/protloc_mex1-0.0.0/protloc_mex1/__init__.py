from .GO_count import read_corpus

