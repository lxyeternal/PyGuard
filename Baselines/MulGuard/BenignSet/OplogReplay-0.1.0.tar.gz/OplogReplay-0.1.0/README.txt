===========
OplogReplay
===========

OplogReplay provides a simple tool that can replay MongoDB oplogs from one
cluster to another.