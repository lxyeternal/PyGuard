# Entelequia
