# from entelequia.system.system import GenericSystem
# from entelequia.system.system_interface import GenericSystemInterface


# class Module:
#     def __init__(
#         self, system: GenericSystem, interface: GenericSystemInterface
#     ) -> None:
#         self.system = system
#         self.interface = interface
