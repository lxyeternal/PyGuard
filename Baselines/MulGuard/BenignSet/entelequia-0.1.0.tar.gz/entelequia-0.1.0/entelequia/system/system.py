# from abc import ABC


# class GenericSystem(ABC):
#     pass
