# from abc import ABC, abstractmethod


# class GenericSystemInterface(ABC):
#     @property
#     @abstractmethod
#     def accessor(self) -> str:
#         pass
