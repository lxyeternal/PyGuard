# from datetime import date, datetime, time

# from entelequia.system.system import GenericSystem


# class TimeSystem(GenericSystem):
#     def now(self) -> datetime:
#         return datetime.now()

#     def today(self) -> date:
#         return datetime.now().date()

#     def time_of_day(self) -> time:
#         return datetime.now().time()
