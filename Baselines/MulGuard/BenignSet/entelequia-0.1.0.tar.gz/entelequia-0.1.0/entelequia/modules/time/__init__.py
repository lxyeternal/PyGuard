# from entelequia.modules.time.interface import TimeSystemInterface
# from entelequia.modules.time.system import TimeSystem
# from entelequia.system.module import Module


# class TimeModule(Module):
#     pass


# module = TimeModule(TimeSystem(), TimeSystemInterface())
