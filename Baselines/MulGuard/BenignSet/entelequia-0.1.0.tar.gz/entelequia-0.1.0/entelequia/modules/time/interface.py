# from entelequia.system.system_interface import GenericSystemInterface


# class TimeSystemInterface(GenericSystemInterface):
#     accessor: str = "time_system"
