API
===

.. automodule:: mete0r_zipedit.zipedit
   :members:
