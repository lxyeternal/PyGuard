import utils

utils.prepare_test_resources()
