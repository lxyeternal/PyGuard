from setuptools import setup, find_packages

setup(
    name='profanity_filter_awesome',
    version='0.1.0',
    author='KamilKujawa',
    author_email='super@email.dev',
    packages=find_packages(),
    description='Awesome profanity filter'
)
