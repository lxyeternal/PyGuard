# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['sherlockeys',
 'sherlockeys.lib',
 'sherlockeys.lib.http',
 'sherlockeys.lib.logger',
 'sherlockeys.lib.utils',
 'sherlockeys.sources']

package_data = \
{'': ['*']}

install_requires = \
['colorama>=0.4.5,<0.5.0',
 'requests>=2.28.1,<3.0.0',
 'validators>=0.20.0,<0.21.0']

entry_points = \
{'console_scripts': ['sherlockeys = sherlockeys.entry:main']}

setup_kwargs = {
    'name': 'sherlockeys',
    'version': '0.1.5',
    'description': 'Sherlockeys is a usefull tool for pen-tester. It can quickly try to discover if a given api key works against the most common saas applications.',
    'long_description': None,
    'author': 's2b1n0',
    'author_email': 's2b1n0.git@gmail.com',
    'maintainer': None,
    'maintainer_email': None,
    'url': 'https://github.com/s2b1n0/sherlockeys',
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'entry_points': entry_points,
    'python_requires': '>=3.8,<4.0',
}


setup(**setup_kwargs)
