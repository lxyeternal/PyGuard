# -*- coding: utf-8 -*-

from django.utils.translation import gettext as _

