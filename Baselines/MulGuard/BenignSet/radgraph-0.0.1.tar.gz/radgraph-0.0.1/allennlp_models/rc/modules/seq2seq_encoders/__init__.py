from allennlp_models.rc.modules.seq2seq_encoders.multi_head_self_attention import (
    MultiHeadSelfAttention,
)
from allennlp_models.rc.modules.seq2seq_encoders.qanet_encoder import QaNetEncoder
from allennlp_models.rc.modules.seq2seq_encoders.stacked_self_attention import (
    StackedSelfAttentionEncoder,
)
