from allennlp_models.lm.dataset_readers.masked_language_model import MaskedLanguageModelingReader
from allennlp_models.lm.dataset_readers.next_token_lm import NextTokenLMReader
from allennlp_models.lm.dataset_readers.simple_language_modeling import (
    SimpleLanguageModelingDatasetReader,
)
