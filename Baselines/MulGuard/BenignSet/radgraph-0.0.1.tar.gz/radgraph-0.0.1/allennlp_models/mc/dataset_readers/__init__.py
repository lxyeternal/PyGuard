from allennlp_models.mc.dataset_readers.swag import SwagReader
from allennlp_models.mc.dataset_readers.commonsenseqa import CommonsenseQaReader
from allennlp_models.mc.dataset_readers.piqa import PiqaReader
