from allennlp.data.dataset_readers.conll2003 import Conll2003DatasetReader  # noqa: F401

# This component lives in the main repo because we need it there for tests.
