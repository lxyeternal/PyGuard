from allennlp_models.tagging.models.crf_tagger import CrfTagger
