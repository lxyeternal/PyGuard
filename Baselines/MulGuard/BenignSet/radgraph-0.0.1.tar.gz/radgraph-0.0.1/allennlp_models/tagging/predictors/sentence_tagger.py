from allennlp.predictors.sentence_tagger import SentenceTaggerPredictor  # noqa: F401

# This component lives in the main repo because we need it there for tests.
