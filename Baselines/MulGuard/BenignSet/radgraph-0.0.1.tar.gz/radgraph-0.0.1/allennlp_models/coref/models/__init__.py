from allennlp_models.coref.models.coref import CoreferenceResolver
