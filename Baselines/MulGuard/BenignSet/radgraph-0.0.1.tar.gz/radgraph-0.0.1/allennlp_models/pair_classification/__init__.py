# flake8: noqa: F403
from allennlp_models.pair_classification.dataset_readers import *
from allennlp_models.pair_classification.models import *
from allennlp_models.pair_classification.predictors import *
