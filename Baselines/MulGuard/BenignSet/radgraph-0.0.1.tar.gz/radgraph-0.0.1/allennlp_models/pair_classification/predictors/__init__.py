from allennlp_models.pair_classification.predictors.textual_entailment import (
    TextualEntailmentPredictor,
)
