from allennlp_models.pair_classification.dataset_readers.quora_paraphrase import (
    QuoraParaphraseDatasetReader,
)
from allennlp_models.pair_classification.dataset_readers.snli import SnliReader
