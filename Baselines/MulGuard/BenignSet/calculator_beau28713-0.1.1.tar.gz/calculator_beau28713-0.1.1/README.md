## Title
GUI Calculator

## Description 
GUI calculator built using Kivy 2.1.0

## Purpose  
To learn the basics of the Kivy GUI framwork

## Requirments
Python 3.11  
Kivy 2.1.0

## How to Install
`pip install calculator-beau28713`

## How to run
`python -m calculator_beau28713`  




---------------------------------------


![Image](https://github.com/Beau28713/Calculator_beau28713/blob/main/Calc.PNG)
