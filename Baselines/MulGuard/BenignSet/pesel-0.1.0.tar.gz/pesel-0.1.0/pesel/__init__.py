"""
PESEL Module
"""
from .pesel import Pesel

__all__ = (
    'Pesel',
)
