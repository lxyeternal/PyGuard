# BioinformaticAnalysisTools

## Introduction
A bioinformatic python toolkit accelerated with rust!

- Author: Hua-nan ZHAO @Tsinghua University
- E-Mail: hermanzhaozzzz@gmail.com

## Installation
```shell
pip install bioat
```

## unit testing
```shell
cd tests
python -m pytest
# or
poetry run pytest
```
## usage


## history




