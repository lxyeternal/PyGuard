from setuptools import setup

setup(name='b2-distributions',
      version='0.1',
      description='Gaussian distributions',
      packages=['b2-distributions'],
      zip_safe=False)
