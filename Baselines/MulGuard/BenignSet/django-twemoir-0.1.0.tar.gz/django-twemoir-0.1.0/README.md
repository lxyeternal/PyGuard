TWEMOIR
=======

Twitter memoirs: Stateful Django models encapsulating Twitter data (using Bootstrap, no less).

![twemoir admin](etc/twemoir-admin.jpg)

![editing a twitter user Oauth2 keyset](etc/twemoir-edit-user-keyset.jpg)
