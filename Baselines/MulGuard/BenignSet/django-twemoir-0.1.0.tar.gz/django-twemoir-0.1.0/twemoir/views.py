#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
twemoir/views.py

Created by FI$H 2000 on 2011-08-02.
Copyright (c) 2011 Objects In Space And Time, LLC. All rights reserved.

"""
