from django.test import TestCase


class admin-fieldsTest(TestCase):
    """
    Tests for django-admin-fields
    """
    def test_admin-fields(self):
        pass