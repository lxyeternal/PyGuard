# kedro-alpiq

kedro-alpiq is a part of [Alpiq](https://Alpiq.com). 
This public copy of the package
is a stub published on pypi.org designed to shield Alpiq users from
[dependency confusion](https://medium.com/@alex.birsan/dependency-confusion-4a5d60fec610),
a remote code execution attack publicly disclosed in 2021 by Alex Birsan.

If you are a Alpiq user, you will only see this public package if your
app is not properly configured to find the local package repository built into
Alpiq. Visit the docs for your Alpiq installation for details.

If you never see this public package, it's still doing its job of protecting you
from the dependency confusion attack!
