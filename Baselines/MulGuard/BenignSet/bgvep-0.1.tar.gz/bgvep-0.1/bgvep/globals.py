
class BGVEPError(Exception):
    pass