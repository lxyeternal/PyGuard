from distutils.core import setup

setup(
    name='lyrebird',
    version='0.1.0',
    packages=[''],
    url='',
    license='MIT',
    author='meituanqa',
    author_email='',
    description='A sample python server',
    install_requires=[
        'flask',
        'mitmproxy',
        'requests',
        'fire',
        'colorama',
        'xlrd'
    ]
)
