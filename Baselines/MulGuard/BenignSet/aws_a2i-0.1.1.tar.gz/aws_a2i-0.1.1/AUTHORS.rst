.. _about_author:

About the Author
------------------------------------------------------------------------------

::

   (\ (\
   ( -.-)o    I am a lovely Rabbit!
   o_(")(")

**Sanhe Hu** is a very active **Python Developer** Since 2010. Research area includes **Machine Learning, Big Data Infrastructure, Block Chain, Business Intelligent, AWS, Distributive System**. Love photography, outdoor, arts, game, and also the best `Python <https://www.python.org/>`_.

- My Github: https://github.com/MacHu-GWU
