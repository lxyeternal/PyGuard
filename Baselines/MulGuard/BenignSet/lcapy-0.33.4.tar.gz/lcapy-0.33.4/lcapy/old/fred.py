def namelist(elements):
    return ', '.join([str(elt) for elt in elements])
