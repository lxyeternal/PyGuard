class A(object):

    conj = B


class B(object):

    conj = A

    
    
    
