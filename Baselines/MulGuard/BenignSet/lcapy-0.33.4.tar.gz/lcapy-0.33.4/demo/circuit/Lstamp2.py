from lcapy import pprint, Circuit

cct = Circuit()
cct.add('L1 1 2 L1 i10')
cct.add('L2 3 4 L2 i20')

