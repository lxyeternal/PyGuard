from lcapy import Vstep, R, L, C, pprint

C1 = C(10)
C2 = C(20)

C3 = C1 + C2

pprint(C3)
