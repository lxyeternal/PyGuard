from lcapy import *

a = TSection(R(10), R(20), R(30))
a

b = a.Pisection()
b

c = b.Tsection()
c

