from lcapy import IdealTransformer

a = IdealTransformer(10)

a.Vtransfer

a.Itransfer



