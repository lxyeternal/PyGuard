from lcapy import R, V
n = V(20) + R(2)
n.draw('VRseries.png')

