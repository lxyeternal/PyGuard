from lcapy import R, C, L

((R(1) + L(2)) | C(3)).draw('pickup.png')
