from lcapy import R, C, L, Par
N = Par(C(1), C(2), C(3), C(4))
N.draw('par4.png')





