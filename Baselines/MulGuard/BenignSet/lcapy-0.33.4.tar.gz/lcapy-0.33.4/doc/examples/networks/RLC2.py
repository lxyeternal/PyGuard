from lcapy import R, C, L
(((R(1) | C(2)) + L(3) + R(4)) | R(5)).draw('RLC2.png')
