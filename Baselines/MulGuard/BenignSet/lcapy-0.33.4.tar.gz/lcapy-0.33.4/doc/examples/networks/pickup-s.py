from lcapy import R, C, L

((R(1) + L(2)) | C(3)).s_model().draw('pickup-s.png')
