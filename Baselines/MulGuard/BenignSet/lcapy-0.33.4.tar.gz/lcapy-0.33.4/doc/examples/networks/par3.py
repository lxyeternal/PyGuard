from lcapy import R, C, L, Par
N = Par(R(1), R(2), R(3))
N.draw('par3.png')
