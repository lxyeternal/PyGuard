from lcapy import R
N = (R(1) + R(2) + R(3)) | (R(4) + R(5))
N.draw('net1.png', label_values=True)
