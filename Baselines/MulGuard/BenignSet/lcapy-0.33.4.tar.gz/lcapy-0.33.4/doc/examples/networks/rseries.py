from lcapy import R
R1 = R(10)
R2 = R(5)
Rtot = R1 + R2
Rtot.draw('rseries.png')
