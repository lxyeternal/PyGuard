from . import utils

__version__ = utils.get_version_information()
