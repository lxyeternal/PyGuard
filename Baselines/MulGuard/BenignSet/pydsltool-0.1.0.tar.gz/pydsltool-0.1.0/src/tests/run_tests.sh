#!/bin/bash

cd `dirname $0`
PYTHONPATH=".." py.test

