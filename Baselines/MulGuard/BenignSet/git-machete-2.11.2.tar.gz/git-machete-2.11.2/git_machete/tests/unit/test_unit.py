import unittest


class GitMacheteTestCase(unittest.TestCase):
    def test_git_machete(self):
        pass


if __name__ == '__main__':
    unittest.main()
