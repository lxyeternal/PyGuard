try:
    import tkinter as tk
except ImportError:
    # Python 2
    import Tkinter as tk

__all__ = []
