==========
reflection
==========

Reflection is a wrapper around `tkinter`_ with support for Python 2 and 3.

It aims to be a more intuitive way of creating graphical interfaces, while keeping the ability to modify widgets in any way you want.
Although still in alpha, things are looking good for development.
The next versions will bring event handling, new widgets and window manager interactions.

Features
--------

* Support for the following widgets:

   * ``Application`` (``tkinter.Tk``)
   * ``Window`` (``tkinter.Toplevel``)
   * ``Frame`` (``tkinter.Frame``)
   * ``Text`` (``tkinter.Label``)
   * ``Image`` (``tkinter.Label``)
   * ``Button`` (``tkinter.Button``)
   * ``Entry`` (``tkinter.Entry``)

* Support for more than 30 image types (requires the `PIL`_ library)
* Custom styles to personalize interfaces
* Completely clutter-free!


Installation
------------

Getting started is easy. Just download the latest version from PyPi.org:

.. code-block:: shell

    pip install reflection

*Note:* You may need to replace ``pip`` with ``pip3`` if you plan on using reflection in Python 3.


Help
----

Reflection is still in alpha, so bugs are to be expected. The semantics of the library may change a great deal over time.

|

If you've found a bug or have a question, please open an issue on GitHub `here`_.

.. _tkinter: https://github.com/python/cpython/tree/3.6/Lib/tkinter
.. _PIL: http://pythonware.com/products/pil/
.. _here: https://github.com/Coal0/reflection/issues/new
