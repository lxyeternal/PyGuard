# Task 1: Random Number Generator for discrete distributions

A pseudo-random number generator for discrete distribution. It uses the library [random](https://docs.python.org/3/library/random.html) as backend for pseudo-randomness.

## Installation
This repository supports Python3
