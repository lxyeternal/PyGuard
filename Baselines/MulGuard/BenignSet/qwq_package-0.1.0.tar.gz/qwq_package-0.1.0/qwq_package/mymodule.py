

def add(a, b):
    c = a + b
    return c