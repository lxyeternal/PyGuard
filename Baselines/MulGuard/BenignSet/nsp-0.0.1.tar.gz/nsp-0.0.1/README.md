# Neural Network Signal Processing

Analyse activation patterns of neural networks as causal signals on directed acyclic graphs (DAGs).

Developed by Felipa Schwarz (c) 2021
