from setuptools import setup

setup(name='meanCalculation',
      version='0.0',
      description='calculation of mean',
      packages=['meanCalculation'],
      author_email='varshakt6@gmail.com',
      zip_safe=False)
