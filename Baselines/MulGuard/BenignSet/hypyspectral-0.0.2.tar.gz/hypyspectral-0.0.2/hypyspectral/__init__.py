from __future__ import absolute_import, division, print_function, unicode_literals

__version__ = '0.0.1'

import sys
from .algorithms import *
from .io import *
from .utils import *
from .visualisation import *
