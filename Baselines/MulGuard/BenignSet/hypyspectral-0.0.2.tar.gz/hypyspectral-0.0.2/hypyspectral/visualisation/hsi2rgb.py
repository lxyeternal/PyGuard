def pseudocolourhsi():
    print("Pseudo Colour HSI")