def visualise_HSI():
    print("Visualise Hypercube")

def visualise_HSI_with_face():
    print("Visualise Hypercube with custom face")

def scrub_HSI():
    print("HSI Band Scrubber")
