"""Python Client zum Abruf unterjähriger Verbrauchsinformationen über die *ARGE consumption-data API*."""
__version__ = "1.0.0"