class Client:
    def __init__(self):
        self.word = "Hello World"

    def speak(self):
        print(self.word)

