from distutils.core import setup

setup(
    name='oag_client',
    version='0.0.1',
    packages=['OAGClient',],
    license='Creative Commons Attribution-Noncommercial-Share Alike license'
)