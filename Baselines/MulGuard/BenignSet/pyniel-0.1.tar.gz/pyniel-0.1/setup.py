from setuptools import setup, find_packages


setup(
    name="pyniel",
    description='Python tools for Yours Truly',
    author='Daniel Dugas',
    version='0.1',
    packages=find_packages(),
)
