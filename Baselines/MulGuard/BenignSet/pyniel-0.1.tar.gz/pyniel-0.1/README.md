# Pyniel

A growing python package of functions which I find myself using all over the place.

## Install

```
# from this repository base folder
pip install .
```

## Import as local package
```
import sys
sys.path.append({Path to pyniel directory})
from numpy_tools.gridify import *
from deep_learning.fullyconnected import FCNetwork, FCNParam
```
