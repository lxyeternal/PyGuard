#!/usr/bin/env python3

from hatch_vcs_footgun_example import __version__

if __name__ == "__main__":
    print(f"My version is '{__version__}'.")
