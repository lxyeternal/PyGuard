"""Meety - quickly start online meetings from YAML."""
