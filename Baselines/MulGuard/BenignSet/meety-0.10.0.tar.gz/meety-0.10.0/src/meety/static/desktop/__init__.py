"""Static desktop files."""
