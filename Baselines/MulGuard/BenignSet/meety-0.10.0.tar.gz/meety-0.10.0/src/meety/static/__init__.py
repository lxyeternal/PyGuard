"""Static data (partial configurations and further resources like icons)."""
