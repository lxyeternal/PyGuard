"""Static configuration."""
