"""Static icons."""
