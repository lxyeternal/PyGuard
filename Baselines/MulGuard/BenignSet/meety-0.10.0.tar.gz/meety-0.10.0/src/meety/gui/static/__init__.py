"""Static resources for the GUI."""
