"""Module for the graphical user interface."""
