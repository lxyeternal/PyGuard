"""Main window."""
from meety.gui.main_window.main_window import MainWindow  # USED
