"""Meeting list"""

from meety.gui.main_window.meeting_list.list import Meetings
