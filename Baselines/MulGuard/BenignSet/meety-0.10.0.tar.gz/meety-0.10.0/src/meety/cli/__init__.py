"""Module for the command line interface."""
