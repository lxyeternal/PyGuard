# -*- coding: utf-8 -*-

"""A community-curated, decentralized biomedical ontology."""

from .api import *  # noqa
