=========
pyflutter
=========


.. image:: https://img.shields.io/pypi/v/pyflutter.svg
        :target: https://pypi.python.org/pypi/pyflutter

.. image:: https://img.shields.io/travis/SpikingNeuron/pyflutter.svg
        :target: https://travis-ci.com/SpikingNeuron/pyflutter

.. image:: https://readthedocs.org/projects/pyflutter/badge/?version=latest
        :target: https://pyflutter.readthedocs.io/en/latest/?badge=latest
        :alt: Documentation Status


.. image:: https://pyup.io/repos/github/SpikingNeuron/pyflutter/shield.svg
     :target: https://pyup.io/repos/github/SpikingNeuron/pyflutter/
     :alt: Updates



Write flutter in Python with FastAPI backend


* Free software: BSD license
* Documentation: https://pyflutter.readthedocs.io.


Features
--------

* TODO

Credits
-------

This package was created with Cookiecutter_ and the `audreyr/cookiecutter-pypackage`_ project template.

.. _Cookiecutter: https://github.com/audreyr/cookiecutter
.. _`audreyr/cookiecutter-pypackage`: https://github.com/audreyr/cookiecutter-pypackage
