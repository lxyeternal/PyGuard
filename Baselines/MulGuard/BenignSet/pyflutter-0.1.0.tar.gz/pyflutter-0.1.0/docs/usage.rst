=====
Usage
=====

To use pyflutter in a project::

    import pyflutter
