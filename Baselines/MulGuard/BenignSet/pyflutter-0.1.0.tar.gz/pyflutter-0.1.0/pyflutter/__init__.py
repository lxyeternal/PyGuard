"""Top-level package for pyflutter."""

__author__ = """Praveen Kulkarni"""
__email__ = 'praveenneuron@gmail.com'
__version__ = '0.1.0'
