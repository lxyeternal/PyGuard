# mkdesigner
Genome-wide design of markers for PCR-based genotyping from NGS data.
