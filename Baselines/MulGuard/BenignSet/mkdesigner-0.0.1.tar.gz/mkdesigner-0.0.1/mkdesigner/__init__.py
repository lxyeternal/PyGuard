__version__ = "0.0.1"
__copyright__    = 'Copyright (C) 2018 CHIGIRA Koki'
__license__      = 'MIT License'
__author__       = 'CHIGIRA Koki'
__author_email__ = 's211905s@st.go.tuat.ac.jp'
__url__          = 'http://github.com/KChigira/mkdesigner'
