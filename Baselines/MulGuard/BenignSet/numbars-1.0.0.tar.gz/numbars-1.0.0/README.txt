# numbars (the very useless but also cool python library)
This python library allows you to add, subtract, multiply, divide, and randomize numbers.