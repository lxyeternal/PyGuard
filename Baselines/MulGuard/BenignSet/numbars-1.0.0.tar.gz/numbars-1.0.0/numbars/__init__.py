import random

def add_numbers(one, two):
    return one + two

def subtract_numbers(one, two):
    return one - two

def multiply_numbers(one, two):
    return one * two

def divide_numbers(one, two):
    return one / two

def random_numbers(min, max):
    return random.randint(min, max)