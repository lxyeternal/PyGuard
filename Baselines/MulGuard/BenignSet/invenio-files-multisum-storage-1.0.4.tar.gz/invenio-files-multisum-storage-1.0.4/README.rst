..
    Copyright (C) 2019 CESNET.

    Invenio Files Multi-Checksum Storage is free software; you can redistribute it and/or modify it
    under the terms of the MIT License; see LICENSE file for more details.

======================================
 Invenio Files Multi-Checksum Storage
======================================

.. image:: https://img.shields.io/github/license/oarepo/invenio-files-multisum-storage.svg
        :target: https://github.com/oarepo/invenio-files-multisum-storage/blob/master/LICENSE

.. image:: https://img.shields.io/travis/oarepo/invenio-files-multisum-storage.svg
        :target: https://travis-ci.org/oarepo/invenio-files-multisum-storage

.. image:: https://img.shields.io/coveralls/oarepo/invenio-files-multisum-storage.svg
        :target: https://coveralls.io/r/oarepo/invenio-files-multisum-storage

.. image:: https://img.shields.io/pypi/v/invenio-files-multisum-storage.svg
        :target: https://pypi.org/pypi/invenio-files-multisum-storage

PyFS File Storage For Invenio with support for multiple checksum algos

Further documentation is available on
https://invenio-files-multisum-storage.readthedocs.io/

