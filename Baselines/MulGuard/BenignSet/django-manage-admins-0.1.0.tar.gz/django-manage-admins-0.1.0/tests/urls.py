# we don't actually need any views
urlpatterns = []  # type: ignore
