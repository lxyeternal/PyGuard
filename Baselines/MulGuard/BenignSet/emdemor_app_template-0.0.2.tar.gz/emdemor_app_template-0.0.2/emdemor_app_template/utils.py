def saudation(n: int, arg: str):
    """ Saudation """
    print(n * "#")
    print("Template for Python Applications")
    print("This is the argument:", arg)