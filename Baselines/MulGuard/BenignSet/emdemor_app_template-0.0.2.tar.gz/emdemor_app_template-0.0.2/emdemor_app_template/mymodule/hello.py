def say_hello(arg1:int=1, arg2:int=2):
    """Say hello"""
    print(arg1+arg2)
    print("Hello!")