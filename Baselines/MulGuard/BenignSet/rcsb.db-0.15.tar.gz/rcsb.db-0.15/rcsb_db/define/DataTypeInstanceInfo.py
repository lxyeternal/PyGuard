##
# File:    DataTypeInstanceInfo.py
# Author:  J. Westbrook
# Date:    7-Jun-2018
# Version: 0.001 Initial version
#
# Updates:
#      15-Jun-2018 jdw cleanup exception handling
#      18-Jun-2018 jdw turn off distracting warning messages by default
#
##
"""
Manage data type details extracted by scanning example data sets.

"""
__docformat__ = "restructuredtext en"
__author__ = "John Westbrook"
__email__ = "jwest@rcsb.rutgers.edu"
__license__ = "Apache 2.0"

import logging

from rcsb_db.io.IoUtil import IoUtil

logger = logging.getLogger(__name__)


class DataTypeInstanceInfo(object):

    def __init__(self, filePath, **kwargs):
        self.__filePath = filePath
        # Turn off warnings for missing values
        self.__verbose = kwargs.get("verbose", False)
        self.__tD = {}
        self.__ioU = IoUtil()
        self.__setup(self.__filePath)

    def __setup(self, filePath):
        """
           Read the output serialized by ScanRepoUtil() -
           tD[category] -> d[atName]->{minWidth: , maxWidth:, minPrec:, maxPrec: , count}
        """
        self.__tD = self.__ioU.deserialize(filePath, format='json')

    def exists(self, catName, atName=None):
        try:
            if atName:
                return atName in self.__tD[catName]
            else:
                return catName in self.__tD
            return True
        except Exception:
            pass
        return False

    def getAttributeTypeInfo(self, catName, atName):
        try:
            return self.__tD[catName][atName]
        except Exception as e:
            if self.__verbose:
                logger.warning("Missing instance type info for category %r attribute %r %s" % (catName, atName, str(e)))
        return {}

    def getCategoryTypeInfo(self, catName):
        try:
            return self.__tD[catName]
        except Exception as e:
            if self.__verbose:
                logger.warning("Missing instance type info for category %r  %s" % (catName, str(e)))
        return {}

    def getMinWidth(self, catName, atName):
        try:
            return self.__tD[catName][atName]['minWidth']
        except Exception as e:
            if self.__verbose:
                logger.warning("Missing instance type info for category %r attribute %r %s" % (catName, atName, str(e)))
        return 0

    def getMaxWidth(self, catName, atName):
        try:
            return self.__tD[catName][atName]['maxWidth']
        except Exception as e:
            if self.__verbose:
                logger.warning("Missing instance type info for category %r attribute %r %s" % (catName, atName, str(e)))
        return 0

    def getMinPrecision(self, catName, atName):
        try:
            return self.__tD[catName][atName]['minPrec']
        except Exception as e:
            if self.__verbose:
                logger.warning("Missing instance type info for category %r attribute %r %s" % (catName, atName, str(e)))
        return 0

    def getMaxPrecision(self, catName, atName):
        try:
            return self.__tD[catName][atName]['maxPrec']
        except Exception as e:
            if self.__verbose:
                logger.warning("Missing instance type info for category %r attribute %r %s" % (catName, atName, str(e)))
        return 0

    def getCount(self, catName, atName):
        try:
            return self.__tD[catName][atName]['count']
        except Exception as e:
            if self.__verbose:
                logger.warning("Missing instance type info for category %r attribute %r %s" % (catName, atName, str(e)))
        return 0
