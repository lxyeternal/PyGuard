# -*- coding: utf-8 -*-


class CellMapsImageDownloaderError(Exception):
    """
    Base exception for CellMapsImageDownloader
    """
    pass
