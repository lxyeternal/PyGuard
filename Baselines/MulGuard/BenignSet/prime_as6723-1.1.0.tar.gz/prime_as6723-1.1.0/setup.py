#!/usr/bin/env python
# coding: utf-8

# In[ ]:


from setuptools import setup, find_packages

setup(
    name="prime_as6723",
    version="1.1.0",
    packages=find_packages(),
)

