from .Semestre import Semestre
from .Nota import Nota
from .Frequencia import Frequencia
from .Disciplina import Disciplina