class Semestre:
	def __init__(self,date,discs):
		self.date=date
		self.discs=discs
