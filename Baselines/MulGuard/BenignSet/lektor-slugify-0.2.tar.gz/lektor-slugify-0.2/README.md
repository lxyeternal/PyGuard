# lektor-slugify

This is a Lektor plugin that provides a simple template filter that transforms a (unicode) string into a slug.

Usage: `{{ var|slug }}`

This is a simple use of the Python package [python-slugify](https://github.com/un33k/python-slugify).
