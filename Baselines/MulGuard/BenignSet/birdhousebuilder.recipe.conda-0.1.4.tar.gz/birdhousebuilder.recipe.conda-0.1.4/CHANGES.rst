Changes
*******

0.1.4 (2015-01-09)
==================

* added https://conda.binstar.org/birdhouse to default channels.

0.1.3 (2015-01-08)
==================

* added https://conda.binstar.org/scitools to default channels.

0.1.2 (2014-12-02)
==================

* added on on-update buildout option. 

0.1.1 (2014-07-31)
==================

* Updated documentation.

0.1.0 (2014-07-10)
==================

* Initial Release.
