# -*- coding: utf-8 -*-
# vi:si:et:sw=4:sts=4:ts=4

__version__ = '0.0.1'
