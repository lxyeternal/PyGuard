Belogging
=========

|TravisCI Build Status| |Coverage Status|

----

A very specific way to configure/setup logging for python applications.

Requirements:

    * Python 3.5 and beyond



.. |TravisCI Build Status| image:: https://travis-ci.org/georgeyk/belogging.svg?branch=master
   :target: https://travis-ci.org/georgeyk/belogging
.. |Coverage Status| image:: https://coveralls.io/repos/github/georgeyk/belogging/badge.svg?branch=master
   :target: https://coveralls.io/github/georgeyk/belogging?branch=master
