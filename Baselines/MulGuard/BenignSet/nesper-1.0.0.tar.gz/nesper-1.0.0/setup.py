from distutils.core import setup

setup(	
	name		= 'nesper',
	version		= '1.0.0',
	py_modules	= ['nesper'],
	author		= 'eduorloff',
	author_email	= 'eduorloff@gmail.com',
	url		= 'eduorloff.com.br',
	description 	= 'Simples print de lista',
)

