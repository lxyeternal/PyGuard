"""Setup script for the project."""
from setuptools import setup

setup()
