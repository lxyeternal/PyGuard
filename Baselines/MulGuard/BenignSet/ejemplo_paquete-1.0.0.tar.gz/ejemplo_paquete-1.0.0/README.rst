Aprende IT - code example 
==========================

.. image:: https://aprendeit.com/wp-content/uploads/2020/02/LOGO-DEF-e1582099960877-1.png
  :alt: pipeline status
  :target: https://aprendeit.com



Installation (*pip or setup*)
=============================

+ With pip (*for extend lib*) : 

  1. ``pip install ejemplo_paquete.zip``


Usage (*scripts*)
=================




.. code::

    usage: ejemplo_paquete
    Returns your public IP



