import ejemplo_paquete

__all__=['ejemplo_paquete']
