# This is synced with git tags to ensure consistency.
VERSION = '0.0.0'
