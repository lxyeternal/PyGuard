from enum import Enum

class Command(Enum):
    GENERATE = 'generate'
