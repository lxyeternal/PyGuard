
def generate(db_url):
    print('I am generating', db_url)
