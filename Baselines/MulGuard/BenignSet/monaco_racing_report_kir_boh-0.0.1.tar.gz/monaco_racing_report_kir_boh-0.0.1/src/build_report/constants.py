const_name = 'name'
const_comand = 'comand'
const_start_time = 'start time'
const_end_time = 'end time'
const_absolute_time = 'absolute time'
const_time_format = '%M:%S.%f'
const_for_join = '|'
const_divider = '_'
const_divider_length = 72
const_predivided_racers = 16

