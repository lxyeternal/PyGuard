import MESAPC._MESAPC.MESAPC as mpc
import sys

def main(argv):
    mpc.MESAPC()

if __name__ == '__main__':
  main(sys.argv)
