
from pprint import pprint

from kea2.util import register_hook


#def pretweet(meta):
#    pprint(meta)


def init(meta):
    pass
    #register_hook('to_execute', printer, 100)
    #meta['_hooks']['pre_expand']['twitter'] = pretweet
