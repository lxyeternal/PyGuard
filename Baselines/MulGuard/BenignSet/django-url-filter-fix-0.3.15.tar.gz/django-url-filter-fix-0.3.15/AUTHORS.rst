Credits
-------

Development Lead
----------------

* Miroslav Shubernetskiy - https://github.com/miki725

Contributors
------------

* João Neto - https://github.com/netjinho
* Jorik Kraaikamp - https://github.com/JostCrow
* Håken Lid - https://github.com/haakenlid
* Ryan O’Hara - https://github.com/ryan-copperleaf
* webrunners - https://github.com/webrunners
* Simone Pellizzari - https://github.com/simone6021
* Jonathon Farzanfar - https://github.com/pctSW1
