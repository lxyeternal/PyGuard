url\_filter.filtersets.plain module
===================================

.. automodule:: url_filter.filtersets.plain
    :members:
    :undoc-members:
    :show-inheritance:
