url\_filter.backends.django module
==================================

.. automodule:: url_filter.backends.django
    :members:
    :undoc-members:
    :show-inheritance:
