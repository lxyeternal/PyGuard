url\_filter.exceptions module
=============================

.. automodule:: url_filter.exceptions
    :members:
    :undoc-members:
    :show-inheritance:
