url\_filter.backends.plain module
=================================

.. automodule:: url_filter.backends.plain
    :members:
    :undoc-members:
    :show-inheritance:
