url\_filter.filtersets.base module
==================================

.. automodule:: url_filter.filtersets.base
    :members:
    :undoc-members:
    :show-inheritance:
