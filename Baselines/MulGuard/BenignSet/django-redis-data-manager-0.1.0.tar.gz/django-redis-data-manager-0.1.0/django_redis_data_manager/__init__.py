default_app_config = "django_redis_data_manager.apps.DjangoRedisDataManagerConfig"


app_requires = [
    'django_static_jquery3',
    'django_static_fontawesome',
    'django_object_toolbar_admin',
]
