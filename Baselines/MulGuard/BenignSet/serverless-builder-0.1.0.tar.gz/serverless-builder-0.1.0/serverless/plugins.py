from serverless.service.plugins.composed_vars import ComposedVars
from serverless.service.plugins.domain_manager import DomainManager
from serverless.service.plugins.generic import Generic
from serverless.service.plugins.prune import Prune
from serverless.service.plugins.python_requirements import PythonRequirements
