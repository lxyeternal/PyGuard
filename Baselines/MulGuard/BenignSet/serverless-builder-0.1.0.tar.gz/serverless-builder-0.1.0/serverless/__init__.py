__version__ = "0.1.0"

from serverless.service import Service
from serverless.service.configuration import Configuration
