from setuptools import setup

setup(name='emacsipython',
      version='0.1.0',
      description='Utility function for calling an IPython embed that works in Emacs.',
      url='',
      author='Nathan Addy',
      author_email='nathan.addy@windfalltechnical.com',
      license='MIT',
      packages=['emacsipython'],
      zip_safe=False)
