from setuptools import setup

setup(name='package_gua',
      version='0.1',
      description='package_gua',
      packages=['package_gua'],
      author = 'Andrew',
      author_name = 'myemail@something.com',
      zip_safe=False)
