# coding=utf-8
"""
Track your life like a pro on Google Calendar via your terminal.
"""
__version__ = '0.1.0'
__author__ = 'adamchainz'
__license__ = 'MIT'
