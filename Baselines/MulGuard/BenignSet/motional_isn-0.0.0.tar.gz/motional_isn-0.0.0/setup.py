import setuptools

setuptools.setup(
    name="motional_isn",
    version="0.0.0",
    author="Motional",
    author_email="devops@motional.com",
    description="motional_isn",
    long_description="motional_isn",
    long_description_content_type="text/markdown",
    url="https://motional.com/",
    packages=[],
    python_requires='>=5',
)
