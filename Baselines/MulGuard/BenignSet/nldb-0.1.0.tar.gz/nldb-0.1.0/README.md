# nldb

natural language database queries
