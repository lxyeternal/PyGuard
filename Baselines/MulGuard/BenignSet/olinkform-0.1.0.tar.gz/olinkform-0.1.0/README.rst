=========
olinkform
=========


.. image:: https://img.shields.io/pypi/v/olinkform.svg
        :target: https://pypi.python.org/pypi/olinkform

.. image:: https://img.shields.io/travis/nehcgnay/olinkform.svg
        :target: https://travis-ci.com/nehcgnay/olinkform

.. image:: https://readthedocs.org/projects/olinkform/badge/?version=latest
        :target: https://olinkform.readthedocs.io/en/latest/?badge=latest
        :alt: Documentation Status




The preprocessing lib for olink data


* Free software: MIT license
* Documentation: https://olinkform.readthedocs.io.


Features
--------

* TODO

Credits
-------

This package was created with Cookiecutter_ and the `audreyr/cookiecutter-pypackage`_ project template.

.. _Cookiecutter: https://github.com/audreyr/cookiecutter
.. _`audreyr/cookiecutter-pypackage`: https://github.com/audreyr/cookiecutter-pypackage
