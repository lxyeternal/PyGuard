=======
History
=======

0.1.0 (2020-06-01)
------------------

* First release on PyPI.
