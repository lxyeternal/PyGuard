=====
Usage
=====

To use olinkform in a project::

    import olinkform
