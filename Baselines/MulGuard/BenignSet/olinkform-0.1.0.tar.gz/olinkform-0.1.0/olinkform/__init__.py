"""Top-level package for olinkform."""

__author__ = """Yang Chen"""
__email__ = 'yang.chen@scilifelab.se'
__version__ = '0.1.0'
