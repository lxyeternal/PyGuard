from alfred_jira.app import AlfredJiraApp


def cli():
    AlfredJiraApp().run()
