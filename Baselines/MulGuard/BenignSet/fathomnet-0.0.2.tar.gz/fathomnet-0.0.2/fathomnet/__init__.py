# __init__.py (fathomnet-py)
