# semv - Semantic Version Printing

Intended use case:
  $ git tag $(semv)

## Design principles

- No unexpected write
- Do not trust the user's commit messages blindly
