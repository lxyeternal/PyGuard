class NoNewVersion(Exception):
    pass


class InvalidCommitType(Exception):
    pass


class InvalidCommitFormat(Exception):
    pass
