# How many labels are at max put into the output
# ranking, everything else will be cut off
LABEL_RANKING_LENGTH = 10
