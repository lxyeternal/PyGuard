GENERATE WITH bin/update-readme.py
