This is a library to generate your project to autoexporting data from Agisoft Metashape
To start run this command
pip install avirtech_autoexport
To start this library
from avirtech_autoexport.avirtech_autoexport import autoexport
To run this script
autoexport.run_process()
