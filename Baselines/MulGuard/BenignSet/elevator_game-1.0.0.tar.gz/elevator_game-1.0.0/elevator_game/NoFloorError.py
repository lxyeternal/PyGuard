class NoFloorError(IndexError):
  pass
