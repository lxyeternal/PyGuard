class NoElevatorError(IndexError):
  pass
