class CannotLoadError(LookupError):
  pass
