class NoDifficultyError(IndexError):
  pass
