# Elevator Game

A TUI game, thanks to curses, where you control elevators in a building to move people to where they want to go.
The quicker they get to their destination, the more points you get.

Install with `pip install elevator_game`
