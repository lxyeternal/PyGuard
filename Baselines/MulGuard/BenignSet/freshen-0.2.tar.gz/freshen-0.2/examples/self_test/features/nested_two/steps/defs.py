from freshen import *

@Given("a step also in the nested directory")
def step():
    pass

