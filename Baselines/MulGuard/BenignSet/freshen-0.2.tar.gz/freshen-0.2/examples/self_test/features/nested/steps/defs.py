from freshen import *

@Given("a step also in the nested directory")
def step():
    pass

@Given("^passing without a table$")
def pass_without_table():
    pass
