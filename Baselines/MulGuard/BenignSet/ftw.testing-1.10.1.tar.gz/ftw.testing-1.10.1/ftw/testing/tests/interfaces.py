from zope.interface import Interface


class IDXTypeSchema(Interface):
    pass
