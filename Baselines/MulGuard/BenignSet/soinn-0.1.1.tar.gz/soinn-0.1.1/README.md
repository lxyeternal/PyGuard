# soinn
This is the repo for python package soinn.

## build python wheel package
`python
python setup.py bdist\_wheel
`
