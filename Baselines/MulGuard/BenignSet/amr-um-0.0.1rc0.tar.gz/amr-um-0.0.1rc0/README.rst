# AMR-UM
Unified Messaging for AMR and MDM systems. A way to enable and simplify multi utility operations. 


