# staff

Staff is a toolbox for computer assisted composition in Python.