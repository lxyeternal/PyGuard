def main():
    print("staff!")
