"""Musical patterns."""

# ruff: noqa
from .duration import DurationPattern
