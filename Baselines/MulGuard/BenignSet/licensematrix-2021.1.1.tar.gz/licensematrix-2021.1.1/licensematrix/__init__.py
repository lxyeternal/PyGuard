"""Set up matrix on startup.
"""

from .license_matrix import LicenseMatrix

licenseMatrix = LicenseMatrix()
