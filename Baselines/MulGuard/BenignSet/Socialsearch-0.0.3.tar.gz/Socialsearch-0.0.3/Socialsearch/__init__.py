def Google_Search(Search):
    link = 'https://www.google.com/search?q={}'.format(Search)
    return link
def Facebook_Search(Search):
    link = 'https://www.facebook.com/search/top?q={}'.format(Search)
    return link
def YouTube_Search(Search):
    link = 'https://www.youtube.com/results?search_query={}'.format(Search)
    return link