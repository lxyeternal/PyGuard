DATASET_NOT_FOUND = (
    "Dataset not found or corrupted. You can use download=True to download it."
)
INVALID_SHIFT_ARGUMENTS = "You can not specify both covariate_shift and target_shift."
UNSUPPORTED_SHIFT_TYPE = "This dataset does not support specified shift type."
