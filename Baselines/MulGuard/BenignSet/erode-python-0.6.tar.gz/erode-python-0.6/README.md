# ERODE-CoLoMoTo

Please download the code and open the jupyter lab notebook contained in the folder `distr`
