from nautobot.utilities.testing import TestCase

from nautobot_plugin_ip_services import views