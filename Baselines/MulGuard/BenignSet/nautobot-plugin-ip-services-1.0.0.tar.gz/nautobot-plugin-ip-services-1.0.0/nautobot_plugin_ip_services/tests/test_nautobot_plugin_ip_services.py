from nautobot_plugin_ip_services import __version__


def test_version():
    assert __version__ == '0.1.0'
