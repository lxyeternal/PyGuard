"""Model definition for nautobot_plugin_ip_services."""

from django.db import models

from nautobot.core.models import BaseModel


# Create your models here. Models should inherit from BaseModel.  
# This plugin uses existing Models, so nothing to see here.  