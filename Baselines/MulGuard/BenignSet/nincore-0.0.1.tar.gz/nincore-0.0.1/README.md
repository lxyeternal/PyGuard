# nincore

Core utilities of `nin`'s packages.
