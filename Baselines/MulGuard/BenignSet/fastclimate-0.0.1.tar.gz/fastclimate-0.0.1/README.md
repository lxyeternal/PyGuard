# Fastclimate
> Testing out nbdev


This file will become your README and also the index of your documentation.

## Install

`pip install fastclimate`

## How to use

Fill me in please! Don't forget code examples:

```
from fastclimate.data import *

test_stuff()
```




    2


