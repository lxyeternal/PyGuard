# bash environment variables
bash_env_variables = {}

# For Future Use
bash_pre_exec = [
'-c',
'export __RUNTIMEFROM__=PYTHON;'
]