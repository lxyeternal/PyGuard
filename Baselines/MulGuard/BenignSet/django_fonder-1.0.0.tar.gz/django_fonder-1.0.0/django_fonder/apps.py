from django.apps import AppConfig


class DjangoFonderConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'django_fonder'
