# i have nothings... to say


write.  Lgk.Help.Help()
colors
bgcolor
TexHlc

more..