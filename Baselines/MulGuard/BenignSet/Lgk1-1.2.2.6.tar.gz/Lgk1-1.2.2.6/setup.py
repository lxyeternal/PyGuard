from setuptools import setup, find_packages

setup(
    name='Lgk1',
    version='1.2.2.006',
    packages=['Lgk'],
    description='Description: just write Lgk.Help.Help()',
    author='BT Ansixs',
    author_email='noobra24l8w@gmail.com',
    license='LICENSE',
)
