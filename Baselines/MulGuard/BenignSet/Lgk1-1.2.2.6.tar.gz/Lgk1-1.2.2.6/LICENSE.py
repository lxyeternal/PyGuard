Copyright (c) [..._.] [team Ansixs]

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to use the
Software in accordance with the following terms:

1. Usage: You are allowed to use and incorporate the Software's functionality
   into your projects, provided that you do not directly copy and paste the
   internal code of the "Lgk" module.

2. Inspiration: You are encouraged to derive inspiration from the Software and
   implement similar functionality in your own projects.

3. No Direct Copying: You may not copy verbatim the internal code of the "Lgk"
   module and use it in your projects.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
