#!/usr/bin/env python3
from .base import polyswarm

if __name__ == '__main__':
    polyswarm(obj={})
