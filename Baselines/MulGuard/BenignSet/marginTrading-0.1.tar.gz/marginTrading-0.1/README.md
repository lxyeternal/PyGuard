# PyCrypto

BR - Programas voltados ao mundo das Criptomoedas

EN - Software related to the Cripto World

[![Build Status](https://travis-ci.com/sambiase/pycrypto.svg?branch=main)](https://travis-ci.com/sambiase/pycrypto)
[![Updates](https://pyup.io/repos/github/sambiase/pycrypto/shield.svg)](https://pyup.io/repos/github/sambiase/pycrypto/)
[![Python 3](https://pyup.io/repos/github/sambiase/pycrypto/python-3-shield.svg)](https://pyup.io/repos/github/sambiase/pycrypto/)

Site: [CryptoTech Br](https://www.cryptotechbr.com.br) 