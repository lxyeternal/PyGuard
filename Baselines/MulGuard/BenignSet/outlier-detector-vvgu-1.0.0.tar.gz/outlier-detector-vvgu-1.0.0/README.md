<h1>outlier_detector</h1>

<h4>Small package for detecting outliers</h4>

**Usage:**
* *<h5>install the package</h5>*
* *"detect_outlier_mean_std"* - by mean and standard deviation. Takes column as a parameter
* *"detect_outlier_kvart"* - by kvartile. Takes column as a parameter
* *"detect_outlier_dbscan"* - with DBSCAN (clusterization). Takes two columns as a parameters
* *"detect_outlier_shovene"* - by Shovene method. Takes column as a parameter