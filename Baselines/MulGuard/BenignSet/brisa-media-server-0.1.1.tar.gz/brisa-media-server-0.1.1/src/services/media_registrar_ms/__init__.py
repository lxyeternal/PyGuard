# Licensed under the MIT license
# http://opensource.org/licenses/mit-license.php or see LICENSE file.
# Copyright 2007-2008 Brisa Team <brisa-develop@garage.maemo.org>

from brisa_media_server.services.media_registrar_ms.media_registrar import\
    MSMediaRegistrar
