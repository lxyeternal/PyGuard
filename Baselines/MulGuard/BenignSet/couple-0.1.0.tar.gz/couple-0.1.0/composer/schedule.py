import functools
from aws_cdk import core as cdk

class Scheduler:
    def __init__(self):
        self.app = cdk.App()
        
