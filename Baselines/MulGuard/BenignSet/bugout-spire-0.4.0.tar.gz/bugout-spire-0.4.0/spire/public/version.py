"""
Public module of Spire library and API version.
"""

SPIRE_PUBLIC_VERSION = "0.1.0"
