"""
Go module of Spire library and API version.
"""

SPIRE_GO_VERSION = "0.1.0"
