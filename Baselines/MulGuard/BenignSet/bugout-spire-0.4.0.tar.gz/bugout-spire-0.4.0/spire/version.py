"""
Spire library and API version.
"""

SPIRE_VERSION = "0.4.0"
