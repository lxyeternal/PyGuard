"""
Journals module of Spire library and API version.
"""

SPIRE_JOURNALS_VERSION = "0.1.1"
