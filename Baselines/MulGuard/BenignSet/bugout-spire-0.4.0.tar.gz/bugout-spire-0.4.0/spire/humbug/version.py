"""
Humbug module of Spire library and API version.
"""

SPIRE_HUMBUG_VERSION = "0.1.0"
