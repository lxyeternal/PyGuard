"""
GitHub module of Spire library and API version.
"""

SPIRE_GITHUB_VERSION = "0.1.0"
