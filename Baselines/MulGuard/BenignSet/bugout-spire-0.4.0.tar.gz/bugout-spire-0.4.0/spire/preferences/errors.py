class PreferenceLocked(Exception):
    pass
