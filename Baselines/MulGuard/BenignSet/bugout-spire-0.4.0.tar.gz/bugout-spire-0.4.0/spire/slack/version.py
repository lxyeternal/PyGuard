"""
Slack module of Spire library and API version.
"""

SPIRE_SLACK_VERSION = "0.1.0"
