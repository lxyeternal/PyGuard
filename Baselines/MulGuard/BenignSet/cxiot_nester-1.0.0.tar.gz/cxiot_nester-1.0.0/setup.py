from distutils.core import setup
setup(
    name        = 'cxiot_nester',
    version     = '1.0.0',
    py_modules  = ['cxiot_nester'],
    author      = 'caoshuo',
    author_email= 'cao87620@126.com',
    url         = 'http://www.cxiot.com',
    description = 'A simple test'
)