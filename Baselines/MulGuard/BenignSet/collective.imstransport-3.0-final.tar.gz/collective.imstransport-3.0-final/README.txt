collective.imstransport Package Readme
=========================

Overview
--------

IMS Content Packaging plugin for Plone.
