# make this directory a product
