from HelloWorld import HelloWorld

helloWorld = HelloWorld()
helloWorld.hello()