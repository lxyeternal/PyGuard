class HelloWorld:
    def __init__(self):
        self.helloWorld = "Hello World!"

    def hello(self):
        print (".......")
        print (self.helloWorld)
        print (".......")
