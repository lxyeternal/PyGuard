===========
mentormatch
===========


.. image:: https://img.shields.io/pypi/v/mentormatch.svg
        :target: https://pypi.python.org/pypi/mentormatch

.. image:: https://img.shields.io/travis/jonathanchukinas/mentormatch.svg
        :target: https://travis-ci.org/jonathanchukinas/mentormatch

.. image:: https://readthedocs.org/projects/mentormatch/badge/?version=latest
        :target: https://mentormatch.readthedocs.io/en/latest/?badge=latest
        :alt: Documentation Status




This python application runs an algorithm to match mentors with mentees for the Cross-Sector Mentoring Program.


* Free software: MIT license
* Documentation: https://mentormatch.readthedocs.io.


Features
--------

* TODO

Credits
-------

This package was created with Cookiecutter_ and the `audreyr/cookiecutter-pypackage`_ project template.

.. _Cookiecutter: https://github.com/audreyr/cookiecutter
.. _`audreyr/cookiecutter-pypackage`: https://github.com/audreyr/cookiecutter-pypackage
