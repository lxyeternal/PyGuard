# -*- coding: utf-8 -*-

"""Top-level package for mentormatch."""

__author__ = """Jonathan Chukinas"""
__email__ = 'chukinas@gmail.com'
__version__ = '0.1.0'
