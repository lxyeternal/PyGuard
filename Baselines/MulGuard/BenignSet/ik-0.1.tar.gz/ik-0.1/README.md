### ik's test package
provides two functions, foo() and bar()
both return a randomised string
ik.foo()
ik.bar()

