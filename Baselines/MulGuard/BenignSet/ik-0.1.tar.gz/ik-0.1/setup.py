#
from setuptools import setup

setup(name='ik',
      version='0.1',
      description='iks test package',
      author='ik',
      author_email='pedro@gmail.com',
      url='http://google.com',
      license='MIT',
      packages=['ik'],
      zip_safe=False)
