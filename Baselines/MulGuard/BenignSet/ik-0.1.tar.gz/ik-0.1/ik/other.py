import random

def bar():
    return "result of iztok's foo(" + str(random.randint(0, 20)) + ") function in the test package...."
