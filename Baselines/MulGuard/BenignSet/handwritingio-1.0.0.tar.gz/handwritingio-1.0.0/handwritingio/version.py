"""
WARNING: This file is manually parsed by setup.py to pull out this version
string, so be careful to not change the format when updating this file.
Test the parser by running:

    $ python setup.py --version
    1.0.0

"""

__version__ = '1.0.0'
