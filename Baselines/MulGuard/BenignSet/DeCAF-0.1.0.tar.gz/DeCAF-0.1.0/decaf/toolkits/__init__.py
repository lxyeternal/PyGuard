# -*- coding: utf-8 -*-
"""RDKit and OpenBabel toolkits for DeCAF

Created on Tue Feb 10 15:51:16 2015
by Marta Stepniewska
"""
