# Autofire

Ridiculously small package that allows creating command line interfaces in O(0) time.
