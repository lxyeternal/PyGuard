
# gradio_textwithattachments
A Custom Gradio component.

## Example usage

```python
import gradio as gr
from gradio_textwithattachments import TextWithAttachments
```
