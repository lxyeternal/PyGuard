from .tests import TestNetJsonParser
