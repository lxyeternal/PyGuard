from .tests import TestBatmanParser
