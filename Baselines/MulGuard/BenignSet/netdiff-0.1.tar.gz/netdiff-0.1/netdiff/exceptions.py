class NetParserException(Exception):
    pass


class NetJsonException(Exception):
    pass
