# -*- coding: utf-8 -*-
version = (0, 2, 0)
__version__ = '.'.join(str(n) for n in version)
__author__ = 'lcd1232'
