# botlabs.py
### About
botlabs.py is an API wrapper for discordlabs.org.

### Documentation
soonTM

### Install
soonTM