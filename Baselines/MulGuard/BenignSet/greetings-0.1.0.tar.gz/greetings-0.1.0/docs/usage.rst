=====
Usage
=====

To use Greetings in a project::

    >>> from greetings.greetings import simple_hello
    >>> simple_hello("Danny")
    'Hello Danny!'
