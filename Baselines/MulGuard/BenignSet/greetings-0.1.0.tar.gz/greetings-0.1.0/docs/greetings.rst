greetings package
=================

Submodules
----------

greetings.cli module
--------------------

.. automodule:: greetings.cli
    :members:
    :undoc-members:
    :show-inheritance:

greetings.greetings module
--------------------------

.. automodule:: greetings.greetings
    :members:
    :undoc-members:
    :show-inheritance:


Module contents
---------------

.. automodule:: greetings
    :members:
    :undoc-members:
    :show-inheritance:
