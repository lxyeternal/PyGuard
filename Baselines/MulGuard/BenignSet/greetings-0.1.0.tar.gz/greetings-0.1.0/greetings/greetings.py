# -*- coding: utf-8 -*-

"""Main module."""

def simple_hello(name="you"):
    """Returns string with greeting."""
    return "Hello {}!".format(name)
