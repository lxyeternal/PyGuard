=========
Greetings
=========


.. image:: https://img.shields.io/pypi/v/greetings.svg
        :target: https://pypi.python.org/pypi/greetings

.. image:: https://img.shields.io/travis/chrisfreeman/greetings.svg
        :target: https://travis-ci.org/chrisfreeman/greetings

.. image:: https://readthedocs.org/projects/greetings/badge/?version=latest
        :target: https://greetings.readthedocs.io/en/latest/?badge=latest
        :alt: Documentation Status




Generate greetings strings


* Free software: MIT license
* Documentation: https://greetings.readthedocs.io.


Features
--------

* Create Hello message based on a *name*. Defaults to *you*.

Credits
-------

This package was created with Cookiecutter_ and the `audreyr/cookiecutter-pypackage`_ project template.

.. _Cookiecutter: https://github.com/audreyr/cookiecutter
.. _`audreyr/cookiecutter-pypackage`: https://github.com/audreyr/cookiecutter-pypackage
