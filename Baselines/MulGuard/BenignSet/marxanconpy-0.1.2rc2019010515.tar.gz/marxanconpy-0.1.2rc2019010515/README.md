# marxanconpy

The python package `marxanconpy` is the workhorse behind the Graphical User Interface [Marxan Connect](http://marxanconnect.ca/) but it can also be used like a traditional python package via the command line.

See [documentation](https://remi-daigle.github.io/marxanconpy/) for more information
