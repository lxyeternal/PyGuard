import logging

logging.basicConfig(format='%(asctime)s - %(filename)s - %(lineno)s - %(levelname)s - %(message)s', level=logging.INFO)
logger = logging.getLogger('cmp_sdk')
