## GONK

Gonk is a backend for building and versioning deep learning datasets. It works with all file formats (text, images, etc.) and uses JSON Schema to validate and enforce consistency in annotations. It allows for efficient storage and reproducible dataset releases.
