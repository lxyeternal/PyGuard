# -*- coding: utf-8 -*-
 
 
"""bookshelf.__main__: executed when bookshelf directory is called as script."""
 
 
from .bookshelf import main
main()
