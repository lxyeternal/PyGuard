# READ ME

Welcome to `flexfiles`!

## The Goal

* Simplify reading and writing CSV files (and some JSON)
* Write a checksum for every file to detect whether something changed
* Auto-creation of folder structures, no extra code needed
