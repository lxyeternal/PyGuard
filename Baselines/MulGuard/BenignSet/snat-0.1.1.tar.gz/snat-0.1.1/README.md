# Snat
Helps you track your Steam achievements

## Installation
Ensure you have at least Python 3.10
```
pip install --upgrade snat
```

## Usage
```
snat
```
or
```
python -m snat
```
