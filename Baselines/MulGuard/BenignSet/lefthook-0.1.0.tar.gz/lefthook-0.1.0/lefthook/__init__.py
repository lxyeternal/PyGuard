"""Wrapper for lefthook installation
"""

from ._core import run


__version__ = '0.1.0'
__all__ = ['run']
