import sys
from ._core import run


sys.exit(run())
