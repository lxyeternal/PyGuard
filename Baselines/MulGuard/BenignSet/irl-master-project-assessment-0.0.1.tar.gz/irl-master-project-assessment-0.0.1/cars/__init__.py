from cars.base_car import BaseCar
from cars.fast_car import FastCar
from cars.slow_car import SlowCar
from cars.fancy_car import FancyCar
