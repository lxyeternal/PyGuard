
Changelog
=========

v0.0.2 (2021-03-25)
-------------------

* Add scenario builder for deflex

v0.0.1 (2020-08-06)
-------------------

* First release on PyPI.
