
import scenario_builder


def test_main():
    print(scenario_builder)
    pass
