============
Installation
============

At the command line::

    pip install scenario-builder
