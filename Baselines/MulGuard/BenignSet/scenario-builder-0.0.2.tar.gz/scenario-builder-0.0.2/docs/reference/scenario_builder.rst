scenario_builder
================

.. testsetup::

    from scenario_builder import *

.. automodule:: scenario_builder
    :members:
