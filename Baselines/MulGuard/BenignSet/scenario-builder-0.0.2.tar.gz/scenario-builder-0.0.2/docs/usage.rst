=====
Usage
=====

To use scenario_builder in a project::

	import scenario_builder
