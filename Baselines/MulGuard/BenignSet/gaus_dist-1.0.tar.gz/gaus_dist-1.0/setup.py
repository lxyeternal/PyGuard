from setuptools import setup

setup(name='gaus_dist',
      version='1.0',
      description='Gaussian and Binomial distributions',
      packages=['gaus_dist'],
      author='Ariyo Sanmi',
      author_email = 'sanmi4ariyo@gmail.com',
      zip_safe=False)
