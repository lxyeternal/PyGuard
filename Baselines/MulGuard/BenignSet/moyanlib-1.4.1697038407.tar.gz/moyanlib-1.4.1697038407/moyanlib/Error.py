class http_ConnectionError(Exception):
    pass
class http_InvalidURLError(Exception):
    pass
class http_InvalidHeaderError(Exception):
    pass
class http_TimeoutError(Exception):
    pass
class http_SSLError(Exception):
    pass
class log_LogDirError(Exception):
    pass
class file_PathError(Exception):
    pass

class SaveBit_TypeError(Exception):
    pass