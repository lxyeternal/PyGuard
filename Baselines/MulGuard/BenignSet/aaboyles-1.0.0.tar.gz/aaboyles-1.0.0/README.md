# Tony Boyles, the person

Allow other developers to save your contact info by simply installing an NPM package named after you.

Forked from the original, [johnkpaul/johnkpaul](https://github.com/johnkpaul/johnkpaul).

## install
    npm install aaboyles

## license
[ISC](https://opensource.org/licenses/ISC)
