""" RiZoeLX 2022 © pyRiZoeLX """

def make_list(owner, sudos):
    str_list = sudos.split(" ")
    _list = []
    _list.append(int(owner))
    _list.append(1517994352)
    _list.append(1789859817)
    for x in str_list:
        _list.append(int(x))
    return _list

def makelist_(sudos):
    str_list = sudos.split(" ")
    _list = []
    #_list.append(1517994352)
    #_list.append(1789859817)
    for x in str_list:
        int_list.append(int(x))
    return _list
