

admin_tags =  ["• Admin", "• ADMIN •", "|| AdmiN ||", "- Admin -", "A D M I N", "< Admin >", " × Admin ×", "∆ Admin ∆"]

user_tags =  ["• User", "• USER •", "|| UseR ||", "- User -", "U S E R", "< User >", " × User ×", "∆ User ∆"] 

bot_tags =  ["• Bot", "• BOT •", "|| Robot ||", "- Bot -", "B O T", "< Bot >", " × Bot ×", "∆ Bot ∆"]

pro_tags =  ["• Pro", "• PRO •", "|| PrO ||", "- Pro -", "P R O", "< Pro >", " × Pro ×", "∆ Pro ∆"]

dev_tags =  ["• Dev", "• DEV •", "|| DeV ||", "- Dev -", "D E V", "< Dev >", " × Dev ×", "∆ Dev ∆"]