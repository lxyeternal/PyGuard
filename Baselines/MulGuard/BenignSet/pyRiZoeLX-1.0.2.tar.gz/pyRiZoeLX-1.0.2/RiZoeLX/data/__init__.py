from .spamx import *
from .tags import *
from .usage_data import *
from .vars import *

Dev = "@TheRiZoeL"
R7_ban_codes = "R7x00|R7x01|R7x02|R7x03|R7x04|R7x05|R7x06|R7x07|R7x08|R7x09|R7x10|R7x11|R7x12|R7x13|R7x14|R7x15|R7x16|R7x17|R7x18" 
