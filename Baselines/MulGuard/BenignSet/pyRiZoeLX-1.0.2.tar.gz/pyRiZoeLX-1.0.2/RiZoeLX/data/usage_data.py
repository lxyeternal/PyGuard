"""
   © RiZoeLX
"""

class raid_usage:
     raid = "**Wrong Usage** \n\nsyntax:\n {}raid (count) (username/id or reply to user) \n\n Example: `.raid 99 @Suzune_superbot`"
          

class spam_usage:
     spam = "**Wrong Usage** \n\nsyntax:\n {}spam (count) (message) \n\n Example: `.spam 99 hello`"
     
     delayspam = "**Wrong Usage** \n\nsyntax:\n {}delayspam (delay speed in seconds) (count) (message) \n\n Example: `.delayspam 0.5 99 hello`"
     
     pspam = "**Wrong Usage** \n\nsyntax:\n {}pornspam (count) \n\n Example: `.pornspam 99`"

class dm_usage:
     dm_spam = "**Wrong Usage** \n\nsyntax:\n {}dmspam (username/id or reply to message) (count) (message) \n\n Example: `.dmspam Suzune_superbot 99 hello`"
     
     dm_raid = "**Wrong Usage** \n\nsyntax:\n {}dmraid (count) (username/id or reply to user) \n\n Example: `.rmraid 99 @Suzune_superbot`"
          
     dm = "**Wrong Usage** \n\nsyntax:\n {}dm (username/id or reply to user) (message) \n\n Example: `.dm @Suzune_superbot hello`"
          
