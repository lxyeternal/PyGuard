# FuncTools+

Functional programming goodies
