from functoolsplus.containers.pipes import P, Pipe, PipeRegistry  # noqa: F401
from functoolsplus.containers.pipes import default_registry as default_pipe_registry  # noqa: F401, E501
from functoolsplus.hof import filter, flatmap, fold, map, unit  # noqa: F401

__version__ = '0.0.1'
