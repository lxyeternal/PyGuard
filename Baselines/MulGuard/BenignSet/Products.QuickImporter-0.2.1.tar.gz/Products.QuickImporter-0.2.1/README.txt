QuickImporter README

 Description

  You can 'upload' .zexp file from your local.

  Please use at your own risk!

 Contact

  Michiharu Sakurai (mojix at mojix.org)

 History

  2003/12/10 - 0.2

    added original permission, changed 'leave' flag default to off 

  2003/11/11 - 0.1

    initial version

