# Calorie count



## Install

`pip install your_project_name`

## How to use

First you will provide your height, weight and age and calculate your Basal Metabolic Rate, the number of calories required to keep your body functioning at rest.

After choosing your usual level of activity the Active Metabolic Rate, the number of calories that we consume on a daily basis depending on our height, gender, age, weight and entered activity level whilst maintaining current weight, will be calculated.

Than you will be asked to type in the activity you were doing today. If there are more than one activities matching your input, you will select one from the lst that matches your search pattern. Additionally you will enter the time you were doing this activity.

source for the formulas:    https://www.verywellfit.com/how-many-calories-do-i-need-each-day-2506873
source for the MET values:  https://golf.procon.org/met-values-for-800-activities/
