''' bibreduce.__main___: executed when bibreduce called as a script '''


from .bibreduce import cmMain
cmMain()
