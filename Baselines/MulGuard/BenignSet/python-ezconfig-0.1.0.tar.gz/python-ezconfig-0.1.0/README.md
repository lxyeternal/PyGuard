# ezconfig

ezconfig package v0.1.0