=======
History
=======

0.1 (2020-07-12)
------------------

* First release on PyPI.
