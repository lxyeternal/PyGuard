=========
Psi4 Step
=========


.. image:: https://img.shields.io/travis/molssi-seamm/psi4_step.svg
   :target: https://travis-ci.org/molssi-seamm/psi4_step
.. image:: https://pyup.io/repos/github/molssi-seamm/psi4_step/shield.svg
   :target: https://pyup.io/repos/github/molssi-seamm/psi4_step/
      :alt: Updates


.. image:: https://codecov.io/gh/molssi-seamm/psi4_step/branch/master/graph/badge.svg
   :target: https://codecov.io/gh/molssi-seamm/psi4_step

.. image:: https://readthedocs.org/projects/psi4-step/badge/?version=latest
   :target: https://psi4-step.readthedocs.io/en/latest/?badge=latest
      :alt: Documentation Status

.. image:: https://img.shields.io/pypi/v/psi4_step.svg
   :target: https://pypi.python.org/pypi/psi4_step


A step for Psi4 in a SEAMM flowchart


* Free software: BSD-3-Clause
* Documentation: https://psi4-step.readthedocs.io.


Features
--------

* TODO

Credits
---------

This package was created with Cookiecutter_ and the `molssi-seamm/cookiecutter-seamm-plugin`_ project template.

.. _Cookiecutter: https://github.com/audreyr/cookiecutter
.. _`molssi-seamm/cookiecutter-seamm-plugin`: https://github.com/molssi-seamm/cookiecutter-seamm-plugin

