=====
Usage
=====

To use the Psi4 Step in a project::

    import psi4_step
