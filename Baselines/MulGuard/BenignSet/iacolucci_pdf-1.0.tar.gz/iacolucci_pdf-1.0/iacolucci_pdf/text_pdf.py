def convert():
    print('text converted')
