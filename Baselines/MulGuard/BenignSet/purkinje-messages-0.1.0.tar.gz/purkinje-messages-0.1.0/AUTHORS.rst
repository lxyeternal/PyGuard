Bernhard (Bernd) Biskup <bbiskup@gmx.de>
