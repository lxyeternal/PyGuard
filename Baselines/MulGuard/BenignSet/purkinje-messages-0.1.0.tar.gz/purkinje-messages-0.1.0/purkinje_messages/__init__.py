__author__ = 'Bernhard Biskup'
__email__ = 'bbiskup@gmx.de'
__version__ = '0.1.0'
