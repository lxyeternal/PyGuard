purkinje-messages
=================

Message definitions for the purkinje test runner.
See `purkinje test runner <https://github.com/bbiskup/purkinje>`_.


Development
===========

Clone other relevant purkinje-* packages, then

 mkvirtualenv purkinje
 workon purkinje
 pip install --editable .

