import openai

logitsai = openai
