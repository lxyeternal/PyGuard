from .object_array import GenericObjectArray
from .dot_array import DotArray
from .rect_array import RectangleArray