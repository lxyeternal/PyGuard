# clumper
It "clumps" lists of dictionaries in a functional way.
