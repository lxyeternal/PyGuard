# alphacore
Core statistical functions for alpha
