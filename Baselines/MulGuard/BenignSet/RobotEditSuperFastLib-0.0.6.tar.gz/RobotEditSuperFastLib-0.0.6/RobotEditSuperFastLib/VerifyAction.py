class VerifyAction:
    @staticmethod
    def learn_say(context):
        print(f"learn, {context}")

    @staticmethod
    def varify(context):
        print(f"learn, {context}")


