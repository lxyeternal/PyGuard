

class Base:
    @staticmethod
    def work(context):
        print(f"work, {context}")
