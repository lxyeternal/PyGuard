class HandshakeRequestMessage(object):

    def __init__(self, protocol, version):
        self.protocol = protocol
        self.version = version
