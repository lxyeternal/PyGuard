class HubError(OSError):
    pass


class UnAuthorizedHubError(HubError):
    pass
