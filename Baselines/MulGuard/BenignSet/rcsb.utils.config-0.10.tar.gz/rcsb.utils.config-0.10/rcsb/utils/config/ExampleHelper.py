class ExampleHelper(object):

    def __init__(self, **kwargs):
        pass

    def echo(self, val):
        return val
