DELIMITER = r'{{[^{}]+}}'
DELIMITER_START = '{{'
DELIMITER_END = '}}'

REGEX_METACHARACTERS = ['*', '+', '.', '?']
