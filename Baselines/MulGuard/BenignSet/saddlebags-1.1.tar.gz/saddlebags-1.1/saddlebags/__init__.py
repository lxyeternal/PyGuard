"""
Saddlebags Program Configuration Library
~~~~~~~~~~~~~~~~~~~~~
"""

from .saddlebag import Saddlebag

__version__ = '1.1'
