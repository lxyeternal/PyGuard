import numpy as np

def hello():
    print("Hello3")