from setuptools import setup

setup(
    name='simplePackage3',
    version='0.1.0',    
    description='A example package',
    author='Alexey',
    author_email='ashik2001@yandex.ru',
    url='https://www.google.com',
    packages=['simplePackage3'],
    install_requires=['numpy==1.20.3'],
)