"""
minimal setup.py file
"""
from setuptools import setup

setup()
