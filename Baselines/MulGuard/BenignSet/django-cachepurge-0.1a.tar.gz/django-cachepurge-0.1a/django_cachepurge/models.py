# -*- coding: utf-8 -*-
""" Needed by django to register as an app (especially in tests)
"""
