from ccxt.pro import woo


class Woo(woo):
    pass