from .base import BaseCollector


class LongShortRatioCollector(BaseCollector):
    pass