from plutous.config import BaseConfig


class Config(BaseConfig):
    __section__ = "trade/crypto"