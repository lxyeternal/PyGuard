from plutous.trade.crypto.models import FundingRate

from .base import BaseCollector


class FundingRateCollector(BaseCollector):
    async def collect(self):
        pass
