from .base import BaseCollector


class OHLCVCollector(BaseCollector):
    pass