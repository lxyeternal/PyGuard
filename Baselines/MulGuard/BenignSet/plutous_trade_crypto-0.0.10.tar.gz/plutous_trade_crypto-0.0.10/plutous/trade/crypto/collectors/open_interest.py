from .base import BaseCollector


class OpenInterestCollector(BaseCollector):
    pass