"""Version information for the plugin"""

BROTHER_LABEL_PLUGIN_VERSION = "2.0a10"
