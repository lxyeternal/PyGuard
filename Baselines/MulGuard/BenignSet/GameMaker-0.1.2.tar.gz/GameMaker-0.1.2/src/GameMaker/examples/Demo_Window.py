import GameMaker as gm

window = gm.Window(screen_size=(800,450),title="This is a window")

while window.RUNNING:
	window.update()