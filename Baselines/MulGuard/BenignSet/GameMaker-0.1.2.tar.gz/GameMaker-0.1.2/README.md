# GameMaker

## Requirements.

```sh
pip install pygame
```

## Installation & Usage

```sh
pip install GameMaker
```

See `examples` for usage of wrapper
