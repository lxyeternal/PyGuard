default_app_config = 'aastatistics.apps.AastatisticsConfig'

__version__ = '0.2.1'
__title__ = "AA Statistics"
