from django.apps import AppConfig


class AastatisticsConfig(AppConfig):
    name = 'aastatistics'
    label = 'aastatistics'
