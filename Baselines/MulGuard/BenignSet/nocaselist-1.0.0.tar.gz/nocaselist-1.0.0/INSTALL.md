Installation of nocaselist project
=======================================================

To install the latest released version of the
nocaselist project into your active Python environment:

      $ pip install nocaselist

This will also install any prerequisite Python packages.

For more details and alternative ways to install, see
[Installation](https://nocaselist.readthedocs.io/en/stable/intro.html#installation).
