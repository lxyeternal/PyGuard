========================
Firebird UUID Management
========================

Package for work with Firebird OID namespace.

