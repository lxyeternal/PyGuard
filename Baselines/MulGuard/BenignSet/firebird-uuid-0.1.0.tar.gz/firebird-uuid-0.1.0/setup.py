#!/usr/bin/env python
#coding:utf-8

# This file is only a shim to allow editable installs. It's not necessary to build
# and install the package via pip (see pyproject.toml and setup.cfg).

import setuptools

if __name__ == "__main__":
    setuptools.setup()
