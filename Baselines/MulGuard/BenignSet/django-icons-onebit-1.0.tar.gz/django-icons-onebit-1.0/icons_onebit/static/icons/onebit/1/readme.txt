Onebit icons

Ammount of icons:
50

File Types:
.png

More icons at http://www.icojoy.com