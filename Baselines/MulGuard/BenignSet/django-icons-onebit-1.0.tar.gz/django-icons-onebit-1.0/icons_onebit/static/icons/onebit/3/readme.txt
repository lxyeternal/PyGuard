Onebit icons #3

Ammount of icons:
25

File Types:
.png

More icons at http://www.icojoy.com