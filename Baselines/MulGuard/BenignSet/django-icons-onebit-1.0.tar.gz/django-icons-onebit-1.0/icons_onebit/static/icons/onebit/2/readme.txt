Onebit icons #2

Ammount of icons:
30

File Types:
.png

More icons at http://www.icojoy.com