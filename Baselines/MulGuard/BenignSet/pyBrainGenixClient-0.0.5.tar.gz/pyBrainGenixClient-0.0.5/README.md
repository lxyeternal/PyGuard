# About
This directory contains the python implementation as defined in the NES block diagram. Please see the below image for project structure:

![Image](Overview.png)
