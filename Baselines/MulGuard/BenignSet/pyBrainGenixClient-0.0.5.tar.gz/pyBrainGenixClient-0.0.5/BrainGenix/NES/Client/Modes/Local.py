# BrainGenix-NES
# AGPLv3

Local = "Local"