# BrainGenix-NES
# AGPLv3

SomaVoltage = "Some attribute - figure out how to structure this later"