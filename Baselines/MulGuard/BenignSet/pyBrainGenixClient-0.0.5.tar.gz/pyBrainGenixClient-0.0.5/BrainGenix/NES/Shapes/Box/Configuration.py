# BrainGenix-NES
# AGPLv3


class Configuration():

    def __init__(self):
        
        # Create Attributes
        self.Name:str = None
        self.CenterPosition_um:list = None
        self.Dimensions_um:list = None
        self.Rotation_rad:list = None
    
