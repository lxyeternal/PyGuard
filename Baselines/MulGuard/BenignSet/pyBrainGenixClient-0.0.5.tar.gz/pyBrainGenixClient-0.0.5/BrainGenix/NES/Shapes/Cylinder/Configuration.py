# BrainGenix-NES
# AGPLv3


class Configuration():

    def __init__(self):
        
        # Create Attributes
        self.Name:str = None
        self.Point1Radius_um:float = None
        self.Point1Position_um:list = None
        self.Point2Radius_um:float = None
        self.Point2Position_um:list = None
    
