Install the plugin https://github.com/pslacerda/pymol-labimm/blob/master/scripts/pymol_labimm.py.
