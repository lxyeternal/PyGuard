from django.apps import AppConfig


class ThstorageConfig(AppConfig):
    name = 'thStorage'
