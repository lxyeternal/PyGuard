import django_describer.actions
import django_describer.datatypes
import django_describer.permissions
import django_describer.describers
import django_describer.utils
import django_describer.adapters

name = "django_describer"
