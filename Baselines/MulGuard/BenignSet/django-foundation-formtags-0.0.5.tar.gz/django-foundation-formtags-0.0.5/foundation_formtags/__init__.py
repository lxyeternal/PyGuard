# -*- coding: utf-8 -*-

__author__ = 'Christopher Clarke'
__email__ = 'cclarke@chrisdev.com'
__version__ = '0.0.5'
