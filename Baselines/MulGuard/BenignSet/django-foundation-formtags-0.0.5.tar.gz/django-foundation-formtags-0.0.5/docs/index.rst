.. foundationform documentation master file, created by
   sphinx-quickstart on Tue Jul  9 22:26:36 2013.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

Django Foundation Forms
=======================

Django template tags to work with Zurb Foundation forms

.. _getting_started:

.. toctree::
   :maxdepth: 2
   :caption: Getting Started

   installation
   usage 


.. _contributing:

.. toctree::
   :maxdepth: 2
   :caption: Project Info

   project_info/contributing
   project_info/authors
   project_info/history