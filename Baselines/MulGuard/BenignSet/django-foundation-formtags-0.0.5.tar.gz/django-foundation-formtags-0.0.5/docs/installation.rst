============
Installation
============

Create a virtualenv::

    $ virtualenv my-env

At the command line::

    $ pip install django-foundation-formtags