Place here all the scripts you need for your tests and be
sure to add them to the test_collection in order to use them in
your test sessions and in the gitlab-pipeline!
