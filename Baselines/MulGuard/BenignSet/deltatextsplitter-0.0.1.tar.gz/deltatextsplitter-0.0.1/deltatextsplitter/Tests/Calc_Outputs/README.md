This folder is used as a dumping-ground for output-files of your code.
The tests can then compare these generated outputs to references,
which produces automated testing.
