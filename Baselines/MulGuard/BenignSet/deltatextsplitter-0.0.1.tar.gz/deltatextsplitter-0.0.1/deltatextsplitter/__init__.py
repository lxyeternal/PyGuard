# import modules and classes you want to be available for
# installation. Be sure to add them to the relevant child-inits as well
# and be sure to use relative imports as from this directory!
from .Source.deltatextsplitter import deltatextsplitter

