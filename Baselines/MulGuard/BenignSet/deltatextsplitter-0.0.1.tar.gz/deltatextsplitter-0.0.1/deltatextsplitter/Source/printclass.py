"""
Module for the printclass-fucntion, a member function of the deltatextsplitter class.
"""

def printclass_deltatextsplitter(self):
    """
    Member function of the deltatextsplitter-class to
    print an overview of the content of the class.

    # Parameters: None (taken from the class)
    # Return: None (printed in the terminal)
    """

    print(" ==> NOTE: " + str(self.label))

    # Done.
