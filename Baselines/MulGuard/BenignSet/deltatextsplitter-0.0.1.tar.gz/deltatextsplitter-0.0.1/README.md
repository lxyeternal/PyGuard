# DeltaTextsplitter package

This package is meant for evaluating the text structure recognition capabilities of the package
[pdftextsplitter](https://pypi.org/project/pdftextsplitter/)
It is under development.
