from .devdoc import write_doc
