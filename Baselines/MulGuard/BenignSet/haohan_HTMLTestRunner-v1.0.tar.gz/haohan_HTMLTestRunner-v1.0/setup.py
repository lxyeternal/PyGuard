from distutils.core import setup

setup(
    name = 'haohan_HTMLTestRunner',#需要打包的名字
    version = 'v1.0',#版本
    author = 'haohan_tester', # 作者
    py_modules = ['haohan_HTMLTestRunner']#需要打包的模块
)