# bijou

A tool for training pytorch deep learning model which is based on fastai course and compatible with PyG models and data.

## Dependency
- pytorch > 1.2
- tqdm > 4.40
- matplotlib > 3.1