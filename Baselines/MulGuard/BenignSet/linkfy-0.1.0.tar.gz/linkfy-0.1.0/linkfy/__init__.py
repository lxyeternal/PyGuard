""":mod:`linky` --- linky
~~~~~~~~~~~~~~~~~~~~~~~~~

"""
from .sub import linky

__all__ = 'linky',
__version_info__ = 0, 1, 0
__version__ = '.'.join(str(v) for v in __version_info__)
