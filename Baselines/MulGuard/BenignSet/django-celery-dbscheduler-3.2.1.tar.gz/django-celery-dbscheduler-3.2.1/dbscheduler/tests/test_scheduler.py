from __future__ import absolute_import
import unittest


class test_ModelEntry(unittest.TestCase):

    def test_dummy(self):
        pass
