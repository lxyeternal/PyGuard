# `flake8-less-than`

Comparisons read better when they're written using the less-than operator.
Code is usually written in ltr languages, and ascending order is more familiar than descending.
By exclusively using the less-than operator, you save yourself some headache.
The greater than operator was a mistake, such a useful symbol...
