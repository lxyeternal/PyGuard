# this is left here for compatibility with previous versions where the package was called pyroscope_io
from pyroscope import *
