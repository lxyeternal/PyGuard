from general_conf.generalops import GeneralClass

class TestOptionCombinations:
    # Class for testing starting/initializing mysqld with different option combinations

    def test_combination_creation(self):
        pass