## Sizer

A simple Python script for iterating recursively over a directory and returning all of the files sorted by size

### Dependencies

You need Python 3.6+ and to run the following command:

        pip install -r requirements.txt

### Usage

For more information on the usege, simply run the script with -h.
