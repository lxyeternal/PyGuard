"A pluggable django app for media management."

__version__ = '1.1.0'
