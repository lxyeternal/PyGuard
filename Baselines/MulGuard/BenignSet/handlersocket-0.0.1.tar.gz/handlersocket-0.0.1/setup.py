#!/usr/bin/env python

from setuptools import setup
import handlersocket

setup(name='handlersocket',
      version=handlersocket.version,
      packages=['handlersocket'],
      )
