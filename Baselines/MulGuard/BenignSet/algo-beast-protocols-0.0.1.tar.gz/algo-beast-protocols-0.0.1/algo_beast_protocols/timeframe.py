from typing import Protocol


class TimeFrame(Protocol):
  ONE_MINUTE: str
