from typing import Protocol


class Symbol(Protocol):
  name: str
