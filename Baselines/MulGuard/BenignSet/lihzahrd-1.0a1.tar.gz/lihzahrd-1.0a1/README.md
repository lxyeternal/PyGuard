# lihzahrd
A Terraria world parser in Python

## References
- http://seancode.com/terrafirma/world.html
- http://ludwig.schafer.free.fr/
- https://github.com/cokolele/terraria-world-parser/
- https://github.com/TEdit/Terraria-Map-Editor/blob/master/TEditXna/Terraria/World.FileV2.cs
- https://steamcommunity.com/sharedfiles/filedetails/?id=841032800