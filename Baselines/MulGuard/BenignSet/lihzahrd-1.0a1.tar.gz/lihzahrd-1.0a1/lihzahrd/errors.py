class InvalidFooterError(Exception):
    """This exception is raised if the footer contents do not match the expected data."""
