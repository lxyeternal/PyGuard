# utoken  
[![image alt >](http://img.shields.io/pypi/v/greekroom.svg)](https://pypi.python.org/pypi/greekroom/)

_greekroom_ will be a suite of tools to support Biblical natural language processing.

### Installation

```bash
pip install greekroom
```
or
```bash
git clone https://github.com/uhermjakob/greekroom.git
```

