#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
The Greek Room will be a suite of tools supporting Biblical natural language processing.
"""


def main():
    print("Greek Room (work in progress)")


if __name__ == "__main__":
    main()

