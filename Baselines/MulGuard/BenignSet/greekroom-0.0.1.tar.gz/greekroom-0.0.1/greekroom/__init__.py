__version__ = '0.0.1'
__description__ = '''The Greek Room will be a suite of tools supporting Biblical natural language processing.'''
last_mod_date = 'May 31, 2022'
