from setuptools import setup

setup(name='distributionspackage',
      version='0.1',
      description='Gaussian distributions',
      packages=['distributions'],
      zip_safe=False)
