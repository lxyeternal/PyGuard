# Auto-generated file, do not edit.
##
# version.py: Specifies the version of the qsharp-chemistry package.
##
# Copyright (c) Microsoft Corporation. All rights reserved.
# Licensed under the MIT License.
##
__version__ = "0.12.2008.2513"
_user_agent_extra = ""
