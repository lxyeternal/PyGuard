# relatively
:bar_chart: Plotly abundance figure with absolute and relative abundances across a hierarchy
