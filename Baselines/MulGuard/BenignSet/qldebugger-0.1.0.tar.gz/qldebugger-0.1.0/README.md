# Queue Lambda Debugger

Utility to debug AWS lambdas with SQS messages.
