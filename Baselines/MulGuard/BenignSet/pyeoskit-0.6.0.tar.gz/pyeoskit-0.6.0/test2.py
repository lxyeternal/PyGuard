from pyeoskit import wallet
psw = wallet.create('mywallet6')
print(psw)
wallet.import_key('mywallet6', '5JEcwbckBCdmji5j8ZoMHLEUS8TqQiqBG1DRx1X9DN124GUok9s')
wallet.import_key('mywallet6', '5JbDP55GXN7MLcNYKCnJtfKi9aD2HvHAdY7g8m67zFTAFkY1uBB')

