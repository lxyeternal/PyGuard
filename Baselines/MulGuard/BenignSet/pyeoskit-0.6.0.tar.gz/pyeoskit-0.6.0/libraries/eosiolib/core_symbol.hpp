/** @file 
 *    @copyright defined in eos/LICENSE.txt 
 *
 * \warning This file is machine generated. DO NOT EDIT.  See core_symbol.hpp.in for changes.
 */

#define CORE_SYMBOL S(4,EOS)
