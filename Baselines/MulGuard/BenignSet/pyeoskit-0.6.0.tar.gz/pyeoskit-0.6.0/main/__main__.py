
if __name__ == "__main__":
    from . import eosapi
    info = eosapi.get_info()
    print(info)
    

