from distutils.core import setup

setup(
    name = 'rolldice',      
    version = '1.1.0',
    py_modules = ['rolldice'],
    author = 'lioushell',        
    author_email = 'lzq521426@163.com',
    url = 'https://pypi.python.org/pypi',
    description = ' A roll or cast of dice.'   
    )