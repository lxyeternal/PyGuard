class OutputData:
    """
    输出数据的说明
    """
    def __init__(self):
        # 文件名
        self.file_name = None
        # 文件内容
        self.content = ""
