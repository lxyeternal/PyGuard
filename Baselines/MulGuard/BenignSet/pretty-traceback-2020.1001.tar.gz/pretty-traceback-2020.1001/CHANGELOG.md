# Changelog for https://gitlab.com/mbarkhau/pretty-traceback

## 2020.1001

 - Initial release
