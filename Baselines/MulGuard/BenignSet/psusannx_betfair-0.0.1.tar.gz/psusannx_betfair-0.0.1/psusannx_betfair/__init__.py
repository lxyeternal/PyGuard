"""A package containing a class for getting odds for upcoming matches on the betfair exchange"""

from psusannx_betfair.psusannx_betfair import PsusannxBetfair