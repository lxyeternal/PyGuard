from setuptools import setup

setup(name="GeodesicPointGenerator",
      version="0.0",
      packages=["GeodesicPointGenerator"])
