
__version__ = "0.0.0a"

def get_provider_info():
    return {
        "package-name": "airflow-provider-hyperopt",  # Required
        "name": "airflow-provider-hyperopt",  # Required
        "description": "A short description of the package",  # Required
        "versions": [__version__],  # Required
    }
