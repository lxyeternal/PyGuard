# coding: utf-8
from __future__ import unicode_literals

from .shortcuts import dehydrate
from .base import Dehydrator
