# -*- coding: utf-8 -*-
# @author: Algorithm Team @ 杉数科技/Cardinal Operations
# @email: coalgo@shanshu.ai
# @date: 2023/06

import warnings
warnings.filterwarnings("ignore")

__version__ = "0.0.0"

print("杉数科技算法工具包的联络信息：coalgo@shanshu.ai")



