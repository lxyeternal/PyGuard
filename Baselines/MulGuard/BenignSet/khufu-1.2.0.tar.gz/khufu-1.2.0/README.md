# khufu


<amp-iframe width="700" height="1200" layout="responsive" sandbox="allow-scripts allow-same-origin allow-popups" resizable allowfullscreen frameborder="0" src="https://e.infogram.com/c1fb1d06-61e4-4ef7-affe-c1c0fa2d235f?src=embed"><div style="visibility: hidden" overflow tabindex=0 role=button aria-label="Loading..." placeholder>Loading...</div></amp-iframe>
