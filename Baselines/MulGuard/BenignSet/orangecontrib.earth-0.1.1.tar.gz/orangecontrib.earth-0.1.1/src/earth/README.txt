This directrory contains the unmodified C source files from the earth
r package (http://cran.r-project.org/web/packages/earth/index.html).
