Minimal required R library (libR) for running EARTH.

These are basically linpack routines (dqrdc2 is a modified linpack dqrdc)
translated with f2c along with some minimal environment for them to run
(defined in f2c.h and f2c.c).

Retrieved on 2013/07/29 from http://svn.r-project.org/R/trunk/src/appl
