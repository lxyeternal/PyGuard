from setuptools import setup

setup(
    name='hoptim',
    version='0.0.1',
    description='',
    long_description='',
    url='https://www.example.com',
    author='me',
    author_email='me@example.com',
    packages=[],
    classifiers=['Development Status :: 1 - Planning'],
)
