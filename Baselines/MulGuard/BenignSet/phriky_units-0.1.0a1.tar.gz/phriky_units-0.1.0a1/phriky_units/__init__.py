# -*- coding: utf-8 -*-

__author__ = 'John-Paul Ore'
__email__ = 'jore@cse.unl.edu'
__version__ = '0.1.0'
