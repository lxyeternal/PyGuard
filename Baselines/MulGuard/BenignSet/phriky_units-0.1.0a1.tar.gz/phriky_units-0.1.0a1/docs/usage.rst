=====
Usage
=====

To use Phriky Units in a project::

    import phriky_units
