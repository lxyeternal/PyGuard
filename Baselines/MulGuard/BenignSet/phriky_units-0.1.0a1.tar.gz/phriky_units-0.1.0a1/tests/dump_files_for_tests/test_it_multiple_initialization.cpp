#include "geometry_msgs/Accel.h"
#include "geometry_msgs/Twist.h"

int main(int argc, char **argv)
{

geometry_msgs::Accel a;
geometry_msgs::Twist t;

a.linear.x = t.angular.x = 0;

// MULT SAME UNITS

  return 0;
}





