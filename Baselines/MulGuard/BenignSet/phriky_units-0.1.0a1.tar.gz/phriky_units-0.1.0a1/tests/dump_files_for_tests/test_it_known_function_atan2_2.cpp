#include <ros/ros.h>
#include <math.h>

using namespace std;
int main(int argc, char **argv)
{
  
  float f = atan2(10, 10); // f SHOULD GET RADIANS

}
