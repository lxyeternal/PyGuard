#include "geometry_msgs/Twist.h"

int main(int argc, char **argv)
{

geometry_msgs::Twist t;
float f;
float z = 11.;

f = t.angular.x * z;

  return 0;
}





