#include <ros/ros.h>
#include <math.h>

int main(int argc, char **argv)
{
  float x = M_PI;
}
