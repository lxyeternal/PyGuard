#include "sensor_msgs/LaserScan.h"

int main(int argc, char **argv)
{
  sensor_msgs::LaserScan ls;

  int x = ls.ranges.size();
}
