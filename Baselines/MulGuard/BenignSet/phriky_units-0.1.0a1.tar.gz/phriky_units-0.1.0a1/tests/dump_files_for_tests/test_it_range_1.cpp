#include "sensor_msgs/Range.h"
#include "math.h"


int main(int argc, char **argv)
{

  sensor_msgs::Range r;
  float y = 0;
  float x = std::acos(y) + r.field_of_view; // ERROR

}
