#include "../include/test_it_header_include_2.h"

int main(int argc, char **argv)
{
  float x = g(10);
}
