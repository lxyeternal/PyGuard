#include "../include/test_it_header_include_1.h"

int main(int argc, char **argv)
{
  float x = f(10);
}
