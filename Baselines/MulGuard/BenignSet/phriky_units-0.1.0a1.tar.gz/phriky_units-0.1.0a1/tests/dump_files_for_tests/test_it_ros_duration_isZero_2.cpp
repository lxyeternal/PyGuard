#include <ros/ros.h>

int main(int argc, char **argv)
{
  ros::Duration d1(0.1);
  int t = d1.toSec();

}
