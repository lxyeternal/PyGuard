#include <ros/ros.h>
#include <math.h>

int main(int argc, char **argv)
{
  
  float f = std::asin(10); // f SHOULD GET RADIANS

}
