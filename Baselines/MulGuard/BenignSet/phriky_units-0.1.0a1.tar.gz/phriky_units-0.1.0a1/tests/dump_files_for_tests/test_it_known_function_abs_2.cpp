#include <ros/ros.h>
#include <math.h>
#include <sensor_msgs/Range.h>

int main(int argc, char **argv)
{
  sensor_msgs::Range r;


  using std::abs;
  float s = abs(r.range);

}
