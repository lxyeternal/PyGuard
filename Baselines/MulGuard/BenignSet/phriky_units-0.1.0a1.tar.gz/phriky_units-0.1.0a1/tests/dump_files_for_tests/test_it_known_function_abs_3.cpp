#include <ros/ros.h>
#include <math.h>

int main(int argc, char **argv)
{
  
  float s = std::abs(-32.);

}
