#include <ros/ros.h>

int main(int argc, char **argv)
{
  ros::Duration d1(0.1);
  bool b = d1.isZero();

}
