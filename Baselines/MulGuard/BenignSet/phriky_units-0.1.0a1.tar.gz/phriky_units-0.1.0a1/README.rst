===============================
Phriky Units
===============================


.. image:: https://img.shields.io/pypi/v/phriky_units.svg
        :target: https://pypi.python.org/pypi/phriky_units

.. image:: https://img.shields.io/travis/jpwco/phriky_units.svg
        :target: https://travis-ci.org/jpwco/phriky_units

.. image:: https://readthedocs.org/projects/phriky-units/badge/?version=latest
        :target: https://phriky-units.readthedocs.io/en/latest/?badge=latest
        :alt: Documentation Status

.. image:: https://pyup.io/repos/github/jpwco/phriky_units/shield.svg
     :target: https://pyup.io/repos/github/jpwco/phriky_units/
     :alt: Updates


Physical unit static analysis tool for C++, especially for ROS


* Free software: MIT license
* Documentation: https://phriky-units.readthedocs.io.


sudo apt-get install python-setuptools python-dev build-essential
sudo easy_install pip


Features
--------

* TODO

Credits
---------

This package was created with Cookiecutter_ and the `audreyr/cookiecutter-pypackage`_ project template.

.. _Cookiecutter: https://github.com/audreyr/cookiecutter
.. _`audreyr/cookiecutter-pypackage`: https://github.com/audreyr/cookiecutter-pypackage

