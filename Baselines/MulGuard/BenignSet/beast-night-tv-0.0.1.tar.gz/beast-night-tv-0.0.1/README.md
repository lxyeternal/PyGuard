<div align=center>

# JAK-Python-Package

</div>

Go to the [Package](https://pypi.org/project/jak-python-package/)

## Installation
### Windows
`pip install jak_python_package`

### Linux
`python3 pip install jak_python_package`

### MacOS
`pip install jak_python_package`

## Contributors
<a href = "https://github.com/Jonak-Adipta-Kalita/JAK-Python-Package/graphs/contributors">
  <img src = "https://contrib.rocks/image?repo=Jonak-Adipta-Kalita/JAK-Python-Package"/>
</a>
