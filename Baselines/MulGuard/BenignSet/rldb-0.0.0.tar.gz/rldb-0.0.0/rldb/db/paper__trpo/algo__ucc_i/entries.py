
entries = [
    {
        'env-title': 'atari-beam-rider',
        'score': 5702,
    },
    {
        'env-title': 'atari-breakout',
        'score': 380,
    },
    {
        'env-title': 'atari-enduro',
        'score': 741,
    },
    {
        'env-title': 'atari-pong',
        'score': 21,
    },
    {
        'env-title': 'atari-qbert',
        'score': 20025,
    },
    {
        'env-title': 'atari-seaquest',
        'score': 2995,
    },
    {
        'env-title': 'atari-space-invaders',
        'score': 692,
    },
]
