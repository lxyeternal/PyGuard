entries = [
    {
        'env-title': 'atari-beam-rider',
        'score': 859.5,
    },
    {
        'env-title': 'atari-breakout',
        'score': 34.2,
    },
    {
        'env-title': 'atari-enduro',
        'score': 430.8,
    },
    {
        'env-title': 'atari-pong',
        'score': 20.9,
    },
    {
        'env-title': 'atari-qbert',
        'score': 7732.5,
    },
    {
        'env-title': 'atari-seaquest',
        'score': 788.4,
    },
    {
        'env-title': 'atari-space-invaders',
        'score': 450.2,
    },
]
