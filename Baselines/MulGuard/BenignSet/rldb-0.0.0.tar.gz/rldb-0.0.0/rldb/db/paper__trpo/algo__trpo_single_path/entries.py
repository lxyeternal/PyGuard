entries = [
    {
        'env-title': 'atari-beam-rider',
        'score': 1425.2,
    },
    {
        'env-title': 'atari-breakout',
        'score': 10.8,
    },
    {
        'env-title': 'atari-enduro',
        'score': 534.6,
    },
    {
        'env-title': 'atari-pong',
        'score': 20.9,
    },
    {
        'env-title': 'atari-qbert',
        'score': 1973.5,
    },
    {
        'env-title': 'atari-seaquest',
        'score': 1908.6,
    },
    {
        'env-title': 'atari-space-invaders',
        'score': 568.4,
    },
]
