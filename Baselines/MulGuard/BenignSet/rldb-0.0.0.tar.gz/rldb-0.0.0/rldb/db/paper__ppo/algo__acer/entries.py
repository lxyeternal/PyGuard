# TODO Assuming they ran it themselves
entries = [
    {
        'env-title': 'atari-alien',
        'score': 1655.4,
    },
    {
        'env-title': 'atari-amidar',
        'score': 827.6,
    },
    {
        'env-title': 'atari-assault',
        'score': 4653.8,
    },
    {
        'env-title': 'atari-asterix',
        'score': 6801.2,
    },
    {
        'env-title': 'atari-asteroids',
        'score': 2389.3,
    },
    {
        'env-title': 'atari-atlantis',
        'score': 1841376.0,
    },
    {
        'env-title': 'atari-bank-heist',
        'score': 1177.5,
    },
    {
        'env-title': 'atari-battle-zone',
        'score': 8983.3,
    },
    {
        'env-title': 'atari-beam-rider',
        'score': 3863.3,
    },
    {
        'env-title': 'atari-bowling',
        'score': 33.3,
    },
    {
        'env-title': 'atari-boxing',
        'score': 98.9,
    },
    {
        'env-title': 'atari-breakout',
        'score': 456.4,
    },
    {
        'env-title': 'atari-centipede',
        'score': 8904.8,
    },
    {
        'env-title': 'atari-chopper-command',
        'score': 5287.7,
    },
    {
        'env-title': 'atari-crazy-climber',
        'score': 132461.0,
    },
    {
        'env-title': 'atari-demon-attack',
        'score': 38808.3,
    },
    {
        'env-title': 'atari-double-dunk',
        'score': -13.2,
    },
    {
        'env-title': 'atari-enduro',
        'score': 0.0,
    },
    {
        'env-title': 'atari-fishing-derby',
        'score': 34.7,
    },
    {
        'env-title': 'atari-freeway',
        'score': 0.0,
    },
    {
        'env-title': 'atari-frostbite',
        'score': 285.6,
    },
    {
        'env-title': 'atari-gopher',
        'score': 37802.3,
    },
    {
        'env-title': 'atari-gravitar',
        'score': 225.3,
    },
    {
        'env-title': 'atari-ice-hockey',
        'score': -5.9,
    },
    {
        'env-title': 'atari-jamesbond',
        'score': 261.8,
    },
    {
        'env-title': 'atari-kangaroo',
        'score': 50.0,
    },
    {
        'env-title': 'atari-krull',
        'score': 7268.4,
    },
    {
        'env-title': 'atari-kung-fu-master',
        'score': 27599.3,
    },
    {
        'env-title': 'atari-montezuma-revenge',
        'score': 0.3,
    },
    {
        'env-title': 'atari-ms-pacman',
        'score': 2718.5,
    },
    {
        'env-title': 'atari-name-this-game',
        'score': 8488.0,
    },
    {
        'env-title': 'atari-pitfall',
        'score': -16.9,
    },
    {
        'env-title': 'atari-pong',
        'score': 20.7,
    },
    {
        'env-title': 'atari-private-eye',
        'score': 182.0,
    },
    {
        'env-title': 'atari-qbert',
        'score': 15316.6,
    },
    {
        'env-title': 'atari-riverraid',
        'score': 9125.1,
    },
    {
        'env-title': 'atari-road-runner',
        'score': 35466.0,
    },
    {
        'env-title': 'atari-robotank',
        'score': 2.5,
    },
    {
        'env-title': 'atari-seaquest',
        'score': 1739.5,
    },
    {
        'env-title': 'atari-space-invaders',
        'score': 1213.9,
    },
    {
        'env-title': 'atari-star-gunner',
        'score': 49817.7,
    },
    {
        'env-title': 'atari-tennis',
        'score': -17.6,
    },
    {
        'env-title': 'atari-time-pilot',
        'score': 4175.7,
    },
    {
        'env-title': 'atari-tutankham',
        'score': 280.8,
    },
    {
        'env-title': 'atari-up-n-down',
        'score': 145051.4,
    },
    {
        'env-title': 'atari-venture',
        'score': 0.0,
    },
    {
        'env-title': 'atari-video-pinball',
        'score': 156226.6,
    },
    {
        'env-title': 'atari-wizard-of-wor',
        'score': 2308.3,
    },
    {
        'env-title': 'atari-zaxxon',
        'score': 29.0,
    },
]
