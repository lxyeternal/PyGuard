# TODO Assuming they ran it themselves
entries = [
    {
        'env-title': 'atari-alien',
        'score': 1141.7,
    },
    {
        'env-title': 'atari-amidar',
        'score': 380.8,
    },
    {
        'env-title': 'atari-assault',
        'score': 1562.9,
    },
    {
        'env-title': 'atari-asterix',
        'score': 3176.3,
    },
    {
        'env-title': 'atari-asteroids',
        'score': 1653.3,
    },
    {
        'env-title': 'atari-atlantis',
        'score': 729265.3,
    },
    {
        'env-title': 'atari-bank-heist',
        'score': 1095.3,
    },
    {
        'env-title': 'atari-battle-zone',
        'score': 3080.0,
    },
    {
        'env-title': 'atari-beam-rider',
        'score': 3031.7,
    },
    {
        'env-title': 'atari-bowling',
        'score': 30.1,
    },
    {
        'env-title': 'atari-boxing',
        'score': 17.7,
    },
    {
        'env-title': 'atari-breakout',
        'score': 303.0,
    },
    {
        'env-title': 'atari-centipede',
        'score': 3496.5,
    },
    {
        'env-title': 'atari-chopper-command',
        'score': 1171.7,
    },
    {
        'env-title': 'atari-crazy-climber',
        'score': 107770.0,
    },
    {
        'env-title': 'atari-demon-attack',
        'score': 6639.1,
    },
    {
        'env-title': 'atari-double-dunk',
        'score': -16.2,
    },
    {
        'env-title': 'atari-enduro',
        'score': 0.0,
    },
    {
        'env-title': 'atari-fishing-derby',
        'score': 20.6,
    },
    {
        'env-title': 'atari-freeway',
        'score': 0.0,
    },
    {
        'env-title': 'atari-frostbite',
        'score': 261.8,
    },
    {
        'env-title': 'atari-gopher',
        'score': 1500.9,
    },
    {
        'env-title': 'atari-gravitar',
        'score': 194.0,
    },
    {
        'env-title': 'atari-ice-hockey',
        'score': -6.4,
    },
    {
        'env-title': 'atari-jamesbond',
        'score': 52.3,
    },
    {
        'env-title': 'atari-kangaroo',
        'score': 45.3,
    },
    {
        'env-title': 'atari-krull',
        'score': 8367.4,
    },
    {
        'env-title': 'atari-kung-fu-master',
        'score': 24900.3,
    },
    {
        'env-title': 'atari-montezuma-revenge',
        'score': 0.0,
    },
    {
        'env-title': 'atari-ms-pacman',
        'score': 1626.9,
    },
    {
        'env-title': 'atari-name-this-game',
        'score': 5961.2,
    },
    {
        'env-title': 'atari-pitfall',
        'score': -55.0,
    },
    {
        'env-title': 'atari-pong',
        'score': 19.7,
    },
    {
        'env-title': 'atari-private-eye',
        'score': 91.3,
    },
    {
        'env-title': 'atari-qbert',
        'score': 10065.7,
    },
    {
        'env-title': 'atari-riverraid',
        'score': 7653.5,
    },
    {
        'env-title': 'atari-road-runner',
        'score': 32810.0,
    },
    {
        'env-title': 'atari-robotank',
        'score': 2.2,
    },
    {
        'env-title': 'atari-seaquest',
        'score': 1714.3,
    },
    {
        'env-title': 'atari-space-invaders',
        'score': 744.5,
    },
    {
        'env-title': 'atari-star-gunner',
        'score': 26204.0,
    },
    {
        'env-title': 'atari-tennis',
        'score': -22.2,
    },
    {
        'env-title': 'atari-time-pilot',
        'score': 2898.0,
    },
    {
        'env-title': 'atari-tutankham',
        'score': 206.8,
    },
    {
        'env-title': 'atari-up-n-down',
        'score': 17369.8,
    },
    {
        'env-title': 'atari-venture',
        'score': 0.0,
    },
    {
        'env-title': 'atari-video-pinball',
        'score': 19735.9,
    },
    {
        'env-title': 'atari-wizard-of-wor',
        'score': 859.0,
    },
    {
        'env-title': 'atari-zaxxon',
        'score': 16.3,
    },
]
