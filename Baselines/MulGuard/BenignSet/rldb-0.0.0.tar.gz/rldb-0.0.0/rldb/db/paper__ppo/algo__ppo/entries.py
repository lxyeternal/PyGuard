entries = [
    {
        'env-title': 'atari-alien',
        'score': 1850.3,
    },
    {
        'env-title': 'atari-amidar',
        'score': 674.6,
    },
    {
        'env-title': 'atari-assault',
        'score': 4971.9,
    },
    {
        'env-title': 'atari-asterix',
        'score': 4532.5,
    },
    {
        'env-title': 'atari-asteroids',
        'score': 2097.5,
    },
    {
        'env-title': 'atari-atlantis',
        'score': 2311815.0,
    },
    {
        'env-title': 'atari-bank-heist',
        'score': 1280.6,
    },
    {
        'env-title': 'atari-battle-zone',
        'score': 17366.7,
    },
    {
        'env-title': 'atari-beam-rider',
        'score': 1590.0,
    },
    {
        'env-title': 'atari-bowling',
        'score': 40.1,
    },
    {
        'env-title': 'atari-boxing',
        'score': 94.6,
    },
    {
        'env-title': 'atari-breakout',
        'score': 274.8,
    },
    {
        'env-title': 'atari-centipede',
        'score': 4386.4,
    },
    {
        'env-title': 'atari-chopper-command',
        'score': 3516.3,
    },
    {
        'env-title': 'atari-crazy-climber',
        'score': 110202.0,
    },
    {
        'env-title': 'atari-demon-attack',
        'score': 11378.4,
    },
    {
        'env-title': 'atari-double-dunk',
        'score': -14.9,
    },
    {
        'env-title': 'atari-enduro',
        'score': 758.3,
    },
    {
        'env-title': 'atari-fishing-derby',
        'score': 17.8,
    },
    {
        'env-title': 'atari-freeway',
        'score': 32.5,
    },
    {
        'env-title': 'atari-frostbite',
        'score': 314.2,
    },
    {
        'env-title': 'atari-gopher',
        'score': 2932.9,
    },
    {
        'env-title': 'atari-gravitar',
        'score': 737.2,
    },
    {
        'env-title': 'atari-ice-hockey',
        'score': -4.2,
    },
    {
        'env-title': 'atari-jamesbond',
        'score': 560.7,
    },
    {
        'env-title': 'atari-kangaroo',
        'score': 9928.7,
    },
    {
        'env-title': 'atari-krull',
        'score': 7942.3,
    },
    {
        'env-title': 'atari-kung-fu-master',
        'score': 23310.3,
    },
    {
        'env-title': 'atari-montezuma-revenge',
        'score': 42.0,
    },
    {
        'env-title': 'atari-ms-pacman',
        'score': 2096.5,
    },
    {
        'env-title': 'atari-name-this-game',
        'score': 6254.9,
    },
    {
        'env-title': 'atari-pitfall',
        'score': -32.9,
    },
    {
        'env-title': 'atari-pong',
        'score': 20.7,
    },
    {
        'env-title': 'atari-private-eye',
        'score': 69.5,
    },
    {
        'env-title': 'atari-qbert',
        'score': 14293.3,
    },
    {
        'env-title': 'atari-riverraid',
        'score': 8393.6,
    },
    {
        'env-title': 'atari-road-runner',
        'score': 25076.0,
    },
    {
        'env-title': 'atari-robotank',
        'score': 5.5,
    },
    {
        'env-title': 'atari-seaquest',
        'score': 1204.5,
    },
    {
        'env-title': 'atari-space-invaders',
        'score': 942.5,
    },
    {
        'env-title': 'atari-star-gunner',
        'score': 32689.0,
    },
    {
        'env-title': 'atari-tennis',
        'score': -14.8,
    },
    {
        'env-title': 'atari-time-pilot',
        'score': 4342.0,
    },
    {
        'env-title': 'atari-tutankham',
        'score': 254.4,
    },
    {
        'env-title': 'atari-up-n-down',
        'score': 95445.0,
    },
    {
        'env-title': 'atari-venture',
        'score': 0.0,
    },
    {
        'env-title': 'atari-video-pinball',
        'score': 37389.0,
    },
    {
        'env-title': 'atari-wizard-of-wor',
        'score': 4185.3,
    },
    {
        'env-title': 'atari-zaxxon',
        'score': 5008.7,
    },
]
