entries = [
    {
        'env-title': 'atari-berzerk',
        'env-variant': 'Human start',
        'score': 196.10,
    },
    {
        'env-title': 'atari-defender',
        'env-variant': 'Human start',
        'score': 1965.50,
    },
    {
        'env-title': 'atari-phoenix',
        'env-variant': 'Human start',
        'score': 1134.40,
    },
    {
        'env-title': 'atari-pitfall',
        'env-variant': 'Human start',
        'score': -348.80,
    },
    {
        'env-title': 'atari-skiing',
        'env-variant': 'Human start',
        'score': -15287.40,
    },
    {
        'env-title': 'atari-solaris',
        'env-variant': 'Human start',
        'score': 2047.20,
    },
    {
        'env-title': 'atari-surround',
        'env-variant': 'Human start',
        'score': -9.70,
    },
    {
        'env-title': 'atari-yars-revenge',
        'env-variant': 'Human start',
        'score': 1476.90,
    },
]
