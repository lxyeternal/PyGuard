entries = [
    {
        'env-title': 'atari-berzerk',
        'env-variant': 'Human start',
        'score': 2237.50,
    },
    {
        'env-title': 'atari-defender',
        'env-variant': 'Human start',
        'score': 14296.00,
    },
    {
        'env-title': 'atari-phoenix',
        'env-variant': 'Human start',
        'score': 6686.20,
    },
    {
        'env-title': 'atari-pitfall',
        'env-variant': 'Human start',
        'score': 5998.90,
    },
    {
        'env-title': 'atari-skiing',
        'env-variant': 'Human start',
        'score': -3686.60,
    },
    {
        'env-title': 'atari-solaris',
        'env-variant': 'Human start',
        'score': 11032.60,
    },
    {
        'env-title': 'atari-surround',
        'env-variant': 'Human start',
        'score': 5.40,
    },
    {
        'env-title': 'atari-yars-revenge',
        'env-variant': 'Human start',
        'score': 47135.20,
    },
]
