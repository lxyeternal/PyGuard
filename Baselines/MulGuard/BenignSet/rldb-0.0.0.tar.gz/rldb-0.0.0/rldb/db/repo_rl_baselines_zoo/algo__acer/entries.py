entries = [
    {
        'env-title': 'classic-acrobot',
        'score': -90.850,
        'stddev': 32.797,
    },
    {
        'env-title': 'atari-beam-rider',
        'score': 2440.692,
        'stddev': 1357.964,
    },
    {
        'env-title': 'classic-cartpole',
        'score': 498.620,
        'stddev': 23.862,
    },
    {
        'env-title': 'atari-enduro',
        'score': 0.000,
        'stddev': 0.000,
    },
    {
        'env-title': 'box2d-lunarlander',
        'score': 185.210,
        'stddev': 64.829,
    },
    {
        'env-title': 'classic-mountain-car',
        'score': -131.213,
        'stddev': 32.541,
    },
    {
        'env-title': 'atari-ms-pacman',
        'score': 3908.105,
        'stddev': 585.407,
    },
    {
        'env-title': 'atari-pong',
        'score': 20.667,
        'stddev': 0.507,
    },
    {
        'env-title': 'atari-qbert',
        'score': 18880.469,
        'stddev': 1648.937,
    },
    {
        'env-title': 'atari-seaquest',
        'score': 872.121,
        'stddev': 25.555,
    },
    {
        'env-title': 'atari-space-invaders',
        'score': 542.556,
        'stddev': 172.332,
    },
]
