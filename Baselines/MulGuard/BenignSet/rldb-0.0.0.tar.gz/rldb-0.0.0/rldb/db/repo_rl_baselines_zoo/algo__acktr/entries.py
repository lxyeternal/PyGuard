entries = [
    {
        'env-title': 'classic-acrobot',
        'score': -91.284,
        'stddev': 32.515,
    },
    {
        'env-title': 'atari-beam-rider',
        'score': 3760.976,
        'stddev': 1826.059,
    },
    {
        'env-title': 'atari-breakout',
        'score': 448.514,
        'stddev': 88.882,
    },
    {
        'env-title': 'classic-cartpole',
        'score': 487.573,
        'stddev': 63.866,
    },
    {
        'env-title': 'atari-enduro',
        'score': 0.000,
        'stddev': 0.000,
    },
    {
        'env-title': 'box2d-lunarlander',
        'score': 96.822,
        'stddev': 64.020,
    },
    {
        'env-title': 'classic-mountain-car',
        'score': -111.917,
        'stddev': 21.422,
    },
    {
        'env-title': 'atari-ms-pacman',
        'score': 1598.776,
        'stddev': 264.338,
    },
    {
        'env-title': 'atari-pong',
        'score': 19.224,
        'stddev': 3.697,
    },
    {
        'env-title': 'atari-qbert',
        'score': 9569.575,
        'stddev': 3980.468,
    },
    {
        'env-title': 'atari-seaquest',
        'score': 1672.239,
        'stddev': 105.092,
    },
    {
        'env-title': 'atari-space-invaders',
        'score': 738.045,
        'stddev': 306.756,
    },
]
