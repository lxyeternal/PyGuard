entries = [
    {
        'env-title': 'classic-pendulum',
        'score': 244.566,
        'stddev': 75.617,
    },
    {
        'env-title': 'box2d-lunarlander-continuous',
        'score': 91.858,
        'stddev': 1.350,
    },
    {
        'env-title': 'classic-mountain-car-continuous',
        'score': -169.829,
        'stddev': 93.303,
    },
]
