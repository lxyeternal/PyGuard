entries = [
    {
        'env-title': 'bullet-ant',
        'score': 2354.785,
        'stddev': 42.501,
    },
    {
        'env-title': 'box2d-bipedal-walker',
        'score': 307.198,
        'stddev': 1.055,
    },
    {
        'env-title': 'box2d-bipedal-walker-hardcore',
        'score': 100.802,
        'stddev': 117.769,
    },
    {
        'env-title': 'bullet-half-cheetah',
        'score': 2021.599,
        'stddev': 261.582,
    },
    {
        'env-title': 'bullet-hopper',
        'score': 2438.152,
        'stddev': 335.284,
    },
    {
        'env-title': 'bullet-humanoid',
        'score': 2048.187,
        'stddev': 829.776,
    },
    {
        'env-title': 'bullet-inverted-double-pendulum',
        'score': 9357.406,
        'stddev': 0.504,
    },
    {
        'env-title': 'bullet-inverted-pendulum-swingup',
        'score': 891.508,
        'stddev': 0.963,
    },
    {
        'env-title': 'box2d-lunarlander-continuous',
        'score': 269.783,
        'stddev': 57.077,
    },
    {
        'env-title': 'classic-pendulum',
        'score': -159.669,
        'stddev': 86.665,
    },
    {
        'env-title': 'bullet-reacher',
        'score': 17.529,
        'stddev': 9.860,
    },
    {
        'env-title': 'bullet-walker2d',
        'score': 2052.646,
        'stddev': 13.631,
    },
]
