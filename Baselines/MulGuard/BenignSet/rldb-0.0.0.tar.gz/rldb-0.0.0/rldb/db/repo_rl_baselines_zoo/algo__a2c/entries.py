entries = [
    {
        'env-title': 'classic-acrobot',
        'score': -86.616,
        'stddev': 25.097,
    },
    {
        'env-title': 'atari-beam-rider',
        'score': 2809.115,
        'stddev': 1298.573,
    },
    {
        'env-title': 'atari-breakout',
        'score': 384.865,
        'stddev': 51.231,
    },
    {
        'env-title': 'classic-cartpole',
        'score': 499.903,
        'stddev': 1.672,
    },
    {
        'env-title': 'atari-enduro',
        'score': 0.000,
        'stddev': 0.000,
    },
    {
        'env-title': 'box2d-lunarlander',
        'score': 36.321,
        'stddev': 135.294,
    },
    {
        'env-title': 'classic-mountain-car',
        'score': -130.921,
        'stddev': 32.188,
    },
    {
        'env-title': 'atari-ms-pacman',
        'score': 1581.111,
        'stddev': 499.757,
    },
    {
        'env-title': 'atari-pong',
        'score': 18.973,
        'stddev': 2.135,
    },
    {
        'env-title': 'atari-qbert',
        'score': 5742.333,
        'stddev': 2033.074,
    },
    {
        'env-title': 'atari-seaquest',
        'score': 746.420,
        'stddev': 111.370,
    },
    {
        'env-title': 'atari-space-invaders',
        'score': 658.907,
        'stddev': 197.833,
    },
]
