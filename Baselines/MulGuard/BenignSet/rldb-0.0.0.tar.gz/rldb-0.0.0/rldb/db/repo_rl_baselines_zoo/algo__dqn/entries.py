entries = [
    {
        'env-title': 'classic-acrobot',
        'score': -88.103,
        'stddev': 33.037,
    },
    {
        'env-title': 'atari-beam-rider',
        'score': 888.741,
        'stddev': 248.487,
    },
    {
        'env-title': 'atari-breakout',
        'score': 191.165,
        'stddev': 97.795,
    },
    {
        'env-title': 'classic-cartpole',
        'score': 500.000,
        'stddev': 0.000,
    },
    {
        'env-title': 'atari-enduro',
        'score': 699.800,
        'stddev': 214.231,
    },
    {
        'env-title': 'box2d-lunarlander',
        'score': 269.048,
        'stddev': 41.056,
    },
    {
        'env-title': 'classic-mountain-car',
        'score': -134.507,
        'stddev': 24.748,
    },
    {
        'env-title': 'atari-ms-pacman',
        'score': 1781.818,
        'stddev': 605.289,
    },
    {
        'env-title': 'atari-pong',
        'score': 21.000,
        'stddev': 0.000,
    },
    {
        'env-title': 'atari-qbert',
        'score': 644.345,
        'stddev': 66.854,
    },
    {
        'env-title': 'atari-seaquest',
        'score': 1948.571,
        'stddev': 234.328,
    },
    {
        'env-title': 'atari-space-invaders',
        'score': 636.618,
        'stddev': 146.066,
    },
]
