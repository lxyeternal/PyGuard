entries = [
    {
        'env-title': 'classic-acrobot',
        'score': -85.137,
        'stddev': 26.272,
    },
    {
        'env-title': 'bullet-ant',
        'score': 2170.104,
        'stddev': 250.575,
    },
    {
        'env-title': 'atari-beam-rider',
        'score': 1691.072,
        'stddev': 904.484,
    },
    {
        'env-title': 'box2d-bipedal-walker',
        'score': 265.939,
        'stddev': 80.994,
    },
    {
        'env-title': 'box2d-bipedal-walker-hardcore',
        'score': 166.481,
        'stddev': 119.300,
    },
    {
        'env-title': 'atari-breakout',
        'score': 228.594,
        'stddev': 141.964,
    },
    {
        'env-title': 'classic-cartpole',
        'score': 500.000,
        'stddev': 0.000,
    },
    {
        'env-title': 'atari-enduro',
        'score': 643.824,
        'stddev': 205.988,
    },
    {
        'env-title': 'bullet-half-cheetah',
        'score': 2037.586,
        'stddev': 59.480,
    },
    {
        'env-title': 'bullet-hopper',
        'score': 1944.588,
        'stddev': 612.994,
    },
    {
        'env-title': 'bullet-humanoid',
        'score': 1285.814,
        'stddev': 918.715,
    },
    {
        'env-title': 'bullet-inverted-double-pendulum',
        'score': 7702.750,
        'stddev': 2888.815,
    },
    {
        'env-title': 'bullet-inverted-pendulum-swingup',
        'score': 866.989,
        'stddev': 27.134,
    },
    {
        'env-title': 'box2d-lunarlander',
        'score': 99.676,
        'stddev': 62.033,
    },
    {
        'env-title': 'box2d-lunarlander-continuous',
        'score': 128.124,
        'stddev': 44.384,
    },
    {
        'env-title': 'bullet-minitaur-duck',
        'score': 5.780,
        'stddev': 3.372,
    },
    {
        'env-title': 'bullet-minitaur',
        'score': 11.334,
        'stddev': 3.562,
    },
    {
        'env-title': 'classic-mountain-car',
        'score': -143.501,
        'stddev': 22.928,
    },
    {
        'env-title': 'classic-mountain-car-continuous',
        'score': 91.705,
        'stddev': 1.706,
    },
    {
        'env-title': 'atari-ms-pacman',
        'score': 2255.090,
        'stddev': 706.412,
    },
    {
        'env-title': 'classic-pendulum',
        'score': -168.285,
        'stddev': 107.164,
    },
    {
        'env-title': 'atari-pong',
        'score': 20.507,
        'stddev': 0.694,
    },
    {
        'env-title': 'atari-qbert',
        'score': 14510.000,
        'stddev': 2847.445,
    },
    {
        'env-title': 'bullet-reacher',
        'score': 17.879,
        'stddev': 9.780,
    },
    {
        'env-title': 'atari-seaquest',
        'score': 1782.687,
        'stddev': 80.883,
    },
    {
        'env-title': 'atari-space-invaders',
        'score': 689.631,
        'stddev': 202.143,
    },
    {
        'env-title': 'bullet-walker2d',
        'score': 1276.848,
        'stddev': 504.586,
    },
]
