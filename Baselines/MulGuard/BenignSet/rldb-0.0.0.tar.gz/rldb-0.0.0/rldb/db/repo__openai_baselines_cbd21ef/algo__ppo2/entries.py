entries = [
    {
        'env-title': 'atari-enduro',
        'score': 350.22,
    },
    {
        'env-title': 'atari-space-invaders',
        'score': 557.28,
    },
    {
        'env-title': 'atari-qbert',
        'score': 7012.06,
    },
    {
        'env-title': 'atari-seaquest',
        'score': 1218.87,
    },
    {
        'env-title': 'atari-pong',
        'score': 13.68,
    },
    {
        'env-title': 'atari-beam-rider',
        'score': 1299.25,
    },
    {
        'env-title': 'atari-breakout',
        'score': 114.26,
    },
]
