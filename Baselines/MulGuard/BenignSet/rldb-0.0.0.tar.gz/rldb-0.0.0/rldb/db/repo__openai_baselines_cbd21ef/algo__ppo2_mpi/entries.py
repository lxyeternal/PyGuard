entries = [
    {
        'env-title': 'atari-enduro',
        'score': 207.47,
    },
    {
        'env-title': 'atari-space-invaders',
        'score': 459.89,
    },
    {
        'env-title': 'atari-qbert',
        'score': 7184.73,
    },
    {
        'env-title': 'atari-seaquest',
        'score': 1383.38,
    },
    {
        'env-title': 'atari-pong',
        'score': 13.9,
    },
    {
        'env-title': 'atari-beam-rider',
        'score': 594.45,
    },
    {
        'env-title': 'atari-breakout',
        'score': 81.61,
    },
]
