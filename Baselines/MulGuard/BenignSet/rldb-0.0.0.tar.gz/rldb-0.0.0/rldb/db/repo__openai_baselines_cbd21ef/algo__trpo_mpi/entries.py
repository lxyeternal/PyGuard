entries = [
    {
        'env-title': 'atari-enduro',
        'score': 24.83,
    },
    {
        'env-title': 'atari-space-invaders',
        'score': 457.7,
    },
    {
        'env-title': 'atari-qbert',
        'score': 2486.18,
    },
    {
        'env-title': 'atari-seaquest',
        'score': 710.07,
    },
    {
        'env-title': 'atari-pong',
        'score': 2.82,
    },
    {
        'env-title': 'atari-beam-rider',
        'score': 683.11,
    },
    {
        'env-title': 'atari-breakout',
        'score': 14.98,
    },
]
