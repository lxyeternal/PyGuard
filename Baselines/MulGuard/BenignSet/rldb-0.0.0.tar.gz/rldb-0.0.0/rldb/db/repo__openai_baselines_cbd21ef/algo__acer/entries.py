entries = [
    {
        'env-title': 'atari-enduro',
        'score': 0.0,
    },
    {
        'env-title': 'atari-space-invaders',
        'score': 656.91,
    },
    {
        'env-title': 'atari-qbert',
        'score': 6433.38,
    },
    {
        'env-title': 'atari-seaquest',
        'score': 1065.98,
    },
    {
        'env-title': 'atari-pong',
        'score': 3.11,
    },
    {
        'env-title': 'atari-beam-rider',
        'score': 1959.22,
    },
    {
        'env-title': 'atari-breakout',
        'score': 82.94,
    },
]
