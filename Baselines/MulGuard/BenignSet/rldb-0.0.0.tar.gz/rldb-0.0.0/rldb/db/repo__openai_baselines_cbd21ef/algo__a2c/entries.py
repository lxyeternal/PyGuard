entries = [
    {
        'env-title': 'atari-enduro',
        'score': 0.0,
    },
    {
        'env-title': 'atari-space-invaders',
        'score': 463.06,
    },
    {
        'env-title': 'atari-qbert',
        'score': 2047.07,
    },
    {
        'env-title': 'atari-seaquest',
        'score': 1150.66,
    },
    {
        'env-title': 'atari-pong',
        'score': 1.0,
    },
    {
        'env-title': 'atari-beam-rider',
        'score': 1302.61,
    },
    {
        'env-title': 'atari-breakout',
        'score': 59.72,
    },
]
