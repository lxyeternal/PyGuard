entries = [
    {
        'env-title': 'atari-enduro',
        'score': 0.0,
    },
    {
        'env-title': 'atari-space-invaders',
        'score': 557.19,
    },
    {
        'env-title': 'atari-qbert',
        'score': 4429.3,
    },
    {
        'env-title': 'atari-seaquest',
        'score': 1201.16,
    },
    {
        'env-title': 'atari-pong',
        'score': 9.56,
    },
    {
        'env-title': 'atari-beam-rider',
        'score': 2171.19,
    },
    {
        'env-title': 'atari-breakout',
        'score': 113.58,
    },
]
