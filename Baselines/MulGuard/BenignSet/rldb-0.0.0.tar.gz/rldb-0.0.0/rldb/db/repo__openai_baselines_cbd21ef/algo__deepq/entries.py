entries = [
    {
        'env-title': 'atari-enduro',
        'score': 479.75,
    },
    {
        'env-title': 'atari-space-invaders',
        'score': 459.86,
    },
    {
        'env-title': 'atari-qbert',
        'score': 3254.83,
    },
    {
        'env-title': 'atari-seaquest',
        'score': 1164.08,
    },
    {
        'env-title': 'atari-pong',
        'score': 16.49,
    },
    {
        'env-title': 'atari-beam-rider',
        'score': 1582.34,
    },
    {
        'env-title': 'atari-breakout',
        'score': 131.46,
    },
]
