entries = [
    {
        'env-title': 'atari-beam-rider',
        'score': 354,
    },
    {
        'env-title': 'atari-breakout',
        'score': 1.2,
    },
    {
        'env-title': 'atari-enduro',
        'score': 0,
    },
    {
        'env-title': 'atari-pong',
        'score': -20.4,
    },
    {
        'env-title': 'atari-qbert',
        'score': 157,
    },
    {
        'env-title': 'atari-seaquest',
        'score': 110,
    },
    {
        'env-title': 'atari-space-invaders',
        'score': 179,
    },
]
