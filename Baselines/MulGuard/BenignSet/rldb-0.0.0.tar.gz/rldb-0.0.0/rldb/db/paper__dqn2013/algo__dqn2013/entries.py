entries = [
    {
        'env-title': 'atari-beam-rider',
        'score': 4092,
    },
    {
        'env-title': 'atari-breakout',
        'score': 168,
    },
    {
        'env-title': 'atari-enduro',
        'score': 470,
    },
    {
        'env-title': 'atari-pong',
        'score': 20,
    },
    {
        'env-title': 'atari-qbert',
        'score': 1952,
    },
    {
        'env-title': 'atari-seaquest',
        'score': 1705,
    },
    {
        'env-title': 'atari-space-invaders',
        'score': 581,
    },
]
