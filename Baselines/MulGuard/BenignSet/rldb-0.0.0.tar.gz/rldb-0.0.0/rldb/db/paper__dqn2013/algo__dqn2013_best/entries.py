entries = [
    {
        'env-title': 'atari-beam-rider',
        'score': 5184,
    },
    {
        'env-title': 'atari-breakout',
        'score': 225,
    },
    {
        'env-title': 'atari-enduro',
        'score': 661,
    },
    {
        'env-title': 'atari-pong',
        'score': 21,
    },
    {
        'env-title': 'atari-qbert',
        'score': 4500,
    },
    {
        'env-title': 'atari-seaquest',
        'score': 1740,
    },
    {
        'env-title': 'atari-space-invaders',
        'score': 1075,
    },
]
