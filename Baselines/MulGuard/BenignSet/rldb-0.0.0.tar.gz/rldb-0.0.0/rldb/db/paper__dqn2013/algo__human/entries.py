entries = [
    {
        'env-title': 'atari-beam-rider',
        'score': 7456,
    },
    {
        'env-title': 'atari-breakout',
        'score': 31,
    },
    {
        'env-title': 'atari-enduro',
        'score': 368,
    },
    {
        'env-title': 'atari-pong',
        'score': -3,
    },
    {
        'env-title': 'atari-qbert',
        'score': 18900,
    },
    {
        'env-title': 'atari-seaquest',
        'score': 28010,
    },
    {
        'env-title': 'atari-space-invaders',
        'score': 3690,
    },
]
