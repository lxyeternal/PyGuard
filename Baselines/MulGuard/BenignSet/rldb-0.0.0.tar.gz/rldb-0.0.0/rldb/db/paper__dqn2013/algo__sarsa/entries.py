entries = [
    {
        'env-title': 'atari-beam-rider',
        'score': 996,
    },
    {
        'env-title': 'atari-breakout',
        'score': 5.2,
    },
    {
        'env-title': 'atari-enduro',
        'score': 129,
    },
    {
        'env-title': 'atari-pong',
        'score': -19,
    },
    {
        'env-title': 'atari-qbert',
        'score': 614,
    },
    {
        'env-title': 'atari-seaquest',
        'score': 665,
    },
    {
        'env-title': 'atari-space-invaders',
        'score': 271,
    },
]
