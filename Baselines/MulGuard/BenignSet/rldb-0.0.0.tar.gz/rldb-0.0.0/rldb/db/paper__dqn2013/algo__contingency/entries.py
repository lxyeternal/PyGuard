entries = [
    {
        'env-title': 'atari-beam-rider',
        'score': 1743,
    },
    {
        'env-title': 'atari-breakout',
        'score': 6,
    },
    {
        'env-title': 'atari-enduro',
        'score': 159,
    },
    {
        'env-title': 'atari-pong',
        'score': -17,
    },
    {
        'env-title': 'atari-qbert',
        'score': 960,
    },
    {
        'env-title': 'atari-seaquest',
        'score': 723,
    },
    {
        'env-title': 'atari-space-invaders',
        'score': 268,
    },
]
