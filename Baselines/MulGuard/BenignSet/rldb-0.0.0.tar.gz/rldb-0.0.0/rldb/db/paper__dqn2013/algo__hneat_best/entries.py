entries = [
    {
        'env-title': 'atari-beam-rider',
        'score': 3616,
    },
    {
        'env-title': 'atari-breakout',
        'score': 52,
    },
    {
        'env-title': 'atari-enduro',
        'score': 106,
    },
    {
        'env-title': 'atari-pong',
        'score': 19,
    },
    {
        'env-title': 'atari-qbert',
        'score': 1800,
    },
    {
        'env-title': 'atari-seaquest',
        'score': 920,
    },
    {
        'env-title': 'atari-space-invaders',
        'score': 1720,
    },
]
