entries = [
    {
        'env-title': 'mujoco-half-cheetah',
        'score': 7057.1,
    },
    {
        'env-title': 'mujoco-swimmer',
        'score': 297.0,
    },
    {
        'env-title': 'mujoco-hopper',
        'score': 3804.9,
    },
    {
        'env-title': 'mujoco-walker2d',
        'score': 5027.2,
    },
    {
        'env-title': 'mujoco-ant',
        'score': 6104.2,
    },
]
