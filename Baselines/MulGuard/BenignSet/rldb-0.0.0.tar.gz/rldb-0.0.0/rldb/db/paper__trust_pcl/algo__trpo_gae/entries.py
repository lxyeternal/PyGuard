entries = [
    {
        'env-title': 'mujoco-half-cheetah',
        'score': 4871.36,
    },
    {
        'env-title': 'mujoco-swimmer',
        'score': 137.25,
    },
    {
        'env-title': 'mujoco-hopper',
        'score': 3765.78,
    },
    {
        'env-title': 'mujoco-walker2d',
        'score': 6028.73,
    },
    {
        'env-title': 'mujoco-ant',
        'score': 2918.25,
    },
]
