entries = [
    {
        'env-title': 'mujoco-half-cheetah',
        'score': 4343.6,
    },
    {
        'env-title': 'mujoco-swimmer',
        'score': 288.1,
    },
    {
        'env-title': 'mujoco-hopper',
        'score': 3516.7,
    },
    {
        'env-title': 'mujoco-walker2d',
        'score': 2838.4,
    },
    {
        'env-title': 'mujoco-ant',
        'score': 4347.5,
    },
]
