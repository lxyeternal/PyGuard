entries = [
    {
        'env-title': 'atari-berzerk',
        'env-variant': 'No-op start',
        'score': 123.7,
    },
    {
        'env-title': 'atari-defender',
        'env-variant': 'No-op start',
        'score': 2874.5,
    },
    {
        'env-title': 'atari-phoenix',
        'env-variant': 'No-op start',
        'score': 761.4,
    },
    {
        'env-title': 'atari-pitfall',
        'env-variant': 'No-op start',
        'score': -229.4,
    },
    {
        'env-title': 'atari-skiing',
        'env-variant': 'No-op start',
        'score': -17098.1,
    },
    {
        'env-title': 'atari-solaris',
        'env-variant': 'No-op start',
        'score': 1236.3,
    },
    {
        'env-title': 'atari-surround',
        'env-variant': 'No-op start',
        'score': -10.0,
    },
    {
        'env-title': 'atari-yars-revenge',
        'env-variant': 'No-op start',
        'score': 3092.9,
    },
]
