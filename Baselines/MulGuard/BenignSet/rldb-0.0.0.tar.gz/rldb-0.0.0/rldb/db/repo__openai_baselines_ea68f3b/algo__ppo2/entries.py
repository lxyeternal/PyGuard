entries = [
    {
        'env-title': 'mujoco-half-cheetah',
        'score': 1668.58,
    },
    {
        'env-title': 'mujoco-hopper',
        'score': 2316.16,
    },
    {
        'env-title': 'mujoco-inverted-pendulum',
        'score': 809.43,
    },
    {
        'env-title': 'mujoco-swimmer',
        'score': 111.19,
    },
    {
        'env-title': 'mujoco-inverted-double-pendulum',
        'score': 7102.91,
    },
    {
        'env-title': 'mujoco-reacher',
        'score': -6.71,
    },
    {
        'env-title': 'mujoco-walker2d',
        'score': 3424.95,
    },
]
