entries = [
    {
        'env-title': 'mujoco-half-cheetah',
        'score': 1289.7,
    },
    {
        'env-title': 'mujoco-hopper',
        'score': 1912.9,
    },
    {
        'env-title': 'mujoco-inverted-pendulum',
        'score': 905.1,
    },
    {
        'env-title': 'mujoco-swimmer',
        'score': 94.96,
    },
    {
        'env-title': 'mujoco-inverted-double-pendulum',
        'score': 6731.63,
    },
    {
        'env-title': 'mujoco-reacher',
        'score': -4.82,
    },
    {
        'env-title': 'mujoco-walker2d',
        'score': 2342.63,
    },
]
