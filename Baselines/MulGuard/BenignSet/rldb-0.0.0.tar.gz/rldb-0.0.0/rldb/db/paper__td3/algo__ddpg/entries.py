entries = [
    {
        'env-title': 'mujoco-half-cheetah',
        'score': 3305.60,
    },
    {
        'env-title': 'mujoco-hopper',
        'score': 2020.46,
    },
    {
        'env-title': 'mujoco-walker2d',
        'score': 1843.85,
    },
    {
        'env-title': 'mujoco-ant',
        'score': 1005.30,
    },
    {
        'env-title': 'mujoco-reacher',
        'score': -6.51,
    },
    {
        'env-title': 'mujoco-inverted-pendulum',
        'score': 1000.00,
    },
    {
        'env-title': 'mujoco-inverted-double-pendulum',
        'score': 9355.52,
    },
]
