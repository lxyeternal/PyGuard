entries = [
    {
        'env-title': 'mujoco-half-cheetah',
        'score': 1795.43,
    },
    {
        'env-title': 'mujoco-hopper',
        'score': 2164.70,
    },
    {
        'env-title': 'mujoco-walker2d',
        'score': 3317.69,
    },
    {
        'env-title': 'mujoco-ant',
        'score': 1083.20,
    },
    {
        'env-title': 'mujoco-reacher',
        'score': -6.18,
    },
    {
        'env-title': 'mujoco-inverted-pendulum',
        'score': 1000.00,
    },
    {
        'env-title': 'mujoco-inverted-double-pendulum',
        'score': 8977.94,
    },
]
