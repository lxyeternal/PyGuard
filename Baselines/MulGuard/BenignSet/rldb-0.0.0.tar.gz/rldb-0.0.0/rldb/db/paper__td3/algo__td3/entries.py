entries = [
    {
        'env-title': 'mujoco-half-cheetah',
        'score': 9636.95,
        'stddev': 859.065,
    },
    {
        'env-title': 'mujoco-hopper',
        'score': 3564.07,
        'stddev': 114.74,
    },
    {
        'env-title': 'mujoco-walker2d',
        'score': 4682.82,
        'stddev': 539.64,
    },
    {
        'env-title': 'mujoco-ant',
        'score': 4372.44,
        'stddev': 1000.33,
    },
    {
        'env-title': 'mujoco-reacher',
        'score': -3.60,
        'stddev': 0.56,
    },
    {
        'env-title': 'mujoco-inverted-pendulum',
        'score': 1000.00,
        'stddev': 0.00,
    },
    {
        'env-title': 'mujoco-inverted-double-pendulum',
        'score': 9337.47,
        'stddev': 14.96,
    },
]
