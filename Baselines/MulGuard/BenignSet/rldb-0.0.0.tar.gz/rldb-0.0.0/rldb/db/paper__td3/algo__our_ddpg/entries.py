entries = [
    {
        'env-title': 'mujoco-half-cheetah',
        'score': 8577.29,
    },
    {
        'env-title': 'mujoco-hopper',
        'score': 1860.02,
    },
    {
        'env-title': 'mujoco-walker2d',
        'score': 3098.11,
    },
    {
        'env-title': 'mujoco-ant',
        'score': 888.77,
    },
    {
        'env-title': 'mujoco-reacher',
        'score': -4.01,
    },
    {
        'env-title': 'mujoco-inverted-pendulum',
        'score': 1000.00,
    },
    {
        'env-title': 'mujoco-inverted-double-pendulum',
        'score': 8369.95,
    },
]
