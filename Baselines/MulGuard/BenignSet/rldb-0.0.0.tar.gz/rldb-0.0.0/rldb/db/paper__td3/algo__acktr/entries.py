entries = [
    {
        'env-title': 'mujoco-half-cheetah',
        'score': 1450.46,
    },
    {
        'env-title': 'mujoco-hopper',
        'score': 2428.39,
    },
    {
        'env-title': 'mujoco-walker2d',
        'score': 1216.70,
    },
    {
        'env-title': 'mujoco-ant',
        'score': 1821.94,
    },
    {
        'env-title': 'mujoco-reacher',
        'score': -4.26,
    },
    {
        'env-title': 'mujoco-inverted-pendulum',
        'score': 1000.00,
    },
    {
        'env-title': 'mujoco-inverted-double-pendulum',
        'score': 9081.92,
    },
]
