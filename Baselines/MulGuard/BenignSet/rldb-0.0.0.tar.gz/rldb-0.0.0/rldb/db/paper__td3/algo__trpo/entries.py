entries = [
    {
        'env-title': 'mujoco-half-cheetah',
        'score': -15.57,
    },
    {
        'env-title': 'mujoco-hopper',
        'score': 2471.30,
    },
    {
        'env-title': 'mujoco-walker2d',
        'score': 2321.47,
    },
    {
        'env-title': 'mujoco-ant',
        'score': -75.85,
    },
    {
        'env-title': 'mujoco-reacher',
        'score': -111.43,
    },
    {
        'env-title': 'mujoco-inverted-pendulum',
        'score': 985.40,
    },
    {
        'env-title': 'mujoco-inverted-double-pendulum',
        'score': 205.85,
    },
]
