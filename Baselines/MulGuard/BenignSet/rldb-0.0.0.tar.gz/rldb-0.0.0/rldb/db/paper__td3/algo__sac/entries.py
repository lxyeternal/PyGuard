entries = [
    {
        'env-title': 'mujoco-half-cheetah',
        'score': 2347.19,
    },
    {
        'env-title': 'mujoco-hopper',
        'score': 2996.66,
    },
    {
        'env-title': 'mujoco-walker2d',
        'score': 1283.67,
    },
    {
        'env-title': 'mujoco-ant',
        'score': 655.35,
    },
    {
        'env-title': 'mujoco-reacher',
        'score': -4.44,
    },
    {
        'env-title': 'mujoco-inverted-pendulum',
        'score': 1000.00,
    },
    {
        'env-title': 'mujoco-inverted-double-pendulum',
        'score': 8487.15,
    },
]
