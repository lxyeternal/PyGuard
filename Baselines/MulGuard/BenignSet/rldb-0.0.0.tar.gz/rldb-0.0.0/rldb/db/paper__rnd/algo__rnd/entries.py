entries = [
    {
        'env-title': 'atari-gravitar',
        'score': 3906,
    },
    {
        'env-title': 'atari-montezuma-revenge',
        'score': 8152,
    },
    {
        'env-title': 'atari-pitfall',
        'score': -3,
    },
    {
        'env-title': 'atari-private-eye',
        'score': 8666,
    },
    {
        'env-title': 'atari-solaris',
        'score': 3282,
    },
    {
        'env-title': 'atari-venture',
        'score': 1859,
    },
]
