# NOTE Probably they ran it themselves since they used much more frames
entries = [
    {
        'env-title': 'atari-gravitar',
        'score': 3426,
    },
    {
        'env-title': 'atari-montezuma-revenge',
        'score': 2497,
    },
    {
        'env-title': 'atari-pitfall',
        'score': 0,
    },
    {
        'env-title': 'atari-private-eye',
        'score': 105,
    },
    {
        'env-title': 'atari-solaris',
        'score': 3387,
    },
    {
        'env-title': 'atari-venture',
        'score': 0,
    },
]
