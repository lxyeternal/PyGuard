"""
2D-Fourier Magnitude Coefficients
---------------------------------
.. autosummary::
    :toctree: generated/

    Segmenter
"""
from .config import *
from .segmenter import *
