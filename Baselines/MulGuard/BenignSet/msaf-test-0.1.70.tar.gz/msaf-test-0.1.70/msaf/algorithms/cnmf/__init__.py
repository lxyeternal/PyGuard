"""
Convex Non-Negative Matrix Factorization
----------------------------------------
.. autosummary::
    :toctree: generated/

    Segmenter
"""
from .config import *
from .segmenter import *
