"""
Laplacian Segmentation
----------------------
.. autosummary::
    :toctree: generated/

    Segmenter
"""
from .config import *
from .segmenter import *
