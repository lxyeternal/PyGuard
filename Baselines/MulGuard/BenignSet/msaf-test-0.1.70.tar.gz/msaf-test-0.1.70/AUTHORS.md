Contributors
------------

* Oriol Nieto <https://github.com/urinieto>
* Jordan Smith <https://github.com/jblsmith>
* Eric Humphrey <https://github.com/ejhumphrey>
* Stephan Balke <https://github.com/stefan-balke>
* Keunwoo Choi <https://github.com/keunwoochoi>
* Rustam S <https://github.com/fortunto2>
* Cheng-i Wang <https://github.com/wangsix>
* Carl Thomé <https://github.com/carlthome>

OLDA and Laplacian algorithm implementations were forked from the original repos by the titanest Brian McFee:
<https://github.com/bmcfee/olda> and <https://github.com/bmcfee/laplacian_segmentation>, respectively.

SI-PLCA implementation was forked from the original repo by Ron Weiss: <http://ronw.github.io/siplca-segmentation/>.

Constrained Clustering implementation was forked from the original code by Mark Levy: <https://code.soundsoftware.ac.uk/projects/qm-dsp/repository/show/dsp/segmentation>.

Additional thanks to Juan Pablo Bello and the rest of MARL for all their help and support.
