# same version as in:
# - setup.py
# - stdeb.cfg
__version__ = '0.21.0'
