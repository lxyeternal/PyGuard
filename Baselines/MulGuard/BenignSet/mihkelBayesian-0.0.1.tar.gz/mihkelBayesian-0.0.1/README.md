This is a test package purely for learning purposes. 

Kirjeldus
kirjeldus
kirjeldus


To install mihkelBayesian, along with the tools needed to develope and run tests, run the following in your virtual environment:

'''bash
$ pip install -e .[dev]
'''
