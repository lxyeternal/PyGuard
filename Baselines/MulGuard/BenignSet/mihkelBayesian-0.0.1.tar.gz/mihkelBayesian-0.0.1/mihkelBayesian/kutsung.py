import tere

print("kutsun tervitust")


tere.tere()


print("kutsutud")