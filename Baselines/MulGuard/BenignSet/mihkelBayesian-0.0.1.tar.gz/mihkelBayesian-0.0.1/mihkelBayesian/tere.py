

def tere():
	print("tere")