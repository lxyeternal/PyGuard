
def liida(a,b):
	return a+b

def lahuta(a,b):
	return a-b