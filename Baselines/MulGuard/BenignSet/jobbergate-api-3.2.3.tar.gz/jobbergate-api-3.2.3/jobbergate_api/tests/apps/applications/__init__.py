"""
Tests for the Application resource.
"""
