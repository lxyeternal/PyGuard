"""
Tests for the Apps.
"""
