"""
Tests for the JobScript resource.
"""
