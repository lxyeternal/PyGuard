"""
Tests for the JobSubmission resource.
"""
