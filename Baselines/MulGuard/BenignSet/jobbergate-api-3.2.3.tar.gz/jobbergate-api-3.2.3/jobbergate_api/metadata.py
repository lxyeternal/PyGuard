"""
Holds the metadata for all apps.
"""
from sqlalchemy import MetaData

metadata = MetaData()
