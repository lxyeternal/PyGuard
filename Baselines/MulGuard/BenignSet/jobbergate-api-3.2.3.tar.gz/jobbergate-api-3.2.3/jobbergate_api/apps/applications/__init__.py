"""
Provide module for applications.
"""
