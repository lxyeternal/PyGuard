"""
Main components of the application: routers, config, main, pagination and create super user script.
"""
