from nvector._examples import getting_started_functional
__doc__ = getting_started_functional  # @ReservedAssignment


if __name__ == '__main__':
    from nvector._common import write_readme, test_docstrings
    test_docstrings(__file__)
    write_readme(__doc__)
