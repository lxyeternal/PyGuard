Changelog of nested-dataclasses
===================================================


0.1 (2020-06-08)
----------------

- Initial project structure created with cookiecutter and
  https://github.com/PDOK/cookiecutter-python-base

- Added `nested` decorator.

- `nested` decorator uses ValidationMixin and ToDictMixin.
