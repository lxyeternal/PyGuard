=====
Usage
=====

To use fastdiff in a project::

    import fastdiff
