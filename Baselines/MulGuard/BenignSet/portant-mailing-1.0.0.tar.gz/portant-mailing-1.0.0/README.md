[![CircleCI](https://circleci.com/gh/portant-shop/mailing/tree/master.svg?style=svg&circle-token=4e584405508d26673ea9aad5fb2a06d1eb97bbff)](https://circleci.com/gh/portant-shop/mailing/tree/master)

# mailing
a django app for sending emails in portant
