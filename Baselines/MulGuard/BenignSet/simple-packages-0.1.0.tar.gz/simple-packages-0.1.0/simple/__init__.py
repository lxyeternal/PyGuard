# vim: set et nosi ai ts=4 sts=4 sw=4 colorcolumn=80:
# coding: utf-8

__all__ = ['__version__']
__version__ = '0.1.0'
