from invoke.main import program

program.run()
