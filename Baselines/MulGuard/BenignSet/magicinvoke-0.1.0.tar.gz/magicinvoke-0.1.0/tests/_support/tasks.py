from invoke.tasks import task


@task
def foo(c):
    print("Hm")
