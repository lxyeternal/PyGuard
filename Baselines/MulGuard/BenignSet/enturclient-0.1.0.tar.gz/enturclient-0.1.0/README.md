# Entur API client

Python client for fetching estimated departures from stop places in Norway from Entur.org's API. Information about stop places, platforms and real-time departures.
