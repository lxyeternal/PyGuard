from .element import Element


class Paragraph(Element):
    """
    Element class to represent HTML Paragraph
    """
