from .element import Element


class Link(Element):
    """
    Element class to represent HTML Link
    """
