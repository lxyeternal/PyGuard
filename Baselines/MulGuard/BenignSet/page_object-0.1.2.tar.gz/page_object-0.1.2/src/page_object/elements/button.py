from .element import Element


class Button(Element):
    """
    Element class to represent HTML Button
    """
