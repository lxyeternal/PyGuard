from page_object.elements.element import Element


class Span(Element):
    """
    Element class to represent HTML Span
    """
