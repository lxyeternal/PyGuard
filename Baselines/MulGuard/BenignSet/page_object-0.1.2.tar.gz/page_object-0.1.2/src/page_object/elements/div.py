from .element import Element


class Div(Element):
    """
    Element class to represent HTML Div
    """
