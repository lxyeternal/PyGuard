from .element import Element


class RadioButton(Element):
    """
    Element class to represent HTML Radio Button
    """
