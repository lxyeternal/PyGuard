from .element import Element


class Heading(Element):
    """
    Element class to represent HTML headings
    """
