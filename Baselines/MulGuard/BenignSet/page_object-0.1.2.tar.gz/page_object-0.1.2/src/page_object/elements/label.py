from .element import Element


class Label(Element):
    """
    Element class to represent HTML Label
    """
