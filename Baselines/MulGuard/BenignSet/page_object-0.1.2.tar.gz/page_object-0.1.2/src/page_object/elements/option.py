from .element import Element


class Option(Element):
    """
    Element class to represent HTML Option
    """
