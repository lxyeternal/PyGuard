from .element import Element


class TableCell(Element):
    """
    Element class to represent HTML td
    """
