from page_object.page_object import PageObject
from page_object.page_factory import on, visit
from page_object.browser import Browser
