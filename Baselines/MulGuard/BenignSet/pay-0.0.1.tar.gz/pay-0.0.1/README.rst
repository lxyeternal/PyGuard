Pay
===

.. image:: https://img.shields.io/pypi/v/pay.svg
    :target: https://pypi.python.org/pypi/pay/
    :alt: Latest Version

.. image:: https://img.shields.io/pypi/wheel/pay.svg
    :target: https://pypi.python.org/pypi/pay/

.. image:: https://img.shields.io/pypi/pyversions/pay.svg
    :target: https://pypi.python.org/pypi/pay/

.. image:: https://img.shields.io/pypi/l/pay.svg
    :target: https://pypi.python.org/pypi/pay/



Pay SDK.


Installing
----------

Install and update using `pip`_:

.. code-block:: text

    pip install -U pay



.. _pip: https://pip.pypa.io/en/stable/quickstart/
