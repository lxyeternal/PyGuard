imdo
----

imdo launches a process in such a way as to prevent changing the process group
id.
