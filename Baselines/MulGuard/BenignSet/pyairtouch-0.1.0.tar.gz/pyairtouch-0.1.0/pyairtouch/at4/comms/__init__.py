"""AirTouch 4 implementation of the communication interfaces.

Implementation is in accordance with v1.1 of the communication protocol.
"""
