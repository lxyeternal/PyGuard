"""Implementation of the pyairtouch API for the AirTouch 4."""
