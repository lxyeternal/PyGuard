# -*- coding: ascii -*-
 
 
"""Pragmatic.Stuff: stuff module within the Pragmatic package."""
 
 
class Stuff(object):
    pass