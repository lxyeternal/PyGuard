# -*- coding: ascii -*-
 
 
"""Pragmatic.__main__: executed when bootstrap directory is called as script."""
 
 
from .Pragmatic import Main

Main()