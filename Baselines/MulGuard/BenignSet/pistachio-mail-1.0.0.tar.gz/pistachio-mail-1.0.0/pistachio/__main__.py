from .pistachio import main

main()
