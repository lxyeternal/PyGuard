====================
Changelog for Django
====================

This needs some work to be used in productive.


Installation
------------

Install using pip:

.. code-block:: bash

	pip install django-changelog


.. code-block:: python

   # settings.py
   INSTALLED_APPS = [
       # ...
       'changelog.apps.ChangelogConfig',
       # ...
   ]
