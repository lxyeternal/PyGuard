from pysnakegym.model.deep_q_network import DeepQNetwork
from pysnakegym.model.ffnn import FFNN