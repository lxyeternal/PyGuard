bChart
=======

A Python Library for bChart
^^^^^^^^^^^^^^^^^^^^^^^^^^^

This library helps python developers to visualize their data with bChart. This is lightweight and easy to use. No need of javascript experience. 

Concept
-------

The data capabilities of Python. The visualization capabilities of
JavaScript.

bChart-Python let python developers to create a couple of different charts and render them in browsers. It shares the same APIs as the bChart (bchart.org) for javascript developers. It is easy of use, and you can customize your chart through python other than CSS/Javascript.

