# marlight-py

marlight-py is Python library for controlling Marlight "smart" bulbs through the ethernet bridge.

These bulbs seem to be built by LEDE and can be found under a few different brand names:

 * Marlight
 * New-Deal K9
 * TIME2
 * ...
