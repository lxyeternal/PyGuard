# License: MIT
# Copyright © 2022 Frequenz Energy-as-a-Service GmbH

"""Frequenz gRPC API to propagate dispatches to microgrids."""
