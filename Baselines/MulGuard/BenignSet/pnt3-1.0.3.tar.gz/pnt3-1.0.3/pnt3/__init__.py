from .src.canonical import convert_to_canonical
from .src.get_similarity import get_similarity
from .src.calc_similarity import calc_similarity
