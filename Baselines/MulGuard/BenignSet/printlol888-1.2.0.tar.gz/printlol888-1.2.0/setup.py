from distutils.core import setup

setup(
     name = "printlol888",
	 version = "1.2.0",
	 py_modules = ['printlol888'],
	 author     = 'lh',
	 author_email='119662230@qq.com',
	 url ='https://pypi.python.org',
	 description = 'a simple printer of test lists',

)

