# interdict
Python dictionary filter
