import string

CHARS_ALLOWED = string.ascii_lowercase + string.digits
SEPS_ALLOWED = '_- '
BRANCH = 'release'
