from typing import Annotated

Tasmota = Annotated
