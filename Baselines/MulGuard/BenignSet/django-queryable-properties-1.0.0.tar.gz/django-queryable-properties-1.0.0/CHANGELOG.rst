Changelog
=========

master (unreleased)
-------------------

1.0.0 (2018-12-31)
------------------

- Initial release
