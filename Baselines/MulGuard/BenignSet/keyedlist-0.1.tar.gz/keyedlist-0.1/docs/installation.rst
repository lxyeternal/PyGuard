============
Installation
============

At the command line::

    $ pip install keyedlist

Or, if you have virtualenvwrapper installed::

    $ mkvirtualenv keyedlist
    $ pip install keyedlist
