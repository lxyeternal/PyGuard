========
Usage
========

To use keyedlist in a project::

    import keyedlist
