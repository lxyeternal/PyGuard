===============================
keyedlist
===============================

.. image:: https://img.shields.io/travis/vanangamudi/keyedlist.svg
        :target: https://travis-ci.org/vanangamudi/keyedlist

.. image:: https://img.shields.io/pypi/v/keyedlist.svg
        :target: https://pypi.python.org/pypi/keyedlist


keyedlist implementation for python

* Free software: MIT license
* Documentation: (COMING SOON!) https://keyedlist.readthedocs.org.

Features
--------

* TODO
