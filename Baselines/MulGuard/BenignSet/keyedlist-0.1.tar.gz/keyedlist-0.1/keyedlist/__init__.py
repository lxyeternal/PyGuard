# -*- coding: utf-8 -*-
from __future__ import print_function
from ._version import get_versions

__author__ = 'Pa Mu Selvakumar'
__email__ = 'selva.developer@gmail.com'
__version__ = get_versions()['version']
del get_versions


from .keyedlist import KeyedList
