from setuptools import setup, find_packages

setup(
    name='CronoAPI',
    version='1.1.1',
    description='Biblioteca de datas e horas',
    author='Sabio_',
    packages=find_packages(),
    install_requires=['datetime'],
)