[![Build Status](https://github.com/davidbrochart/kernel_server/workflows/CI/badge.svg)](https://github.com/davidbrochart/kernel_server/actions)
[![Code style: black](https://img.shields.io/badge/code%20style-black-000000.svg)](https://github.com/psf/black)

# Kernel server

A library for serving the
[Jupyter kernel protocol](https://jupyter-client.readthedocs.io/en/stable/messaging.html) to the web
using a [WebSocket](https://en.wikipedia.org/wiki/WebSocket).
