# Copyright (c) 2021 - for information on the respective copyright owner see the
# NOTICE file and/or the repository https://github.com/boschresearch/parameterspace
#
# SPDX-License-Identifier: Apache-2.0

import importlib.metadata

import parameterspace.priors
import parameterspace.transformations
from parameterspace.parameters import *
from parameterspace.parameterspace import *

__version__ = importlib.metadata.version("parameterspace")
