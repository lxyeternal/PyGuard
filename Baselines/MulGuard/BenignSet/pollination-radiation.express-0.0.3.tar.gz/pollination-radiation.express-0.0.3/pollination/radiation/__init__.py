from .entry import CumulativeRadiationEntryPoint


__pollination__ = {
    'entry_point': CumulativeRadiationEntryPoint
}
