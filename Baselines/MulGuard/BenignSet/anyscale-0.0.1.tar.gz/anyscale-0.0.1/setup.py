from distutils.core import setup

setup(
  name = 'anyscale',
  packages = ['anyscale'],
  version = '0.0.1',
)
