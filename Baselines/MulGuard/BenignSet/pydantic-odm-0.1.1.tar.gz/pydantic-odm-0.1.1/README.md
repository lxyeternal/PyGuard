# Pydantic ODM
###### Small async ODM for MongoDB based in Motor and Pydantic
