"""Small async ODM for MongoDB based in Motor and Pydantic"""

__version__ = '0.1.1'
