"""Tools for handle raw data."""
