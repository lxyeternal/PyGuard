"""Evaluate functions and tools."""
