generate scrip key
