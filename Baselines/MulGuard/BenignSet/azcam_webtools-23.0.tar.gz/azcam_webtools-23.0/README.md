# azcam-webtools

*azcam-webtools* contains azcam web applications which interact with azcamserver over the web interface. Current functions include a status page and an exposure control page.

## Installation

`pip install azcam-webtools`

Or download from github: https://github.com/mplesser/azcam-webtools.git.

## Usage:

ToDo
