"""
Status web tool.
"""
