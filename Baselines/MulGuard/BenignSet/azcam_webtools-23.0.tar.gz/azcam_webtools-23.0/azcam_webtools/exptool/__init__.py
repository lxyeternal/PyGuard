"""
Exposure web tool.
"""
