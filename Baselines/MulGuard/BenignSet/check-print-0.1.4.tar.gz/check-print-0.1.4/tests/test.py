print()

# access
fprint(

# access
    f_print(

# access
f_0print(

# access
.print (

# access
. print (

# access
.print(

# access
    .
    print(

# access
def print(

# access
def
 print(

# access
.
print(

# decline
print(

# decline
(print(

# decline
= print (

# decline
    print(
