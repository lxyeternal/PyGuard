"""Top-level package for ACM DL HCI Searcher."""

__author__ = """Ahmed Shariff"""
__email__ = 'shariff.mfa@outlook.com'
__version__ = '0.1.0-alpha.2'
