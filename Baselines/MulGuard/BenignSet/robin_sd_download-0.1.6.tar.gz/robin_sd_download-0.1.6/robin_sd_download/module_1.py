def bar():
    print("This function is defined in module_1.py and can be called from any module in the package.")

variable = "This variable is defined in module_1.py and can be accessed from any module in the package."
