from .h5dict import File, h5dict

__version__ = "0.1.4"