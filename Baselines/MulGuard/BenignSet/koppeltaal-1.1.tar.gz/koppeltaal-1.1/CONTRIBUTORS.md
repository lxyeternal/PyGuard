# Koppeltaal Python Connector

## Contributors:

* Stichting Koppeltaal
* Minddistrict Development B.V.
