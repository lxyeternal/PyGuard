# This code is Copyright 2014-2017 by Pier Carlo Chiodi.
# See full license in LICENSE file.
