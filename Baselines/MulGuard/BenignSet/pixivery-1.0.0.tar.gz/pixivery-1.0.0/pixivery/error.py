class HTTPException(Exception):
  pass

class RankingModeException(Exception):
  pass