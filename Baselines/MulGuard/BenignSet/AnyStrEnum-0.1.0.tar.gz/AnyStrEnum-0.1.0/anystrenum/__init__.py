from .anystrenum import (BaseStrEnumItem, StrItem, BytesItem, BaseAnyStrEnum, AnyStrEnumMeta,
                         StrEnum, BytesEnum, auto_str, auto_bytes)

__version__ = '0.1.0'
