class ReadabilityException(Exception):
    pass
