
from .flesch import Flesch
from .flesch_kincaid import FleschKincaid
from .gunning_fog import GunningFog
