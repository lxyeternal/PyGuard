# py-readabilitiy

## Install

coming soon...

## Usage

```python
 r = Readability(text)
 r.flesch_kincaid()
 r.flesch()
```

## Contributing

[see contributing](CONTRIBUTING.md)

## License

[MIT](LICENSE)
