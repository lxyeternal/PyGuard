#  Copyright (c) 2023 Thomas Mathieson.
#  Distributed under the terms of the MIT license.

# setup.py shim for use with applications that require it.
__import__("setuptools").setup()
