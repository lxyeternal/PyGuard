#!/usr/bin/env python
# coding: utf-8

#  Copyright (c) 2023 Thomas Mathieson.
#  Distributed under the terms of the MIT license.


version_info = (0, 1, 0)
__version__ = ".".join(map(str, version_info))
