from setuptools import setup                                                     
setup(                                                                           
  name = 'everyday',                                                                 
  version = '0.0.0',                                                             
  description = 'Python client library for the Everyday API.',                       
  author = 'Fabian Popa',                                                        
  author_email = 'public@fabianpopa.com',                                        
  url = 'https://github.com/everyday',                                               
)
