from .scheudler import RedisTaskScheduler

task_scheduler = RedisTaskScheduler()
