from task import create_haozhuo_spider_task

create_haozhuo_spider_task(
    url="https://www.farfetch.cn/it/shopping/women/michel-klein-maglioncino-con-fiocco-item-12222186.aspx?storeid=9560&from=listing",
    url_id=0, flag="005", spider_product_id=38979)
