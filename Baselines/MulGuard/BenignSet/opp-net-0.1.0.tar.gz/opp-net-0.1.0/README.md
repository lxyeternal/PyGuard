[![Build Status](https://dev.azure.com/OpenPeerPower/OpenSource/_apis/build/status/opp-net?branchName=dev)](https://dev.azure.com/OpenPeerPower/OpenSource/_build/latest?definitionId=2&branchName=dev)

## Cloud integration in Open Peer Power
