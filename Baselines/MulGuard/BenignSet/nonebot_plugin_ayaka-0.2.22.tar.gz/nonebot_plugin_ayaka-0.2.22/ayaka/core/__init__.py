from .model import Ayaka, AyakaApp, AyakaDevice, AyakaBot, AyakaTrigger, AyakaStorage, AyakaCache, create_path, create_file, beauty_save

# 初始化
from .bot import ayaka
from . import deal, inner_plugins
