这里只保留Ayaka的公用代码，具体使用请移步[AyakaBot](https://github.com/bridgeL/ayaka_bot)或[nonebot-plugin-ayaka](https://github.com/bridgeL/nonebot-plugin-ayaka)
