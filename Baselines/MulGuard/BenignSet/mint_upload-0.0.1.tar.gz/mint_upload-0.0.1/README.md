# MINT Upload

[![Upload Python Package](https://github.com/mintproject/mint_upload/actions/workflows/python-publish.yml/badge.svg)](https://github.com/mintproject/mint_upload/actions/workflows/python-publish.yml) [![codecov](https://codecov.io/gh/mintproject/mint_upload/branch/master/graph/badge.svg)](https://codecov.io/gh/mintproject/mint_upload)

A python module to upload file to MINT
