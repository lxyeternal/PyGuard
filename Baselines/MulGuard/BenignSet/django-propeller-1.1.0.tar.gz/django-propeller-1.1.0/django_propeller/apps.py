from django.apps import AppConfig


class DjangoPropellerConfig(AppConfig):
    name = 'django_propeller'
