# -*- coding: utf-8 -*-
from __future__ import unicode_literals


class PropellerException(Exception):
    """
    Any exception from this package
    """
    pass


class PropellerError(PropellerException):
    """
    Any exception that is an error
    """
    pass
