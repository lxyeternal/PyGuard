from PyCytoData.__init__ import __VERSION__

def main():
    print(f"PyCytoData Version: v{__VERSION__}")


if __name__ == "__main__":
    main()