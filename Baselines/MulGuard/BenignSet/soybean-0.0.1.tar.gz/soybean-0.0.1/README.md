# soybean
A tiny message-queue application framwork
