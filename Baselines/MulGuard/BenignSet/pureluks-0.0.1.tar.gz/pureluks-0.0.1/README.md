Simple cryptsetup wrapper for LUKS image files
