= nl

nl is a python library that provides a production system with an API modelled on the natural language.

More info can be found in http://bitbucket.org/enriquepablo/nl/wiki/Home.

To install, see INSTALL.txt in this same directory.
