require([
    "jquery",
    "nbtutor-deps",

], function(jquery, deps){
    "use strict";

    $(function(){
    });
});
