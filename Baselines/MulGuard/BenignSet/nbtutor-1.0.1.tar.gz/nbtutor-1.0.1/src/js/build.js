({
    baseUrl: ".",
    paths: {
        "nbtutor-deps": "../../nbtutor/static/nbtutor/js/nbtutor.deps.min",
        "jquery": "../../node_modules/jquery/dist/jquery"
    },
    name: "main",
    out: "../../nbtutor/static/nbtutor/js/nbtutor.static.min.js",
    preserveLicenseComments: true
})
