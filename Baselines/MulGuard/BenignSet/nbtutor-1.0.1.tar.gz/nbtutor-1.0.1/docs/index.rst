Welcome to nbtutor's documentation!
=====================================

Contents:

.. toctree::
   :maxdepth: 2

   readme
   api


Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`
