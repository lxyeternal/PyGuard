# apptk

[![PyPI - Version](https://img.shields.io/pypi/v/apptk.svg)](https://pypi.org/project/apptk)
[![PyPI - Python Version](https://img.shields.io/pypi/pyversions/apptk.svg)](https://pypi.org/project/apptk)

-----

**Table of Contents**

- [Installation](#installation)
- [License](#license)

## Installation

```console
pip install apptk
```

## License

`apptk` is distributed under the terms of the [MIT](https://spdx.org/licenses/MIT.html) license.
