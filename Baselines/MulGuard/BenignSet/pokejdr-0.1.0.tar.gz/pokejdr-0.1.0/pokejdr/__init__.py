from ._version import __version__
from .model import Pokemon
