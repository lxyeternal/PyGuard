Register dexterity behaviors here
