from collective.grok import gs

# -*- extra stuff goes here -*- 
