Register browserviews here
