from zope.interface import Interface

class IProductSpecific(Interface):
    pass

