Drop static resources here
