=====
Usage
=====

To use kodiak in a project::

    import kodiak
