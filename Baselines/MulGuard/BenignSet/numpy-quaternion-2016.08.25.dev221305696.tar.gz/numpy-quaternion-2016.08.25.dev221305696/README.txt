This Python module adds a quaternion dtype to NumPy.  See full
description here:

    https://github.com/moble/quaternion/blob/master/README.md
