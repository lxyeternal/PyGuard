# package_name

Description. 
The package package_name is used to:
	- 
	-

## Installation

Use the package manager [pip](https://pip.pypa.io/en/stable/) to install package_name

```bash
pip install package_calc
```

## Usage

```python
from package_operacoes import funcoes
funcoes.my_function()
```

## Author
Nelson Lara

## License
[MIT](https://choosealicense.com/licenses/mit/)