def soma (x,y):
    r = x+y
    return r

def subtracao (x,y):
    r = x-y
    return (r)
    