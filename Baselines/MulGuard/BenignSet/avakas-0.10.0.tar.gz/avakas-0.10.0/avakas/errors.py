"""
Avakas Errors
"""


class AvakasError(Exception):
    """
    Basic Avakas Error
    """
