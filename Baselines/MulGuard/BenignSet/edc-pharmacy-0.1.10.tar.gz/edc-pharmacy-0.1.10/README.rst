|pypi| |travis| |codecov| |downloads|

edc-pharmacy
------------

Work in progress ...

medication
==========

dosage guidelines
=================

prescription
============

prescription items
==================

dispensed items
===============

TODO:

* add refill schedule
* add/generate refill appointments
* connect to edc_pharma dashboard

.. |pypi| image:: https://img.shields.io/pypi/v/edc-pharmacy.svg
    :target: https://pypi.python.org/pypi/edc-pharmacy
    
.. |travis| image:: https://travis-ci.com/clinicedc/edc-pharmacy.svg?branch=develop
    :target: https://travis-ci.com/clinicedc/edc-pharmacy
    
.. |codecov| image:: https://codecov.io/gh/clinicedc/edc-pharmacy/branch/develop/graph/badge.svg
  :target: https://codecov.io/gh/clinicedc/edc-pharmacy

.. |downloads| image:: https://pepy.tech/badge/edc-pharmacy
   :target: https://pepy.tech/project/edc-pharmacy
