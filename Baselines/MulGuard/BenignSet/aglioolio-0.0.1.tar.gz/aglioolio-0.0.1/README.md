# octarin

## TODO

- Formalize AWS services
- Write tests
- Check S3 Inventory
- Use ProtoBuf instead of pickle
