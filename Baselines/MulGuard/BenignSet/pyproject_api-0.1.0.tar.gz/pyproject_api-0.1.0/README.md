# [`pyproject-api`](https://pyproject-api.readthedocs.io/en/latest/)

[![check](https://github.com/tox-dev/pyproject-api/actions/workflows/check.yml/badge.svg)](https://github.com/tox-dev/pyproject-api/actions/workflows/check.yml)
[![codecov](https://codecov.io/gh/tox-dev/pyproject-api/branch/rewrite/graph/badge.svg)](https://codecov.io/gh/tox-dev/pyproject-api/branch/rewrite)
[![Code style:
black](https://img.shields.io/badge/code%20style-black-000000.svg)](https://github.com/psf/black)
[![Documentation Status](https://readthedocs.org/projects/pyproject-api/badge/?version=latest)](https://pyproject-api.readthedocs.io/en/latest/?badge=latest)
