# MaximumInscribedCircle
find smallest covering circle
