class NcDjangoError(BaseException):
    pass


class ConfigurationError(NcDjangoError):
    pass