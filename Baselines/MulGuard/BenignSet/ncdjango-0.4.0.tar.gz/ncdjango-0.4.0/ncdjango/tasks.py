from ncdjango.geoprocessing.celery_tasks import *
