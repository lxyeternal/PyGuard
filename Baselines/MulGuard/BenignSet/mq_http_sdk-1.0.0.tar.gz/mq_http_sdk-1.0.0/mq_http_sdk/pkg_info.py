name = "mq_http_sdk"
version = "1.0.0"
url = "https://github.com/aliyunmq/mq-http-python-sdk"
license = "MIT"
short_description = "Aliyun Message Queue(MQ) Http Python SDK"
long_description = """
    Provides http interfaces to Aliyun Message Queue(MQ) Service.
"""
