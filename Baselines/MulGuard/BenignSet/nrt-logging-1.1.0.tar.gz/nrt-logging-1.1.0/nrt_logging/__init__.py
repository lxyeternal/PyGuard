"""
Version 1.1.0: Add support for configuration file.
"""

__version__ = '1.1.0'
