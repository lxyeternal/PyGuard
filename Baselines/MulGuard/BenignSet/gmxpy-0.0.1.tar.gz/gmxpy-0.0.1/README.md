# gmxpy
Wrapping GROMACS by python script for me

Since 2023. 07. 12.  
Tested GROMCAS ver. 2023.1
