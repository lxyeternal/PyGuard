#!/usr/bin/python

__version__ = '1.0.0'
__author__  = 'Yassine Azzouz'
__license__ = 'MIT'
