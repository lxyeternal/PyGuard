# A Python gNxI Project

This project is part of a development effort to build a modular set of python packages 
for building on top of [OpenConfig gRPC Network Management & Operations Interfaces](https://www.openconfig.net/projects/rpc/).

This project is currently a namespace placeholder and will be updated as individual 
components get published.
