===========
Cryptohands
===========


.. image:: https://img.shields.io/pypi/v/cryptohands.svg
        :target: https://pypi.python.org/pypi/cryptohands

.. image:: https://img.shields.io/travis/chaffelson/cryptohands.svg
        :target: https://travis-ci.org/chaffelson/cryptohands

.. image:: https://readthedocs.org/projects/cryptohands/badge/?version=latest
        :target: https://cryptohands.readthedocs.io/en/latest/?badge=latest
        :alt: Documentation Status

.. image:: https://pyup.io/repos/github/chaffelson/cryptohands/shield.svg
     :target: https://pyup.io/repos/github/chaffelson/cryptohands/
     :alt: Updates


For making Crypto Pizza


* Free software: Apache Software License 2.0
* Documentation: https://cryptohands.readthedocs.io.


Features
--------

# TODO: Add some features to add

Credits
---------

This package was created with Cookiecutter_ and the `audreyr/cookiecutter-pypackage`_ project template.

.. _Cookiecutter: https://github.com/audreyr/cookiecutter
.. _`audreyr/cookiecutter-pypackage`: https://github.com/audreyr/cookiecutter-pypackage

