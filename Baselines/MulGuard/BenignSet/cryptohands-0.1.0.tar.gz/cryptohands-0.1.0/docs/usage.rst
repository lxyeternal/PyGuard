=====
Usage
=====

To use Cryptohands in a project:

Rename sample_config.json to config.json and supply your credential information

You can probably find Bitfinex information at: https://www.bitfinex.com/api

You can probably figure out how to get GoogleAPI keys at: https://github.com/burnash/gspread

I strongly recommend reading the gspread guide on setting up security.
You'll need to share your sheet with the client email that the Google OAuth creates
