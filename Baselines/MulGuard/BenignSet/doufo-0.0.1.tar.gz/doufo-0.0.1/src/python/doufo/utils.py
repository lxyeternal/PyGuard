def method_not_support_msg(func, obj):
    return f"{func} for {type(obj)} is not implemented yet."
