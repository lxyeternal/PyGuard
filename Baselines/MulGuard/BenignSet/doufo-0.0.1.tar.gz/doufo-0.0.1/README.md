# doufo
Data flow under function operations
