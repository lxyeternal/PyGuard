#!/usr/bin/env python
# coding: utf-8

# Copyright (c) Juan F. Esteban Müller.
# Distributed under the terms of the Modified BSD License.

version_info = (0, 1, 2)
__version__ = ".".join(map(str, version_info))
