#!/usr/bin/env python
# coding: utf-8

# Copyright (c) Juan F. Esteban Müller.
# Distributed under the terms of the Modified BSD License.

"""
Information about the frontend package of the widgets.
"""

module_name = "ipytableview"
module_version = "^0.1.0"
