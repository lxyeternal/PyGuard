# SPDX-FileCopyrightText: 2022-present Robert Luke <code@robertluke.net>
#
# SPDX-License-Identifier: MIT
__version__ = '0.0.1'
