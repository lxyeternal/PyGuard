# conversations

[![PyPI - Version](https://img.shields.io/pypi/v/conversations.svg)](https://pypi.org/project/conversations)
[![PyPI - Python Version](https://img.shields.io/pypi/pyversions/conversations.svg)](https://pypi.org/project/conversations)

-----

**Table of Contents**

- [Installation](#installation)
- [License](#license)

## Installation

```console
pip install conversations
```

## License

`conversations` is distributed under the terms of the [MIT](https://spdx.org/licenses/MIT.html) license.
