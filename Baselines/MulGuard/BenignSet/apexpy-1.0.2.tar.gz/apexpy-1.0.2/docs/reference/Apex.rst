apexpy.Apex
===========

The ``Apex`` class is used for all the main functionality (converting between coordinate systems, field line mapping, and calculating base vectors).

.. currentmodule:: apexpy

.. autoclass:: apexpy.Apex
    :members:
