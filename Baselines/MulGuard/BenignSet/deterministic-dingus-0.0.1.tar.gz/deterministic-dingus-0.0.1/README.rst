Deterministic Dingus
====================

This is a very simple wrapper around the Dingus library to simplify
checking that the result of the tested is the result of calling the
function with particular arguments.
