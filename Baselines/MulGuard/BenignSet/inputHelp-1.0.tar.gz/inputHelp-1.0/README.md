# inputHelpPackage
Functions to validate input for command line programs
