# import

`from lora_lang_splitter import split_eng_cn`

# Usage

`english_text, chinese_text = split_eng_cn("Markov's long 中文 text")`

# Output

`str(english_text), str(chinese_text)`
