from .exception import ShapeError  # noqa: F401
from .shapecheck import *  # noqa: F401, F403

__version__ = '0.0.1'
