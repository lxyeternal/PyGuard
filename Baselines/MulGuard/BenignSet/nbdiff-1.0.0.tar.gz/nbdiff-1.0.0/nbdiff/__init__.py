#!/usr/bin/env python
# -*- coding: utf-8 -*-

__author__ = 'The NBDiff Team'
__email__ = 'tavisharmstrong@gmail.com'
__version__ = '1.0.0'
