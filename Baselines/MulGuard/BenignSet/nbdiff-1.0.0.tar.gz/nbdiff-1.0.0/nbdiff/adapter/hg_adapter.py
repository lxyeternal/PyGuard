__author__ = 'root'


class HgAdapter:

    def get_modified_notebooks(self):
        pass

    def get_unmerged_notebooks(self):
        pass

    def stage_file(self, file, contents=None):
        pass
