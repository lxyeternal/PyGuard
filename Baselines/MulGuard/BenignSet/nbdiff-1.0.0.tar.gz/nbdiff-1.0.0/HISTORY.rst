.. :changelog:

History
-------


1.0.0 (2013-03-28)
++++++++++++++++++

* End of the original capstone team project.
* First release on PyPI
