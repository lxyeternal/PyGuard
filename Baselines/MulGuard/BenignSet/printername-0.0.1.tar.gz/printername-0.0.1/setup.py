import setuptools

setuptools.setup(
    name="printername",
    version="0.0.1",
    author="Yitian",
    author_email="123@456.com",
    url="https://dev.azure.com/yliu9yl/pypi-test",
    packages=[
        "test"
    ],
    python_requires='>=3.6',
)