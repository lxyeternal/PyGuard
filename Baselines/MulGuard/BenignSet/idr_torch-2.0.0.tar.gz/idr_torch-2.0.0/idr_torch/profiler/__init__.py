from torch.profiler import *

from .patch_kineto import tensorboard_trace_handler
