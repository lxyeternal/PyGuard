# HybridNN

This is a Package for Backpropagation and Hybrid Neural Netwok with Particle Swarm Optimization