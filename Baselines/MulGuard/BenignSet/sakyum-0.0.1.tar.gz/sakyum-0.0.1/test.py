from sakyum import project

# create a project called sakyum_todo
project("sakyum_todo")
