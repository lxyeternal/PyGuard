
from . base import BaseStructure

def project(name):
  """create project"""
  BaseStructure().dir_tree(name)
  
def delete_app():
  """delete app"""
  pass
