from setuptools import setup

setup(name='cellworld-tracking',author='german espinosa',author_email='germanespinosa@gmail.com',packages=['cellworld_tracking'],install_requires=['cellworld', 'json-cpp', 'tcp-messages'],license='MIT',version='0.0.11',zip_safe=False)
