from setuptools import setup, find_packages

setup(
    name='kobold',
    version='1',
    packages=find_packages(),
    install_requires=[],
    tests_require=['nosetests'],
)
