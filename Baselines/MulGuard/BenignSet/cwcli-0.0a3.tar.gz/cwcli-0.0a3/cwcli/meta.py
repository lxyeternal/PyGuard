"""
cwcli/meta.py

Metadata about the application.
"""

__app__ = 'cwcli'
__description__ = 'Command line interface for the ConnectWise SOAP API.'
__author__ = 'Jacob A. Bridges'
__version__ = '0.0a3'
