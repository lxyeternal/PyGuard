connectwise-soap-cli
====================

Command line interface for the ConnectWise SOAP API.
