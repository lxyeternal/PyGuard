from modularizador_ipynb import ativa, desativa, status_startup
