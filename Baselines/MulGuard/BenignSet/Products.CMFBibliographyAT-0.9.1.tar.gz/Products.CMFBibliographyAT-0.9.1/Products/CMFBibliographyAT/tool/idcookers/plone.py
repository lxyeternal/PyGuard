"""PLONE Default Bibliography IdCooker class"""

# Zope stuff
from Globals import InitializeClass
from App.Dialogs import MessageDialog

# CMF stuff
from Products.CMFCore.utils import getToolByName

# Bibliography stuff
from Products.CMFBibliographyAT.tool.idcookers.base \
     import IBibliographyIdCooker, BibliographyIdCooker


class PloneIdCooker(BibliographyIdCooker):
    """
    The ID is cooked from the bibliographical reference's title as a normalized string. That is the way Plone normally cooks object IDs.
    """

    __implements__ = (IBibliographyIdCooker ,)

    meta_type = "PLONE Default Bibliography ID Cooker"

    def __init__(self,
                 id = 'plone',
                 title = "PLONE Default Bibliography ID Cooker"):
        """
        initializes id and title
        """
        self.id = id
        self.title = title

    def _cookIdCore(self, ref, **kwargs):
        """
        cooks a bibref id for one reference entry dict
        """
	plone_utils = getToolByName(self, 'plone_utils')
        return plone_utils.normalizeString(ref['title'])

InitializeClass(PloneIdCooker)


def manage_addPloneIdCooker(self, REQUEST=None):
    """ """
    try:
        self._setObject('plone', PloneIdCooker())
    except:
        return MessageDialog(
            title='Bibliography tool warning message',
            message='The id cooker you attempted to add already exists.',
            action='manage_main')
    return self.manage_main(self, REQUEST)
