"""
make Extension importable
so we can use CMFTestCase
"""
