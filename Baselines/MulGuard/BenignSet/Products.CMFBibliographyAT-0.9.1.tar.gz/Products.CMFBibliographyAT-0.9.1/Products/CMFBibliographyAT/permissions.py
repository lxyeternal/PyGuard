# Product imports
from config import PROJECTNAME

ManageReferenceTypes = '%s: Manage Reference Types' % PROJECTNAME
