"""\
Unit test package for CMFBibliographyAT

To run all tests type 'python runalltests.py'
"""
GLOBALS = globals()
