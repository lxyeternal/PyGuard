This is the evolving documentation section for CMFBibliographyAT

  The individual documents are FTP dumps from my development site
where I write them as regular Plone documents. Import them using
FTP into your site to provide a local online version.

  Raphael