from Interface import Interface

class IBibliographyExport(Interface):
    """Marker interface for exportable bibliography elements
    """
