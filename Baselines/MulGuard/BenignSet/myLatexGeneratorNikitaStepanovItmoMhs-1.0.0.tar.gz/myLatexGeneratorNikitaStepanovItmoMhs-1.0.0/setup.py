from setuptools import setup

setup(
    name='myLatexGeneratorNikitaStepanovItmoMhs',
    version='1.0.0',
    description='Latex table and img generator library',
    packages=['tsk_second'],
    install_requires=[
    ],
    author_email='nik-stepanov-2001@bk.ru'
)
