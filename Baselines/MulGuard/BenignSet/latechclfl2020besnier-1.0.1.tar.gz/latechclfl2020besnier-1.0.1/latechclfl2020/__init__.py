import os

PACKDIR = os.path.abspath(os.path.dirname(__file__))