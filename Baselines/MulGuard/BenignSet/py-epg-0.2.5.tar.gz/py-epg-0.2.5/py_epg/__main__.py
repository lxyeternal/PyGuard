#!/usr/bin/env python3
from py_epg import main

# Run
main.main()
