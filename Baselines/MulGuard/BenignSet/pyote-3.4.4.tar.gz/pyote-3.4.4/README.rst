pyote
=====

pyote is a Python implementation of the essential parts of the R-OTE occultation timing extractor.

This app has fewer 'bells and whistles' than R-OTE and so should be easier to use for a newbie.
It also runs faster than R-OTE and deployment is simpler and more reliable.
