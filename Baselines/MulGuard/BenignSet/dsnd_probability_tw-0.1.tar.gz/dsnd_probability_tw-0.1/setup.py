from setuptools import setup

setup(name='dsnd_probability_tw',
      version='0.1',
      description='Gaussian distributions',
      packages=['dsnd_probability_tw'],
      author = 'Tanise Williams',
      author_email = 'tanise.williams@icloud.com',
      zip_safe=False)
