# OffensiveNN - Offensive Language Identification with Neural Networks

OffensiveNN provides state-of-the-art neural network models for multilingual offensive language identification.