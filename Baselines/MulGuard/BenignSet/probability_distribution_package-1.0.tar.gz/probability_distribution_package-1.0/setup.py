from setuptools import setup

setup(name='probability_distribution_package',
      version='1.0',
      description='Gaussian and binomial distributions functions',
      packages=['probability_distribution_package'],
      author = 'Siddhesh Sanap',
      author_email = 'siddheshsanap0002@gmail.com',
      zip_safe=False)
