# -*- coding: utf-8 -*-

"""
jsonvaluetester

This file was automatically generated for Stamplay by APIMATIC v3.0 (
 https://www.apimatic.io ).
"""


class ContentType(object):

    """Implementation of the 'Content-Type' enum.

    TODO: type enum description here.

    Attributes:
        ENUM_APPLICATIONXWWWFORMURLENCODED: TODO: type description here.

    """

    ENUM_APPLICATIONXWWWFORMURLENCODED = 'application/x-www-form-urlencoded'
