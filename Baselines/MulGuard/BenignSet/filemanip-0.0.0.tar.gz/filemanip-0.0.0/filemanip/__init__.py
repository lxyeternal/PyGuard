name = "filemanip"
from .filemanip import normalize_str, compare_normalized, find_files, insert_flag, replace_flag, remove_flag 
