from aftershoq.structure.classes import *
from aftershoq.structure.sgenerator import *