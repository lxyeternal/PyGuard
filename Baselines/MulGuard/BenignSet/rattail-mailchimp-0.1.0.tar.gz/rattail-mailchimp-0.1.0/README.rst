
rattail_mailchimp
=================

Rattail is a retail software framework, released under the GNU General
Public License.

This package contains software interfaces for the `MailChimp`_ system.

.. _`MailChimp`: https://mailchimp.com/

Please see the `Rattail Project`_ for more information.

.. _`Rattail Project`: https://rattailproject.org/
