def test(args):
    print(args)
