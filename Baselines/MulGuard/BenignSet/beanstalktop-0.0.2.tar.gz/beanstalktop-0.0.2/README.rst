beanstalktop
============

DESCRIPTION
-----------

beanstalktop is a simple, top-like UI for monitoring beanstalkd_ servers.


TO DO
-----

- Sortable columns
- Multiple host support
- Better colours

.. _beanstalkd: http://kr.github.io/beanstalkd/
