* Travis docker testing with robot framework and pytest
* Move services