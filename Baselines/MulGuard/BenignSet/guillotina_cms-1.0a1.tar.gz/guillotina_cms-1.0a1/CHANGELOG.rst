1.0a1 (2018-07-30)
------------------

- Initial release with search, tiles, websocket pubsub and basic content
  [bloodbare, jordic, vangheem]
