
from guillotina_cms.interfaces import ITileType
from zope.interface import implementer


@implementer(ITileType)
class TileType(object):
    pass
