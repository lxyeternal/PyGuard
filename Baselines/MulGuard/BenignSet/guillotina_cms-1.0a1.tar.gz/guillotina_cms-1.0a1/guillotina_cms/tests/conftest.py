pytest_plugins = [
    'pytest_docker_fixtures',
    'guillotina.tests.fixtures',
    'guillotina_elasticsearch.tests.fixtures',
    'guillotina_rediscache.tests.fixtures',
    'guillotina_cms.tests.fixtures'
]
