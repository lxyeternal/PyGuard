from guillotina.interfaces import IAsyncUtility
from zope.interface import Interface


class IWorkflowUtility(IAsyncUtility):
    pass


class IWorkflow(Interface):
    pass
