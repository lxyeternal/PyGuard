from guillotina.interfaces import IAsyncUtility


class IPubSubUtility(IAsyncUtility):
    pass
