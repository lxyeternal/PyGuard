class signal:
    def __init__(self):
        pass
    
    def set_price(OHLC_data, start_date=None, end_date=None):
        pass