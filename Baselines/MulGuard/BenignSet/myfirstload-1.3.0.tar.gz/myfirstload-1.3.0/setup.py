from distutils.core import setup

setup(

	name = 'myfirstload',
	version = '1.3.0',
	py_modules = ['myfirstload'],
	author = 'Luiz Henrique Alves',
	author_email = 'edge@jogargame.com.br',
	url = 'http://www.jogargame.com.br',
	description = 'A simple module printer of lists, with TAB, creating by guy brasilian',
)