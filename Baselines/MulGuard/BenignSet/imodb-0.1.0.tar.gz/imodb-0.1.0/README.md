# IMODB

In-Memory object database

## Requirements

* Python 3.6+

## Installation

```bash
~: pip install imodb
```
