# encoding: utf-8

NO_CONTEXT_MODULE = 1
NO_CONTEXT_CLASS = 2
NO_CONTEXT_CLASS_MESSAGE = 'Context module should contain a `Context` class'
COMMAND_NOT_FOUND = 3
COMMAND_NOT_FOUND_MESSAGE = 'Command not found'
