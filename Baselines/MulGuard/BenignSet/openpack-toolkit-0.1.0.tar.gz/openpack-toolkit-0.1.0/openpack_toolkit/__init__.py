"""
.. include:: ../README.md
"""

__version__ = '0.1.0'
from .activity import OPENPACK_WORKPROCESS_CLASSES, ActClass, ActSet

__all__ = [
    "OPENPACK_WORKPROCESS_CLASSES", "ActClass", "ActSet"
]
