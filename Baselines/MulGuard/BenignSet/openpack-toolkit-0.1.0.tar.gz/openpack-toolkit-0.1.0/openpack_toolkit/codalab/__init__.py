from .workprocess_segmentation import (
    eval_workprocess_segmentation,
    eval_workprocess_segmentation_wrapper,
)

__all__ = [
    "eval_workprocess_segmentation",
    "eval_workprocess_segmentation_wrapper"
]
