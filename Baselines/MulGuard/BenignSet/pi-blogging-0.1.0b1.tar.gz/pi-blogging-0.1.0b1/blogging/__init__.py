'''
pi-Blogging App version 0.1 (beta)
'''