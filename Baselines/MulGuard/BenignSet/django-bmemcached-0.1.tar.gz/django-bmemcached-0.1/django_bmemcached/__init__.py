from memcached import BMemcached
