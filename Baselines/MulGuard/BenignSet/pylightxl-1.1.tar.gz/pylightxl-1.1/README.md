# pylightxl
A light weight, zero non-standard-lib dependency, minial functionality excel read 
(writer coming soon) python library. See documentation: pylightxl.readthedocs.io/

Supports:
 - Supports .xlsx and .xlsm file extensions. 

Limitations:
 - Does not support .xls (excel 97-2003 worksheet).
 - Does not support worksheet cell data more than 536,870,912 cells (32-bit list limitation)
