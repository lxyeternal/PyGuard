# Help
This is multiplayer lobby. Here you can start a game session against a real person and inspect your 
statistics.

**Create game**  
Customize game options and wait for someone to join your game session.

**Join game**  
Pick from a list of existing sessions and join.

**Statistics**  
Have a look at your account's statistics: win count, total time in-game etc.

**Logout**  
Log out of the current account.
