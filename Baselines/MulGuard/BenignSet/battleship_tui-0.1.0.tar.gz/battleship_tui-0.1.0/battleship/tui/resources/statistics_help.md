# Help
Here you can have a look at your player statistics accumulated over all played games.

**Only finished multiplayer games count towards statistics.**

Right now it includes the following.
* Played games count
* Win/loss ratio
* Shots count
* Accuracy (hits/shots ratio)
* Average game duration
* The quickest win (by shots count)
* The quickest win (by duration)
