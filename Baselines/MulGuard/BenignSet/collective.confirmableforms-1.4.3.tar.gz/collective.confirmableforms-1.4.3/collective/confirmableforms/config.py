PROJECTNAME = 'collective.confirmableforms'
