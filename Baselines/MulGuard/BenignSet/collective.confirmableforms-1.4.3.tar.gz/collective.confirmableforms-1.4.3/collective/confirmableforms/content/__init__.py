from confirmedFormMailerAdapter import ConfirmedFormMailerAdapter  # noqa
