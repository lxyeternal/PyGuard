from distutils.core import setup

setup(
    name = 'lks_first',
    version = '1.0.0',
    py_modules = ['lks_first'],
    author = 'lks',
    author_email = 'kakakana@naver.com',
    url = 'aa',
    description = 'TEST',
    )
