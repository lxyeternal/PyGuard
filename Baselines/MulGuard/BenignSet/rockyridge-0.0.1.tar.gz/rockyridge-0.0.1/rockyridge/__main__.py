import sys

print("< rockyridge > main")

print("\nargs: {}".format(sys.argv))