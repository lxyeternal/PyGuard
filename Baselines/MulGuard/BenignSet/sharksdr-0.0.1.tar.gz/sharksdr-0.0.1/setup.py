from setuptools import setup, find_packages


setup(name='sharksdr',
      version='0.0.1',
      description='SHaRK',
      long_description='',
      classifiers=[
          'Development Status :: 3 - Alpha',
          'Programming Language :: Python :: 3',
          'Programming Language :: Python :: 3.5',
          'Programming Language :: Python :: 3.6',
          'Programming Language :: Python :: 3.7',
          'Intended Audience :: Developers',
      ],
      url='http://github.com/storborg/shark',
      keywords='',
      author='Scott Torborg',
      author_email='storborg@gmail.com',
      license='',
      packages=find_packages(),
      include_package_data=True,
      zip_safe=False,
     )
