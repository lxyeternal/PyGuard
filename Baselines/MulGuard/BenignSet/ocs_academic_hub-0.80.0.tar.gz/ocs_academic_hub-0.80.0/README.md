# OSIsoft Academic Hub 

To support data analytics learning material developed for [OSIsoft Academic Hub](https://academic.osisoft.com). 

IN DEVELOPMENT 
