VERSION = '2.4.5'

__version__ = VERSION
gap_char = '-'