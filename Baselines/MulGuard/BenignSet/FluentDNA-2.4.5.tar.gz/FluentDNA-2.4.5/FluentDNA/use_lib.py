import sys
import os
sys.path.append(os.path.join(os.path.dirname(sys.argv[0]), "lib"))
# This idea is from http://unafaltadecomprension.blogspot.com/2014/07/pyinstaller-separating-executable-from.html