class TrieNode:
    def __init__(self):
        self.children = {}
        self.book_number = None

