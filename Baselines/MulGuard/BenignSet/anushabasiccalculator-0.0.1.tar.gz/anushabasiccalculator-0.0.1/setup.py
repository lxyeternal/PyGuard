from setuptools import setup, find_packages

setup(
    name='anushabasiccalculator',
    version = '0.0.1',
    description ="A very basic calculator",
    author ='Anusha H S',
    author_email='anusha.anu.sam@gmail.com',
    keywords='calculator',
    packages = find_packages(),
    install_requires=['']
)