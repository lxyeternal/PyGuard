config_file_path = './config.ini'
logger_config_file_path = './logger.yaml'