#!/usr/bin/env python
# encoding=utf-8

def hello_world():
    print "hello world"

def test():
    print "test a method"
