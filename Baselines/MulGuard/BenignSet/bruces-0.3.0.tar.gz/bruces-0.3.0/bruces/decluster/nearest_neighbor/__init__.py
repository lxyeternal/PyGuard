from ._nearest_neighbor import decluster

__all__ = [
    "decluster",
]
