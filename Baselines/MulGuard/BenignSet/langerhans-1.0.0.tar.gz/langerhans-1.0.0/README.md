# langerhans
Analysis of beta cells' calcium signals in the islet of Langerhans.
