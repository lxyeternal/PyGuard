# `runner_client` project #

The `psquared_runner` project contains the `psquared_runner` package that provides a python code to run the `psquared` "command" in background outside the server.

