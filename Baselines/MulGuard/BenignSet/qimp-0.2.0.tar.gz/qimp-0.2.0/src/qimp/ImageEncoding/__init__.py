"""Image subpackage for qimp."""
