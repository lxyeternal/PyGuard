"""Top-level package for qimp."""

__author__ = """Giacomo Antonioli"""
__email__ = "giacomo.antonioli@phd.unipi.it"
__version__ = "0.1.0"
