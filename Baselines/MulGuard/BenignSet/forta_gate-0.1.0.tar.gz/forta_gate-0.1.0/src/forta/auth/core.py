import forta.fastapi

app = forta.fastapi.fabric(title=r'SSO')