#!/usr/bin/python3
# -*- coding: utf-8 -*-

def login_udp(login, password, hash):
	return "Логин " + login + " Пароль: " + password + " Хэш: " + hash + "были введены верно!"

def udp_setm():
	return "menj"

def udp_setb():
	return "bolj"