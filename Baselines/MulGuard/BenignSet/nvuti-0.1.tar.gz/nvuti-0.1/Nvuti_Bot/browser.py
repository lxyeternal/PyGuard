#!/usr/bin/python3
# -*- coding: utf-8 -*-
import random

def browser_nvutiadd():
	return "New Browser successfully added!"

def browser_getData(hash):
	return "Game data has been saved"

def data():
	return str(random.randint(100000, 999999)) + "\n" + str(random.randint(100000, 999999)) + "\n" + str(random.randint(100000, 999999)) + "nvuti \n" + str(random.randint(100000, 999999))

def browser_set(data):
	return "Success"