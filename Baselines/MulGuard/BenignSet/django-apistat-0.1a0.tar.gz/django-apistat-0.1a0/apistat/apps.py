from django.apps import AppConfig


class ApistatConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'apistat'
