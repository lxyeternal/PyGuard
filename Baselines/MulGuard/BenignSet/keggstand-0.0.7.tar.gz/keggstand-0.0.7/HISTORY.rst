=======
History
=======

0.0.7 (2020-07-19)
------------------

* First release on PyPI.
