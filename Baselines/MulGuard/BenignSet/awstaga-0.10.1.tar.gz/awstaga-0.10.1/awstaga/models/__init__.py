"""
awstaga
=======
Tag any AWS resource via config file.
"""
