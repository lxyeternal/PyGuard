from distutils.core import setup

setup (
        name            =   'recurlister',

        version         =   '1.0.0',

        py_modules      = ['recurlister'],

        author          = 'kevin kirkwood',

        author_email    = 'metalicrust@gmail.com',

        url             = '',

        description     = 'A program that prints a nested list'

        )
