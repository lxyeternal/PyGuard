import StellarNet as SN
