"""
BreezeCLI
----
A Universal Command Line Environment for Breeze Operations.
"""
import os

__version__ = '0.0.3'