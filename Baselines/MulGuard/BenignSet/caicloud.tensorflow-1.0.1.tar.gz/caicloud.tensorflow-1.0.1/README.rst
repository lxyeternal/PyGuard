Caicloud TensorFlow as a Service (TaaS) dev environment, including files needed to start TensorFlow training process and serving client.
