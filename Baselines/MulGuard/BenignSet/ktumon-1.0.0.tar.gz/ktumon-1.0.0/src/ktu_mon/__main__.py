from ktu_mon.systray import systray


def main():
    systray()


if __name__ == "__main__":
    main()
