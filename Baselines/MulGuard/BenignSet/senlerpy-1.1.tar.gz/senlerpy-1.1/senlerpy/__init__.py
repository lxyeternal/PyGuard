# -*- coding: utf-8 -*-
__author__ = 'tezmen'
__version__ = '1.1'
__api_version__ = '1.0'

from .senler import Senler
from .exceptions import HttpError, WrongSecret, WrongId, ApiError
