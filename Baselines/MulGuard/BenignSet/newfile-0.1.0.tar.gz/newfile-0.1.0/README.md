# newfile
create files from preset template cli app

- [Docs](https://github.com/teeaz/newfile)
- [Examples](https://github.com/teeaz/newfile/tree/main/example)