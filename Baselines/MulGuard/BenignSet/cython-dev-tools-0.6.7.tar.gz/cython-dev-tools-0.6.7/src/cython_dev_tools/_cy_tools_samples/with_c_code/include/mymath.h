

double sinc(double);