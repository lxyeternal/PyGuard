from .debug import debug_command, debug
from .run import run_command, run
from .valgrind import valgrind_command, valgrind