import os

CYTHON_TOOLS_DIRNAME = os.getenv("CYTHON_TOOLS_DIRNAME", '.cython_dev_tools')
CYTHON_TOOLS_LOG_PATH = os.getenv("CYTHON_TOOLS_LOG_PATH", None)
CYTHON_TOOLS_LOG_FNAME = os.getenv("CYTHON_TOOLS_LOG_FNAME", 'cython_dev_tools')
