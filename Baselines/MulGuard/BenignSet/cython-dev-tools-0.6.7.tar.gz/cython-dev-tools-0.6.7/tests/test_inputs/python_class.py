class PySomeClass(object):
    def test_main(self):
        pass

def main():
    print('main')
