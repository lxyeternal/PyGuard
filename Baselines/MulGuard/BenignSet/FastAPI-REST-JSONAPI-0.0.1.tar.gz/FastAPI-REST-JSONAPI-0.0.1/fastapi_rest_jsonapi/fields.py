from marshmallow_jsonapi.fields import Integer as MarshmallowInteger, String as MarshmallowString


class Integer(MarshmallowInteger):
    ...


class String(MarshmallowString):
    ...
