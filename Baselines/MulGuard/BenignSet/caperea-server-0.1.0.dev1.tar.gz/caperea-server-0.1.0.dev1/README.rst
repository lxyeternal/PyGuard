==============
Caperea Server
==============

.. image:: https://img.shields.io/badge/license-AGPL--3.0--only-blue.svg
   :alt: AGPL-3.0-only
   :target: https://gitlab.com/pascalpepe/caperea-server/blob/nebula/COPYING

Library management platform.


License
=======

Caperea Server is free software: you can redistribute it and/or modify
it under the terms of the `GNU Affero General Public License`_ as published by
the Free Software Foundation, version 3 of the License only.

Caperea Server is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
GNU Affero General Public License for more details.

You should have received a copy of the GNU Affero General Public License
along with Caperea Server. If not, see https://www.gnu.org/licenses/.


.. _`GNU Affero General Public License`: https://gitlab.com/pascalpepe/caperea-server/blob/nebula/COPYING
