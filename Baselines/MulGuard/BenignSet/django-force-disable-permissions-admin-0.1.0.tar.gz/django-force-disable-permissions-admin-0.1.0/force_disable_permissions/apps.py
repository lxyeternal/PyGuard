from django.apps import AppConfig


class ForceDisablePermissionsConfig(AppConfig):
    name = 'force_disable_permissions'
