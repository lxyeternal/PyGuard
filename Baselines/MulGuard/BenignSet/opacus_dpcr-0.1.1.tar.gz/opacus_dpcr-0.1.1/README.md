# exCvxpy
 A extension of cvxpy that adds some atomic operations
