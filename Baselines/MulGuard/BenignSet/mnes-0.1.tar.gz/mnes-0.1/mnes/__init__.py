def hello():
    return (u'Hello')
