from distutils.core import setup

setup(
	name='nesterFay',
	version='1.0.0',
	py_modules=['nester'],
	author='Fay',
	author_email='309323122@qq.com',
	#url='http://www.headfirstlabs.com',
	description='A simple printer of nested lists',
	)