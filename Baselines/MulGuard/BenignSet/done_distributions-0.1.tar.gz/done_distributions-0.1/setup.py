from setuptools import setup

setup(name='done_distributions',
      version='0.1',
      description='Gaussian distributions',
      packages=['done_distributions'],
      zip_safe=False)
