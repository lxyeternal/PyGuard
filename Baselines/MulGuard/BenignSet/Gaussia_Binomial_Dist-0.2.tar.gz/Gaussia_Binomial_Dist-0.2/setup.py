from setuptools import setup

setup(name='Gaussia_Binomial_Dist',
      version='0.2',
      description='Gaussian distributions',
      author="Eslam Abdelghany",
      author_email="eslam322_1@hotmail.com",
      packages=['Gaussia_Binomial_Dist'],
      zip_safe=False)
