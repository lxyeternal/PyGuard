Changelog
=========

0.1.1
----------------

- moved the hitcounter viewlet to the viewlets.IPortalFooter
- added custom app.js which asynchronously pulls stats from the 'awstats_hitcounter_view'
- the stats view now returns the content type, creation date and number of views
  [pigeonflight]
- update to use BeautifulSoup for scraping awstats
  [pigeonflight]

0.1 
----------------

- Initial release.
  [pigeonflight]

