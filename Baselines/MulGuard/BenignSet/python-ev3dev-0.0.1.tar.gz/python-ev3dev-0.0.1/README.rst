Python language bindings for ev3dev
===================================

.. image:: https://travis-ci.org/rhempel/ev3dev-lang-python.svg?branch=master
    :target: https://travis-ci.org/rhempel/ev3dev-lang-python
.. image:: https://readthedocs.org/projects/python-ev3dev/badge/?version=latest
    :target: http://python-ev3dev.readthedocs.org/en/latest/?badge=latest
    :alt: Documentation Statu

This is a python library implementing unified interface for ev3dev_ devices.

.. _ev3dev: http://ev3dev.org

