def is_verb(func):
    return hasattr(func, '_action')
