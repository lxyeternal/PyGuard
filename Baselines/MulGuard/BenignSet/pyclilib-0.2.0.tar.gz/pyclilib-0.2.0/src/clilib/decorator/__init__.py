from clilib.decorator.arg import arg
from clilib.decorator.verb import verb
from clilib.decorator.resource import resource
