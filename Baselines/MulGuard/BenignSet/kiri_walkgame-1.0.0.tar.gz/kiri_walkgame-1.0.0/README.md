# kiri-walkgame

![PythonVersion](https://img.shields.io/badge/python-3.*-blue)
![PyPi](https://img.shields.io/pypi/v/kiri-walkgame)

This is a mini game to visualize the path-finding algorithm.

To play this game, you just need to click the map twice. The first clicking will place a cat named **Kiri**, and the following one will place a box. Then Kiri will find his way to get inside the box immediately.

## Usage

```shell
python kiri_walkgame
```
