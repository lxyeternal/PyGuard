#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Fri Jul 21 10:20:23 2023

@author: anthony
"""
from kiri_walkgame import Game
game = Game()
screen = game.on_run()
