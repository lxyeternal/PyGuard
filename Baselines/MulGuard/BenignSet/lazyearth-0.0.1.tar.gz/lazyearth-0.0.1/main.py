# from lazy_multiply.lazymultiply import Multiplication
# obj1 = Multiplication(2)
# print(obj1.multiply(10))

from lazy_multiply import Multiplication
obj1 = Multiplication(2)
print(obj1.multiply(10))

