from setuptools import setup

setup(name='moniBenzi_probability',
      version='0.1',
      description='Gaussian distributions',
      packages=['moniBenzi_probability'],
      zip_safe=False)
