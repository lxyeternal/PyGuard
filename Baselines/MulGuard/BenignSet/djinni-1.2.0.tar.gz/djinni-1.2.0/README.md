# Djinni python bindings

This is the required python clue to make djinni generated python bindings work.

More about djinni, the tool for generating cross-language type declarations and interface bindings: https://djinni.xlcpp.dev