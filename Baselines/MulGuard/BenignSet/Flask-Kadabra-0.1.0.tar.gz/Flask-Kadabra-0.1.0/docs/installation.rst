.. _installation:

Installation
============

You can install Flask-Kadabra through the `Python package index (pip)
<https://pypi.python.org/pypi/pip>`_. Installation is simple::

    $ sudo pip install Flask-Kadabra

After installing, you should check out :doc:`usage`.
