.. _api:

API
===

.. module:: flask_kadabra

.. autoclass:: flask_kadabra.Kadabra
   :members:
   :inherited-members:

.. autofunction:: record_metrics
