from ruamel.yaml import YAML, yaml_object

yaml = YAML()
