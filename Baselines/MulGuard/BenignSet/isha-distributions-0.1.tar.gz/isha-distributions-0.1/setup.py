from setuptools import setup

setup(name='isha-distributions',
      version='0.1',
      description='Gaussian and Binomial distributions',
      packages=['isha-distributions'],
      zip_safe=False)
