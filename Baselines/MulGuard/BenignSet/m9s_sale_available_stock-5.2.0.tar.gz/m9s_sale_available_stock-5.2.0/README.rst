Sale Available Stock Module
###########################

This module shows the available quantity for a product in sale's warehouse.
A user creating a sale line can see the quantity that can be assigned for a
customer shipment.
This is more useful at a Point of Sale where the salesman needs to know the
available quantity in the store's warehouse.
