"""
bilibili_api.settings

这里是配置模块的地方
"""

# 代理设置
proxy: str = ""
