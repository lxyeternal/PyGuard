from setuptools import setup
setup(name='ccdingtalk',
      version='0.1',
      description='Send dingtalk webhook with simple interface and load balance',
      url='https://github.com/OpenFibers/CCDingTalk',
      author='OpenFibers',
      author_email='openfibers@gmail.com',
      license='MIT',
      packages=['ccdingtalk'],
      zip_safe=False)
