webpackHotUpdate(0,{

/***/ 88:
/***/ (function(module, exports, __webpack_require__) {

exports = module.exports = __webpack_require__(325)(undefined);
// imports
exports.push([module.i, "@import url(https://fonts.googleapis.com/css?family=Roboto:400);", ""]);

// module
exports.push([module.i, ":root {\n    --font-face: 'Roboto', sans-serif;\n}\n\nsvg text {\n    cursor: default;\n    user-select: none;\n}\n\n.output-container {\n    border: 1px solid silver;\n    border-radius: 2px;\n    font-family: var(--font-face);\n    font-size: 20px;\n}\n\n#cspviewer > #footer {\n    margin: 10px;\n}\n\n#cspviewer #output {\n    margin-top: 5px;\n    font-size: 14px;\n}", ""]);

// exports


/***/ })

})
//# sourceMappingURL=0.c72aae456de39db629d5.hot-update.js.map