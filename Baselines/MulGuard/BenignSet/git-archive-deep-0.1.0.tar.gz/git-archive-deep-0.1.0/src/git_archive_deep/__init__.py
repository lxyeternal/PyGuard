"""Git Archive Deep."""
