from fetcha.ssb import SSB

__version__ = "0.0.1"
