NetworkLiteratureDownloader
==============================

Introduction
-------------
This is a GUI downloader for NetworkLiterature!

Documentation
--------------
Documentation can be found in ...

Example Usage
--------------
Here is an example to import the modules from this package.
..code::python
    form downloader.downloadApp import App
    app = App()
    app.MainLoop()
settings.py is for you to set your own preference.

LICENSE
--------
See MIT