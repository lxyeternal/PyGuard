from setuptools import setup

setup(name='markphi',
      version='0.1',
      description='Gaussian distributions',
      packages=['markphi'],
      zip_safe=False)
