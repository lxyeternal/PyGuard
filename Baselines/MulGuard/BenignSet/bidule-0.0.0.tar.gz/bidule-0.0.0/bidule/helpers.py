# this one needs no further import

def helper(*args, **kwds):
    print("BIDULE: ", *args, **kwds)
