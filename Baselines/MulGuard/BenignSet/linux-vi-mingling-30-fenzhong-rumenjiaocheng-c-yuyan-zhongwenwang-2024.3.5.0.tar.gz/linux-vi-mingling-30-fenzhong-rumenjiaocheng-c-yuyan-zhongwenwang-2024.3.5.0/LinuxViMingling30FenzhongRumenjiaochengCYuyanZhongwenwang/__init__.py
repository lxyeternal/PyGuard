#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""linux-vi-mingling-30-fenzhong-rumenjiaocheng-c-yuyan-zhongwenwang
https://github.com/apachecn/linux-vi-mingling-30-fenzhong-rumenjiaocheng-c-yuyan-zhongwenwang"""

__author__ = "ApacheCN"
__email__ = "apachecn@163.com"
__license__ = "CC BY-NC-SA 4.0"
__version__ = "2024.3.5.0"