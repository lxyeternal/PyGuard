# CoreUtil
## Purpose 
This core mainly to personal use, and it just wraped some other packages. the perpose that is make some functions are easy to use quickly.
- getTimeStamp
- getFormatedTime
- getFakerData
- multiDimArrayTransfer2SingleDim
- getSha1Password
- getToken
- Download example
- dataFram example
- crotine example

