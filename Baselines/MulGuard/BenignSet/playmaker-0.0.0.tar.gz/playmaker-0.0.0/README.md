# playmaker
Generative models of in-game player actions built from NFL NextGenStats
