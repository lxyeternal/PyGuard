# python-electricity
Tariff Periods for electricity billing
