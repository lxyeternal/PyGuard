#!/usr/bin/env python3

import sys

class PyMomError(Exception):
    """ A specialized exception for the PyMom framework. """
    pass
