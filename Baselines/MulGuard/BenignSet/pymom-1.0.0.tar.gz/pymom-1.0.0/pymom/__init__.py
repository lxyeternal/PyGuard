# Version of the PyMom package
__version__ = "1.0.0"
