class Loopable:
    def __init__(self) -> None:
        pass

    def loop(self, screen, *args):
        pass