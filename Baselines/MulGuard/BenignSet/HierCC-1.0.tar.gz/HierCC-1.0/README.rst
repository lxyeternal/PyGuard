# HierCC
Hierarchical clustering of cgMLST
