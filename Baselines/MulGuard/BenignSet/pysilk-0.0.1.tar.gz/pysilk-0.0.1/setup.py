from setuptools import setup

setup(
    name='pysilk',
    version='0.0.1',
    description='',
    long_description='',
    author='CindyMoon',
    packages=[],
    classifiers=['Development Status :: 1 - Planning'],
)
