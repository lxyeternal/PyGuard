from django.apps import AppConfig


class MaasConfig(AppConfig):
    name = 'maas'
    verbose_name = 'Mail as a Service'