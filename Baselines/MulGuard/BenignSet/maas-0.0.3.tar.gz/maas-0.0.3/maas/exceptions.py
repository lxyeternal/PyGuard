
class MaasConfigurationException(Exception):
    pass


class MaasProviderException(Exception):
    pass


class MaasUnknownException(Exception):
    pass