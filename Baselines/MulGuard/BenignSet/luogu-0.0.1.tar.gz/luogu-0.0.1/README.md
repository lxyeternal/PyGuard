<p align="center">
  <a href="https://github.com/piterator-org">
    <img src="./docs/_static/logo.svg" alt="Logo" width="128em">
    <br>
    Made by <strong>Piterator</strong> with &lt;3
  </a>
</p>

# pyluogu

[![Python package](https://github.com/piterator-org/pyluogu/actions/workflows/python-package.yml/badge.svg)](https://github.com/piterator-org/pyluogu/actions/workflows/python-package.yml)
[![codecov](https://codecov.io/gh/piterator-org/pyluogu/graph/badge.svg)](https://codecov.io/gh/piterator-org/pyluogu)
[![Documentation Status](https://readthedocs.org/projects/pyluogu/badge/)](https://pyluogu.readthedocs.io/zh_CN/latest/)
![license](https://img.shields.io/github/license/piterator-org/pyluogu)

A model-based Python implement for Luogu API client
