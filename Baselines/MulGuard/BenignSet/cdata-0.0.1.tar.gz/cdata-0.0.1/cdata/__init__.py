def info():
    return {
        'version':'v0.0.1',
        'dataModified':'2017-06-19',
        'author':'Li Ding'}
