"""__init__ file for smile package."""

# Expose some internal module for outer use.
from smile import app
from smile import flags
