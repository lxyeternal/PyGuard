
# This statement makes Registrant available to import via:
#   from Products.SignupSheet.content import Registrant



from registrant import Registrant