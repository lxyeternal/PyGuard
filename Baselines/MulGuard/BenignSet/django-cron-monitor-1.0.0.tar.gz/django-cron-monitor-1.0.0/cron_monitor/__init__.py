VERSION = (1, 0, 0)
__version__ = ".".join([str(n) for n in VERSION])
