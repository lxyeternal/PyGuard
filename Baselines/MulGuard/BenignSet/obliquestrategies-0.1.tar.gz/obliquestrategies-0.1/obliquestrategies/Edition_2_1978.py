Abandon normal instruments
Accept advice
Accretion
A line has two sides
Allow an easement (an easement is the abandonment of a stricture)
Always first steps
Always give yourself credit for having more than personality (given by Arto Lindsay)
Are there sections? Consider transitions
Ask people to work against their better judgement
Ask your body
Assemble some of the instruments in a group and treat the group
A very small object -Its centre
Balance the consistency principle with the inconsistency principle
Be dirty
Be extravagant
Breathe more deeply
Bridges -build -burn
Cascades
Change instrument roles
Change nothing and continue with immaculate consistency
Children's voices -speaking -singing
Cluster analysis
Consider different fading systems
Consult other sources -promising -unpromising
Convert a melodic element into a rhythmic element
Courage!
Cut a vital connection
Decorate, decorate
Define an area as 'safe' and use it as an anchor
Destroy -nothing -the most important thing
Discard an axiom
Disciplined self-indulgence
Disconnect from desire
Discover the recipes you are using and abandon them
Distorting time
Do nothing for as long as possible
Don't be afraid of things because they're easy to do
Don't be frightened of cliches
Don't be frightened to display your talents
Don't break the silence
Don't stress *on* thing more than another (sic)
Do something boring
Do the washing up
Do the words need changing?
Do we need holes?
Emphasise differences
Emphasise repetitions
Emphasise the flaws
Faced with a choice, do both (given by Dieter Rot)
Feed the recording back out of the medium
Fill every beat with something
Get your neck massaged
Ghost echoes
Give the game away
Give way to your worst impulse
Go outside. Shut the door.
Go slowly all the way round the outside
Honor thy error as a hidden intention
How would you have done it?
Humanise something free of error
Idiot glee (?)
Imagine the piece as a set of disconnected events
Infinitesimal gradations
Intentions -credibility of -nobility of -humility of
In total darkness, or in a very large room, very quietly
Into the impossible
Is it finished?
Is the tuning intonation correct?
Is there something missing?
It is quite possible (after all)
Just carry on
Left channel, right channel, centre channel
Listen to the quiet voice
Look at the order in which you do things
Look closely at the most embarrassing details and amplify them
Lost in useless territory
Lowest common denominator
Make a blank valuable by putting it in an exquisite frame
Make an exhaustive list of everything you might do and do the last thing on the list
Make a sudden, destructive unpredictable action; incorporate
Mechanicalise something idiosyncratic
Mute and continue
Not building a wall but making a brick
Only one element of each kind
(Organic) machinery
Overtly resist change
Put in earplugs
Question the heroic approach
Remember .those quiet evenings
Remove ambiguities and convert to specifics
Remove specifics and convert to ambiguities
Repetition is a form of change
Revaluation (a warm feeling)
Reverse
Short circuit (example; a man eating peas with the idea that they will improve his virility shovels them straight into his lap)
Simple subtraction
Simply a matter of work
Spectrum analysis
State the problem in words as simply as possible
Take a break
Take away the elements in order of apparent non-importance
Tape your mouth (given by Ritva Saarikko)
The inconsistency principle
The most important thing is the thing most easily forgotten
The tape is now the music
Think of the radio
Tidy up
Towards the insignificant
Trust in the you of now
Turn it upside down
Twist the spine
Use an old idea
Use an unacceptable colour
Use fewer notes
Use filters
Use 'unqualified' people
Water
What are the sections sections of? Imagine a caterpillar moving
What are you really thinking about just now?
What is the reality of the situation?
What mistakes did you make last time?
What would your closest friend do?
What wouldn't you do?
What would your closest friend do?
Work at a different speed
You are an engineer
You can only make one dot at a time
You don't have to be ashamed of using your own ideas