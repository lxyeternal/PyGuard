#!/usr/bin/env python
# -*- coding: utf-8 -*-

from .__version__ import __version__

VERSION = __version__
