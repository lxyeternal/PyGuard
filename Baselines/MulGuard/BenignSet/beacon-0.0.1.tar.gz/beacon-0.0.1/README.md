# beacon

Beacon collects usage and exception data from your Python production applications.

