#!/usr/bin/env python
# encoding=utf-8
name = "gzvoc"

def get(src, dst):
    pass


def check():
    pass


def gen(train=0.8, val=0):
    pass


def printoho():
    print("oho, we have done!")