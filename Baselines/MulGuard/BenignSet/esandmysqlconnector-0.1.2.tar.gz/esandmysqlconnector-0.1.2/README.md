###
Fastnext elasticsearch python package

###
Configure
	add BASE_DIR to parser fiel read in __init__.py
###
Done

