from ConfigParser import SafeConfigParser


class MysqlClient:

    def __init__(self):
        pass

