def none_check(value):
    if value is None:
        return False
    else:
        return True


def is_empty(any_type_value):
    if any_type_value:
        return False
    else:
        return True
