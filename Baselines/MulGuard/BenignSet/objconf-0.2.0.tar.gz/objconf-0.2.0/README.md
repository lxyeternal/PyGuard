# Objconf
`objconf` provides an object configuration for Python projects.
It allows to access your configuration values as attributes. It also adds type conversions and type checks.

