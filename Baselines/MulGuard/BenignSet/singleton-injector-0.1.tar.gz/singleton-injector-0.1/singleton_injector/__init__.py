from singleton_injector.singleton import Singleton
from singleton_injector.injector import Injector

injector = Injector(Singleton())
