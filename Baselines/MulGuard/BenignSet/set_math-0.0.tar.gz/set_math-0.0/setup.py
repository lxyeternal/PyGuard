from setuptools import setup

setup(name='set_math',
      version='0.0',
      description='calculation of algebraic sets',
      packages=['C:/Users/Алексей/PycharmProjects/Set_math'],
      author_email='ggammi1007@yandex.ru',
      zip_safe=False)