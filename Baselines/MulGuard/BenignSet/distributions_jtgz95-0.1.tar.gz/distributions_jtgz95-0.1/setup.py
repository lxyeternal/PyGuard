from setuptools import setup

setup(name='distributions_jtgz95',
      version='0.1',
      description='Gaussian and bionomial distributions',
      packages=['distributions_jtgz95'],
      author_email = "myemail@email.com",
      zip_safe=False)
