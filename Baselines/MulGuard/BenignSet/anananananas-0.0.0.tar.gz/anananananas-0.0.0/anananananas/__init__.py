def print_me_some_anas(number_of_anas):
    return "ana" * number_of_anas