from setuptools import setup, find_packages

setup(name="anananananas", packages=find_packages())
