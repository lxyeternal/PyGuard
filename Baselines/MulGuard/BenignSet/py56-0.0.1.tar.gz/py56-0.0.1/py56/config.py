APPKEY = ''
SECRET = ''
DOMAIN = 'http://oapi.56.com'
