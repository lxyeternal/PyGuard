#from distutils.core import setup
from setuptools import setup, find_packages

setup(
    name         = 'py56',
    version      = '0.0.1',
    author       = 'Allan Sun',
    author_email = 'alnsun.cn@gmail.com',
    url          = 'https://pythoner.cn',
    description  = 'Python module for 56 (56Video)',
    packages     = find_packages()
)
