c2cgeoportal application
========================

c2cgeoportal is the server part of `GeoMapFish <http://geomapfish.org/>`_,
the client part is `ngeo <https://github.com/camptocamp/ngeo/>`_,
the old client and API part is `CGXP <https://github.com/camptocamp/cgxp/>`_.

Read the `Documentation <https://camptocamp.github.io/c2cgeoportal/master/>`_.
