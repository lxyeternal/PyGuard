This package is a Python version of MATLAB TOOLBOX -- SOSTOOLS. 

This package contains functions based on **sympy** package. However, in case of a large number of decision variables, **sympy** may take a long time to parse the data.

Demos are in the folder SOSPy/SOSPy_demos.
