Please see our on-line docs for detailed instructions, examples, support forums, etc.:

http://simplegeo.com/docs/clients-code-libraries/python


See also these other two libraries:


https://github.com/simplegeo/python-simplegeo-shared

http://pypi.python.org/pypi/simplegeo-shared


https://github.com/simplegeo/python-simplegeo-context

http://pypi.python.org/pypi/simplegeo-context
