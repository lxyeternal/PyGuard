

class ClassD(object):
    def __init__(self):
        self.x = "D"

class ClassE(object):
    def __init__(self):
        self.x = "E"

class ClassF(object):
    def __init__(self):
        self.x = "F"


