from KarateClub.NonOverlapping import ClassA, ClassB, ClassC
from KarateClub.Overlapping import ClassD, ClassE, ClassF

