import numpy as np

class ClassA(object):
    def __init__(self):
        self.x = "A"
        self.y = np.ones(5)

class ClassB(object):
    def __init__(self):
        self.x = "B"

class ClassC(object):
    def __init__(self):
        self.x = "C"


