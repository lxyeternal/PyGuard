#!/usr/bin/env python
# coding: utf-8

# Copyright (c) tjdevries.
# Distributed under the terms of the Modified BSD License.

from jupyter_ascending._version import __version__
from jupyter_ascending._version import version_info
from jupyter_ascending.extension import load_ipython_extension
from jupyter_ascending.extension import load_jupyter_server_extension
from jupyter_ascending.nbextension import _jupyter_nbextension_paths
from jupyter_ascending.widget import SyncWidget

__all__ = [
    "SyncWidget",
    "__version__",
    "_jupyter_nbextension_paths",
    "load_ipython_extension",
    "load_jupyter_server_extension",
    "version_info",
]
