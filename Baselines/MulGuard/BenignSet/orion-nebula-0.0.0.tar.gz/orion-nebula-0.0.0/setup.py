

from setuptools import setup

setup(
   name='orion-nebula',
   version='0.0.0',
   description='',
   author='Open Orion',
   author_email='',
   packages=['nebula'],
   install_requires=[

   ]
)