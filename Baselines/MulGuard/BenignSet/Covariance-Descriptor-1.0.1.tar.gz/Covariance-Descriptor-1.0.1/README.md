requires:
    numpy>=1.16.2
    cv2>=0.3
    scipy>=3.4.2