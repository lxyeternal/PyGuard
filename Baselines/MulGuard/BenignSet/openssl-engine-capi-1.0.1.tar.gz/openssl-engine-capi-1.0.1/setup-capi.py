from setup_init import *

setup(name='openssl-engine-capi',
      version='1.0.1',
      description='Python capi openssl engine support and utility methods to set a default for urllib3 and pip',
      install_requires=["openssl_engine"],
     )