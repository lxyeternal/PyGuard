from mastercurves import MasterCurve
