# mastercurves
Python package for automatically superimposing data sets to create a master curve, using Gaussian process regression and maximum a posteriori estimation.
