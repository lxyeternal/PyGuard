# cas

## Developer Guide

Clone this repo.

## Install & Run Server
1. `pip install cas/server`
2. Run server: `python -m clip_server`

## Install & Run Server
1. `pip install cas/client`
2. Run:
