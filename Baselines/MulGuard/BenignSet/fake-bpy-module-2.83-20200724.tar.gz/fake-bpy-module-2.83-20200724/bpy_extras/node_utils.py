import sys
import typing


def find_node_input(node, name):
    ''' 

    '''

    pass
