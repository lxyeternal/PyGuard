import sys
import typing


def addon_keymap_register(keymap_data):
    ''' Register a set of keymaps for addons using a list of keymaps. See 'blender_defaults.py' for examples of the format this takes.

    '''

    pass


def addon_keymap_unregister(keymap_data):
    ''' Unregister a set of keymaps for addons.

    '''

    pass


def keyconfig_test(kc):
    ''' 

    '''

    pass
