import sys
import typing


def write_sysinfo(filepath):
    ''' 

    '''

    pass
