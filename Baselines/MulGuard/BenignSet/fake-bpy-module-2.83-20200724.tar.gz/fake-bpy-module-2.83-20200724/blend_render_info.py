import sys
import typing


def main():
    ''' 

    '''

    pass


def read_blend_rend_chunk(path):
    ''' 

    '''

    pass
