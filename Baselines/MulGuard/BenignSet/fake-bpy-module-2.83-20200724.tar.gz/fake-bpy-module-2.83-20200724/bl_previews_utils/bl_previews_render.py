import sys
import typing


def do_clear_previews(do_objects, do_collections, do_scenes, do_data_intern):
    ''' 

    '''

    pass


def do_previews(do_objects, do_collections, do_scenes, do_data_intern):
    ''' 

    '''

    pass


def ids_nolib(bids):
    ''' 

    '''

    pass


def main():
    ''' 

    '''

    pass


def rna_backup_gen(data, include_props, exclude_props, root):
    ''' 

    '''

    pass


def rna_backup_restore(data, backup):
    ''' 

    '''

    pass
