import sys
import typing


class DataPathBuilder:
    data_path = None
    ''' '''

    def resolve(self, real_base, rna_update_from_map, fcurve, log):
        ''' 

        '''
        pass


def anim_data_actions(anim_data):
    ''' 

    '''

    pass


def classes_recursive(base_type, clss):
    ''' 

    '''

    pass


def drepr(string):
    ''' 

    '''

    pass


def find_path_new(id_data, data_path, rna_update_from_map, fcurve, log):
    ''' 

    '''

    pass


def id_iter():
    ''' 

    '''

    pass


def update_data_paths(rna_update, log):
    ''' 

    '''

    pass
