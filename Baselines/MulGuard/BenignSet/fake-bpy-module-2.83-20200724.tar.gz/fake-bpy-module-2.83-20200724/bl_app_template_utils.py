import sys
import typing


def activate(template_id):
    ''' 

    '''

    pass


def import_from_id(template_id, ignore_not_found):
    ''' 

    '''

    pass


def import_from_path(path, ignore_not_found):
    ''' 

    '''

    pass


def reset(reload_scripts):
    ''' 

    '''

    pass
