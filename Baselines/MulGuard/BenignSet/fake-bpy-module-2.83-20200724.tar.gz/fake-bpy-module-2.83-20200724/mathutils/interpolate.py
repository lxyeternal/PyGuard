import sys
import typing


def poly_3d_calc(veclist, pt):
    ''' Calculate barycentric weights for a point on a polygon.

    '''

    pass
