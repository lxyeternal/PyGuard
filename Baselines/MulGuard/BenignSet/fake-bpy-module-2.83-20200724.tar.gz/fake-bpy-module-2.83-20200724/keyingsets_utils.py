import sys
import typing


def RKS_GEN_available(_ksi, _context, ks, data):
    ''' 

    '''

    pass


def RKS_GEN_bendy_bones(_ksi, _context, ks, data):
    ''' 

    '''

    pass


def RKS_GEN_location(_ksi, _context, ks, data):
    ''' 

    '''

    pass


def RKS_GEN_rotation(_ksi, _context, ks, data):
    ''' 

    '''

    pass


def RKS_GEN_scaling(_ksi, _context, ks, data):
    ''' 

    '''

    pass


def RKS_ITER_selected_bones(ksi, context, ks):
    ''' 

    '''

    pass


def RKS_ITER_selected_item(ksi, context, ks):
    ''' 

    '''

    pass


def RKS_ITER_selected_objects(ksi, context, ks):
    ''' 

    '''

    pass


def RKS_POLL_selected_bones(_ksi, context):
    ''' 

    '''

    pass


def RKS_POLL_selected_items(ksi, context):
    ''' 

    '''

    pass


def RKS_POLL_selected_objects(_ksi, context):
    ''' 

    '''

    pass


def get_transform_generators_base_info(data):
    ''' 

    '''

    pass


def path_add_property(path, prop):
    ''' 

    '''

    pass
