import sys
import typing


def url_prefill_from_blender(addon_info):
    ''' 

    '''

    pass
