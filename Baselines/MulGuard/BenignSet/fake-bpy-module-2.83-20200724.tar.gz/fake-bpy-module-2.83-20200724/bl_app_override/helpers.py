import sys
import typing


class AppOverrideState:
    addon_paths = None
    ''' '''

    addons = None
    ''' '''

    class_ignore = None
    ''' '''

    ui_ignore_classes = None
    ''' '''

    ui_ignore_label = None
    ''' '''

    ui_ignore_menu = None
    ''' '''

    ui_ignore_operator = None
    ''' '''

    ui_ignore_property = None
    ''' '''

    def setup(self):
        ''' 

        '''
        pass

    def teardown(self):
        ''' 

        '''
        pass
