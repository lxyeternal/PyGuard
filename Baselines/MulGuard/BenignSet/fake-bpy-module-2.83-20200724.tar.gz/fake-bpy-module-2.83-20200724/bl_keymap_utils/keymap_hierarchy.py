import sys
import typing


def generate():
    ''' 

    '''

    pass
