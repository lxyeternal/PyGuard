import sys
import typing


def keyconfig_data_oskey_from_ctrl(keyconfig_data_src, filter_fn):
    ''' 

    '''

    pass


def keyconfig_data_oskey_from_ctrl_for_macos(keyconfig_data_src):
    ''' 

    '''

    pass
