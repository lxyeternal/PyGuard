import sys
import typing


def generate(context, space_type, use_fallback_keys, use_reset):
    ''' 

    '''

    pass
