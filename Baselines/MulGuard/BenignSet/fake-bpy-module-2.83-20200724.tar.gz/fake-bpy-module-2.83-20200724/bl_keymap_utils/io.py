import sys
import typing


def indent(levels):
    ''' 

    '''

    pass


def keyconfig_export_as_data(wm, kc, filepath, all_keymaps):
    ''' 

    '''

    pass


def keyconfig_import_from_data(name, keyconfig_data):
    ''' 

    '''

    pass


def keyconfig_init_from_data(kc, keyconfig_data):
    ''' 

    '''

    pass


def keyconfig_merge(kc1, kc2):
    ''' 

    '''

    pass


def keymap_init_from_data(km, km_items, is_modal):
    ''' 

    '''

    pass


def kmi_args_as_data(kmi):
    ''' 

    '''

    pass


def repr_f32(f):
    ''' 

    '''

    pass


def round_float_32(f):
    ''' 

    '''

    pass
