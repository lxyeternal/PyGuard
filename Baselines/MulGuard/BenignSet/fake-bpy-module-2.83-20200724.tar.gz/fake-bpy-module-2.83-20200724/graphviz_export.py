import sys
import typing


def compat_str(text, line_length):
    ''' 

    '''

    pass


def graph_armature(obj, filepath, FAKE_PARENT, CONSTRAINTS, DRIVERS,
                   XTRA_INFO):
    ''' 

    '''

    pass
