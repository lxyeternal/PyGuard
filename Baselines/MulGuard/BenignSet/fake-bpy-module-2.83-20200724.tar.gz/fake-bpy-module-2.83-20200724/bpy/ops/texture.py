import sys
import typing


def new():
    ''' Add a new texture

    '''

    pass


def slot_copy():
    ''' Copy the material texture settings and nodes

    '''

    pass


def slot_move(type: typing.Union[str, int] = 'UP'):
    ''' Move texture slots up and down

    :param type: Type
    :type type: typing.Union[str, int]
    '''

    pass


def slot_paste():
    ''' Copy the texture settings and nodes

    '''

    pass
