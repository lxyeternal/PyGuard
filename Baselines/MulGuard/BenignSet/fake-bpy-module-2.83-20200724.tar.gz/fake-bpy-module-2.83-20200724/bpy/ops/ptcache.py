import sys
import typing


def add():
    ''' Add new cache

    '''

    pass


def bake(bake: bool = False):
    ''' Bake physics

    :param bake: Bake
    :type bake: bool
    '''

    pass


def bake_all(bake: bool = True):
    ''' Bake all physics

    :param bake: Bake
    :type bake: bool
    '''

    pass


def bake_from_cache():
    ''' Bake from cache

    '''

    pass


def free_bake():
    ''' Delete physics bake

    '''

    pass


def free_bake_all():
    ''' Delete all baked caches of all objects in the current scene

    '''

    pass


def remove():
    ''' Delete current cache

    '''

    pass
