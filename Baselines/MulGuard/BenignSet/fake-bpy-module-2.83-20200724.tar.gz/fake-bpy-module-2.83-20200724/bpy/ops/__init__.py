import sys
import typing
from . import anim
from . import fluid
from . import lattice
from . import transform
from . import import_scene
from . import ed
from . import cycles
from . import info
from . import camera
from . import texture
from . import text
from . import cloth
from . import view2d
from . import constraint
from . import import_curve
from . import armature
from . import node
from . import outliner
from . import action
from . import pose
from . import gizmogroup
from . import world
from . import object
from . import render
from . import ptcache
from . import paintcurve
from . import curve
from . import palette
from . import script
from . import scene
from . import image
from . import safe_areas
from . import file
from . import preferences
from . import gpencil
from . import brush
from . import dpaint
from . import particle
from . import ui
from . import sound
from . import sequencer
from . import export_anim
from . import nla
from . import surface
from . import workspace
from . import import_anim
from . import graph
from . import paint
from . import export_mesh
from . import font
from . import export_scene
from . import rigidbody
from . import console
from . import cachefile
from . import marker
from . import import_mesh
from . import uv
from . import sculpt
from . import boid
from . import screen
from . import buttons
from . import material
from . import clip
from . import poselib
from . import collection
from . import mesh
from . import mball
from . import mask
from . import wm
from . import view3d


class BPyOps:
    pass


class BPyOpsSubMod:
    pass


class BPyOpsSubModOp:
    def get_rna_type(self):
        ''' 

        '''
        pass

    def idname(self):
        ''' 

        '''
        pass

    def idname_py(self):
        ''' 

        '''
        pass

    def poll(self, args):
        ''' 

        '''
        pass
