import sys
import typing


def copy():
    ''' Copy the material settings and nodes

    '''

    pass


def new():
    ''' Add a new material

    '''

    pass


def paste():
    ''' Paste the material settings and nodes

    '''

    pass
