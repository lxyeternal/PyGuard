import sys
import typing


def new():
    ''' Create a new world Data-Block

    '''

    pass
