import sys
import typing


def build_property_typemap(skip_classes, skip_typemap):
    ''' 

    '''

    pass


def print_ln(data):
    ''' 

    '''

    pass


def rna2xml(fw, root_node, root_rna, root_rna_skip, root_ident, ident_val,
            skip_classes, skip_typemap, pretty_format, method):
    ''' 

    '''

    pass


def xml2rna(root_xml, root_rna):
    ''' 

    '''

    pass


def xml_file_run(context, filepath, rna_map):
    ''' 

    '''

    pass


def xml_file_write(context, filepath, rna_map, skip_typemap):
    ''' 

    '''

    pass
