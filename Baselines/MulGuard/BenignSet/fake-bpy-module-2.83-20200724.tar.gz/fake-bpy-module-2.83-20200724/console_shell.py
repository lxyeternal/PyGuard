import sys
import typing


def add_scrollback(text, text_type):
    ''' 

    '''

    pass


def autocomplete(_context):
    ''' 

    '''

    pass


def banner(context):
    ''' 

    '''

    pass


def execute(context, _is_interactive):
    ''' 

    '''

    pass


def shell_run(text):
    ''' 

    '''

    pass
