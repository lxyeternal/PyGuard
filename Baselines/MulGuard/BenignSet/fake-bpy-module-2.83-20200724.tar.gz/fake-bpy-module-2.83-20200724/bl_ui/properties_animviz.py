import sys
import typing


class MotionPathButtonsPanel:
    bl_label = None
    ''' '''

    bl_region_type = None
    ''' '''

    bl_space_type = None
    ''' '''

    def draw_settings(self, _context, avs, mpath, bones):
        ''' 

        '''
        pass


class MotionPathButtonsPanel_display:
    bl_label = None
    ''' '''

    bl_region_type = None
    ''' '''

    bl_space_type = None
    ''' '''

    def draw_settings(self, _context, avs, mpath, bones):
        ''' 

        '''
        pass
