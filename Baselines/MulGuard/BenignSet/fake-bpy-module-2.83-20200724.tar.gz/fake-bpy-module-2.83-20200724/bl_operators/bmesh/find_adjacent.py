import sys
import typing


def edges_from_elem(ele):
    ''' 

    '''

    pass


def elems_depth_measure(ele_dst, ele_src, other_edges_over_cb):
    ''' 

    '''

    pass


def elems_depth_search(ele_init, depths, other_edges_over_cb, results_init):
    ''' 

    '''

    pass


def find_next(ele_dst, ele_src):
    ''' 

    '''

    pass


def other_edges_over_edge(e):
    ''' 

    '''

    pass


def other_edges_over_face(e):
    ''' 

    '''

    pass


def select_next(bm, report):
    ''' 

    '''

    pass


def select_prev(bm, report):
    ''' 

    '''

    pass


def verts_from_elem(ele):
    ''' 

    '''

    pass
