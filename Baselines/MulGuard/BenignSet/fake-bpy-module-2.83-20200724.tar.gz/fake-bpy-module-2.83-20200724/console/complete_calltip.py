import sys
import typing


def complete(line, cursor, namespace):
    ''' 

    '''

    pass


def get_argspec(func, strip_self, doc, source):
    ''' 

    '''

    pass


def get_doc(obj):
    ''' 

    '''

    pass


def reduce_newlines(text):
    ''' 

    '''

    pass


def reduce_spaces(text):
    ''' 

    '''

    pass
