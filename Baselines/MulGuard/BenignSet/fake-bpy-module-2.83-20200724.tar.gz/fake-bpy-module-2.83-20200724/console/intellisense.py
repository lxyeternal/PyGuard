import sys
import typing


def complete(line, cursor, namespace, private):
    ''' 

    '''

    pass


def expand(line, cursor, namespace, private):
    ''' 

    '''

    pass
