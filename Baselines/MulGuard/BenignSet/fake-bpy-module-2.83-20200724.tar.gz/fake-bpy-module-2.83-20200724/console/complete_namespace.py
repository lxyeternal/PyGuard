import sys
import typing


def complete(word, namespace, private):
    ''' 

    '''

    pass


def complete_indices(word, namespace, obj, base):
    ''' 

    '''

    pass


def complete_names(word, namespace):
    ''' 

    '''

    pass


def is_dict(obj):
    ''' 

    '''

    pass


def is_struct_seq(obj):
    ''' 

    '''

    pass
