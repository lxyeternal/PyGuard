import sys
import typing


def gen_menu_file(stats, settings):
    ''' 

    '''

    pass
