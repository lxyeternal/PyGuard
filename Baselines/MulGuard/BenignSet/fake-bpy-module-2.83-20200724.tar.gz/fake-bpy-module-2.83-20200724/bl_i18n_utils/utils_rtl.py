import sys
import typing


def log2vis(msgs, settings):
    ''' 

    '''

    pass


def protect_format_seq(msg):
    ''' 

    '''

    pass
