import sys
import typing


def check(check_ctxt, msgs, key, msgsrc, settings):
    ''' 

    '''

    pass


def dump_addon_messages(module_name, do_checks, settings):
    ''' 

    '''

    pass


def dump_messages(do_messages, do_checks, settings):
    ''' 

    '''

    pass


def dump_py_messages(msgs, reports, addons, settings, addons_only):
    ''' 

    '''

    pass


def dump_py_messages_from_files(msgs, reports, files, settings):
    ''' 

    '''

    pass


def dump_rna_messages(msgs, reports, settings, verbose):
    ''' 

    '''

    pass


def dump_src_messages(msgs, reports, settings):
    ''' 

    '''

    pass


def init_spell_check(settings, lang):
    ''' 

    '''

    pass


def main():
    ''' 

    '''

    pass


def print_info(reports, pot):
    ''' 

    '''

    pass


def process_msg(msgs, msgctxt, msgid, msgsrc, reports, check_ctxt, settings):
    ''' 

    '''

    pass
