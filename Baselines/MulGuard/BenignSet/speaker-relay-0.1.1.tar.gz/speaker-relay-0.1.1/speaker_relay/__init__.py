__version__ = '0.1.0'

from .main import main

___all___ = [main]