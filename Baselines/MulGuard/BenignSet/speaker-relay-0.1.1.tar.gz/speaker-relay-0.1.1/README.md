Streaming loopback audio through websocket to another device.

AudioContext is used. Tested with Chrome. 
