def hello():
    print("Hello package manager! I am ready")