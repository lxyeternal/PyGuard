# python-simple-package-demo
This is a sample packaging files to understand the structure and execution of python project
