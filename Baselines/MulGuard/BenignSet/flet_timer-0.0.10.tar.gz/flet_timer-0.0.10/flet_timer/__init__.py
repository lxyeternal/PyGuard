"""Top-level package for Flet Timer."""

__author__ = """Panos Stavrianos"""
__email__ = 'panos@orbitsystems.gr'
__version__ = '0.0.10'

