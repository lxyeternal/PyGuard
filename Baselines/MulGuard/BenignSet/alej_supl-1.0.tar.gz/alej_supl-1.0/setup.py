import setuptools

setuptools.setup(
    name="alej_supl",
    version="1.0",
    description="A very simple cli program that shows supplementation for Gymnazium Nad Aleji school",
    packages=setuptools.find_packages(),
    url="https://github.com/kockahonza/alej_supl",
)
