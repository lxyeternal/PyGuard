=========================
GeomCompare documentation
=========================

.. This is the documentation of **Geomcompare**.

Contents
========

.. toctree::
   :maxdepth: 2

   Overview <readme>
   Getting Started <gettingstarted>
   API <api>
   Contributions & Help <contributing>
   License <license>
   Authors <authors>
   Changelog <changelog>
   Module Reference <api/modules>


Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`
