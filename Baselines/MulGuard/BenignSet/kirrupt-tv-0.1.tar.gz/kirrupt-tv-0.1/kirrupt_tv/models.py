class UserShow:
    pass


class Episode:
    pass


class Show:
    pass
