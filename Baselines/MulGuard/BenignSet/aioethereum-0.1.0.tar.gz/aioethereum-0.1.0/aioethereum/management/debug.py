import asyncio


class DebugMixin:
    pass
