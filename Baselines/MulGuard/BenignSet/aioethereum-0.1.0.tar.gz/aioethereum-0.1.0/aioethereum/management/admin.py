import asyncio


class AdminMixin:
    pass
