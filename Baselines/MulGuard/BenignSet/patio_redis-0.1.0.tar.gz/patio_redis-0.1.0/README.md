PATIO Redis
===========

PATIO is an acronym for **P**ython **A**synchronous **T**ask for Async**IO**.

This package provides Redis broker implementation.

