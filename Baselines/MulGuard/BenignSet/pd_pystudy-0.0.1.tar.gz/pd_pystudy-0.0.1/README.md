# shpystudy

This is a package for Shanghai student to use python. You can use
[Github-flavored Markdown](https://guides.github.com/features/mastering-markdown/)
to write your content.