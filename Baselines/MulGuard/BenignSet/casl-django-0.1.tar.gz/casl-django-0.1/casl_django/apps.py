from django.apps import AppConfig


class CaslDjangoConfig(AppConfig):
    name = 'casl_django'
