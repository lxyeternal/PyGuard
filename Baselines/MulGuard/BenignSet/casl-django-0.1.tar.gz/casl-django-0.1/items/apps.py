from django.apps import AppConfig


class ItemsConfig(AppConfig):
    name = 'items'
