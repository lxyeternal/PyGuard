#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""cong-lingdao-yi-goujian-jiyu-fabric-sdk-node-de-xiangmu-kaifa-shizhan
https://github.com/apachecn/cong-lingdao-yi-goujian-jiyu-fabric-sdk-node-de-xiangmu-kaifa-shizhan"""

__author__ = "ApacheCN"
__email__ = "apachecn@163.com"
__license__ = "CC BY-NC-SA 4.0"
__version__ = "2024.3.5.0"