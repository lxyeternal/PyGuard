# 从零到壹构建基于fabric-sdk-node的项目开发实战

## 下载

### Docker

```
docker pull apachecn0/cong-lingdao-yi-goujian-jiyu-fabric-sdk-node-de-xiangmu-kaifa-shizhan
docker run -tid -p <port>:80 apachecn0/cong-lingdao-yi-goujian-jiyu-fabric-sdk-node-de-xiangmu-kaifa-shizhan
# 访问 http://localhost:{port} 查看文档
```

### PYPI

```
pip install cong-lingdao-yi-goujian-jiyu-fabric-sdk-node-de-xiangmu-kaifa-shizhan
cong-lingdao-yi-goujian-jiyu-fabric-sdk-node-de-xiangmu-kaifa-shizhan <port>
# 访问 http://localhost:{port} 查看文档
```

### NPM

```
npm install -g cong-lingdao-yi-goujian-jiyu-fabric-sdk-node-de-xiangmu-kaifa-shizhan
cong-lingdao-yi-goujian-jiyu-fabric-sdk-node-de-xiangmu-kaifa-shizhan <port>
# 访问 http://localhost:{port} 查看文档
```