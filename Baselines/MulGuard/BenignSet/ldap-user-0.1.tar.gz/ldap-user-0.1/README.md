# mysqldb_rich

## 2.4
DB add function link

## 2.2
fix db2.DB not commit

## 2.1
解决两个连接使用不同数据库问题

## 2.0
AUTO_CLOSE default is False

## 1.9
add execute_select_left

## 1.8
add RichDB

## 1.6
fix bug in TableDB

## 0.1
rich operation for mysql 