# mathsfunlib
Maths tables speed test questions generator library
