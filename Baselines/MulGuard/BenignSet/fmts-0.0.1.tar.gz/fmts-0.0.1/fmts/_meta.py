# -*- coding: utf-8 -*-
"""Package metadata/info"""

__title__ = "fmts"
__description__ = "str transformation utils"
__pkgroot__ = __file__.replace("_meta.py", "").rstrip("/\\")
__version__ = "0.0.1"
