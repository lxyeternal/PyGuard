

# 定义一个函数来给url添加标签
def add_link(url):
    return f'<a href="{url}">{url}</a>'


def add_div_link(url):
    return f'<div class="td-link"><a href="{url}">{url}</a></div>'