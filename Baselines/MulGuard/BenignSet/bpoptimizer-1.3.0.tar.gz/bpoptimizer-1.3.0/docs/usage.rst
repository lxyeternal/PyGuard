=====
Usage
=====

To use BlockParty Floor Optimizer in a project::

    import bpoptimizer
