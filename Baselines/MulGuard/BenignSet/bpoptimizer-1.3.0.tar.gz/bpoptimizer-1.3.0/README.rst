==========================
BlockParty Floor Optimizer
==========================


.. image:: https://img.shields.io/pypi/v/bpoptimizer.svg
        :target: https://pypi.python.org/pypi/bpoptimizer

.. image:: https://img.shields.io/travis/RadioactiveDroid/bpoptimizer.svg
        :target: https://travis-ci.org/RadioactiveDroid/bpoptimizer

.. image:: https://readthedocs.org/projects/bpoptimizer/badge/?version=latest
        :target: https://bpoptimizer.readthedocs.io/en/latest/?badge=latest
        :alt: Documentation Status




This package allows for reading a BlockParty floor as a 48x48 pixel image and provides analytics including optimized standing positions.


* Free software: MIT license
* Documentation: https://bpoptimizer.readthedocs.io.


Features
--------

* TODO

Credits
-------

This package was created with Cookiecutter_ and the `audreyr/cookiecutter-pypackage`_ project template.

.. _Cookiecutter: https://github.com/audreyr/cookiecutter
.. _`audreyr/cookiecutter-pypackage`: https://github.com/audreyr/cookiecutter-pypackage
