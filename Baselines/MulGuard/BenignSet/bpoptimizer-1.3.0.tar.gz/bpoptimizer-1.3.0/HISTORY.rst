=======
History
=======

0.1.0 (2020-01-21)
------------------

* First release on PyPI.
