"""Top-level package for BlockParty Floor Optimizer."""

__author__ = """RadioactiveDroid"""
__email__ = "radioactivedroid@gmail.com"
__version__ = "1.3.0"


from .floor import Floor
