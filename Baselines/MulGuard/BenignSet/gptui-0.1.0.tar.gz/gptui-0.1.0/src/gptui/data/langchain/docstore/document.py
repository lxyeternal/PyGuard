from ..schema import Document

__all__ = ["Document"]
