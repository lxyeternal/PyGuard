def hello():
    return (u"Hello there")