from setuptools import setup

setup(name='qtxdbpackages',
      version='1.0',
      description='database connection strings',
      url='http://github.com/storborg/funniest',
      author='Flying Circus',
      author_email='flyingcircus@example.com',
      license='MIT',
      packages=['qtxdbpackage'],
      zip_safe=False)
