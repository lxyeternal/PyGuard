from .spa import SinglePageApp
