=======
History
=======

0.0.1 (2021-01-26)
------------------

* First release on PyPI.
