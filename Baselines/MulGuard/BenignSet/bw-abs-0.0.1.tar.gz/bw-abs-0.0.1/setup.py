from distutils.core import setup

setup(
    name="bw-abs",
    version="0.0.1",
    description="Placekeeper package for security purposes",
    author="Ville M. Vainio",
    author_email="ville.vainio@basware.com",
    url="https://github.com/vivainio/scaffer-templates",
    packages=["bwade"],
    install_requires=[],
)
