# coding: utf-8

from __future__ import unicode_literals
from sqlalchemy.ext.declarative import declarative_base


DbModel = declarative_base()
