Authors
=======

- James Collins <collijk@uw.edu>
- Michelle Park <hpark3@uw.edu>
- Kate Wilson <kwilson7@uw.edu>
- Cody Horst <chorst@uw.edu>
- Abraham Flaxman <abie@uw.edu>

Current Maintainers
-------------------

- James Collins <collijk@uw.edu>
- Michelle Park <hpark3@uw.edu>
- Cody Horst <chorst@uw.edu>
- Kate Wilson <kwilson7@uw.edu>
- Abraham Flaxman <abie@uw.edu>
