Risk Distributions
======================

This library contains various distributions, compatible for use with ``Vivarium``.

You can install ``risk_distributions`` from PyPI with pip:

  ``> pip install risk_distributions``

or build it from source with

  ``> git clone https://github.com/ihmeuw/risk_distributions.git``

  ``> cd risk_distributions``

  ``> python setup.py install``


