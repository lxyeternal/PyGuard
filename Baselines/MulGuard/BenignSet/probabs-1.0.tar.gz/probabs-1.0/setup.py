from setuptools import setup

setup(name = 'probabs',
      version = '1.0',
      description = 'Gaussian and Binomial distributions',
      packages = ['probabs'],
      author = 'Ankur Chourasia',
      author_email = 'chourasia.ankur1@gmail.com',
      zip_safe = False)
