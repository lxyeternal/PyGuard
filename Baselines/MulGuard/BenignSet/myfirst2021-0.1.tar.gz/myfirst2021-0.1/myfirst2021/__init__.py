# __init__.py
from myfirst2021.studentclass import Student,Specialstudent

