# This is a folder for stuff which I haven't decided on where to 
# put yet. These locations are not intended to be permanent. (But 
# probably will be)
