"""Pylux is a suite for the management of lighting documentation"""
import os

_ROOT = os.path.abspath(os.path.dirname(__file__))
