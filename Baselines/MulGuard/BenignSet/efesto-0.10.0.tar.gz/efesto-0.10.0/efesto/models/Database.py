# -*- coding: utf-8 -*-
from peewee import PostgresqlDatabase


db = PostgresqlDatabase(None)
