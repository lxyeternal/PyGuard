# -*- coding: utf-8 -*-
version = '0.10.0'
