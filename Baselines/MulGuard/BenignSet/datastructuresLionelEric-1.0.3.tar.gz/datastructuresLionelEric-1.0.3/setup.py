from setuptools import find_packages, setup
setup (
name = 'datastructuresLionelEric',
packages=find_packages(include = ['datastructures.Linear', 'datastructures.Nodes', 'datastructures.Trees ']), 
version='1.0.3', 
description='datastructures',
author = 'Lionel Eric',
author_email = "lionel.hasan@ucalgary.ca",
)