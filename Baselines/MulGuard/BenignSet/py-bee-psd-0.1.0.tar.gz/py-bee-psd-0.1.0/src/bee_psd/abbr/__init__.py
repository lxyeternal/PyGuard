#!/usr/bin/env python
# -*- coding: utf-8 -*-
__author__ = 'wenchao.hao'

"""
db.psd.abbr package.
"""
from .abbr import *