from bee_psd.connection.connection import IConnection


class Builder():

    def build_conn(self) -> IConnection:
        pass
