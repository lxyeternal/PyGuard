#!/usr/bin/env python
# -*- coding: utf-8 -*-
__author__ = 'wenchao.hao'

"""
db.psd.connection package. is a model which wrapped db's connection
"""
