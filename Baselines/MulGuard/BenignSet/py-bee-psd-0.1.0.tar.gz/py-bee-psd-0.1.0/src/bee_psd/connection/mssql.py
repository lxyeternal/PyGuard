#
# from db.psd.connection.connection import IConnection
#
#
# class MssqlConnection(IConnection):
#     def __init__(self, conn=Connection()):
#         self.conn = conn
#
#     def exec(self, Query, *args):
#         self.conn
#
#     def find_one(self, Query, *args):
#         pass
#
#     def find_list(self, Query, *args):
#         pass
