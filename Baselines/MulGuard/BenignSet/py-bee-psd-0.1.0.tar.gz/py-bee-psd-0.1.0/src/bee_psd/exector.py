class IExecutor():

    def exec(self, query, args=[]):
        pass

    def find_one(self, query, args=[]):
        pass

    def find_list(self, query, args=[]):
        pass
