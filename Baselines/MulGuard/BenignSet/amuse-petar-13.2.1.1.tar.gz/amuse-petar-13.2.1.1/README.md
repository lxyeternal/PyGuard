This package installs the PeTar community code for AMUSE.
