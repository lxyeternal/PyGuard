from .simplekivy import SimpleKivy
