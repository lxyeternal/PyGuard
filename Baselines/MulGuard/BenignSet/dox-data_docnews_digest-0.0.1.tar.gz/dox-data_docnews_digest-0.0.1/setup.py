import setuptools

setuptools.setup(
    name="dox-data_docnews_digest",
    version="0.0.1",
    packages=setuptools.find_packages(),
)
