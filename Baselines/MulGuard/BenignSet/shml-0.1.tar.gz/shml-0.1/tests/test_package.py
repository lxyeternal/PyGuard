import shml as m


def test_version():
    assert m.__version__
