$(document).ready(function () {
    InitBuildRequest();
});