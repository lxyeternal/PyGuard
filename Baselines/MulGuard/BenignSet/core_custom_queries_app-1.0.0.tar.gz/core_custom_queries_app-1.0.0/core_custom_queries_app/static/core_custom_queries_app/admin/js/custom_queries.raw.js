var listQueriesUrl = "{% url 'admin:core_custom_queries_app_queries' %}" ;
var deleteQueryUrl = "{% url 'admin:core_custom_queries_app_delete_query' %}" ;