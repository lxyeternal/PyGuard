default_app_config = 'core_custom_queries_app.apps.CustomQueriesAppConfig'

