""" Rights for core custom queries app
"""

custom_queries_content_type = "core_custom_queries_app"
custom_queries_access = "access_custom_queries"
