# -*- coding: utf-8 -*-

def func(x):  
    return x+1  
  
def test_func():  
    assert func(3) == 4