pii
---

|py3|

.. |py3| image:: https://img.shields.io/badge/python-3-blue.svg

Bugs/Requests
-------------

Please use the `GitHub issue tracker`_ to submit bugs or request features.

.. _`GitHub issue tracker`: https://github.com/kprzybyla/pii/issues

License
-------

Copyright Krzysztof Przybyła, 2021.

Distributed under the terms of the `MIT`_ license.

.. _`MIT`: https://github.com/kprzybyla/pii/blob/master/LICENSE
