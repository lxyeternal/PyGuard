from setuptools import setup


def main():
    setup()


if __name__ == "__main__":
    main()
