"""Top-level package for camonline."""

__author__ = "wh1isper"
__email__ = "9573586@qq.com"
__version__ = "0.1.0"
