class ConfigError(Exception):
    pass


class ConfigFileNotFoundError(ConfigError):
    pass
