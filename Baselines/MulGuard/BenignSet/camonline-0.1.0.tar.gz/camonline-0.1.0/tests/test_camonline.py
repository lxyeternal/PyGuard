import pytest


def test_camonline():
    assert True


if __name__ == "__main__":
    pytest.main()
