$(document).ready(function() {
    var gallery = $('#thumbs').galleriffic({
	imageContainerSel:         '#slideshow',
	controlsContainerSel:      '#controls',
	captionContainerSel:       '#caption',
	numThumbs:		   10,
    });
});

