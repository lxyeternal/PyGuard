This package installs the SWAN community code for OMUSE.

SWAN is a third-generation wave model, developed at Delft University of Technology, that computes random, short-crested wind-generated waves in coastal regions and inland waters.

The latest version of SWAN can be found at [here](http://swanmodel.sourceforge.net)
