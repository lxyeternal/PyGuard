from setuptools import setup

setup(name='distributions12',
      version='0.1',
      description='Gaussian and Bionomial distributions',
      packages=['distributions12'],
      author = "abc",
      zip_safe=False)
