#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
Copyright (c) 2022 Baidu.com, Inc. All Rights Reserved
"""
from __future__ import absolute_import

from baiduads_manual.oauth.api.oauth_service import OAuthService
