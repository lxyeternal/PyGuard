# learncloudops-awsutils

Useful object oriented abstractions of commonly used utilities for building Python serverless or container based projects in AWS.

## Utlities

TODO Document the utilities here.