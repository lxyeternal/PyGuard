# a simple file that does nothing other than extend
# a hello to users

def greeting(name:str) -> str:
    return f'Hello {name}!'