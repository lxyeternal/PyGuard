# kronos

![Versions](https://img.shields.io/badge/python->3.7-blue)
[![Documentation Status](https://readthedocs.org/projects/sdss-kronos/badge/?version=latest)](https://sdss-kronos.readthedocs.io/en/latest/?badge=latest)
[![Travis (.org)](https://img.shields.io/travis/sdss/kronos)](https://travis-ci.org/sdss/kronos)
[![codecov](https://codecov.io/gh/sdss/kronos/branch/main/graph/badge.svg)](https://codecov.io/gh/sdss/kronos)

robot scheduling app for SDSS V

Much of this package is based off the [Material Dashboard template](https://github.com/creativetimofficial/material-dashboard). Portions borrowed from this template are licensed under an MIT license.
