"""
surfing_pylib
~~~~~
surfing_pylib is a simple python lib
"""

__author__ = 'surfing'
__version__ = '0.0.1'