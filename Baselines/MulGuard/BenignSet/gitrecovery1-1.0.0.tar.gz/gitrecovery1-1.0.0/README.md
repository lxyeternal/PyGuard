# Gitrecover
### RECOVER YOUR FILES

A simple python recovery tool for git 

### Getting Started

Gitrecover was written for python 3

All you need to do is 
    
    from recover import RecoverFile
    files = RecoverFile()
    files.recover_git_files()
