from .discord_logging import Discord_Handler
name = "discord_handler"
