class PremiumBondCheckerException(BaseException):
    pass


class InvalidHolderNumberException(PremiumBondCheckerException):
    pass
