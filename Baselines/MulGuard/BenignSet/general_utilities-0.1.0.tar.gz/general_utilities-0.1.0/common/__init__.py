# coding: utf-8
# -*- coding: utf-8 -*-

__author__ = "Jalpesh Borad"
__copyright__ = "Copyright 2018"

__version__ = "0.0.1"
__maintainer__ = "Jalpesh Borad"
__email__ = "jalpeshborad@gmail.com"
__status__ = "Development"