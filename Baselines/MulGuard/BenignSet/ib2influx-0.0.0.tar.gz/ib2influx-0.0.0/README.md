# ib2influx
Collect IB network measurements to InfluxDB
