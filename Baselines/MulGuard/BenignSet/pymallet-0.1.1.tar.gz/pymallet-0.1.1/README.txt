Python package for MALLET
