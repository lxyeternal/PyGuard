# __init__.py
from .plugin import Image2FigurePlugin