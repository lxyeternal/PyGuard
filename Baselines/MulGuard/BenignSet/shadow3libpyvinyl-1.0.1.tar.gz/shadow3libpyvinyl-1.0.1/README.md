# shadow3-libpyvinyl
libpyvinyl interface for shadow3
