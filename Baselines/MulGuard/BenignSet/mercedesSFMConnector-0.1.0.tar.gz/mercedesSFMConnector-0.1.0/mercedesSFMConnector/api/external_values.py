class ExternalValues:
    def upload_external_values():
        pass
    