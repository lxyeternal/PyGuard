import datetime
import os

now = datetime.datetime.now()
test_string = f"Hello from slemasne at {now} in London"

print(test_string)
print("Now making another change - test")


test = "test test test"


test_dict = {"test1": 2, "test2": 3}
