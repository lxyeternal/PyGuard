#define QOI_IMPLEMENTATION
#include "c/qoi.h"