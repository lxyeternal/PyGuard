
class DataError(Exception):
    pass


class InsufficientDecimationError(Exception):
    pass