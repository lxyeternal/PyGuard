# JSE Tracker
##### get JSE stock data
###
###
``` python
from jsetracker import Stocks

s = Stocks()

s.get_all() # returns all the stocks listed on the JSE
s.get("JSE CODE HERE") # returns the specified the Stock data
```
see the article for more information and for other useful tools
https://snr99.medium.com/jse-tracker-4dbab8d35d7f
## License
MIT
**Free Software, Hell Yeah!**
### developed by [Ntwanano Rikhotso](http://ntwanano.me)(c) 2021
