# hookit

Semi-transparent HTTP proxy to enhance any API with Webhooks
