PyActuary
==============



|      CI              | status |
|----------------------|--------|
| pip builds           | [![Pip Actions Status][actions-pip-badge]][actions-pip-link] |
| [`cibuildwheel`][]   | [![Wheels Actions Status][actions-wheels-badge]][actions-wheels-link] |


[actions-badge]:           https://github.com/timomax/PyActuary/workflows/Tests/badge.svg
[actions-pip-link]:        https://github.com/timomax/PyActuary/actions?query=workflow%3A%22Pip
[actions-pip-badge]:       https://github.com/timomax/PyActuary/workflows/Pip/badge.svg
[actions-wheels-link]:     https://github.com/timomax/PyActuary/actions?query=workflow%3AWheels
[actions-wheels-badge]:    https://github.com/timomax/PyActuary/workflows/Wheels/badge.svg



Installation
------------



