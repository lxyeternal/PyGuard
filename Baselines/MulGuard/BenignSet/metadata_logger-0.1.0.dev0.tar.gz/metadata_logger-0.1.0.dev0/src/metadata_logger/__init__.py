"""
Top-level package for metadata_logger.
"""
