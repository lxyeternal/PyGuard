===============
metadata_logger
===============


.. image:: https://readthedocs.org/projects/metadata-logger/badge/?version=latest
        :target: https://metadata-logger.readthedocs.io/en/latest/?badge=latest
        :alt: Documentation Status

Logging utilites for ml-metadata


* Free software: MIT license
* Documentation: https://metadata-logger.readthedocs.io.


Features
--------

* TODO

Credits
-------

This package was created with Cookiecutter_ and the `audreyr/cookiecutter-pypackage`_ project template.

.. _Cookiecutter: https://github.com/audreyr/cookiecutter
.. _`audreyr/cookiecutter-pypackage`: https://github.com/audreyr/cookiecutter-pypackage
