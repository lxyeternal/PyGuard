from setuptools import setup

setup(name='lzy-MyFtp',
      version='0.1',
      author_email='mvli@qq.com',
      py_modules=['MyFtp']
      )

# python setup.py sdist
# twine upload dist/*