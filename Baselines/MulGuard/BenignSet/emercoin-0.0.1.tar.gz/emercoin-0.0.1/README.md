# Emercoin.py

Emercoin python 3 API