=======
Credits
=======

Protocol Engineer
-----------------

* Ricardo A. López <lopez.ricardoa at gmail>

Development Lead
----------------

* Nahuel Defossé <ndefosse@tw.unp.edu.ar>

Contributors
------------

None yet. This protocol is part of a R+D project that started back in 2009, we're still in bussiness if you'd like to join :)
