=====
Usage
=====

To use MaraNet in a project::

    import maranet
