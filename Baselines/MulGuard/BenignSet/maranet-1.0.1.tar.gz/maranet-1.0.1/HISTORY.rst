=======
History
=======


1.0 (2017-07-09)
------------------

* First release on PyPI. The sourcecode is extracted from https://github.com/d3f0/txscada and placed in an independet package.

1.0.1 (2017-07-09)
------------------

* Move code to cookiecutter python pacakge.
