INSERT INTO `djkorektor_words` (`id`, `word`, `word_unidecoded`, `length`, `quality_index`, `count`, `locale_id`)
VALUES
	(1,'bigrams','bigrams',7,1,1,123),
	(2,'are','are',3,1,1,123),
	(3,'fun','fun',3,1,1,123),
	(4,'it','it',2,1,2,123),
	(5,'is','is',2,1,1,123),
	(6,'raining','raining',7,1,1,123),
	(7,'let','let',3,1,1,123),
	(8,'s','s',1,1,1,123),
	(9,'dance','dance',5,1,1,123),
	(10,'together','together',8,1,1,123),
	(11,'will','will',4,1,1,123),
	(12,'be','be',2,1,1,123),
	(13,'my','my',2,1,1,123),
	(14,'pleasure','pleasure',8,1,1,123);