from . import psgen

if __name__ == '__main__':
    psgen.main()
