# kelpie

A python-based module for managing VASP (Vienna Abinitio Simulation Package) runs on supercomputers/clusters.
