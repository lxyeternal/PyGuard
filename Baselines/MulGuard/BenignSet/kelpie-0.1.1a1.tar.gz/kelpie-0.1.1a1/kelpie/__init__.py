#version
__version__ = '0.1.1a1'
VERSION = __version__
