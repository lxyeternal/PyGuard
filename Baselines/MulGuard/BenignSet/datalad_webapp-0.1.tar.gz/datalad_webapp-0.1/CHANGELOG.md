     ____            _             _                   _ 
    |  _ \    __ _  | |_    __ _  | |       __ _    __| |
    | | | |  / _` | | __|  / _` | | |      / _` |  / _` |
    | |_| | | (_| | | |_  | (_| | | |___  | (_| | | (_| |
    |____/   \__,_|  \__|  \__,_| |_____|  \__,_|  \__,_|
                                                   WebApp

This is a high level and scarce summary of the changes between releases.
Consult the full history of the [git
repository](http://github.com/datalad/datalad-webapp) for more details.

## 0.1 (Sep 20, 2018)

- Initial release.
