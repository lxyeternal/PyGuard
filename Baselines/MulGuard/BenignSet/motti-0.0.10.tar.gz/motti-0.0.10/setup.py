from setuptools import setup, find_packages

setup(name='motti',
      version='0.0.10',
      description='Hello world',
      author='lup1n',
      author_email='780966523@qq.com',
      license='MIT',
      packages=['motti'],
      zip_safe=False)
