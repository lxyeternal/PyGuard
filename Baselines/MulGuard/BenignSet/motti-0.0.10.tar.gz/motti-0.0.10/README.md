### Changelog

`0.0.7`: feat
`0.0.6`: debug
```shell
from typing import Optiona, Union
ImportError: cannot import name 'Optiona' from 'typing' (/GPFS/rhome/liyaojiao/miniconda3/envs/py311cu118/lib/python3.11/typing.py)
```

`0.0.5`:
```python
from motti.tools import (
    pil2str,
    str2pil,
    get_datetime,
    project_dir_with,
    is_abs_path,
)
```

`0.0.4`: init