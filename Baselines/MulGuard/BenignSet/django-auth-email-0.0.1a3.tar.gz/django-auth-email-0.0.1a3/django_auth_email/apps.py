from django.apps import AppConfig


class DjangoEmailAuthConfig(AppConfig):
    name = 'django_email_auth'
