# -*- coding: utf-8 -*-
"""
docdump

Core Objects: doc_reader
"""

import datetime

from docdump.main import doc_reader

__all__ = ["doc_reader"]