from setuptools import setup

setup(name='sauing',
      version='0.1',
      description='Test file to create a package',
      url='https://github.com/sauing/IIN_Trollers',
      author='Saurabh Singh',
      author_email='ssaurabhsingh009@gmail.com',
      package=['sauing'],
      zip_safe=False)
