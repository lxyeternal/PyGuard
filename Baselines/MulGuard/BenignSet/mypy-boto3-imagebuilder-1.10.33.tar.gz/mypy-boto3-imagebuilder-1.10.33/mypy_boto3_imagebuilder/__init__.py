"Main interface for imagebuilder service"

from mypy_boto3_imagebuilder.client import Client


__all__ = ("Client",)
