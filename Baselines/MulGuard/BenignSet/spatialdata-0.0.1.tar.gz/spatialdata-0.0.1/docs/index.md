```{include} ../README.md

```

```{toctree}
:hidden: true
:maxdepth: 1

api.md
changelog.md
developer_docs.md
references.md

notebooks/example
```
