from anndata import AnnData


def basic_preproc(adata: AnnData) -> int:
    """Run a basic preprocessing on the AnnData object."""
    print("Implement a preprocessing function here.")
    return 0
