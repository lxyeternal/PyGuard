import setuptools

setuptools.setup(
        name='endaq-cloud',
        version='0.0.0a1',
        author='Mide Technology',
        author_email='help@mide.com',
        packages=[],
        package_dir={'endaq-cloud': './endaq'},
        install_requires=[],
)
