"""Tests for inels-mqtt library."""
