Inels-mqtt
========
A Python library that handles communication with inels over mqtt
[iNels](https://www.inels.com/) by ElkoEP company.

Requirements
============
For smooth using you need to have Python 3.9 or higher.

Install
=======
Use PyPI repository
```
pip install inels-mqtt-dev
```

Testing
=======
I use [tox](https://tox.readthedocs.io) for testing.

```
$ pip install tox

```
