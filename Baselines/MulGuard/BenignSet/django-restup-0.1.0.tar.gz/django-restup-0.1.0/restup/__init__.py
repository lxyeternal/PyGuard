__author__ = 'Justin Walters <walters.justin01@gmail.com>'
__license__ = 'BSD'
__version__ = (0, 1, 0)


from .resources import ModelResource
