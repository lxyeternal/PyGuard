# SimpleEVA
A simple libary to use the EVA robot arm in python. This libary simplifies the use of IK and allows for easy control of the robot arm.

## Installation
To install the libary, first clone the repository:
```
git clone URL
```
Then navigate to the directory and run the setup.py file:
```python
python setup.py install
```