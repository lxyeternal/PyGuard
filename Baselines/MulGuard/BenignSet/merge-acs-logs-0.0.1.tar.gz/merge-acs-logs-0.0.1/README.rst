merge-acs-logs
===============

just a small tool to merge log files of ACS by timestamp
