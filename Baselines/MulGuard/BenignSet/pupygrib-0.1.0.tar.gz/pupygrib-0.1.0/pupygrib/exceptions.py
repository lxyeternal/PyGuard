"""Exceptions for pupygrib."""

from __future__ import unicode_literals


class ParseError(Exception):

    """Unable to parse a GRIB message."""
