# refaci

A toolbox for changing imports in enormous codebases after a large refactoring.

---

<p align="center">
<a href="https://github.com/ovsyanka83/refaci/actions?query=workflow%3ATests+event%3Apush+branch%3Amain" target="_blank">
    <img src="https://github.com/Ovsyanka83/refaci/actions/workflows/test.yaml/badge.svg?branch=main&event=push" alt="Test">
</a>
<a href="https://codecov.io/gh/ovsyanka83/refaci" target="_blank">
    <img src="https://img.shields.io/codecov/c/github/ovsyanka83/refaci?color=%2334D058" alt="Coverage">
</a>
<a href="https://pypi.org/project/refaci/" target="_blank">
    <img alt="PyPI" src="https://img.shields.io/pypi/v/refaci?color=%2334D058&label=pypi%20package" alt="Package version">
</a>
<a href="https://pypi.org/project/refaci/" target="_blank">
    <img src="https://img.shields.io/pypi/pyversions/refaci?color=%2334D058" alt="Supported Python versions">
</a>
</p>

## Installation

```bash
pip install refaci
```
