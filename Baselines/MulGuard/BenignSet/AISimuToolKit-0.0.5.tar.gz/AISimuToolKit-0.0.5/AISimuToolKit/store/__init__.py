from . import text

__all__ = ["text"]
