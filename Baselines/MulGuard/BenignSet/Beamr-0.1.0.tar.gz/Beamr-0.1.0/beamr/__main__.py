from beamr.cli import main
from sys import exit

exit(main())
