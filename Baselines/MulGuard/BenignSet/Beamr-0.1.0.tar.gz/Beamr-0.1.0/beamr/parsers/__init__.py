from beamr.parsers.document import parser as docParser
from beamr.parsers.slide import parser as slideParser
from beamr.parsers.image import parser as imageParser
