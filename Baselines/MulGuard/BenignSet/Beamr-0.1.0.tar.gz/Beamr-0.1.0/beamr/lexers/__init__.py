from beamr.lexers.document import lexer as docLexer
from beamr.lexers.slide import lexer as slideLexer
from beamr.lexers.image import lexer as imageLexer
