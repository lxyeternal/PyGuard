from distutils.core import setup

setup(
    name             = 'nester_xz',
    version          = '1.1.0',
    py_modules       = ['nester'],
    author           = 'chendg',
    author_email     = '1334415215@qq.com',
    url              = 'http://www.headfirstlabs.com',
    description      = 'A simple',
    )
