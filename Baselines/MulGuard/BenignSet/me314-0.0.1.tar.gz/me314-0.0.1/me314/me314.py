import numpy as np
import sympy as sym


def test_installation():
    print("package has been successfully installed.")

