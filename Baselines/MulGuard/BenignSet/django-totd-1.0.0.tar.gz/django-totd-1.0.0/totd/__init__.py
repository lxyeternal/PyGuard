default_app_config = "totd.apps.TotdConfig"
