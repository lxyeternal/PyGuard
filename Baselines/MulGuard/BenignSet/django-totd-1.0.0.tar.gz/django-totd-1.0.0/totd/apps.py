from django.apps import AppConfig


class TotdConfig(AppConfig):
    label = "totd"
    name = "totd"
    verbose_name = "Tip of the Day"
