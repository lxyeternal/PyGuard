from .RDFM import RDFM, GenCtypesStruct
from .utils import filetime_to_str, str_to_filetime, dump_to_dict