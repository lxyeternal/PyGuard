python3.8.8
https://mirrors.tuna.tsinghua.edu.cn/anaconda/archive/Anaconda3-2021.11-Windows-x86.exe
https://pypi.org/project/pypcdp/0.1/
python setup.py sdist bdist_whee
twine upload dist/*