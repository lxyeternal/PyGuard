import setuptools
setuptools.setup(
name = 'Leetease',
version = '0.1.1',
description = "This makes LeetCode Interview programs easy",
long_description = "This Python Package Helps Python Programmers Crack LeetCode programs with just 2 lines of code",
author = "SaatwikCodz",
packages = ['Leetease'],
install_requires = []
	)