from setuptools import setup

setup(name='gauss_bino_dists',
      version='0.1',
      description='Gaussian distributions',
      packages=['gauss_bino_dists'],
      zip_safe=False)
