# pynuvo
Python3 interface implementation for "simple" Nuvo zone amplifiers
This was derived from code initally published by ejonesnospam
Supports Essentia D and possibly Simplese models

## Notes
This is for use with [Home-Assistant](http://home-assistant.io)

## Usage
```python

```

