import os.path


LOCATION = os.path.dirname(os.path.abspath(__file__))
