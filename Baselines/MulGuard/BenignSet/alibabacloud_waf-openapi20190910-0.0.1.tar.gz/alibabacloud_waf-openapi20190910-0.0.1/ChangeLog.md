2021-04-25 Version: 1.1.1
- Generated python 2019-09-10 for waf-openapi.

2021-03-03 Version: 1.1.0
- Add API DescribeDomainList.

2020-12-30 Version: 1.0.0
- AMP Version Change.

