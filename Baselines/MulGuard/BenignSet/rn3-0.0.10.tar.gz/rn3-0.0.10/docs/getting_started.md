# Getting started

## Installation

```
pip install rn3
```
