Location for notebooks
