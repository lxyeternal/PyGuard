"""
Package for creating DGLdataset for training
"""
