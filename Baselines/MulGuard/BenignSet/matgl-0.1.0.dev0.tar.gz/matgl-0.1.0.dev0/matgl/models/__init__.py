"""
Package containing model implementations.
"""

# flake8: noqa

from .megnet import *
