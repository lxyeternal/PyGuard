"""
This package implements graph networks for materials science.
"""
