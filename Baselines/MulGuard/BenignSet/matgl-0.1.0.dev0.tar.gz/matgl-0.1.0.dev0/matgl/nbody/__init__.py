"""
Implementation of n-body interaction terms.
"""
