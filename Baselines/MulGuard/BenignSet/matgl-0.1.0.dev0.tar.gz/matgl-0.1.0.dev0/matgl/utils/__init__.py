"""
Implementation of various utility methods and classes.
"""
