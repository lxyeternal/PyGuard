# FinnTK

A small amount of wrapper code I end up rewriting every time I write some code
to work with Finnish language. This project is according to my personal
preferences but might be helpful to others for exploratory coding.
