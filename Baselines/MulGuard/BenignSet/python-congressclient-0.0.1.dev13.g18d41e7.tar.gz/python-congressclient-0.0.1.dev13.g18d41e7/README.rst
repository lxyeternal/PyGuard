===============================
python-congressclient
===============================

Client for Congress

* Free software: Apache license
* Documentation: http://docs.openstack.org/developer/python-congressclient
* Source: http://git.openstack.org/cgit/stackforge/python-congressclient
* Bugs: http://bugs.launchpad.net/python-congressclient

Features
--------

* TODO