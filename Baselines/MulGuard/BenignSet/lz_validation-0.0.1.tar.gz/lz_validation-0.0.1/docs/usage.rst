=====
Usage
=====

To use lz-validation in a project::

    import lz_validation
