=======
History
=======

0.0.1 (2018-07-19)
------------------

* First release on PyPI.
