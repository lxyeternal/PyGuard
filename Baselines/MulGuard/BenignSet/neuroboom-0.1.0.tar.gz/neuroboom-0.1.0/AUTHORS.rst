=======
Credits
=======

Maintainer
----------

* Markus William Pleijzier <mp824@cam.ac.uk>

Contributors
------------

None yet. Why not be the first? See: CONTRIBUTING.rst
