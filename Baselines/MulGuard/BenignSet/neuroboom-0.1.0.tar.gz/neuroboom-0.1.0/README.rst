=========
Neuroboom
=========

.. image:: https://img.shields.io/travis/markuspleijzier/neuroboom.svg
        :target: https://travis-ci.org/markuspleijzier/neuroboom

.. image:: https://img.shields.io/pypi/v/neuroboom.svg
        :target: https://pypi.python.org/pypi/neuroboom


A suite of python tools for visualisation and analysis of Connectomic data

* Free software: 3-clause BSD license
* Documentation: (COMING SOON!) https://markuspleijzier.github.io/neuroboom.

Features
--------

* TODO
