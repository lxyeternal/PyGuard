=====
Usage
=====

Start by importing Neuroboom.

.. code-block:: python

    import neuroboom
