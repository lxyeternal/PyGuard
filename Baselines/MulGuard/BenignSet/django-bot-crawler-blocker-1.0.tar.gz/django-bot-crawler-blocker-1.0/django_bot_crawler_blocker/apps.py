from django.apps import AppConfig


class DjangoBotCrawlerBlockerConfig(AppConfig):
    name = 'django_bot_crawler_blocker'
