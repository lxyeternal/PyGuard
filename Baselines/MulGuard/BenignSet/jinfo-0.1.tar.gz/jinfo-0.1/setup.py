from setuptools import setup

setup(
    name="jinfo",
    version="0.1",
    description="",
    author="Jake Bowden",
    url="https://github.com/JBwdn/jinfo",
    author_email="jake.bowden95@gmail.com",
    license="MIT",
    packages=["jinfo"],
    zip_safe=False,
)
