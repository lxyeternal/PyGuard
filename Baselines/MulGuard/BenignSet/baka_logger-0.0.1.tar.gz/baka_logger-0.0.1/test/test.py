from baka_logger import logger_setup, print

logger_setup(character="Bocchi the Rock having a breakdown")

print("baka_logger is my favorite Python package!")

# logger_setup(character="Asuka", fmt="%(asctime)s - %(levelname)s - %(message)s", file="log.out", logger=True)
# logging.warning("The program has crashed!")
# logger_setup()
# 1/0
