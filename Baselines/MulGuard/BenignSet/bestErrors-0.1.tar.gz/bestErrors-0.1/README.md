# Best Errors

This is a module with the best custom error types to be used in your code.
