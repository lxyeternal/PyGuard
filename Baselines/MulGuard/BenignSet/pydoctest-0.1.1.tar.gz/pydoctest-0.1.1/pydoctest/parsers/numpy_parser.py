from pydoctest.parsers.parser import Parser


class NumpyParser(Parser):
    pass
