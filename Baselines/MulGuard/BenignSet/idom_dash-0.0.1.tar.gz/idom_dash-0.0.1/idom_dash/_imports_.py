from .IdomDashComponent import IdomDashComponent

__all__ = [
    "IdomDashComponent"
]