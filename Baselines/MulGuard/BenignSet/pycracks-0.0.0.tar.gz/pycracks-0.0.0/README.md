# pycracks
💢🔍 breaking change detection in Python - Compatible with Semantic Version and Semantic Release
