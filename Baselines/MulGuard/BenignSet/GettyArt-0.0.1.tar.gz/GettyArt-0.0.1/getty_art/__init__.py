"""Module to scrape images from getty.edu"""


from __future__ import absolute_import
from getty_art.getty_art import Scraper  # noqa


__all__ = ['getty_art']
