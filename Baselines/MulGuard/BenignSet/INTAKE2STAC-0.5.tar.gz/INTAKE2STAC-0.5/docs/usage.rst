=====
Usage
=====

To use INTAKE2STAC in a project::

    import intake2stac
