===========
INTAKE2STAC
===========



.. image:: https://img.shields.io/pypi/v/intake2stac.svg
        :target: https://pypi.python.org/pypi/intake2stac


.. image:: https://img.shields.io/travis/CAT4KIT/intake2stac.svg
        :target: https://travis-ci.com/CAT4KIT/intake2stac

.. image:: https://readthedocs.org/projects/intake2stac/badge/?version=latest
        :target: https://intake2stac.readthedocs.io/en/latest/?version=latest
        :alt: Documentation Status


.. image:: https://pyup.io/repos/github/CAT4KIT/intake2stac/shield.svg
     :target: https://pyup.io/repos/github/CAT4KIT/intake2stac/
     :alt: Updates



A python module for creating STAC catalog from datasets in INTAKE


* Free software: EUPL-1.2
* Documentation: https://intake2stac.readthedocs.io.


Features
--------

* TODO

Copyright
---------
Copyright © 2023 Karlsruher Institut für Technologie

Licensed under the EUPL-1.2-or-later

This program is distributed in the hope that it will be useful, but WITHOUT ANY
WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR A
PARTICULAR PURPOSE. See the EUPL-1.2 license for more details.

You should have received a copy of the EUPL-1.2 license along with this
program. If not, see https://www.eupl.eu/.