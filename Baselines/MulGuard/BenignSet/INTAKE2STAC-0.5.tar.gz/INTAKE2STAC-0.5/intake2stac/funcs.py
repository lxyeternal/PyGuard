def replacement_func(id):
    return id.replace(" ", "_")
