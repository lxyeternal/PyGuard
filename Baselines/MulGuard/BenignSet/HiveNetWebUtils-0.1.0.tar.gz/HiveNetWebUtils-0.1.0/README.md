# HiveNetWebUtils

HiveNetWebUtils is a web application tool component of HiveNetAssemble, which provides common web service abstract classes and tool classes.
