"""Top-level package for rastvectpy."""

__author__ = """Lukman Fashina"""
__email__ = 'lukmanfashina@yahoo.com'
__version__ = '0.0.1'
