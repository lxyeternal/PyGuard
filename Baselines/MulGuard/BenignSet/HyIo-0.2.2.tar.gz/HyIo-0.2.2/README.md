# HyIo
IO abstraction for raspberryPi


# Todo
* use json to load pin layout
