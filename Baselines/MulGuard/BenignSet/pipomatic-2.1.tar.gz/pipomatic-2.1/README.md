# pipomatic
Automatically create pip installable modules from functions in your Jupyter notebook
