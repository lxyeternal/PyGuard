# Trees ![](https://api.travis-ci.com/abarker21/trees.svg?branch=master)

This is a homework for CMC's [CS46: data structures](https://github.com/abarker21/cmc-csci046) course.
