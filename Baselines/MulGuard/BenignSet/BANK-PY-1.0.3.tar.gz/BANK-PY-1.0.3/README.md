# BankPy Armazen de Dados Versatil
## Muito Simples De Usa

### Muito Pythonic

**Você Pode Cria Um Armazen de Dados Para Sua Aplicaçã Como Sé Fosse Um Banco de Dados...**

**Esse Dados Serão Armazenado Em Um Arquivo Python Onde é Possivel Fazer a Comicação do Sua Aplicação Com Arquivo Python de Uma Forma Simples é Util**

* Não Reque Nada Especial 
* Utiliza Apena Modulo OS

```
from Jiton import *

Criando o Path
Create.Path.Pop('testando')
Esta Função Cria Uma Pasta Com um __init__.py
Este Dados Ficaram Salvo Nesse __init__.py

Conectando O Path Criado
var = Connect.Path.Pop('testando')

Armazenando Um Dado Na Variavel 
Write.Variable.Str.Pop(var'Nome_Da_Variavel''Conteudo da Variavel')

```

__Criado Por José Alexsandro__




[Desenvolvido Pela Star Comics](https://starcomicstar.weebly.com/)

[Portifolio_Do_Autor](https://alexsandrodev.netlify.app/)




