__version__ = "0.1.0"
__author__ = "Sebastian Bocquet and Faustin W. Carter"
__contributors__ = [
    'Samuel Flender',
    'Ben Hoyle'
]
__all__ = ['plotGTC']
from .pygtc import plotGTC
