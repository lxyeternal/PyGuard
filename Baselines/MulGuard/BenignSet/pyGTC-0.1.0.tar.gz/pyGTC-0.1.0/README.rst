pygtc.py
=========

Make a sweet giant triangle confusogram (GTC) plot with just one line of code!

See source for documentation, or check out demo.ipynp.

Works great with the output from ``emcee``.

Install with pip: pip install pygtc
