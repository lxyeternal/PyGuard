# mobacache [![Build Status](https://travis-ci.org/redrush85/mobacache.svg?branch=master)](https://travis-ci.org/redrush85/mobacache)
mobacache is a pythonic interface for creating a cache over redis. It provides simple decorators that can be added to any function to cache its return values.

# Install
`pip install moba-cache`


