# Eve Utility Functions

### loot_distribution

```python
python3 distribute.py
```
