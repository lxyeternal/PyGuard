# Document
## Description
- This project is used to quickly generate fastapi project.
## Requirements
- python 3.8
## Version
- 0.0.1
    - only create app/main.py