# SPDX-FileCopyrightText: 2023-present Chipy <iamchipy@gmail.com>
#
# SPDX-License-Identifier: MIT
__version__ = '0.0.2'

print("Loading chipys_5e_tools v"+__version__)

