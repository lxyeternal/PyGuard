from setuptools import setup, find_namespace_packages

setup(
    name="attr.s",
    packages=find_namespace_packages(include=['attr.*'])
)
