def foo():
    return 'bar'