# py-pbay
A python driver for SPEC Sensors PBay board

# Getting started::
1. Install pyserial
```pip install pyserial```
2. Connect Board & check the board's devpath - e.g. ```/dev/ttyUSB0```.
3. Run example:
```python3 example.py /dev/ttyUSB0```

