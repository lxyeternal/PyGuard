```{include} ../README.md
:start-after: '<!-- intro-begin -->'
:end-before: '<!-- intro-end -->'
```

## Table of Contents

```{toctree}
:maxdepth: 3

why
installation/index
usage/index
configuration/index
updating
contributing/index
```
