# Authors

Josh Thomas <josh@joshthomas.dev>
Jeff Triplett <@jefftriplett>

## Original Authors

This project is inspired by [`django-mailer`](https://github.com/pinax/django-mailer).

The authors of `django-mailer` at the time of this project's creation are listed at [pinax/django-mailer/AUTHORS](https://github.com/pinax/django-mailer/blob/15433786534d5d7d44f1d55b15a601d5d01bab42/AUTHORS).
