from setuptools import setup

setup(name='Basic_Statistical_distributions',
      version='0.4',
      description='Gaussian and Binomial distributions',
      packages=['Basic_Statistical_distributions'],
      zip_safe=False)
