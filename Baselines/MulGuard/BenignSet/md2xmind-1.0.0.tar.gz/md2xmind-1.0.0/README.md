# md2xmind
Translate markdown file to xmind file.
