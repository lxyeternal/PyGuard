# !/usr/bin/python
# -*- coding:utf-8 -*-
"""
@Author  : jingle1267
@Time    : 2019-07-20 09:40
@desc：  : 
"""

__title__ = 'md2xmind'
__description__ = 'md2xmind'
__keywords__ = 'md2xmind, md, xmind',
__url__ = 'https://github.com/jingle1267/md2xmind'
__author__ = 'jingle1267'
__author_email__ = 'jingle1267@163.com'
__version__ = '1.1.0'
__license__ = 'Apache License Version 2.0'
__cake__ = u'\u2728 \U0001f370 \u2728'
