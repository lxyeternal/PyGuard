# reb -- Regular Expression Beautiful

To make infomation extraction with patterns easier, reb tries to improve traditional re in some ways:

+ Maintainability -- examples come with patterns to show how patterns were made
+ Reusability -- name a pattern and it could be used in another pattern
+ Readability -- multiline patterns are encouraged for complex ones

