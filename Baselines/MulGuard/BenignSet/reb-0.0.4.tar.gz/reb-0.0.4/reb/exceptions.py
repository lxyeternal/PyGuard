class RebException(Exception):
    pass


class InvalidPattern(RebException):
    pass


class ExampleFail(RebException):
    pass
