from setuptools import setup

setup(
  name="sanjose-twitter",
  version="0.1dev",
  description="Getting trends on Twitter",
  author="sanjose",
  scripts=["sanjose-twitter"],
  install_requires=["twitter",]
)
