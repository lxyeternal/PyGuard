sentry-nirror
=============

An extension for Sentry which integrates with Nirror. Specifically, it lists associated nirror visits
for each group of events.


Install
-------

Install the package via ``pip``::

    pip install sentry-nirror

