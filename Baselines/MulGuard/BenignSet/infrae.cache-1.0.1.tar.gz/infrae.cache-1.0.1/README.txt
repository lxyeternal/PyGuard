============
infrae.cache
============

This packages includes several utilities to work with caching.

It provides the following beaker backend extension:

- nocache: as it name says, do not cache (for testing),

- memorylru: a memory backend that use the LRU stategies, that is close to
  the strategy memcache use.


