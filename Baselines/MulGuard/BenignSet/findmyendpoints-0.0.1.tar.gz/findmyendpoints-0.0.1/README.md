# FindMyEndpoints

## Description

This tool will find and display information about public endpoints in an AWS
 account. Its focus is in Elastic Network Interfaces (ENIs), which can be
 attached resources like EC2 instances and RDS DB instances.

## Installation

pip instal findmyendpoints

## Usage

findmyendpoints [-h]

## TODO

* Add support for Organizations/Control Tower
