from collections import namedtuple

AnnotatedValue = namedtuple('AnnotatedValue', ['value', 'message'])
