from setuptools import setup

setup(name='amerdistribution',
      version='0.2',
      description='Gaussian and Binomial distributions',
      packages=['amerdistribution'],
      author="Amer",
      author_email="amer.deraa@gmail.com",
      zip_safe=False)
