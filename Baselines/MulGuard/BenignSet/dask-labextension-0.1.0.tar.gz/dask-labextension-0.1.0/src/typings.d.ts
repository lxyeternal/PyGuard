/// <reference path="../typings/bokeh/bokeh.d.ts"/>
