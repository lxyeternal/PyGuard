import os, datetime

UTC_DATE = datetime.datetime.utcnow().strftime('%Y%m%d')
CWD = os.getcwd()
