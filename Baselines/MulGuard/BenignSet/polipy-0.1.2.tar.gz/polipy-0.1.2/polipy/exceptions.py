class NetworkIOException(Exception):
    pass

class ParserException(Exception):
    pass
