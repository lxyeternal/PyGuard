"""
This package contains the tests for L{pyzim}
"""
pass
