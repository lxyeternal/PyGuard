"""
pyzim - python library for working with ZIM files.
"""
from .archive import Zim


__all__ = ["Zim"]
