scikit-groups

A Package for the construction of finite abelian groups
