# Pygenix
-  Its A Collection Of Small Animations And Other Stuff Like Getting Username And Platform.