"""Define litbee."""
from logzero import logger


def litbee():
    """Define litbee."""
    logger.debug(" entry ")
