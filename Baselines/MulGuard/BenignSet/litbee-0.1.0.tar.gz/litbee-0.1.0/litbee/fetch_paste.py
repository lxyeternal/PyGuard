"""Display from paste."""
import pandas as pd
import streamlit as st
from logzero import logger


def fetch_paste():
    """Display from paste."""
    st.write("Coming soon")
