"""Fetch from urls."""
import pandas as pd
import streamlit as st
from logzero import logger


def fetch_urls():
    """Display from urls."""
    st.write("Coming soon")
