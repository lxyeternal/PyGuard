from rouge.rouge import FilesRouge, Rouge

__version__ = "0.2"
