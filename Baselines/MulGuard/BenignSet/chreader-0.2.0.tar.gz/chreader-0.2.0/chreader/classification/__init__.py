# -*- coding: utf-8 -*-
from .tnews import TnewsDatasetReader
from .afqmc import AfqmcDatasetReader
