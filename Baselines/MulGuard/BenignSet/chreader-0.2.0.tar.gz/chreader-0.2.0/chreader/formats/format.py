# -*- coding: utf-8 -*-
class Format:
    def decode(self, data: str) -> dict:
        raise NotImplementedError
