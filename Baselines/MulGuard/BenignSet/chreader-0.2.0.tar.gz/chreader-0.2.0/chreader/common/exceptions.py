# -*- coding: utf-8 -*-
class MissingDatasetPathError(ValueError):
    """没有找到指定数据集的文件路径或者 url """
