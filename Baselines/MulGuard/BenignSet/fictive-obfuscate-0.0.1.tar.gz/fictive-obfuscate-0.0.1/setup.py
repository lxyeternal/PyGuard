
import os
import setuptools

name = 'fictive-obfuscate'
version = '0.0.1'
author = 'Fictive Kin LLC'
email = 'hello@fictivekin.com'
classifiers = [
    'Development Status :: 1 - Planning',
    'Topic :: Software Development',
]

if __name__ == "__main__":
    setuptools.setup(
        name=name,
        version=version,
        description='',
        long_description='',
        classifiers=classifiers,
        url='',
        author=author,
        author_email=email,
        maintainer=author,
        maintainer_email=email,
        packages=[],
        install_requires=[],
        scripts=[],
    )
