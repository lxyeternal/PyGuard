# Ghoul

Discord - `ghoul#1337`

# Marci

Discord - `Marci#4399`