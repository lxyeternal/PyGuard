# Bad Word Obfuscator
 This code obfuscates naughty words by using a rot13 cipher to prevent them from being directly visible.

## Install Instructions

### Manual Build & Install

1. Build Wheel with:<br>
    `python setup.py bdist_wheel`
2. Install Wheel with:<br>
    `pip install {/path/to/wheelfile.whl}`