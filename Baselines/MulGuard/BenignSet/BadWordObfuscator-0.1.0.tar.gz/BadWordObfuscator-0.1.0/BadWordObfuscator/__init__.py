from BadWordObfuscator import Obfuscator

Obfuscator.load_slurListDefault()