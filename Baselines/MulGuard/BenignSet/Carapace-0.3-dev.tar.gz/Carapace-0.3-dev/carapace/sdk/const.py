# Interpreter types
PYTHON = "python"
ECHO = "echo"
SHARED_PYTHON = "sharedpython"

# Prevent use of raw strings when we can help it
INTERPRETER = "interpreter"
KEYGEN = "keygen"
SHELL = "shell"
STOP = "stop"
