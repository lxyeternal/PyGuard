# wasserstein-distance
Fast Numba-enabled CPU and GPU computations of Earth Mover's (scipy.stats.wasserstein_distance) and Euclidean distances.
