"""Predict materials properties using only the composition information."""
__version__ = "1.0.0"