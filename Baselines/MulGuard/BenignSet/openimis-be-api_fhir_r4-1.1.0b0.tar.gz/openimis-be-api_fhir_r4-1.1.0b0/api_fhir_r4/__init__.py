default_app_config = 'api_fhir_r4.apps.ApiFhirConfig'
