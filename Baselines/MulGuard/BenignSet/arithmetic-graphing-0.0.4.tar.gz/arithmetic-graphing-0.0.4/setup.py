from setuptools import *

setup(name='arithmetic-graphing',
    version='0.0.4',
    description='A small arithmetic module for functions of graphing',
    author='TheOnlyWalrus',
    license='MIT',
    packages=find_packages(),
    classifiers=[
        'Programming Language :: Python :: 3'
    ],
)