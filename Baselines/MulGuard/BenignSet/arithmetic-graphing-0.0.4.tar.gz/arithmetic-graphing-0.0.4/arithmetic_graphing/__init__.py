def Slope(pos, pos2):
    y = (pos2[1] - pos[1])
    x = (pos2[0] - pos2[1])
    print(y/x)