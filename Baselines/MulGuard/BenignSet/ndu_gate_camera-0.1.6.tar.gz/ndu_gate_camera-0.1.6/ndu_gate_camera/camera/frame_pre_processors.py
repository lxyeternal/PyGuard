class FramePreProcessors:
    """
    Herbir frame için yapılacak olan ön işleme metodları burada bulunur.
    """
    def __init__(self):
        pass

    @staticmethod
    def find_persons(self, frame):
        pass

    @staticmethod
    def find_faces(self, frame):
        pass
