# easy-logger

Simple Easy baseline Logger. Creates a color stream logger or a basic rotating logger that can be used and called on throughout a project.
