
Changelog
=========

0.0.0 (2023-02-19)
------------------

* First release on PyPI.
