=====
Usage
=====

To use hirezapi in a project::

	import hirezapi
