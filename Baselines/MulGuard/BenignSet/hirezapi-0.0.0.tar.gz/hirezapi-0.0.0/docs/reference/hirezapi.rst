hirezapi
========

.. testsetup::

    from hirezapi import *

.. automodule:: hirezapi
    :members:
