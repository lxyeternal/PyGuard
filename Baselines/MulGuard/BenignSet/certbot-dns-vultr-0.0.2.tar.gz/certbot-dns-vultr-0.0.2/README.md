# certbot-dns-vultr

This package provides a Certbot authenticator plugin
that can complete the DNS-01 challenge using the Vultr API.

**NOTE: This is \*not\* an official certbot DNS plugin.**
