class DeferredCommonSubjectRvalUsage(RuntimeError):
    """Thrown upon usages of a deferred `common_subject_rval`
    """
