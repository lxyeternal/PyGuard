from je_locust_wrapper.wrapper.locust_as_library import *
