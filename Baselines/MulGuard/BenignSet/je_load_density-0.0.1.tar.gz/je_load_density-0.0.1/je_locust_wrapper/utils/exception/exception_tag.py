# locust error
not_found_locust_error = "locust not found"
# json error
cant_reformat_json_error = "can't reformat json is type right?"
wrong_json_data_error = "can't parser json"
cant_find_json_error = "can't find json"
cant_save_json_error = "can't save json"
# executor error
executor_data_error = "executor receive wrong data"
executor_list_error = "executor receive wrong data list is none or wrong type"
