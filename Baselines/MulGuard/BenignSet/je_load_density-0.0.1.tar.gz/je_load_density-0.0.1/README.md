# JE_LocustWrapper

---

### Locust Wrapper a framework for stress testing and load testing

#### Features
* HTTP HTTPS stress testing and load testing
* Action FIle
* response compare
* CLI with action file
---
[![CircleCI](https://circleci.com/gh/JE-Chen/JE_LocustWrapper/tree/main.svg?style=svg)](https://circleci.com/gh/JE-Chen/JE_LocustWrapper/tree/main)

### Documentation

---

## install 

```
pip install je_locust_wrapper
```
