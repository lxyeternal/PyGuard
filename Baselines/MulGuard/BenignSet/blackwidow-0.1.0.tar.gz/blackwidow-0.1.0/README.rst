BlackWidow
======

Visualizing Python Project Import Graphs

Installation:

::

    sudo pip install blackwidow

Demo with:

::

    python -m blackwidow.web [path-to-package]

