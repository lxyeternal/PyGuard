# -*- coding: utf-8 -*-

# django-simple-help
# simple_help/templatetags/__init__.py

from __future__ import unicode_literals


__all__ = [
    "help_tags",
]
