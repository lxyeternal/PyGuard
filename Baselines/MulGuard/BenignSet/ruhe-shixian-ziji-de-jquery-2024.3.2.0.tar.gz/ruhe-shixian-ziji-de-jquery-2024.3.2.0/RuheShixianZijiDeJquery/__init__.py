#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""ruhe-shixian-ziji-de-jquery
https://github.com/apachecn/ruhe-shixian-ziji-de-jquery"""

__author__ = "ApacheCN"
__email__ = "apachecn@163.com"
__license__ = "CC BY-NC-SA 4.0"
__version__ = "2024.3.2.0"