plonetheme.notredame Package Readme
=========================

Overview
--------

Theme for Plone 3 with color scheme based on new Plone Logo
