from plone.theme.interfaces import IDefaultPloneLayer

class IPlonethemeNotredameLayer(IDefaultPloneLayer):
    """Marker interface that defines a browser layer.
    """
