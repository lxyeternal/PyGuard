# Gornilo-Checker

This is a checker wrapper lib.

Features:

- no exit-code/chk-sys interface requirements
- object model, fully documented
- built-in error handling
- asyncio support