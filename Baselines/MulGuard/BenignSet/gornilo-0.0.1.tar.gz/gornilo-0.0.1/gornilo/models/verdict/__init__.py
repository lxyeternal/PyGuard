from .verdict import Verdict
from .verdict_codes import OK, CORRUPT, MUMBLE, DOWN, CHECKER_ERROR
