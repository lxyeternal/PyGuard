
CHECK, PUT, GET, INFO = "CHECK", "PUT", "GET", "INFO"
TEST = "TEST"  # feature for easier development process
