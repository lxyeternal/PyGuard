HTTP_BASE_HEADERS = {
    "User-Agent": "python-requests/2.25.1",
    "Accept-Encoding": "gzip, deflate",
    "Accept": "*/*",
    "Connection": "keep-alive",
}
