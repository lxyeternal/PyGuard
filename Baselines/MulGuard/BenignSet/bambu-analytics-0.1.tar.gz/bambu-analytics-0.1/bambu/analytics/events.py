PAGE = 'page'
EVENT = 'event'
TRANSACTION = 'transaction'
TRANSACTION_ITEM = 'transaction_item'
