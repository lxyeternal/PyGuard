from setuptools import setup


packages = ['king_libs',
'king_libs/king_tools',
'king_libs/number_to_word_project']








setup(name= "king_libs",

version = "0.0.7",

description = "This is code with king package",
long_description = "This Are just Some Test Libs",
author = "Ahmad Dehghani",
author_email = 'ahd76money@gmail.com',
license='MIT',
url = 'https://github.com/jacktamin/king_libs',

download_url = 'https://github.com/jacktamin/king_libs/king_libs-0.0.6.tar.gz',
  keywords = ['scraping', 'easy', 'scraper', 'website', 'download', 'links', 'images', 'videos'],
packages = packages
,

install_requires = [])
