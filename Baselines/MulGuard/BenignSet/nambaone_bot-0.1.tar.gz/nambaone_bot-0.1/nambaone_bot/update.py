class Update:

    def __init__(self, user=None, message=None, chat=None):
        self.user = user
        self.chat = chat
        self.message = message
