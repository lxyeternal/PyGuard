class User:

    def __init__(self, id, name='', gender=''):
        self.id = id
        self.name = name
        self.gender = gender
