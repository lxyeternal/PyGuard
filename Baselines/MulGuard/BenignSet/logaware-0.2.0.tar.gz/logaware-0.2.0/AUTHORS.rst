Authors
=======

* Mike Thornton - http://devdetails.com/
