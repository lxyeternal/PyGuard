=====
Usage
=====

To use logaware in a project::

	import logaware
