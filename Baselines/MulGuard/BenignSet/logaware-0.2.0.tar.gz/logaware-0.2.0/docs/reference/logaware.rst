logaware
========

Logger
------

.. automodule:: logaware.logger
    :members:
    :undoc-members:


MetaLogger
----------

.. automodule:: logaware.metalogger
    :members:
    :undoc-members:
