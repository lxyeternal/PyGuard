from zope.interface import Interface


class IDownloadUser(Interface):
    """ Marker to show the download users down viewlet
    """
