
from zope.i18nmessageid import MessageFactory
DownloadUserMessageFactory = MessageFactory('c2.app.downloaduser')

def initialize(context):
    """Initializer called when used as a Zope 2 product."""
