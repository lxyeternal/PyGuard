
from c2.app.downloaduser.record import downloadIt

def notify_record(context, event):
    downloadIt(context)
