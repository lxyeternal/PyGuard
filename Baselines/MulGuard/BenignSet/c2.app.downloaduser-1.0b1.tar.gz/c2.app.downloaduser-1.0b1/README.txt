Introduction
==============

Showing download user name for File or Image. It support AT-content types only yet.

- Repository: https://bitbucket.org/cmscom/c2.app.downloaduser
- Issue tracker: https://bitbucket.org/cmscom/c2.app.downloaduser/issues


I tested only Plone 4.3. Maybe it works Plone 4.0 and later.


TODO
======

Download method - action = record.downloadIt(context)
action is "already" or "download"