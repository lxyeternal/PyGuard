Changelog
---------

16.0 - `master`_
~~~~~~~~~~~~~~~~~

.. note:: This version is not yet released and is under active development.


* Initial release.


.. _`master`: https://github.com/pypa/pipfile/
