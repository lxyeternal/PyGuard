# robotframework-aws
 [![contributions welcome](https://img.shields.io/badge/contributions-welcome-brightgreen.svg?style=flat)](https://github.com/dwyl/esta/issues)
 ![PyPI](https://img.shields.io/pypi/v/robotframework-aws.svg)

A library of keywords for interacting with AWS services.

### Contributors are welcome. This package is at the beginning of development.

> ## Session
####  Keywords

 - | `Create Session` | region | profile=optional |
 - | `Delete Session` | region | profile=optional |
 - | `Delete All Sessions` |

 > ### S3 
 ####  Keywords
 - | `Get Bucket` | bucket_name |
 - | `Get Object` | bucket_name | object_path 
