from setuptools import setup

setup(name='make_all_distributions',
      version='0.1',
      description='Gaussian distributions',
      packages=['make_all_distributions'],
      zip_safe=False)
