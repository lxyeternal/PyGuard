# kabaret.flow_button_pages

A collection of custom_page widgets to use in your flow, as well as an extended Home page showing thumbnail/icon and color for your Projects.
