import kabaret.app.resources as resources
resources.add_folder('icons.fbp', __file__)

