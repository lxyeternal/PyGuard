from . import icons  # install ('icons.fbp', *) icons
from .button_home import ButtonHomeRoot
