# (E)a(z)y (bench)marking

Helper to make benchmarking easy as creating function.

# Installation

Simple as `pip3 install ezlog`

# Some examples on how to use it

TODO: