================
django-couchbase
================

This package is aimed at developing the ORM for the couchbase - the next generation NoSQL database.
