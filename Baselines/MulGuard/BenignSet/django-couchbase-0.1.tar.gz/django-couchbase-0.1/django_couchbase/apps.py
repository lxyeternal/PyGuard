from __future__ import unicode_literals

from django.apps import AppConfig


class DjangoCouchbaseConfig(AppConfig):
    name = 'django_couchbase'
