cppyad: Python bindings for CppAD
=================================

|GHAction|

.. |GHAction| image:: https://github.com/fracek/cppyad_private/workflows/Python%20package/badge.svg