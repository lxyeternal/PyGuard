from .lib import form_sqlmodel as __form_sqlmodel


def form_sqlmodel(__schema, Base):
    return __form_sqlmodel(__schema, Base)
