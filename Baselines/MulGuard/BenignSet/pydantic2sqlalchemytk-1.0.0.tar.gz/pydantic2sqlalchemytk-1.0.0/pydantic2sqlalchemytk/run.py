def run():
    result = 'Running [pydantic2sqlalchemytk]'
    print(result)
    return result

