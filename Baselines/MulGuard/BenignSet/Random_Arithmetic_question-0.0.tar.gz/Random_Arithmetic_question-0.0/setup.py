from setuptools import setup

setup(name='Random_Arithmetic_question',
      version='0.0',
      description='Random Arithmetic Question',
      packages=['Random_Arithmetic_question'],
      author_email='dharmisha2207@gmail.com',
      zip_safe=False)
