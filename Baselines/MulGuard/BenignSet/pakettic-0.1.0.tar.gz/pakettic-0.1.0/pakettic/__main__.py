from pakettic import main

main.main()
