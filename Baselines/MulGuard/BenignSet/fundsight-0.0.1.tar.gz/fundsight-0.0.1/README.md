# fundsight

This package allows you to calculate a panel of performance indicators from a Fund net asset value serie or Asset price serie.
Indicators are multiple from annualised volatility, to calmar or sharpe ratio.

## Installation Process

    :construction:

## Examples

    :construction:
