============
kotti_site_gallery
============

This is an extension to Kotti that allows to add a site gallery to
your site.

`Find out more about Kotti`_

Development happens at https://github.com/chrneumann/kotti_site_gallery

Setup
=====

To enable the extension in your Kotti site, activate the configurator:

  kotti.configurators = kotti_site_gallery.kotti_configure

.. _Find out more about Kotti: http://pypi.python.org/pypi/Kotti
