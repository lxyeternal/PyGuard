__all_ = ['download_not_active']




class download_not_active(Exception):
    """ Download Not active """