# __init__.py
from . import version

__version__ = version.current_version
