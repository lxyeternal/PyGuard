def get_current():
    return "0.0.4"

current_version = get_current()
