# my-happy-jupyter-utils

Jupyter utils.

## Features

1. markdown utils
1. image utils

## test and developing environment
OS: centos7

python:  3.7.7

## install
```shell
python3.7 -m pip install -U my-happy-jupyter-utils

or

python3.7 -m pip install -i https://pypi.org/simple/ -U my-happy-jupyter-utils

```

## uninstall
```shell
python3.7 -m pip uninstall my-happy-jupyter-utils
```


## how to use
See the examples directory in the project.
