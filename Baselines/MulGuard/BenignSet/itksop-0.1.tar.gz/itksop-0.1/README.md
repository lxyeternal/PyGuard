# IHEP ATLAS ITk Strip Module Standard Operating Procedure

 
| No. | Title      | 
| --- | ---------- | 
| 000 | Master SOP | 
| 101 | Hybrid assembly | 
| 102 | Hybird wire bonding | 
| 103 | Module assembly | 
| 104 | Module wire bonding |
| 105 | Rework of hybrid and module | 
| 201 | Hybrid electric test | 
| 202 | Module electric test | 
| 203 | Sensor I-V scan | 
| 301 | Database usage | 
| 302 | Cleanroom |





