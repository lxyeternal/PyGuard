#!/usr/bin/env python
from setuptools import setup
from esc_ls import _version

if __name__ == "__main__":
    setup(version=_version.__version__)
