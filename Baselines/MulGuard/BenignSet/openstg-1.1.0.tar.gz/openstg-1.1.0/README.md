# OpenSTG
OpenSTG is a OpenSource STG implementation supporting the following protocols:

* PRIME
