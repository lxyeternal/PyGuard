#! /usr/bin/env python

from setuptools import setup, find_packages

setup(name="robot-detection",
      version="0.2.4",
      author="Rory McCann",
      author_email="rory@technomancy.org",
      py_modules=['robot_detection'],
)
