class FirstClass:
    pass


class SecondClass:
    pass


def first_function():
    c = 42


def second_function():
    this_is_a_variable_with_a_really_long_name = 96


a = FirstClass()
b = SecondClass()
first_function()
second_function()
a = SecondClass()
c = 42
