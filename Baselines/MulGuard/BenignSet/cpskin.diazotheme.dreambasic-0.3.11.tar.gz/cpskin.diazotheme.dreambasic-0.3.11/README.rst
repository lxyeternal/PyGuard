============================
cpskin.diazotheme.dreambasic
============================

This is a Cpskin Diazo theme

Installation
------------

Add this to your buildout.cfg, or do something equivalent

::

    develop += src/cpskin.diazotheme.dreambasic
    
    [instance]
    eggs += cpskin.diazotheme.dreambasic
    zcml += cpskin.diazotheme.dreambasic

Install the package in the quickinstaller

Activate the diazo theme

Screenshot
----------

.. image:: /cpskin/diazotheme/dreambasic/static/preview.png
