=====
Usage
=====

To use litter_getter in a project::

    import litter_getter
