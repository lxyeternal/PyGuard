litter_getter package
=====================

Submodules
----------

litter_getter.hero module
-------------------------

.. automodule:: litter_getter.hero
    :members:
    :undoc-members:
    :show-inheritance:

litter_getter.pubmed module
---------------------------

.. automodule:: litter_getter.pubmed
    :members:
    :undoc-members:
    :show-inheritance:

litter_getter.ris module
------------------------

.. automodule:: litter_getter.ris
    :members:
    :undoc-members:
    :show-inheritance:

litter_getter.utils module
--------------------------

.. automodule:: litter_getter.utils
    :members:
    :undoc-members:
    :show-inheritance:


Module contents
---------------

.. automodule:: litter_getter
    :members:
    :undoc-members:
    :show-inheritance:
