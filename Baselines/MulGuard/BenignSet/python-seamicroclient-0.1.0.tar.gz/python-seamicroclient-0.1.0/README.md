Python client for consuming SeaMicro REST API v2.0

