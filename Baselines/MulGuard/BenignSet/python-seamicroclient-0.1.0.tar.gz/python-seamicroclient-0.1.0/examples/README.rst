To run example script

PYTHONPATH=./../seamicroclient/ python ./server_example.py
