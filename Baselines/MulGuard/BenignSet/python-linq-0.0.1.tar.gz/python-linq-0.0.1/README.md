# python-linq
Provides simple to use LINQ features to Python.

## Install
Coming soon...

## Usage
Coming soon...
