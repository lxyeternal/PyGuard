
# It must be possible to import this file with 
# none of the package's dependencies installed

__version__ = '0.1.0'
