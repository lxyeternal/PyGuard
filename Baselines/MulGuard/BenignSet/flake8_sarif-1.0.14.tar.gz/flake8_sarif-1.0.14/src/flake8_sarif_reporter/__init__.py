"""flake8_sarif_reporter module."""
__version__ = "1.0.14"
