#!/usr/bin/env python3
# -*- coding: utf-8 -*-

from palmiche._version import __version__, __version_tuple__
__author__ = "Alejandro Martínez León"
__email__ = "ale94mleon@gmail.com"