from setuptools import setup

setup(name='dsnd_g_v1_probability',
      version='0.1',
      description='Gaussian distributions',
      packages=['dsnd_g_v1_probability'],
      zip_safe=False)
