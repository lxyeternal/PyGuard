v1.0.0
======

Introducing ``jaraco.versioning`` based on ``hgtools`` 9.2.
