from django.apps import AppConfig


class GarpixUtilsConfig(AppConfig):
    name = 'garpix_utils'
    verbose_name = 'GarpixUtils'
