=======
History
=======

0.1.0 (2020-07-27)
------------------

- Initial release on PyPI.
