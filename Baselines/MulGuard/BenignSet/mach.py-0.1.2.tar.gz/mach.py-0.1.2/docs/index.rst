Welcome to mach's documentation!
======================================

.. toctree::
   :maxdepth: 2

   readme
   installation
   usage
   contributing
   history
