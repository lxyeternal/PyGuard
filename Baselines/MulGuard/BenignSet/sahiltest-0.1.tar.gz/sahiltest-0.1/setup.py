from setuptools import setup, find_packages

setup(
    name='sahiltest',
    version='0.1',
    description='A sample Python package',
    author='Sahil Kumar',
    author_email='sahilkanger1999@gmail.com',
    packages=find_packages(),
    install_requires=[],
)
