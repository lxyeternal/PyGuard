from create_app.cli import main

main()
