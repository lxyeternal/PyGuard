# Python implementation of A. Sierk's `BARFIT`

Read online version: https://gitlab.in2p3.fr/gregoire.henning/fisbar-python/-/tree/v001

![](badges/version.svg)
![](badges/pytest.svg)
![](badges/coverage.svg)
![](badges/profile.svg)
![](badges/mypy.svg)
![](badges/pylint.svg)
![](badges/flake8.w.svg)
![](badges/flake8.e.svg)
![Python 3.6](https://img.shields.io/badge/python-3.6-blue.svg)
![](https://img.shields.io/badge/License-CeCILL-blue)
[![Binder](https://mybinder.org/badge_logo.svg)](https://mybinder.org/v2/git/https%3A%2F%2Fgitlab.in2p3.fr%2Fgregoire.henning%2Ffisbar-python/v001)

## History

Between 1984 and 2986, A. J. Sierk developped the `BARFIT` (also refered as `fisbar`) routine to compute fission barrier, ground state energy and maximum angular momentum a nucleus can sustain in the framework of the liquid drop model. 

The routine used fitted value over a wide range of A, Z and L. 
In fact, it is an impressive piece of code that performs a global fit, where we would use today some kind of machine learning model.
The full calculation and routine is described in [*A. Sierk, Phys. Rev. C33 (1986) 2039.*](https://journals.aps.org/prc/abstract/10.1103/PhysRevC.33.2039).


The [routine](https://www-nds.iaea.org/RIPL-3/fission/fis-barrier-liquiddrop.for) is still available today from the [RIPL-3 website](https://www-nds.iaea.org/RIPL-3/) ([Readme of original routine](https://www-nds.iaea.org/RIPL-3/fission/fis-barrier-liquiddrop.readme)).

## Python implementation

The 1986 Fortran routine is old and may not compile on modern computers. However, the routine is still of great interest, as it is able to provide an estimate for a fission barrier for light elements (For heavy ones, one can find the predicted values by P.&nbsp;Moeller, A.&nbsp;J.&nbsp;Sierk, *et&nbsp;al* : "**[HEAVY-ELEMENT FISSION BARRIERS](https://t2.lanl.gov/nis/molleretal/publications/PRCFIS-2009.html)**").

The code of is quite straightforward, so it's not too hard to translate it into python. 

This is one implementation in python 3.6. The code is almost a line-for-line translation of the original fortran routine. As is, it is quite un-pythonic, but it makes the working, testing and checking easier when writing from the orginal code.

The `lpoly` routine of Sierk was replaced with the `numpy.polynomial.legendre` module to obtain the legendre polynomial values. (This is the only external dependency of the module).

### Accuracy

The output of the code is compared to the references values given by A. Sierk in the [original Fortran file](https://www-nds.iaea.org/RIPL-3/fission/fis-barrier-liquiddrop.for). 
The python module was tested against theses values : 

|   |   |   |      A. Sierk's reference values       ||| Python Implementation results       || |
|---|---|---|:--------:|:---:|:----:|:--------------:|:---:|:----:|
| Z | A | L | B_f      | Egs | Lmax | Bf             | Egs | Lmax | 
|   |   |   |          |     |      |                |     |      |
| 28 | 58 | 0 | 33.14   | 0.0 | 46.1 | 33.14    | 0.00 | 46.13 |
| 28 | 58 | 25 | 19.5   | 21.36 | 46.1 | 18.52    | 20.00 | 46.13 |
| 28 | 58 | 40 | 2.97   | 49.66 | 46.1 | 2.47    | 31.18 | 46.13 |
| 28 | 58 | 46.1 | 0   | 59.14 | 46.1 | 0.00    | 58.56 | 46.13 |
|   |   |   |          |     |      |                |     |      |
| 65 | 153 | 0 | 28.88   | 0.0 | 82.3 | 28.88    | 0.00 | 82.27 |
| 65 | 153 | 50 | 16.16   | 19.0 | 82.3 | 14.16    | 19.80 | 82.27 |
| 65 | 153 | 80 | 0.26   | 45.24 | 82.3 | 0.12    | 31.47 | 82.27 |
| 65 | 153 | 82.3 | 0.0   | 47.01 | 82.3 | 0.00    | 47.29 | 82.27 | 
|   |   |   |          |     |      |                |     |      |
| 93 | 229 | 0 | 3.76   | 0.0 | 68.1 | 3.76    | 0.00 | 68.13 |
| 93 | 229 | 45 | 1.26   | 8.21 | 68.1 | 1.22    | 9.12 | 68.13 |
| 93 | 229 | 68.1 | 0.0   | 17.96 | 68.1 | 0.00    | 17.83 | 68.13 |

⚠ We notice significant differences. This is probably due to floating point precision between today's python and the Fortran used by A. Sierk to perform the fits in 1986. Therefore, the values should be not be taken at face value, but they are a good first approximation. 


### Online version

An online [![Binder](https://mybinder.org/badge_logo.svg)](https://mybinder.org/v2/git/https%3A%2F%2Fgitlab.in2p3.fr%2Fgregoire.henning%2Ffisbar-python/v001?filepath=online.ipynb) notebook has been created to allow the execution of the code online.


Click on the [![Binder](https://mybinder.org/badge_logo.svg)](https://mybinder.org/v2/git/https%3A%2F%2Fgitlab.in2p3.fr%2Fgregoire.henning%2Ffisbar-python/v001?filepath=online.ipynb) link and once the notebook is started, run the only cell on the top with the `Execute` ▶ button (or the `Cell` menu and `Execute All`). The interface to enter your input Z, A and L will appear. Put in your parameters of interest and click the **Go** button. The result will appear below. If the calculation failed, a ❌ will appear and the shown values will be **0** or **"\*\*"**

### Running Locally

You can also install and run the routine on your local computer.

#### Installation

###### Requirements

The only external dependency is [numpy](https://numpy.org/). The module has been developped with version **1.18**.
The developpment was made with python 3.8.6 but should work starting with version 3.6.

##### Via pip

The prefered way of installing the library is via `pip` by running the following command:

```shell
$ pip install fisbar
```


##### Using the `.whl` file

Installation can be perfomed using the [dist/fisbar-release_001-py3-none-any.whl](dist/fisbar-release_001-py3-none-any.whl) file, that contain the module installation files, to be installed via :

```shell
$ pip install dist/fisbar-release_001-py3-none-any.whl
```

This is useful if you need to install the software on a computer not connected to the internet, or to install a version that is not the in the PyPi registry yet.


##### *by hand*

Additionnally, you can install the package by downloading the [files](dist/fisbar_release-001_hal.tar.gz) from gitlab and install them *by hand*. Use this method at your own risk.

#### Running

##### As a standalone program

Once installed, the module can be used as a standalone software.

Usage:

```shell
$ python -m fisbar [-h] [--style {columns,human,dict,yaml}] Z A [L]
```

This runs the module at stand alone program. 

Arguments are `Z`, `A` (both mandatory), `L` (default = 0) and output style.

The style can be `columns`, `human`, `dict` (default) or `yaml`. 
When using `columns` output style, the results are outputed as columns following : `Z A L bfis Egs Lmax`.
`human` outputs the results in a readable format. `yaml` as a Yaml formated dictionnary and `dict` as a python dictionnary (also compatible with json). When a value is not computed (because the code failed), it appears either as 0 or `***`.


##### As a python module

The `fisbar` routine can be used in a python code by importing it inside your program. For example

```python
import fisbar

Z = 92
A = 238
L = 0

print(fisbar,fisbar(Z, A, L))
```

will output the follwoing :
> {'success': True, 'Z': 92, 'A': 238, 'L': 0, 'bfis': 5.025724362097368, 'elmax': 74.71058361153018, 'egs': 0.0, 'sel80': 25.15441724085784, 'sel20': -7678.607423002325, 'exit': 'condition(il < 1)'}
> 

The routine returns a `dict` with 

- `success` either `True` or `False`
- `Z`, `A`, and `L`: the input parameters
- `bfis`, `egs`, and `elmax` the computed values of Bf, Egs and Lmax.
- and (possibliy) other items related to the routine internal work.


## Versions

- Current: [![](badges/version.svg)](https://gitlab.in2p3.fr/gregoire.henning/fisbar-python/-/tree/v001)
- [20201120](https://gitlab.in2p3.fr/gregoire.henning/fisbar-python/-/commits/dev-20201120) developpment branch. (pre-version 1)

## Authors

- Greg Henning

## Licence 

- [CeCILL FREE SOFTWARE LICENSE AGREEMENT](LICENSE)
- [Original file](https://www-nds.iaea.org/RIPL-3/fission/fis-barrier-liquiddrop.for) license :
```
Copyright, 1986,  The Regents of the University of California.
This software was produced under a U. S. Government contract
(W-7405-ENG-36) by the Los Alamos National Laboratory, which is
operated by the University of California for the U. S. Department
of Energy.  The U. S. Government is licensed to use, reproduce,
and distribute this software.  Permission is granted to the public
to copy and use this software without charge, provided that this
notice and any statement of authorship are reproduced on all
copies.  Neither the Government nor the University makes any
warranty, expressed or implied, or assumes any liability
or responsibility for the use of this software.
```