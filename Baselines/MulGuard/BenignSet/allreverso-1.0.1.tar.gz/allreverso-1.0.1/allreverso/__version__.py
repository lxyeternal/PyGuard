__title__ = 'allreverso'
__description__ = 'A simple package to handle allreverso.net services (translation, voice, dictionary etc.).'
__url__ = 'https:/github.com/PetitPotiron/allreverso/'
__version__ = '1.0.1'
__build__ = 0x1
__author__ = '🔥 Fire'
__author_discord__ = '🔥 Fire#8388 (id : 715826047949471785)'
__license__ = 'Apache 2.0'
__copyright__ = 'Copyright (c) 2021 🔥 Fire'

