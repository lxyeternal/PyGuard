import os

_kachery_cloud_api_url = os.environ.get('KACHERY_CLOUD_API_URL', 'https://cloud.kacheryhub.org')