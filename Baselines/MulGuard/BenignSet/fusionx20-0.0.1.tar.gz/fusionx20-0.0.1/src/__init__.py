from main import sayhi
sayhi()
