<br />
<img src='https://i.imgur.com/ehI5gmo.png'>

```bash
pip install omic
```

```python
from omic import omic
omic.configure({'user': '[YOUR_USER_ID]'})
data = omic.client('data')
client.download(vpath='/', mode='public')
```

<!-- <hr /> -->

[c19.ai](https://c19.ai) | [omic.ai](https://omic.ai)