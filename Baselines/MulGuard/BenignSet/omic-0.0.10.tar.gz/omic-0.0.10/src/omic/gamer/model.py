class OmicModel(object):
    def __init__(self):
        pass
    def train(self):
        raise NotImplemented()
    def test(self):
        raise NotImplemented()