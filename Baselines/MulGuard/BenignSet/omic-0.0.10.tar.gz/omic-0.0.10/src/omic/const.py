PROD_ENDPOINT = 'https://lg4cwf8juj.execute-api.us-west-2.amazonaws.com/api'
DEVEL_ENDPOINT = 'https://ichdv2ek6j.execute-api.us-west-2.amazonaws.com/api'
LOCAL_ENDPOINT = 'http://127.0.0.1:3001'
