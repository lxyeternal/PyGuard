from .omic import Omic
omic = Omic()