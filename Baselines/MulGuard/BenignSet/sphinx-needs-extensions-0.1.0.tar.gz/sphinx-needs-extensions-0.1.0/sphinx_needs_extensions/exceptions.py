class InvalidConfigException(BaseException):
    pass


class CommunicationException(BaseException):
    pass
