from collections import OrderedDict

# Type names for comparison
# Checking types is a bad idea, blahdy blahdy blahdy

dictType = type(dict())
orderedDictType = type(OrderedDict())
listType = type(list())
unicodeType = type(u'')
noneType = type(None)
strType = type('')
