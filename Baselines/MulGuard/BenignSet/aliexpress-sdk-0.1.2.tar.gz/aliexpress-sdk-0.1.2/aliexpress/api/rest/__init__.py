from aliexpress.api.rest.PostproductRedefiningOnlineaeproductRequest import (
    AliexpressPostproductRedefiningOnlineaeproductRequest,
)
from aliexpress.api.rest.PostproductRedefiningEditsingleskustockRequest import (
    AliexpressPostproductRedefiningEditsingleskustockRequest,
)
from aliexpress.api.rest.PostproductRedefiningFindaeproductbyidRequest import (
    AliexpressPostproductRedefiningFindaeproductbyidRequest,
)
from aliexpress.api.rest.TradeRedefiningFindorderlistsimplequeryRequest import (
    AliexpressTradeRedefiningFindorderlistsimplequeryRequest,
)
from aliexpress.api.rest.PostproductRedefiningSetsizechartRequest import (
    AliexpressPostproductRedefiningSetsizechartRequest,
)
from aliexpress.api.rest.ImageRedefiningUploadtempimageRequest import (
    AliexpressImageRedefiningUploadtempimageRequest,
)
from aliexpress.api.rest.SolutionBatchProductPriceUpdateRequest import (
    AliexpressSolutionBatchProductPriceUpdateRequest,
)
from aliexpress.api.rest.logistics.RedefiningGetallprovinceRequest import (
    AliexpressLogisticsRedefiningGetallprovinceRequest,
)
from aliexpress.api.rest.MerchantRedefiningQuerydsrddisputeproductlistRequest import (
    AliexpressMerchantRedefiningQuerydsrddisputeproductlistRequest,
)
from aliexpress.api.rest.SolutionIssuePartnerRmaStateUpdateRequest import (
    AliexpressSolutionIssuePartnerRmaStateUpdateRequest,
)
from aliexpress.api.rest.PhotobankRedefiningUploadimageforsdkRequest import (
    AliexpressPhotobankRedefiningUploadimageforsdkRequest,
)
from aliexpress.api.rest.FreightRedefiningCalculatefreightRequest import (
    AliexpressFreightRedefiningCalculatefreightRequest,
)
from aliexpress.api.rest.OfferRedefiningDeletebundleRequest import (
    AliexpressOfferRedefiningDeletebundleRequest,
)
from aliexpress.api.rest.PhotobankRedefiningDelunusephotoRequest import (
    AliexpressPhotobankRedefiningDelunusephotoRequest,
)
from aliexpress.api.rest.PostproductRedefiningGetproductgrouplistRequest import (
    AliexpressPostproductRedefiningGetproductgrouplistRequest,
)
from aliexpress.api.rest.KfcKeywordSearchRequest import (
    KfcKeywordSearchRequest,
)
from aliexpress.api.rest.MerchantOverseaBrandGetRequest import (
    AliexpressMerchantOverseaBrandGetRequest,
)
from aliexpress.api.rest.MarketingLimitdiscountpromotionEditRequest import (
    AliexpressMarketingLimitdiscountpromotionEditRequest,
)
from aliexpress.api.rest.PostproductRedefiningEditmultilanguageproductRequest import (
    AliexpressPostproductRedefiningEditmultilanguageproductRequest,
)
from aliexpress.api.rest.DataRedefiningQueryproductviewedinfoeverydaybyidRequest import (
    AliexpressDataRedefiningQueryproductviewedinfoeverydaybyidRequest,
)
from aliexpress.api.rest.MerchantRedefiningQueryremarksRequest import (
    AliexpressMerchantRedefiningQueryremarksRequest,
)
from aliexpress.api.rest.PostproductRedefiningCreateproductgroupRequest import (
    AliexpressPostproductRedefiningCreateproductgroupRequest,
)
from aliexpress.api.rest.PostproductRedefiningQueryproductgroupidbyproductidRequest import (
    AliexpressPostproductRedefiningQueryproductgroupidbyproductidRequest,
)
from aliexpress.api.rest.IssueIssuelistGetRequest import (
    AliexpressIssueIssuelistGetRequest,
)
from aliexpress.api.rest.SolutionSkuAttributeQueryRequest import (
    AliexpressSolutionSkuAttributeQueryRequest,
)
from aliexpress.api.rest.OfferDraftproductsGetRequest import (
    AliexpressOfferDraftproductsGetRequest,
)
from aliexpress.api.rest.PostproductRedefiningGetsizechartinfobycategoryidRequest import (
    AliexpressPostproductRedefiningGetsizechartinfobycategoryidRequest,
)
from aliexpress.api.rest.PhotobankRedefiningUploadimageRequest import (
    AliexpressPhotobankRedefiningUploadimageRequest,
)
from aliexpress.api.rest.PostproductRedefiningFindaeproductmodulebyidRequest import (
    AliexpressPostproductRedefiningFindaeproductmodulebyidRequest,
)
from aliexpress.api.rest.MessageFaqwelcomeEditRequest import (
    AliexpressMessageFaqwelcomeEditRequest,
)
from aliexpress.api.rest.OfferProductPostRequest import (
    AliexpressOfferProductPostRequest,
)
from aliexpress.api.rest.PostproductRedefiningEditaeproductRequest import (
    AliexpressPostproductRedefiningEditaeproductRequest,
)
from aliexpress.api.rest.TradeSellerOrderlistGetRequest import (
    AliexpressTradeSellerOrderlistGetRequest,
)
from aliexpress.api.rest.CainiaoGlobalHandoverSavedraftRequest import (
    CainiaoGlobalHandoverSavedraftRequest,
)
from aliexpress.api.rest.MarketingLimitdiscountpromotionproductDelRequest import (
    AliexpressMarketingLimitdiscountpromotionproductDelRequest,
)
from aliexpress.api.rest.OpenuidGetRequest import OpenuidGetRequest
from aliexpress.api.rest.MarketingLimitdiscountpromotionproductEditRequest import (
    AliexpressMarketingLimitdiscountpromotionproductEditRequest,
)
from aliexpress.api.rest.MerchantRedefiningQuerylevelinfoRequest import (
    AliexpressMerchantRedefiningQuerylevelinfoRequest,
)
from aliexpress.api.rest.logistics.RedefiningSellermodifiedshipmentsupportsubtradeorderRequest import (
    AliexpressLogisticsRedefiningSellermodifiedshipmentsupportsubtradeorderRequest,
)
from aliexpress.api.rest.PostproductRedefiningSetshopwindowproductRequest import (
    AliexpressPostproductRedefiningSetshopwindowproductRequest,
)
from aliexpress.api.rest.SolutionSchemaProductInstancePostRequest import (
    AliexpressSolutionSchemaProductInstancePostRequest,
)
from aliexpress.api.rest.SolutionIssuePartnerRmaScreeningCreateRequest import (
    AliexpressSolutionIssuePartnerRmaScreeningCreateRequest,
)
from aliexpress.api.rest.logistics.QuerylogisticsorderdetailRequest import (
    AliexpressLogisticsQuerylogisticsorderdetailRequest,
)
from aliexpress.api.rest.OpenuidChangeRequest import OpenuidChangeRequest
from aliexpress.api.rest.PostproductRedefiningQuerypromisetemplatebyidRequest import (
    AliexpressPostproductRedefiningQuerypromisetemplatebyidRequest,
)
from aliexpress.api.rest.PostproductRedefiningFindaeproductdetailmodulelistbyqureyRequest import (
    AliexpressPostproductRedefiningFindaeproductdetailmodulelistbyqureyRequest,
)
from aliexpress.api.rest.OfferProductQueryRequest import (
    AliexpressOfferProductQueryRequest,
)
from aliexpress.api.rest.SolutionProductPostRequest import (
    AliexpressSolutionProductPostRequest,
)
from aliexpress.api.rest.PostproductRedefiningOfflineaeproductRequest import (
    AliexpressPostproductRedefiningOfflineaeproductRequest,
)
from aliexpress.api.rest.TradeRedefiningFindloanlistqueryRequest import (
    AliexpressTradeRedefiningFindloanlistqueryRequest,
)
from aliexpress.api.rest.TradeRedefiningFindorderreceiptinfoRequest import (
    AliexpressTradeRedefiningFindorderreceiptinfoRequest,
)
from aliexpress.api.rest.OfferRedefiningCopysizetemplateRequest import (
    AliexpressOfferRedefiningCopysizetemplateRequest,
)
from aliexpress.api.rest.DataRedefiningQueryproductbusinessinfobyidRequest import (
    AliexpressDataRedefiningQueryproductbusinessinfobyidRequest,
)
from aliexpress.api.rest.FilesGetRequest import FilesGetRequest
from aliexpress.api.rest.TopAuthTokenCreateRequest import (
    TopAuthTokenCreateRequest,
)
from aliexpress.api.rest.PhotobankRedefiningListimagepaginationRequest import (
    AliexpressPhotobankRedefiningListimagepaginationRequest,
)
from aliexpress.api.rest.DataRedefiningQueryproductexposedinfoeverydaybyidRequest import (
    AliexpressDataRedefiningQueryproductexposedinfoeverydaybyidRequest,
)
from aliexpress.api.rest.CainiaoGlobalSolutionInquiryRequest import (
    CainiaoGlobalSolutionInquiryRequest,
)
from aliexpress.api.rest.logistics.CreatewarehouseorderRequest import (
    AliexpressLogisticsCreatewarehouseorderRequest,
)
from aliexpress.api.rest.EvaluationListorderevaluationGetRequest import (
    AliexpressEvaluationListorderevaluationGetRequest,
)
from aliexpress.api.rest.MessageFaqwelcomeAddRequest import (
    AliexpressMessageFaqwelcomeAddRequest,
)
from aliexpress.api.rest.PostproductRedefiningPostmultilanguageaeproductRequest import (
    AliexpressPostproductRedefiningPostmultilanguageaeproductRequest,
)
from aliexpress.api.rest.SolutionIssuePartnerRmaReverselogisticStateUpdateRequest import (
    AliexpressSolutionIssuePartnerRmaReverselogisticStateUpdateRequest,
)
from aliexpress.api.rest.OfferRedefiningInitialnewbundleRequest import (
    AliexpressOfferRedefiningInitialnewbundleRequest,
)
from aliexpress.api.rest.MerchantRedefiningQueryservicescoreinfoRequest import (
    AliexpressMerchantRedefiningQueryservicescoreinfoRequest,
)
from aliexpress.api.rest.logistics.RedefiningGetprintinfoRequest import (
    AliexpressLogisticsRedefiningGetprintinfoRequest,
)
from aliexpress.api.rest.SolutionOrderInfoGetRequest import (
    AliexpressSolutionOrderInfoGetRequest,
)
from aliexpress.api.rest.CategoryRedefiningGetchildattributesresultbypostcateidandpathRequest import (
    AliexpressCategoryRedefiningGetchildattributesresultbypostcateidandpathRequest,
)
from aliexpress.api.rest.MarketingStorepromotionProductsQueryRequest import (
    AliexpressMarketingStorepromotionProductsQueryRequest,
)
from aliexpress.api.rest.MessageFaqEditRequest import (
    AliexpressMessageFaqEditRequest,
)
from aliexpress.api.rest.MessageRedefiningVersiontwoQuerymsgdetaillistRequest import (
    AliexpressMessageRedefiningVersiontwoQuerymsgdetaillistRequest,
)
from aliexpress.api.rest.OfferProductSkupricesEditRequest import (
    AliexpressOfferProductSkupricesEditRequest,
)
from aliexpress.api.rest.MessageFaqListRequest import (
    AliexpressMessageFaqListRequest,
)
from aliexpress.api.rest.CainiaoGlobalHandoverCloudprintGetRequest import (
    CainiaoGlobalHandoverCloudprintGetRequest,
)
from aliexpress.api.rest.MerchantRedefiningQueryremarkRequest import (
    AliexpressMerchantRedefiningQueryremarkRequest,
)
from aliexpress.api.rest.TradeSellerOrderAcceptcancelRequest import (
    AliexpressTradeSellerOrderAcceptcancelRequest,
)
from aliexpress.api.rest.TopIpoutGetRequest import TopIpoutGetRequest
from aliexpress.api.rest.SolutionMerchantProfileGetRequest import (
    AliexpressSolutionMerchantProfileGetRequest,
)
from aliexpress.api.rest.AppraiseRedefiningSavesellerfeedbackRequest import (
    AliexpressAppraiseRedefiningSavesellerfeedbackRequest,
)
from aliexpress.api.rest.SolutionBatchProductDeleteRequest import (
    AliexpressSolutionBatchProductDeleteRequest,
)
from aliexpress.api.rest.logistics.RedefiningGetonlinelogisticsservicelistbyorderidRequest import (
    AliexpressLogisticsRedefiningGetonlinelogisticsservicelistbyorderidRequest,
)
from aliexpress.api.rest.PostproductRedefiningEditsingleskupriceRequest import (
    AliexpressPostproductRedefiningEditsingleskupriceRequest,
)
from aliexpress.api.rest.DataRedefiningQueryproductfavoritedinfoeverydaybyidRequest import (
    AliexpressDataRedefiningQueryproductfavoritedinfoeverydaybyidRequest,
)
from aliexpress.api.rest.PostproductRedefiningPostaeproductRequest import (
    AliexpressPostproductRedefiningPostaeproductRequest,
)
from aliexpress.api.rest.SolutionProductInfoGetRequest import (
    AliexpressSolutionProductInfoGetRequest,
)
from aliexpress.api.rest.SolutionBatchProductInventoryUpdateRequest import (
    AliexpressSolutionBatchProductInventoryUpdateRequest,
)
from aliexpress.api.rest.CainiaoGlobalHandoverPdfGetRequest import (
    CainiaoGlobalHandoverPdfGetRequest,
)
from aliexpress.api.rest.MessageFaqwelcomeDelRequest import (
    AliexpressMessageFaqwelcomeDelRequest,
)
from aliexpress.api.rest.HttpdnsGetRequest import HttpdnsGetRequest
from aliexpress.api.rest.CategoryRedefiningGetpostcategorybyidRequest import (
    AliexpressCategoryRedefiningGetpostcategorybyidRequest,
)
from aliexpress.api.rest.IssueSolutionAgreeRequest import (
    AliexpressIssueSolutionAgreeRequest,
)
from aliexpress.api.rest.PostproductRedefiningRenewexpireRequest import (
    AliexpressPostproductRedefiningRenewexpireRequest,
)
from aliexpress.api.rest.TradeRedefiningExtendsbuyeracceptgoodstimeRequest import (
    AliexpressTradeRedefiningExtendsbuyeracceptgoodstimeRequest,
)
from aliexpress.api.rest.AppipGetRequest import AppipGetRequest
from aliexpress.api.rest.CategoryRedefiningGetchildrenpostcategorybyidRequest import (
    AliexpressCategoryRedefiningGetchildrenpostcategorybyidRequest,
)
from aliexpress.api.rest.TimeGetRequest import TimeGetRequest
from aliexpress.api.rest.MarketingStorepromotionsQuerybyproductRequest import (
    AliexpressMarketingStorepromotionsQuerybyproductRequest,
)
from aliexpress.api.rest.CainiaoGlobalHandoverContentQueryRequest import (
    CainiaoGlobalHandoverContentQueryRequest,
)
from aliexpress.api.rest.SolutionOrderFulfillRequest import (
    AliexpressSolutionOrderFulfillRequest,
)
from aliexpress.api.rest.MessageFaqwelcomeGetRequest import (
    AliexpressMessageFaqwelcomeGetRequest,
)
from aliexpress.api.rest.FreightRedefiningListfreighttemplateRequest import (
    AliexpressFreightRedefiningListfreighttemplateRequest,
)
from aliexpress.api.rest.IssueSolutionSaveRequest import (
    AliexpressIssueSolutionSaveRequest,
)
from aliexpress.api.rest.TopSecretGetRequest import TopSecretGetRequest
from aliexpress.api.rest.OfferRedefiningGetsizetemplatesbycategoryidRequest import (
    AliexpressOfferRedefiningGetsizetemplatesbycategoryidRequest,
)
from aliexpress.api.rest.MemberRedefiningQueryaccountlevelRequest import (
    AliexpressMemberRedefiningQueryaccountlevelRequest,
)
from aliexpress.api.rest.OfferRedefiningEditbundleRequest import (
    AliexpressOfferRedefiningEditbundleRequest,
)
from aliexpress.api.rest.CategoryRedefiningSizemodelsrequiredforpostcatRequest import (
    AliexpressCategoryRedefiningSizemodelsrequiredforpostcatRequest,
)
from aliexpress.api.rest.PhotobankRedefiningListgroupRequest import (
    AliexpressPhotobankRedefiningListgroupRequest,
)
from aliexpress.api.rest.CainiaoGlobalHandoverCommitRequest import (
    CainiaoGlobalHandoverCommitRequest,
)
from aliexpress.api.rest.TradeRedefiningFindordertradeinfoRequest import (
    AliexpressTradeRedefiningFindordertradeinfoRequest,
)
from aliexpress.api.rest.logistics.RedefiningGetprintinfosRequest import (
    AliexpressLogisticsRedefiningGetprintinfosRequest,
)
from aliexpress.api.rest.MessageFaqAddRequest import (
    AliexpressMessageFaqAddRequest,
)
from aliexpress.api.rest.MessageRedefiningVersiontwoQuerymsgdetaillistbybuyeridRequest import (
    AliexpressMessageRedefiningVersiontwoQuerymsgdetaillistbybuyeridRequest,
)
from aliexpress.api.rest.SolutionProductEditRequest import (
    AliexpressSolutionProductEditRequest,
)
from aliexpress.api.rest.OpenuidGetBytradeRequest import (
    OpenuidGetBytradeRequest,
)
from aliexpress.api.rest.MarketingRedefiningFindsellercouponactivityRequest import (
    AliexpressMarketingRedefiningFindsellercouponactivityRequest,
)
from aliexpress.api.rest.logistics.SellershipmentsupportsubtradeorderRequest import (
    AliexpressLogisticsSellershipmentsupportsubtradeorderRequest,
)
from aliexpress.api.rest.OfferRedefiningQuerybundleRequest import (
    AliexpressOfferRedefiningQuerybundleRequest,
)
from aliexpress.api.rest.OfferProductEditRequest import (
    AliexpressOfferProductEditRequest,
)
from aliexpress.api.rest.PostproductRedefiningEditproductcidattidskuRequest import (
    AliexpressPostproductRedefiningEditproductcidattidskuRequest,
)
from aliexpress.api.rest.MarketingPromotionListRequest import (
    AliexpressMarketingPromotionListRequest,
)
from aliexpress.api.rest.FreightRedefiningGetfreightsettingbytemplatequeryRequest import (
    AliexpressFreightRedefiningGetfreightsettingbytemplatequeryRequest,
)
from aliexpress.api.rest.DataRedefiningQueryproductsalesinfoeverydaybyidRequest import (
    AliexpressDataRedefiningQueryproductsalesinfoeverydaybyidRequest,
)
from aliexpress.api.rest.IssueDetailGetRequest import (
    AliexpressIssueDetailGetRequest,
)
from aliexpress.api.rest.DataRedefiningQueryproductaddcartinfoeverydaybyidRequest import (
    AliexpressDataRedefiningQueryproductaddcartinfoeverydaybyidRequest,
)
from aliexpress.api.rest.logistics.RedefiningGetfieldinfoforprintRequest import (
    AliexpressLogisticsRedefiningGetfieldinfoforprintRequest,
)
from aliexpress.api.rest.AppraiseRedefiningQuerysellerevaluationorderlistRequest import (
    AliexpressAppraiseRedefiningQuerysellerevaluationorderlistRequest,
)
from aliexpress.api.rest.MessageRedefiningVersiontwoUpdatemsgprocessedRequest import (
    AliexpressMessageRedefiningVersiontwoUpdatemsgprocessedRequest,
)
from aliexpress.api.rest.PostproductRedefiningEditmutilpleskustocksRequest import (
    AliexpressPostproductRedefiningEditmutilpleskustocksRequest,
)
from aliexpress.api.rest.SolutionSellerCategoryTreeQueryRequest import (
    AliexpressSolutionSellerCategoryTreeQueryRequest,
)
from aliexpress.api.rest.MarketingStorepromotionsListRequest import (
    AliexpressMarketingStorepromotionsListRequest,
)
from aliexpress.api.rest.logistics.GetpdfsbycloudprintRequest import (
    AliexpressLogisticsGetpdfsbycloudprintRequest,
)
from aliexpress.api.rest.RedefiningGetlogisticsselleraddressesRequest import (
    AliexpressLogisticsRedefiningGetlogisticsselleraddressesRequest,
)
from aliexpress.api.rest.logistics.RedefiningGetonlinelogisticsinfoRequest import (
    AliexpressLogisticsRedefiningGetonlinelogisticsinfoRequest,
)
from aliexpress.api.rest.PostproductRedefiningFindproductinfolistqueryRequest import (
    AliexpressPostproductRedefiningFindproductinfolistqueryRequest,
)
from aliexpress.api.rest.PhotobankRedefiningQueryphotobankimagebypathsRequest import (
    AliexpressPhotobankRedefiningQueryphotobankimagebypathsRequest,
)
from aliexpress.api.rest.TradeNewRedefiningFindorderbyidRequest import (
    AliexpressTradeNewRedefiningFindorderbyidRequest,
)
from aliexpress.api.rest.CainiaoGlobalSolutionServiceResourceQueryRequest import (
    CainiaoGlobalSolutionServiceResourceQueryRequest,
)
from aliexpress.api.rest.PostproductRedefiningCategoryforecastRequest import (
    AliexpressPostproductRedefiningCategoryforecastRequest,
)
from aliexpress.api.rest.logistics.SellershipmentfortopRequest import (
    AliexpressLogisticsSellershipmentfortopRequest,
)
from aliexpress.api.rest.SolutionFeedQueryRequest import (
    AliexpressSolutionFeedQueryRequest,
)
from aliexpress.api.rest.MerchantRedefiningSaveremarkRequest import (
    AliexpressMerchantRedefiningSaveremarkRequest,
)
from aliexpress.api.rest.MessageRedefiningVersiontwoQuerymsgrelationlistRequest import (
    AliexpressMessageRedefiningVersiontwoQuerymsgrelationlistRequest,
)
from aliexpress.api.rest.OfferRedefiningGetcanusedproductbysizetemplateidRequest import (
    AliexpressOfferRedefiningGetcanusedproductbysizetemplateidRequest,
)
from aliexpress.api.rest.PhotobankRedefiningGetphotobankinfoRequest import (
    AliexpressPhotobankRedefiningGetphotobankinfoRequest,
)
from aliexpress.api.rest.CainiaoGlobalHandoverUpdateRequest import (
    CainiaoGlobalHandoverUpdateRequest,
)
from aliexpress.api.rest.SolutionOrderGetRequest import (
    AliexpressSolutionOrderGetRequest,
)
from aliexpress.api.rest.TopAuthTokenRefreshRequest import (
    TopAuthTokenRefreshRequest,
)
from aliexpress.api.rest.TradeSellerOrderRefusecancelRequest import (
    AliexpressTradeSellerOrderRefusecancelRequest,
)
from aliexpress.api.rest.SolutionProductListGetRequest import (
    AliexpressSolutionProductListGetRequest,
)
from aliexpress.api.rest.logistics.GetwlmailingaddresssnapshotdtoRequest import (
    AliexpressLogisticsGetwlmailingaddresssnapshotdtoRequest,
)
from aliexpress.api.rest.SolutionSchemaProductFullUpdateRequest import (
    AliexpressSolutionSchemaProductFullUpdateRequest,
)
from aliexpress.api.rest.ImageRedefiningUploadtempimageforsdkRequest import (
    AliexpressImageRedefiningUploadtempimageforsdkRequest,
)
from aliexpress.api.rest.OfferDraftproductGetRequest import (
    AliexpressOfferDraftproductGetRequest,
)
from aliexpress.api.rest.CainiaoGlobalHandoverCancelRequest import (
    CainiaoGlobalHandoverCancelRequest,
)
from aliexpress.api.rest.MessageRedefiningVersiontwoUpdatemsgreadRequest import (
    AliexpressMessageRedefiningVersiontwoUpdatemsgreadRequest,
)
from aliexpress.api.rest.OfferRedefiningCreatebundleRequest import (
    AliexpressOfferRedefiningCreatebundleRequest,
)
from aliexpress.api.rest.SolutionFeedListGetRequest import (
    AliexpressSolutionFeedListGetRequest,
)
from aliexpress.api.rest.MarketingLimiteddiscountpromotionAddpromotionproductRequest import (
    AliexpressMarketingLimiteddiscountpromotionAddpromotionproductRequest,
)
from aliexpress.api.rest.SolutionFeedSubmitRequest import (
    AliexpressSolutionFeedSubmitRequest,
)
from aliexpress.api.rest.TopSecretRegisterRequest import (
    TopSecretRegisterRequest,
)
from aliexpress.api.rest.PostproductRedefiningGetwindowproductsRequest import (
    AliexpressPostproductRedefiningGetwindowproductsRequest,
)
from aliexpress.api.rest.OpenuidGetBymixnickRequest import (
    OpenuidGetBymixnickRequest,
)
from aliexpress.api.rest.MessageRedefiningVersiontwoUpdatemsgrankRequest import (
    AliexpressMessageRedefiningVersiontwoUpdatemsgrankRequest,
)
from aliexpress.api.rest.MessageFaqGetRequest import (
    AliexpressMessageFaqGetRequest,
)
from aliexpress.api.rest.CategoryRedefiningGetallchildattributesresultRequest import (
    AliexpressCategoryRedefiningGetallchildattributesresultRequest,
)
from aliexpress.api.rest.DistributorOrderQueryRequest import (
    AliexpressDistributorOrderQueryRequest,
)
from aliexpress.api.rest.PostproductRedefiningFindaeproductstatusbyidRequest import (
    AliexpressPostproductRedefiningFindaeproductstatusbyidRequest,
)
from aliexpress.api.rest.OfferRedefiningFindbundlebyidRequest import (
    AliexpressOfferRedefiningFindbundlebyidRequest,
)
from aliexpress.api.rest.logistics.SellermodifiedshipmentfortopRequest import (
    AliexpressLogisticsSellermodifiedshipmentfortopRequest,
)
from aliexpress.api.rest.CainiaoGlobalHandoverParcelQueryRequest import (
    CainiaoGlobalHandoverParcelQueryRequest,
)
from aliexpress.api.rest.logistics.RedefiningListlogisticsserviceRequest import (
    AliexpressLogisticsRedefiningListlogisticsserviceRequest,
)
from aliexpress.api.rest.TopSdkFeedbackUploadRequest import (
    TopSdkFeedbackUploadRequest,
)
from aliexpress.api.rest.IssueImageUploadRequest import (
    AliexpressIssueImageUploadRequest,
)
from aliexpress.api.rest.PostproductRedefiningFindaeproductprohibitedwordsRequest import (
    AliexpressPostproductRedefiningFindaeproductprohibitedwordsRequest,
)
from aliexpress.api.rest.logistics.RedefiningQuerytrackingresultRequest import (
    AliexpressLogisticsRedefiningQuerytrackingresultRequest,
)
from aliexpress.api.rest.SolutionOrderReceiptinfoGetRequest import (
    AliexpressSolutionOrderReceiptinfoGetRequest,
)
from aliexpress.api.rest.SolutionProductSchemaGetRequest import (
    AliexpressSolutionProductSchemaGetRequest,
)
from aliexpress.api.rest.MarketingRedefiningGetactlistRequest import (
    AliexpressMarketingRedefiningGetactlistRequest,
)
from aliexpress.api.rest.MarketingLimitdiscountpromotionCreateRequest import (
    AliexpressMarketingLimitdiscountpromotionCreateRequest,
)
from aliexpress.api.rest.SolutionIssuePartnerRmaReverselogisticTrackinginfoCreateRequest import (
    AliexpressSolutionIssuePartnerRmaReverselogisticTrackinginfoCreateRequest,
)
from aliexpress.api.rest.TradeRedefiningFindorderbaseinfoRequest import (
    AliexpressTradeRedefiningFindorderbaseinfoRequest,
)
from aliexpress.api.rest.logistics.ValueaddedInsuranceEstimateRequest import (
    AliexpressLogisticsValueaddedInsuranceEstimateRequest,
)
from aliexpress.api.rest.PostproductRedefiningClaimtaobaoproductsapiRequest import (
    AliexpressPostproductRedefiningClaimtaobaoproductsapiRequest,
)
from aliexpress.api.rest.MessageRedefiningVersiontwoAddmsgRequest import (
    AliexpressMessageRedefiningVersiontwoAddmsgRequest,
)
from aliexpress.api.rest.PostproductRedefiningEditsimpleproductfiledRequest import (
    AliexpressPostproductRedefiningEditsimpleproductfiledRequest,
)
from aliexpress.api.rest.logistics.QuerysellershipmentinfoRequest import (
    AliexpressLogisticsQuerysellershipmentinfoRequest,
)
from aliexpress.api.rest.logistics.RedefiningGetnextleveladdressdataRequest import (
    AliexpressLogisticsRedefiningGetnextleveladdressdataRequest,
)
from aliexpress.api.rest.MessageFaqDelRequest import (
    AliexpressMessageFaqDelRequest,
)
from aliexpress.api.rest.PostproductRedefiningSetgroupsRequest import (
    AliexpressPostproductRedefiningSetgroupsRequest,
)
from aliexpress.api.rest.ProductProductgroupsGetRequest import (
    AliexpressProductProductgroupsGetRequest,
)
from aliexpress.api.rest.MessageRedefiningVersiontwoQuerymsgchannelidbybuyeridRequest import (
    AliexpressMessageRedefiningVersiontwoQuerymsgchannelidbybuyeridRequest,
)
from aliexpress.api.rest.logistics.RedefiningQureywlbdomesticlogisticscompanyRequest import (
    AliexpressLogisticsRedefiningQureywlbdomesticlogisticscompanyRequest,
)
from aliexpress.api.rest.CainiaoGlobalLogisticOrderCreateRequest import (
    CainiaoGlobalLogisticOrderCreateRequest,
)
from aliexpress.api.rest.EvaluationEvaluationReplyRequest import (
    AliexpressEvaluationEvaluationReplyRequest,
)
from aliexpress.api.rest.PostproductRedefiningEditproductcategoryattributesRequest import (
    AliexpressPostproductRedefiningEditproductcategoryattributesRequest,
)
