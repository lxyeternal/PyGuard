from aliexpress.api.rest import *
from aliexpress.api.base import FileItem
