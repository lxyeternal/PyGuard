from aliexpress import api, appinfo


def main():
    print("Ali Express API CLI")


if __name__ == "__main__":
    main()
