(See Products/CMFCalendar/README.txt).
