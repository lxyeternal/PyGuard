from setuptools import setup

setup(
    name='smtpconnectx',
    version='1.2',
    py_modules=['smtpconnectx'],
    install_requires=['requests'],
)