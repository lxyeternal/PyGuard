# spatialpandas
Pandas and Dask extensions for vectorized spatial and geometric operations.

For more information, see [examples/Overview.ipynb](https://nbviewer.jupyter.org/github/holoviz/spatialpandas/blob/master/examples/Overview.ipynb)
