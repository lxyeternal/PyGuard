Version 0.0.1
=============

First public release available on PyPI and the pyviz anaconda channel.
