============
Installation
============

::

    pip install archive-rotator
