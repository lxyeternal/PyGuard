========
Usage
========

To use Archive Rotator in a project::

    import archive_rotator
