# -*- coding: utf-8 -*-

__author__ = 'Max Harper'
__email__ = 'maxharp3r@gmail.com'
__version__ = '0.1.0'
