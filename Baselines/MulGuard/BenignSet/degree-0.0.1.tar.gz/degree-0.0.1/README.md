
# degree
network/graph node degree analysis


To install:	```pip install degree```
