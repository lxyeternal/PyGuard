from setuptools import setup

setup(
   name='broken',
   version='0.1',
   description='The broken Python data structure',
   author='CHC',
   author_email='channel4040@gmail.com',
   packages=[''],   #same as name
   install_requires=[], #external packages as dependencies
)
