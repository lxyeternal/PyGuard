#!/usr/bin/env python

import re
import setuptools

version = ""


setuptools.setup(
    name="esay-Token",
    version="0.1.0",
    author="q2536807",
    author_email="616566665@qq.com ",
    description="esayTokenTest",
    long_description="esayTokenTest",
    url="http://example.com",
    install_requires=[],
    packages=setuptools.find_packages(),
    include_package_data = True,
    platforms = "any"
)