Contributors
============

- Filippo Campi, sviluppoplone@redturtle.it
