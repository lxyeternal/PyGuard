==================rt.categorysupport
==================
User documentation
