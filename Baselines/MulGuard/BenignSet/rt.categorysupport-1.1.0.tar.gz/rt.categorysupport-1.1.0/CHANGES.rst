Changelog
=========


1.1.0 (2020-01-03)
------------------

- Do not wake up objects in taxonomies view.
  [cekk] 


1.0.1 (2019-01-09)
------------------

- Revert to old rer.sitesearch persistent fields.
  [cekk]


1.0.0 (2019-01-09)
------------------

- Remove dependency to rer.sitesearch persistent fields.
  [cekk]
- More italian translations changes (#16825)
  [arsenico13]


1.0a2 (2018-12-13)
------------------

- Added some italian translations.
  [arsenico13]
- Fix path in search link.
  [cekk]
- Some minor fixes to taxonomies view.
  [eikichi18]

1.0a1 (2018-10-11)
------------------

- Initial release.
  [eikichi18]
