# -*- coding: utf-8 -*-
"""Init and utils."""
from zope.i18nmessageid import MessageFactory

import logging


_ = MessageFactory('rt.categorysupport')
logger = logging.getLogger(__name__)
