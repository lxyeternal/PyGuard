#!/usr/bin/env python
# -*- coding: utf-8 -*-

"""

Some estimators

"""

from . import estimator
from .estimator import *

__all__ = ['estimator']