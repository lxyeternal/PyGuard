#!/usr/bin/env python
# -*- coding: utf-8 -*-


def print_hi(name):
    print(f'Hi, {name}')


if __name__ == '__main__':
    print_hi('这是金钱世界中的audio包。')
