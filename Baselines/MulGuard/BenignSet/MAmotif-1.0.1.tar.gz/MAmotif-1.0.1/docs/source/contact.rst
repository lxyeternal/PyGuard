.. _contact:

Contact
=======


GitHub Issue
------------

Welcome to ask questions or report bugs on GitHub:

https://github.com/shao-lab/MAmotif/issues

Email
-----

Please contact:

 * Hongduo Sun (sunhongduo@picb.ac.cn)
 * Zhen Shao (shaozhen@picb.ac.cn)
