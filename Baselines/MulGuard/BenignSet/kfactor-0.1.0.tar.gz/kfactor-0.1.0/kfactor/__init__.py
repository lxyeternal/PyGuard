from .kfactor_func import kfactor
from .kfactor_class import KFactor
