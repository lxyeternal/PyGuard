class Interpretter:
    def interpret(self, board):
        pass
