class Logger:
    def __init__(self):
        pass

    def begin(self, **kwargs):
        pass

    def apply(self, board, player1, player2):
        pass

    def end(self):
        pass

    def exit(self):
        pass