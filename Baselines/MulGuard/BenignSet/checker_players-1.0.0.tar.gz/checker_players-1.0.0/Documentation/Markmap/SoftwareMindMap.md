---
markmap:
  colorFreezeLevel: 2
---

# Checker Players

## Environment 

### Board Representation
- Naive Matrix Representation
- Characteristic State Representation

### Reward Function
- Reward function #1
- Reward function #2

## AI Players

- Multilayer Perceptron Classifier
- Transformer Classifier
- Alpha-Beta Pruning
- Q-Learning