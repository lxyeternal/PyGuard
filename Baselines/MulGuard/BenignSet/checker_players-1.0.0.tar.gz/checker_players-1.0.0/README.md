# Checker Players
This is a simple and lightweight library that allows you to train and test various AI models in a game of checkers.

## Supported Games
- Standard Checkers: official rules can be found [here](https://winning-moves.com/images/kingmerulesv2.pdf)

## Supported Players
- Random Player: This player chooses a random move and is not capable of learning from many games. A good benchmark for other players. 