from src.manage_switches.SwitchFunctions import *
from src.manage_switches.DocFunctions import *
from src.manage_switches.DoConcurrent import *
from src.manage_switches.NetworkFunctions import *