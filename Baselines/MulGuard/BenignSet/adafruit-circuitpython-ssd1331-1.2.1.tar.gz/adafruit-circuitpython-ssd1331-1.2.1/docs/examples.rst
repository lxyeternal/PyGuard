Simple test
------------

Ensure your device works with this simple test.

.. literalinclude:: ../examples/ssd1331_simpletest.py
    :caption: examples/ssd1331_simpletest.py
    :linenos:
