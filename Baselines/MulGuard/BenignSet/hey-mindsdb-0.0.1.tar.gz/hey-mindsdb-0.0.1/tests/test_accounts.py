import unittest


class UserTestCase(unittest.TestCase):
    """Tests for accounts module"""

    def test_something(self):
        """Test something."""
        ...
