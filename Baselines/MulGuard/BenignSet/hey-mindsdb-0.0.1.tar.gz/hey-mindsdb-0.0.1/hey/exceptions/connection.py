"""
network-related connection exceptions
"""


class NetworkError(Exception): ...
