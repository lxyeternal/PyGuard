"""
this file contains all custom authentication exceptions
"""


class CredentialsError(Exception): ...
