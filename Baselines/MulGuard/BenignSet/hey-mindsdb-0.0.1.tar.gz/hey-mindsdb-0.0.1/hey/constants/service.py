# MindsDB cloud host address
MINDSDB_HOST = 'https://cloud.mindsdb.com'

# for keyring credential management
SERVICE_NAME = 'Hey'
