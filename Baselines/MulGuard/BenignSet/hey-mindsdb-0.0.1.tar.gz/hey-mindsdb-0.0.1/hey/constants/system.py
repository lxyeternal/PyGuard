"""
this file contains all system constants
"""


LOCAL_EMAIL_ADDRESS_VARIABLE_NAME = 'MINDSDB_EMAIL_ADDRESS'
