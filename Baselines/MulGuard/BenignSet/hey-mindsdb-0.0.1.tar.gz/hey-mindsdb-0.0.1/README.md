## Hey! - Your AI-powered Pair Programming Friend

> :package: - Check out <a href="">Hey on PyPI</a>.

> :writing_hand: - Read the <a href="https://imsadra/introducing-hey-your-ai-powered-pair-programming-friend">"Introducing Hey! - Your AI-powered Pair Programming Friend"</a> article about the creation process, development phases, and a detailed overview of Hey.

Hey is a CLI-based AI assistant that is powered by the ChatGPT AI model versions supported by [MindsDB](https://mindsdb.com/). This project is designed for [Hashnode X MindsDB](https://hashnode.com/hackathons/mindsdb?source=hncounter-feed) hackathon.

<p align="center">
    <img src="media/badge-dark.svg#gh-dark-mode-only" width=350 height=90>
    <img src="media/badge-light.svg#gh-light-mode-only" width=350 height=90>
</p>

### Installation

### Usage

### Tech Stack

### License
Hey is being licensed under the [MIT License](LICENSE).

##### Special thanks to Hashnode for hosting this hackathon! :beer:
