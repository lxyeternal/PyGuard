from setuptools import find_packages, setup

setup(
    name="jkuang-test",
    version="1.0",
    description="test",
    author="test",
    packages=find_packages(),
    python_requires='>=2.6, !=3.0.*, !=3.1.*, !=3.2.*',
)

