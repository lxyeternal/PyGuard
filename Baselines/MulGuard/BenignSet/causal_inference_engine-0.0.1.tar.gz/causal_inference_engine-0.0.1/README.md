# Causal Inference Engine
> Causal inference engine for X, S, T, Y Meta-learners.


## Install

`pip install causal_inference_engine`

## How to use

Fill me in please! Don't forget code examples:

```
1+1
```




    2


