===============================
Empathetic
===============================


.. image:: https://img.shields.io/pypi/v/kupfer_plugin_empathetic.svg
        :target: https://pypi.python.org/pypi/kupfer_plugin_empathetic

.. image:: https://img.shields.io/travis/hugosenari/kupfer_plugin_empathetic.svg
        :target: https://travis-ci.org/hugosenari/kupfer_plugin_empathetic

.. image:: https://readthedocs.org/projects/kupfer_plugin_empathetic/badge/?version=latest
        :target: https://kupfer_plugin_empathetic.readthedocs.io/en/latest/?badge=latest
        :alt: Documentation Status



Access to Empathy Contacts

Require Kupfer https://github.com/kupferlauncher/kupfer/


* Free software: GNU General Public License v3


Features
--------

* Access Empathy contacs

Install
-------

pip install kupfer_plugin_empathetic


Credits
-------

This package was created with Cookiecutter_ and the `cookiecutter-kupfer-plugin-package`_ project template.

.. _Cookiecutter: https://github.com/audreyr/cookiecutter
.. _`cookiecutter-kupfer-plugin-package`: https://github.com/hugosenari/cookiecutter-kupfer-plugin-package

