# pywands

This library was written to help identify MagiQuest Wands.

Config is done via an ini file.

Output is typically in the form of a generator.

I'm working on more documentation.

Also, thanks to lots of kind people sharing their work on the internet. A future revision will include links.
