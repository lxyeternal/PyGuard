# bic

This is a driver for Meanwell bi-directional charger.

## Author
- Frank Chang

## License
See LICENSE
