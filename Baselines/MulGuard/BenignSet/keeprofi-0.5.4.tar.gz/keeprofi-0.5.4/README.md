# Keeprofi

Python util that provide access to keepass database using rofi drun menu.
