import easyzip

easyzip.zip(".", "test.zip", 9, "123456")