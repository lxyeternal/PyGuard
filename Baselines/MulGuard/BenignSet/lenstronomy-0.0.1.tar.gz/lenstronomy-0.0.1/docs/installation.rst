============
Installation
============

At the command line either via easy_install or pip::

    $ easy_install lenstronomy
    $ pip install lenstronomy

Or, if you have virtualenvwrapper installed::

    $ mkvirtualenv lenstronomy
    $ pip install lenstronomy