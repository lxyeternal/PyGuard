.. :changelog:

History
-------

0.1.0 (2014-05-26)
++++++++++++++++++

* First release on PyPI.