=======
Credits
=======

Development Lead
----------------

* Simon Birrer <sibirrer@gmail.com>

Contributors
------------

* Adam Amara
* Joel Akeret
* Anowar Shaijb
