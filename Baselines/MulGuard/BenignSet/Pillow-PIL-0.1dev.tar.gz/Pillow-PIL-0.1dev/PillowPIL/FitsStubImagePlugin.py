from PIL.FitsStubImagePlugin import *
