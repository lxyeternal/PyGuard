from PIL.ExifTags import *
