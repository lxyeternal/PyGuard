from PIL.MspImagePlugin import *
