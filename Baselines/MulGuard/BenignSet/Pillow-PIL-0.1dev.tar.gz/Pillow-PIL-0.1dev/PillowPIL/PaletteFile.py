from PIL.PaletteFile import *
