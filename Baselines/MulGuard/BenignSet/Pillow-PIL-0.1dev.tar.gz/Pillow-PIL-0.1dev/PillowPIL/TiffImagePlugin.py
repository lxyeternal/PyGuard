from PIL.TiffImagePlugin import *
