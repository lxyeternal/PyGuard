from PIL.MpegImagePlugin import *
