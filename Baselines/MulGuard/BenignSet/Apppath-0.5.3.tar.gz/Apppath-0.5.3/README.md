![apppath](.github/images/apppath.svg)

# AppPath

![python](.github/images/python.svg)

[![Build Status](https://travis-ci.com/aivclab/apppath.svg?branch=master)](https://travis-ci.com/aivclab/apppath) [![Code style: black](https://img.shields.io/badge/code%20style-black-000000.svg)](https://github.com/ambv/black) [![Coverage Status](https://coveralls.io/repos/github/aivclab/apppath/badge.svg?branch=master)](https://coveralls.io/github/aivclab/apppath?branch=master) [![Total alerts](https://img.shields.io/lgtm/alerts/g/cnheider/apppath.svg?logo=lgtm&logoWidth=18)](https://lgtm.com/projects/g/cnheider/apppath/alerts/) [![Language grade: Python](https://img.shields.io/lgtm/grade/python/g/cnheider/apppath.svg?logo=lgtm&logoWidth=18)](https://lgtm.com/projects/g/cnheider/apppath/context:python)
___
> Clutter-free app data
___

A class and a set of functions for providing for system-consensual path for apps to store data, logs, cache...
