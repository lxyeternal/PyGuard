version_info = (0, 0, 0)
version = '.'.join(str(c) for c in version_info)
