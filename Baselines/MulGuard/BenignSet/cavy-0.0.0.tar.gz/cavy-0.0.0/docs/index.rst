==============================
cavy -- testing helper library
==============================

.. include:: ../README

Release History
===============

.. include:: ../CHANGELOG
