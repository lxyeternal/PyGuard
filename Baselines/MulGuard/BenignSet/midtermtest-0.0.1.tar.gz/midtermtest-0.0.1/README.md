# midtermtest


[![image](https://img.shields.io/pypi/v/midtermtest.svg)](https://pypi.python.org/pypi/midtermtest)
[![image](https://img.shields.io/conda/vn/conda-forge/midtermtest.svg)](https://anaconda.org/conda-forge/midtermtest)


**Python Boilerplate contains all the boilerplate you need to create a Python package.**


-   Free software: MIT license
-   Documentation: https://Feng96.github.io/midtermtest
    

## Features

-   TODO

## Credits

This package was created with [Cookiecutter](https://github.com/cookiecutter/cookiecutter) and the [giswqs/pypackage](https://github.com/giswqs/pypackage) project template.
