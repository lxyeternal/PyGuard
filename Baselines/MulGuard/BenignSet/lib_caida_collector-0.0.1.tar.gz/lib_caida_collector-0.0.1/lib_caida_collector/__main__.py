from .caida_collector import CaidaCollector

def main():
    CaidaCollector().run()
