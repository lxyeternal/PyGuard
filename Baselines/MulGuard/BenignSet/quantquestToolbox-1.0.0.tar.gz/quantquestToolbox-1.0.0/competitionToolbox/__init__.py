try:
    from .competition import *
except ImportError:
    print("")
