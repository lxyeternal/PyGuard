import unittest


class TestSampleCase(unittest.TestCase):

    def sample_test(self):
        self.assertEqual(1 + 1, 2)


if __name__ == '__main__':
    unittest.main()
