import sys
from setuptools import setup

setup(
    download_url = 'https://pypi.org/project/sphindexer/',
    project_urls = {
        'Code': 'https://github.com/KaKkouo/sphindexer',
        'Issue tracker': 'https://github.com/KaKkouo/sphindexer/issues',
    }
)
