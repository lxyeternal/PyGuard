
def slug_to_path(slug):
    return slug.replace('-', '_')
