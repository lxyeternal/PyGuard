class PartialQueryError(Exception):
    pass