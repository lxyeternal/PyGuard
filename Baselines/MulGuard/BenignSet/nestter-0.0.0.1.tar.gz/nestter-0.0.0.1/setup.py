from distutils.core import setup

setup(
        name        = 'nestter',
        version     = '0.0.0.1',
        py_modules  = ['nester'],
        author      = 'robinliucn',
        author_email = 'robin@hengha.ren',
	url 	    = 'http://www.517taoqi.com',
        description = 'A simple printer of nested lists',
    )
