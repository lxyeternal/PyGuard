# Outline Manager

Manages access keys for servers with Outline server installed.

See API docs [here](https://redocly.github.io/redoc/?url=https://raw.githubusercontent.com/Jigsaw-Code/outline-server/master/src/shadowbox/server/api.yml)
