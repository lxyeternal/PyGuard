class MissingEnvVarError(Exception):
    pass
