default_prefix = "CREA"

known_chains = {"CREA": {"chain_id": "38f14b346eb697ba04ae0f5adcfaa0a437ed3711197704aa256a14cb9b4a8f26",
                        "core_symbol": "CREA",
                        "prefix": "CREA"},
                "TEST": {"chain_id": "39f5e2ede1f8bc1a3a54a7914414e3779e33193f1f5693510e73cb7a87617447",
                         "core_symbol": "TEST",
                         "prefix": "TEST"}
                }
