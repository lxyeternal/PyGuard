from .api import Api
from .exceptions import (
    RPCError,
    NumRetriesReached
)


class GrapheneHTTPRPC(Api):
    """ Deprecated
    """
    pass
