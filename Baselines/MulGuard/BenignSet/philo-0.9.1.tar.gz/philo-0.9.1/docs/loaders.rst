Database Template Loader
========================

.. automodule:: philo.loaders.database
	:members:
