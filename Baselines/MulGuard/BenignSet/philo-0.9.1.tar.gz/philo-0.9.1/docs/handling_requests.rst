Handling Requests
=================

.. automodule:: philo.middleware
	:members:

.. automodule:: philo.views


.. autofunction:: node_view(request[, path=None, **kwargs])
