Template Tags
=============

.. automodule:: philo.templatetags

Collections
+++++++++++

.. automodule:: philo.templatetags.collections
	
.. autotemplatetag:: membersof

Containers
++++++++++

.. automodule:: philo.templatetags.containers


.. autotemplatetag:: container


Embedding
+++++++++

.. automodule:: philo.templatetags.embed

.. autotemplatetag:: embed


Nodes
+++++

.. automodule:: philo.templatetags.nodes

.. autotemplatetag:: node_url

String inclusion
++++++++++++++++

.. automodule:: philo.templatetags.include_string

.. autotemplatetag:: include_string
