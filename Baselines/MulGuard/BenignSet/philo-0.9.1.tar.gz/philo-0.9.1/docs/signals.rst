Signals
=======

.. automodule:: philo.signals
	:members:
