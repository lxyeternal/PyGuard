Sobol
=====

.. automodule:: philo.contrib.sobol
	:members:

Models
++++++

.. automodule:: philo.contrib.sobol.models
	:members:

Search API
++++++++++

.. automodule:: philo.contrib.sobol.search
	:members:
