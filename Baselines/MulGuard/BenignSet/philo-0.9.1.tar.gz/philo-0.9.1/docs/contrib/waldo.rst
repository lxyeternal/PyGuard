Waldo
=====

.. automodule:: philo.contrib.waldo
	:members:

Models
++++++

.. automodule:: philo.contrib.waldo.models
	:members:

Forms
+++++

.. automodule:: philo.contrib.waldo.forms
	:members:

Token generators
++++++++++++++++

.. automodule:: philo.contrib.waldo.tokens


.. autodata:: registration_token_generator

.. autodata:: email_token_generator
