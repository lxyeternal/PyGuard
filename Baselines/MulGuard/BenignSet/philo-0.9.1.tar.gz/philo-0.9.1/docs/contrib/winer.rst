Winer
=====

.. automodule:: philo.contrib.winer

.. automodule:: philo.contrib.winer.models

	.. autoclass:: FeedView
		:members:

.. automodule:: philo.contrib.winer.exceptions
	:members:

.. automodule:: philo.contrib.winer.middleware
	:members: