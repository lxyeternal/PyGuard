Contrib apps
============

.. toctree::
	:maxdepth: 2
	:hidden:
	
	penfield
	shipherd
	sobol
	waldo
	winer

.. automodule:: philo.contrib
