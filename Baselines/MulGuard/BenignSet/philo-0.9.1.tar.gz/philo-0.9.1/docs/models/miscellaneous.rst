Miscellaneous Models
=============================
.. autoclass:: philo.models.nodes.TargetURLModel
	:members:
	:exclude-members: get_target_url