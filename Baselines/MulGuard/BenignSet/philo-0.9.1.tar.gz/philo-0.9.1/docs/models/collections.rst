Collections
===========

.. automodule:: philo.models.collections
	:members: Collection, CollectionMember, CollectionMemberManager

.. autoclass:: CollectionMemberManager
	:members: