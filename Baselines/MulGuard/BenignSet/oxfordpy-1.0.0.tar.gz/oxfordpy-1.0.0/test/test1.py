import oxfordpy

oxford = oxfordpy.Oxford()

word = "HELLO"

print(oxford.entries(word))
