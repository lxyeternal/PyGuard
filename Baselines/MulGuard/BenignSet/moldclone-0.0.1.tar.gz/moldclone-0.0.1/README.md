<h1 align="center">MOAJJEM</h1>
<p>FACEBOOK ACCOUNT CLONER</p>

## INSTALL
````
pip2 install moldclone
````
## RUN
````
moldclone
````


<div align="center">Contact With Me: <a href="https://www.facebook.com/Md.Moajjem.Hossen.4O4"><b>MOAJJEM</a><br><br></div>

<h1 align="center">THANKS FOR USING.</h1>