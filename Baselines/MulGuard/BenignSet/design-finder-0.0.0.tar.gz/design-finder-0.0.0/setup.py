from distutils.core import setup

setup(name="design-finder", version="0.0.0",classifiers=['Development Status :: 1 - Planning'])
