class Task(_Base):
    def __init__(self):
        pass
    
    def set_function(fn):
        pass
    
    def input_node(self):
        pass
    
    def run(self):
        pass
    
    def output_node(self):
        pass