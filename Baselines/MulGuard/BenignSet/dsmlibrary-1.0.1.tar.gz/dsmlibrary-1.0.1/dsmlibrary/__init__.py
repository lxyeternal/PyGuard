__title__ = 'DigitalStoreMesh Dataset'
__version__ = '1.0'
__author__ = 'DigitalStoreMesh Co.,Ltd'
__license__ = 'MIT'

VERSION = __version__