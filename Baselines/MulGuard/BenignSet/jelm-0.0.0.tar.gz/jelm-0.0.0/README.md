# *J*son*E*dge*L*ist*M*odel - jelm

python package, documentation and examples of a json graph description protocol

not for math, but with scaling in mind

### coming up
- rules
- use-cases
- compression
- read/write examples
  - parallel file reading
  - parallel processing
- templates for nodes
- templates for edges