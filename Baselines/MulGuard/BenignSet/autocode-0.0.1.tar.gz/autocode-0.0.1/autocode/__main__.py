# -*- coding: utf-8 -*-


"""autotype.__main__: executed when bootstrap directory is called as script."""


from .run import main
main()
