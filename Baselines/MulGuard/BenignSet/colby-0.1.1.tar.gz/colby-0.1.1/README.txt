# colby
Python module for line graphs, scatterplots, bar charts, tables, and pie charts.

Github repo: https://github.com/m1jkf00/colby

This module facilitates the construction of chartpackets (single- or multi-page long pdfs of charts or tables).
The code is built on top of matplotlib and imposes certain stylistic choices. See the examples folder.

To-do's:
Add new example code for tables. The code in sample_exhibits.py was made prior to the addition of form_partition(), which 
makes table design much easier.