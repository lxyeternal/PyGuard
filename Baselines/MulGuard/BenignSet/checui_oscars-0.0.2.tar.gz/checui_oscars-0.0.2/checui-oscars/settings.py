DB_SETTINGS = {'host':'oscars',
               'user':'root', 
               'password':'example',
               'database':'oscars'}