from setuptools import setup

setup(name='distributions_aks',
      version='0.1',
      description='Gaussian and Binomial Distributions',
      packages=['distributions_aks'],
      zip_safe=False)
