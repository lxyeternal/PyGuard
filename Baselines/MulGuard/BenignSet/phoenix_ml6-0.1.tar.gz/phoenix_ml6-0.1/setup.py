from setuptools import setup


setup(name='phoenix_ml6',
      version='0.1',
      description='Machine Learning FrameWork',
      packages=['phoenix_ml6'],
      zip_safe=False)


