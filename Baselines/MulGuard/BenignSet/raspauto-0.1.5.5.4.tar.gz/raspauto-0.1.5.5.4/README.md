# RaspAuto | Remote management for smart technologies

![PyPI](https://img.shields.io/pypi/v/raspauto) ![PyPI - Downloads](https://img.shields.io/pypi/dm/raspauto) ![GitHub issues](https://img.shields.io/github/issues-raw/aattk/raspauto) ![GitHub](https://img.shields.io/github/license/aattk/raspauto)

Raspberry cihazının uzaktan pinlerine hakim olarak projelerinizi kontrol edebilirsiniz 


## Contents
1. How to Install ?
2. Functions 
3. Websites

### How to install ?
