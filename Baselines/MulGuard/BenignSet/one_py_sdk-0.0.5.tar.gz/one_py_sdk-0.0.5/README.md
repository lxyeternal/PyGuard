# one_py_sdk
This is a package to interact with the ONE water quality platform.
The source code for it is located at https://github.com/AquaticInformatics/ONE.Py.SDK
