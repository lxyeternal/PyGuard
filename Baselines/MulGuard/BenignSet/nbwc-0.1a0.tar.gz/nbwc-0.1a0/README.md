# Python notebook word count

Matthew Brett; BSD 2-clause license.
