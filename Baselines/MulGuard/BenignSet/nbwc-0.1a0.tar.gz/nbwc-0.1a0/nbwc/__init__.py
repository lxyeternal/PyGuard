""" Notebook wordcount
"""

__version__ = "0.1a0"

from .nbwc import wc_nb
