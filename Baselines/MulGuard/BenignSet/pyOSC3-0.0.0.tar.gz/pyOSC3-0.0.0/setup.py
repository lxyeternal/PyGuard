#!/usr/bin/env python

from setuptools import setup

setup(name='pyOSC3',
      description='pyOSC updated for Python 3',
      author='Ryan Kirkbride',
      author_email='ryan@foxdot.org',
      url='http://foxdot.org/',
      packages=['pyOSC3'] )


