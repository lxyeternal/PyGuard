def add_func(a, b):
    return a + b
