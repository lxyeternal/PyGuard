# hoskerlatch

This respository defines a Python package which does two things:

1. Defines `latch` and `unlatch` functions with which to encrypt and decrypt files within a Python script.
1. Defines commands `hoskerlatch` and `hoskerunlatch` with which to encrypt and decrypt files from the command line.
