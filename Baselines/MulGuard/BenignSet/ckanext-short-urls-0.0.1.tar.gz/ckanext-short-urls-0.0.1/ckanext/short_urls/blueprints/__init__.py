from ckanext.short_urls.blueprints.short_urls_blueprint import short_urls_blueprint

blueprints = [
    short_urls_blueprint,
]
