#!/usr/bin/env python
#-*- coding:utf-8 -*-


print("---------------------------------------------\n")
print("           -=-=-=-=-=-=-=-=-=-")
print("          |      astools      |")
print("           -=-=-=-=-=-=-=-=-=-")
print("\n          Developed by D. HU")
print("          Version 0.1 (20191017)")
print("\n---------------------------------------------")


# import sys, os
# sys.path.insert(0, os.path.abspath(__file__))

def iTest():
	'''
	Initial test of astools
	'''
	print("\nHouston, Tranquility Base here. The Eagle has landed.\n")

if __name__ == '__main__':
    
    iTest()
