# Silo

Un ___Silo à MISSILE___ est une construction souterraine, sous forme de puits, depuis lequel un missile (notamment de longue portée) peut être rapidement lancé. Le silo est conçu pour protéger des effets d'une explosion nucléaire rapprochée en cas d'attaque d'un missile balistique. Le missile étant très vulnérable au sol et lors du décollage, le silo doit également permettre le lancement dans le délai le plus court possible, avant qu'une autre attaque n'ait lieu. 
[En savoir plus](https://fr.wikipedia.org/wiki/Silo_à_missile)

![SM-68 Titan dans son silo ; Titan Missile Museum.](archives/Tucson05_TitanICBM.jpg)
