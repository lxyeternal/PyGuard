from setuptools import setup

setup(
    name='mock-registry',
    version='0.1.1',
    description='Foo.',
    author='Foo',
    author_email='foo@foo.com',
    zip_safe=False,
    test_suite='test'
)
