# Hatch Version Action Example


## Installation

```console
pip install hatch-version-action-example
```

## License

`hatch-version-action-example` is distributed under the terms of the [MIT](https://spdx.org/licenses/MIT.html) license.
