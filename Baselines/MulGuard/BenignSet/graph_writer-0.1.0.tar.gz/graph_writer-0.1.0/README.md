# graph_writer

This repository is intended to visualize and publish interactive computation graphs such as -  

<h3>PyTorch Networks</h3>
<h3>Tensorflow Networks</h3>.

## Aknowledgements 

Equal Contributors: [Partha Ghosh](https://github.com/ParthaEth), [Pravir Singh Gupta](https://github.com/GuptaPravirSingh)
