"""
This package contains utilities and extensions for the Astropy sphinx
documentation.  In particular, the `astropy.sphinx.conf` should be imported by
the sphinx ``conf.py`` file for affiliated packages that wish to make use of
the Astropy documentation format.
"""
