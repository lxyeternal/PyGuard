def get_package_data():
    files = ['coveragerc']
    return {'regions.tests': files}
