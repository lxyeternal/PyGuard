def get_package_data():
    shape_test = ['data/*.fits']
    return {'regions.shapes.tests': shape_test}
