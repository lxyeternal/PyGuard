.. include:: references.txt

Development notes
=================

Development design notes can go here

Dependencies
------------

Should we use these packages or start building functionality from scratch


* spherical_geometry https://github.com/spacetelescope/sphere
* Shapely https://pypi.python.org/pypi/Shapely


PyAstro16
---------

This `PyAstro16 doc`_ contains some more information about the discussions that started
this package.
