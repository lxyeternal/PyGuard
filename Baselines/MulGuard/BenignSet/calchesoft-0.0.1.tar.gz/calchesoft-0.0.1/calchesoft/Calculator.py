# -*- coding: utf-8 -*-
"""
Created on Tue Mar 16 10:27:51 2021

@author: hamza_shoukat
"""

class Calculator:
    def add(self, number1, number2):
        return number1 + number2
    def subtract(self, number1, number2):
        return number1 - number2
