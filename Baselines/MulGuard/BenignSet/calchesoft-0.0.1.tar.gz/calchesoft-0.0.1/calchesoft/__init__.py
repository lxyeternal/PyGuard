# -*- coding: utf-8 -*-
"""
Created on Tue Mar 16 10:31:24 2021

@author: hamza_shoukat
"""

from calchesoft import Calculator


__all__ = [
    'Calculator'
]
