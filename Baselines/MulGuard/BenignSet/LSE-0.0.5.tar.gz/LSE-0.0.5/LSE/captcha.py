# -*- coding: utf-8 -*-
"""
    ant.captcha
    ~~~~~~~~~~~

    验证码破解模块

    :copyright: (c) 2016 by iygnohz.
    :license: LICENSE, see LICENSE for more details.
"""
