# -*- coding: utf-8 -*-
"""
    ant.requests
    ~~~~~~~~~~~~

    网络请求模块

    :copyright: (c) 2016 by iygnohz.
    :license: LICENSE, see LICENSE for more details.
"""
