# flake8: noqa
__version__ = '0.0.1-alpha'


def get_version():
    return __version__
