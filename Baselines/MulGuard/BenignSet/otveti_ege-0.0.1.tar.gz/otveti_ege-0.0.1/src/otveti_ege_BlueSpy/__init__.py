"""
:authors: BlueSpy
:license: OSI Approved :: MIT License
:copyright: (c) 2022 BlueSpy
"""

import otveti_ege.py

__author__ = 'BlueSpy'
__version__ = '0.0.1'
__email__ = 'alexej.rutskij@gmail.com'
