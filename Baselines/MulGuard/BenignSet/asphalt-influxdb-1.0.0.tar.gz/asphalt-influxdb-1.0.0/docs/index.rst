.. include:: ../README.rst
   :start-line: 7
   :end-before: Project links

Table of contents
-----------------

.. toctree::
   :maxdepth: 2

   configuration
   usage
   versionhistory

* :ref:`API reference <modindex>`
