Version history
===============

This library adheres to `Semantic Versioning <http://semver.org/>`_.


**1.0.0**

- Initial release
