#############
CLI Reference
#############


.. click:: kafkaconnect.cli:main
   :prog: kafkaconnect
   :show-nested:
