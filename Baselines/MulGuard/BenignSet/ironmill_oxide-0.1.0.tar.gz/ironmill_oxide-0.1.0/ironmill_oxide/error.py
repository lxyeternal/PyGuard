class OxideError(Exception):
    "Raised when user input isn't allowed by oxide api"
    pass
