MANIFEST = 'circuits.toml'
DEPENDENCIES = '[dependencies]'
DEP_DIR = 'circuits'

_POSTPEND = '/v1/repo'
BUNDLER_URL = 'https://bundler.oxide.is' + _POSTPEND
REGISTRY_URL = 'https://registry.oxide.is' + _POSTPEND
