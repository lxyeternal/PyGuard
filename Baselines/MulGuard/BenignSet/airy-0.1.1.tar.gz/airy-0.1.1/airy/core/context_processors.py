from airy.core import markup as markup_mod

def markup(handler, **kwargs):
    return {'markup': markup_mod}

