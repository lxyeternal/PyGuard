"Add your URLs here"

from handlers import *
urlpatterns = [
   # (r"/app", SomeHandler),
]

