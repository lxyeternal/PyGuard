#!/usr/bin/env python
# coding=utf-8

import os

__pkgname__ = os.path.basename(os.path.dirname(os.path.dirname(__file__)))
__description__ = "Index System"
__version__ = "0.2"
