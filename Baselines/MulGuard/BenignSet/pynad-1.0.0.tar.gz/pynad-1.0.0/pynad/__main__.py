#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
2020 - Rafael Guerreiro Osorio - www.ipea.gov.br.

pynad - command line app
"""

from .pynad import main
main()
