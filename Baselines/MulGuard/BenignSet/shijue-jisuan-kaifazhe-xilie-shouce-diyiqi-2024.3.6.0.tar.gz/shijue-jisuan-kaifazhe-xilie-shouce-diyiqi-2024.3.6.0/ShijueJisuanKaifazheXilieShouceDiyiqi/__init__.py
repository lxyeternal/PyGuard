#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""shijue-jisuan-kaifazhe-xilie-shouce-diyiqi
https://github.com/apachecn/shijue-jisuan-kaifazhe-xilie-shouce-diyiqi"""

__author__ = "ApacheCN"
__email__ = "apachecn@163.com"
__license__ = "CC BY-NC-SA 4.0"
__version__ = "2024.3.6.0"