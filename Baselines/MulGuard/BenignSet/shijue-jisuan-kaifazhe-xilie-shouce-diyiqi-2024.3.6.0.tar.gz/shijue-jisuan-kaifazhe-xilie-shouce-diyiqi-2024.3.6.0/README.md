# 视觉计算开发者系列手册-第一期

## 下载

### Docker

```
docker pull apachecn0/shijue-jisuan-kaifazhe-xilie-shouce-diyiqi
docker run -tid -p <port>:80 apachecn0/shijue-jisuan-kaifazhe-xilie-shouce-diyiqi
# 访问 http://localhost:{port} 查看文档
```

### PYPI

```
pip install shijue-jisuan-kaifazhe-xilie-shouce-diyiqi
shijue-jisuan-kaifazhe-xilie-shouce-diyiqi <port>
# 访问 http://localhost:{port} 查看文档
```

### NPM

```
npm install -g shijue-jisuan-kaifazhe-xilie-shouce-diyiqi
shijue-jisuan-kaifazhe-xilie-shouce-diyiqi <port>
# 访问 http://localhost:{port} 查看文档
```