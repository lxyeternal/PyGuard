from pathlib import Path
from smodex import calculate_climatology

def main() -> None:
    pass

if __name__== "__main__":
    main()