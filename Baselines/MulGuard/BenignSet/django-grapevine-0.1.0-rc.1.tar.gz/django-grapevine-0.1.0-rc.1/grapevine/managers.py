from __future__ import unicode_literals

# 3rd Party
from model_utils.managers import PassThroughManager


class SendableManager(PassThroughManager):
    pass
