from __future__ import unicode_literals

"""Package for Grapevine"""

__project__ = "grapevine"
__version__ = "0.1.0-rc.1"

VERSION = __project__ + '-' + __version__
