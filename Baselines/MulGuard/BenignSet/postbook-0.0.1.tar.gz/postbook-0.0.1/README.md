
Install the package using pip
`pip install postbook`

