#!/usr/bin/env python
# -*- coding: utf-8 -*-

# Copyright (C) Radical Prime Limited, registered in the United Kingdom.
# Unauthorized copying of this file, via any medium is strictly prohibited
#
# This file is subject to license, see the "LICENSE" file, which is
# included in this software package for details.
#
# Written by Dan Cvrcek <support@radicalprime.com>, August 2018

__copyright__ = "Radical Prime Limited"
__email__ = "support@radicalprime.com"
__status__ = "Beta"
