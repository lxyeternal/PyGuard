from distutils.core import setup

setup(
	name="plm123",	
	version="2.1.1",
	py_modules=["plm123"],
	author="MR-JI",
	author_email="www.gg@jhun.com",
	url="http://www.jhun.com",
	description="A simple printer for nested lists",
)
