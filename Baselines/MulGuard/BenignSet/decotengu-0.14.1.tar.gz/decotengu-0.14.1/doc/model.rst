Decompression Model
===================

.. automodule:: decotengu.model

.. vim: sw=4:et:ai
