Alternative Implementations
===========================

.. automodule:: decotengu.alt
.. automodule:: decotengu.alt.tab
.. automodule:: decotengu.alt.decimal
.. automodule:: decotengu.alt.bisect
.. automodule:: decotengu.alt.naive

.. vim: sw=4:et:ai
