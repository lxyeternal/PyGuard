Using DecoTengu Library
=======================

.. automodule:: decotengu

.. vim: sw=4:et:ai
