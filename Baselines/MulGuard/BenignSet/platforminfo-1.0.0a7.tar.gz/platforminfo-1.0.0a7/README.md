# PlatformInfo Python library

**This is alpha quality code. Do not use this code in its current form**

Simple system info for Python.



Features:

* Return kernel (kernel version coming soon)

* Return OS version (general AND specific)

* Return architecture (Linux/Mac only, Windows planned)

This code still has an extremely limited feature set and should not be used in production. 

***THERE IS NO DOCUMENTATION YET. IF YOU REALLY WANT TO USE THIS, READ THE CODE. Documentation coming soon***
