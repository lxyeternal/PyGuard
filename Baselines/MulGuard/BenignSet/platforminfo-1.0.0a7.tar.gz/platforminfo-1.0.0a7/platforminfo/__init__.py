from importlib import resources
from .platforminfo import Platform

__version__ = "1.0.0alpha6"
