from django.apps import AppConfig


class HandlersConfig(AppConfig):
    name = 'handlers'
