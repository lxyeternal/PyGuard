# ColdShard CLI
This is the official CLI for ColdShard. This allows you to do whatever it is you would've done on our panel, *but in the command line* 🤯🎉!

## Installation
As of now, the CLI is not on PyPi.