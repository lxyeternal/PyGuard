from ._read_line import idx, indices_of_newlines, readline

__all__ = [
    "idx",
    "indices_of_newlines",
    "readline",
]
