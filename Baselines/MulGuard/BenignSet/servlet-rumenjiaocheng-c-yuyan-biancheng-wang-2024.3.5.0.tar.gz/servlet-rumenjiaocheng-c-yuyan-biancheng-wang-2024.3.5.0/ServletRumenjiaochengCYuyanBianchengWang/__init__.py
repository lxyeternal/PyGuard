#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""servlet-rumenjiaocheng-c-yuyan-biancheng-wang
https://github.com/apachecn/servlet-rumenjiaocheng-c-yuyan-biancheng-wang"""

__author__ = "ApacheCN"
__email__ = "apachecn@163.com"
__license__ = "CC BY-NC-SA 4.0"
__version__ = "2024.3.5.0"