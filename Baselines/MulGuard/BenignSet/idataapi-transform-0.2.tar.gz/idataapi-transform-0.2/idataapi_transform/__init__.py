"""convert data from a format to another format, read/write from file or database, suitable for iDataAPI"""

from .cli import main
__version__ = '0.2'
