from .robot import DingTalkCommand
