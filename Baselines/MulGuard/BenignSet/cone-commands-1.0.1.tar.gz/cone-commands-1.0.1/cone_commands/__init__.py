from .core.management import Command

__version__ = '0.1.0'
