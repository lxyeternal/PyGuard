from enum import IntEnum


class CommandStatus(IntEnum):
    DEVELOPING = 0
    AVAILABLE = 1
