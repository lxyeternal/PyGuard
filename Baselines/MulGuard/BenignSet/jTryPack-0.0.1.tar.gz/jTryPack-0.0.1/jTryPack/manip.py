def add_num(x, y):
    return(x+y)



