# hcjflex, native web gui for python
kind of like electron or tauri, but for python