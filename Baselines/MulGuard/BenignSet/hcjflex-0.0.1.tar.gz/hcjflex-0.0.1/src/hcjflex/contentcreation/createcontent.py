# content creation for hcjflex
# INFO: this script creates html/css/js files for hcjflex apps.
# TODO: Write a proper file creation system for hcjflex