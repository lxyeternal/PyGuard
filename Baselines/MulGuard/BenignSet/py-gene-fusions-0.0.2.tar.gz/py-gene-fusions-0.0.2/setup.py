"""Module for package and distribution"""
from setuptools import setup

setup(version="0.0.2")
