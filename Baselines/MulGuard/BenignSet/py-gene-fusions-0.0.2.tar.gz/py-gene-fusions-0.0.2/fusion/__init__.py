"""Fusion package"""
