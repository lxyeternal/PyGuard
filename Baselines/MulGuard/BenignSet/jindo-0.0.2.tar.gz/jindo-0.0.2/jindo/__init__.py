
"""

__init__.py

Author: Rob Cakebread <cakebread at gmail dawt com>

License  : GNU General Public License Version 2

"""

__docformat__ = 'restructuredtext'
__version__ = '0.0.2'


