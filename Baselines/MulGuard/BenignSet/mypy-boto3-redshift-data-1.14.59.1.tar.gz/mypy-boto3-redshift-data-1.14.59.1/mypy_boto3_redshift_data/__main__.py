if __name__ == "__main__":
    print(
        "Type annotations for boto3.RedshiftDataAPIService 1.14.59\n"
        "Version:         1.14.59.1\n"
        "Builder version: 3.1.0\n"
        "Docs:            https://pypi.org/project/mypy-boto3-redshift-data/\n"
        "Other services:  https://pypi.org/project/boto3-stubs/\n"
        "Changelog:       https://github.com/vemel/mypy_boto3_builder/releases"
    )
