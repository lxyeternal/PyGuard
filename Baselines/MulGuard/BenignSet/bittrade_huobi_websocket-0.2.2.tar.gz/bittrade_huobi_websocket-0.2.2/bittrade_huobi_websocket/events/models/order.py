import dataclasses
from decimal import Decimal
from enum import Enum
from expression import Nothing, Option
from pydantic.dataclasses import dataclass

