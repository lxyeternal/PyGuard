from . import insert_to_db

__all__ = [
    'insert_to_db',
]