# ComposeIt
------------------------------

Python tool for creating a docker-compose.yml file from an existing container

## Installing

```bash
pip install ComposeIt
```

## Usage

```bash
ComposeIt <container id or name>
```

