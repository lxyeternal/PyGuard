"""
Implementation of the dgit 
"""

import pkgutil

__version__ = "0.1.5"
__path__ = pkgutil.extend_path(__path__, __name__)
