test-sphinxcontrib-imageembed
=============================

.. image:: bolt.png
.. image:: svgimg.svg
