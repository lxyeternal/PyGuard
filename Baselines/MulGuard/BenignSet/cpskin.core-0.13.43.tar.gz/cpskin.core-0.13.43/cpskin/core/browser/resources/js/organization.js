jQuery(document).ready(function($) {
    $('.organization-photo a').fancybox();
});
