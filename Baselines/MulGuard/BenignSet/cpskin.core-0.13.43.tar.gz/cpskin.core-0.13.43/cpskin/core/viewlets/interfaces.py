# -*- coding: utf-8 -*-
from zope.interface import Interface


class IViewletMenuToolsFaceted(Interface):
    """
    marker interface used to viewlets menutools
    """


class IViewletMenuToolsBox(Interface):
    """
    marker interface used to viewlets menutools
    """
