import setuptools

setuptools.setup(
  name='mix',
  version='0.0.0',
  author='HSSLab',
  author_email='hsslab.inspur@gmail.com',
  description='A framework for Multimodal Intelligence',
  long_description='',
  long_description_content_type='text/markdown',
  url='https://github.com/hsslab/mix.git',
  packages=setuptools.find_packages(),
  classifiers=[
      'Programming Language :: Python :: 3',
      'Operating System :: OS Independent',
  ],
)
