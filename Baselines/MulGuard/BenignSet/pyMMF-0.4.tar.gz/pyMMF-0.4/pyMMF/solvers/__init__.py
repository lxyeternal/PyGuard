from .eig2D import solve_eig
from .SI import solve_SI
from .radial import solve_radial