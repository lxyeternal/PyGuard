# AutoChromedriver2

## About

### [Pypi page coming soon](https://github.com/JustinTheWhale/)

#### Have a selenium script that you haven't used in awhile? Use this to automatically find and install the latest version of chromedriver for your python code. Cross-platform for Windows, Mac, Debian and Arch based Linux. 

## Usage

### Import this like so

```python

import AutoChromedriver2.chromedriver_check as AC

AC.AutoChromedriver()
```