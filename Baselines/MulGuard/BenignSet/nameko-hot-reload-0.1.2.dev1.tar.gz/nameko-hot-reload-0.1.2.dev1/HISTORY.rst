.. :changelog:

Release History
---------------

0.1.2 (unreleased)
++++++++++++++++++

- Nothing changed yet.


0.1.1 (2017-09-01)
++++++++++++++++++

- Fix incorrect package description.


0.1.0 (2017-09-01)
++++++++++++++++++

- Initial release.
