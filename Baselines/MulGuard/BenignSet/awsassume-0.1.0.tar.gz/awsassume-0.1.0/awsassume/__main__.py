from awsassume.main import main


def console_entry() -> None:
    main()


if __name__ == '__main__':
    main()
