from django.apps import AppConfig


class DjangoSbSimpleMigrationsConfig(AppConfig):
    default_auto_field = "django.db.models.BigAutoField"
    name = "django_sb_simple_migrations"
    verbose_name = "Django simple migrations"
