from .version import VERSION

__version__ = ".".join(VERSION)
