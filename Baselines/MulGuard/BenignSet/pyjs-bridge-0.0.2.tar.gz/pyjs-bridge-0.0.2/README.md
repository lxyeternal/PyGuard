## Server functions<br>  
  
- **__main__.foo**(**p0** : int, **p1** : str = "a", **p2** : any = undefined)  
	This is foo function.  
  
- **__main__.bar**(**p0** : int, **p1** : str = "a", **p2** : any = undefined)  
	This is bar function.  
  
  
## Client callbacks  
  
- **f0**(**p0** : any = undefined)  
	This is f0 function.  
  
- **f1**(**p0** : int, **p1** : str = "a", **p2** : any = undefined)  
	This is f1 function.  
  
