"""
largesteps.

Laplacian parameterization package for shape optimization with differentiable
rendering.
"""

__version__ = "0.1.0"
__author__ = 'Baptiste Nicolet'
