from bicon.ants import BiCoN

from bicon.load_data import data_preprocessing
from bicon.results_processing import results_analysis

