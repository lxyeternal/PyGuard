# lxa5-crab
Reimplementation of linguistica's Crab Nebula algorithm in Python 2+3
