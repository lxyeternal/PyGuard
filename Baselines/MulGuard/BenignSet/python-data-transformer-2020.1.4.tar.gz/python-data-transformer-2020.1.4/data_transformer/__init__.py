# -*- coding: utf-8 -*-

__author__ = 'Pavel Maksimov'
__email__ = 'vur21@ya.com'
__version__ = '2020.1.4'

from .data_transformer import Column, Data
