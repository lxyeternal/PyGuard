assignmentprint
===============

Pretty printer for student-submitted assignments. Helps with prettyprinting student code and generating reports.