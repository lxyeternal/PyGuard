# Automait

This package enables python users to interface with the automait modeling services programmatically using their API key. For more information visit automait.ai.