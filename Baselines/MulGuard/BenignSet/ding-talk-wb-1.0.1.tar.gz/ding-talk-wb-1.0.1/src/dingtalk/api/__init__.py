from dingtalk.api.rest import *
from dingtalk.api.base import FileItem
