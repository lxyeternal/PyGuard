'''
Created by auto_sdk on 2021.04.22
'''
from dingtalk.api.base import RestApi
class OapiRhinoMosLayoutOperationdefsListsimpleRequest(RestApi):
	def __init__(self,url=None):
		RestApi.__init__(self,url)
		self.operation_uids = None
		self.order_id = None
		self.tenant_id = None
		self.userid = None

	def getHttpMethod(self):
		return 'POST'

	def getapiname(self):
		return 'dingtalk.oapi.rhino.mos.layout.operationdefs.listsimple'
