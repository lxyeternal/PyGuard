from enum import Enum

from box_sdk_gen.base_object import BaseObject

from typing import Optional

from typing import Dict

import json

from typing import List

from box_sdk_gen.base_object import BaseObject

from box_sdk_gen.schemas import RetentionPolicyAssignments

from box_sdk_gen.schemas import ClientError

from box_sdk_gen.schemas import RetentionPolicyAssignment

from box_sdk_gen.schemas import FilesUnderRetention

from box_sdk_gen.auth import Authentication

from box_sdk_gen.network import NetworkSession

from box_sdk_gen.utils import prepare_params

from box_sdk_gen.utils import to_string

from box_sdk_gen.utils import ByteStream

from box_sdk_gen.fetch import fetch

from box_sdk_gen.fetch import FetchOptions

from box_sdk_gen.fetch import FetchResponse

class GetRetentionPolicyAssignmentsTypeArg(str, Enum):
    FOLDER = 'folder'
    ENTERPRISE = 'enterprise'
    METADATA_TEMPLATE = 'metadata_template'

class CreateRetentionPolicyAssignmentAssignToArgTypeField(str, Enum):
    ENTERPRISE = 'enterprise'
    FOLDER = 'folder'
    METADATA_TEMPLATE = 'metadata_template'

class CreateRetentionPolicyAssignmentAssignToArg(BaseObject):
    def __init__(self, type: CreateRetentionPolicyAssignmentAssignToArgTypeField, id: str, **kwargs):
        """
        :param type: The type of item to assign the policy to.
        :type type: CreateRetentionPolicyAssignmentAssignToArgTypeField
        :param id: The ID of item to assign the policy to.
            Set to `null` or omit when `type` is set to
            `enterprise`.
        :type id: str
        """
        super().__init__(**kwargs)
        self.type = type
        self.id = id

class RetentionPolicyAssignmentsManager:
    def __init__(self, auth: Optional[Authentication] = None, network_session: Optional[NetworkSession] = None):
        self.auth = auth
        self.network_session = network_session
    def get_retention_policy_assignments(self, retention_policy_id: str, type: Optional[GetRetentionPolicyAssignmentsTypeArg] = None, fields: Optional[str] = None, marker: Optional[str] = None, limit: Optional[int] = None) -> RetentionPolicyAssignments:
        """
        Returns a list of all retention policy assignments associated with a specified
        
        retention policy.

        :param retention_policy_id: The ID of the retention policy.
            Example: "982312"
        :type retention_policy_id: str
        :param type: The type of the retention policy assignment to retrieve.
        :type type: Optional[GetRetentionPolicyAssignmentsTypeArg], optional
        :param fields: A comma-separated list of attributes to include in the
            response. This can be used to request fields that are
            not normally returned in a standard response.
            Be aware that specifying this parameter will have the
            effect that none of the standard fields are returned in
            the response unless explicitly specified, instead only
            fields for the mini representation are returned, additional
            to the fields requested.
        :type fields: Optional[str], optional
        :param marker: Defines the position marker at which to begin returning results. This is
            used when paginating using marker-based pagination.
        :type marker: Optional[str], optional
        :param limit: The maximum number of items to return per page.
        :type limit: Optional[int], optional
        """
        query_params_map: Dict[str, str] = prepare_params({'type': to_string(type), 'fields': to_string(fields), 'marker': to_string(marker), 'limit': to_string(limit)})
        response: FetchResponse = fetch(''.join(['https://api.box.com/2.0/retention_policies/', retention_policy_id, '/assignments']), FetchOptions(method='GET', params=query_params_map, response_format='json', auth=self.auth, network_session=self.network_session))
        return RetentionPolicyAssignments.from_dict(json.loads(response.text))
    def create_retention_policy_assignment(self, policy_id: str, assign_to: CreateRetentionPolicyAssignmentAssignToArg, filter_fields: Optional[List] = None, start_date_field: Optional[str] = None) -> RetentionPolicyAssignment:
        """
        Assigns a retention policy to an item.
        :param policy_id: The ID of the retention policy to assign
        :type policy_id: str
        :param assign_to: The item to assign the policy to
        :type assign_to: CreateRetentionPolicyAssignmentAssignToArg
        :param filter_fields: If the `assign_to` type is `metadata_template`,
            then optionally add the `filter_fields` parameter which will
            require an array of objects with a field entry and a value entry.
            Currently only one object of `field` and `value` is supported.
        :type filter_fields: Optional[List], optional
        :param start_date_field: The date the retention policy assignment begins.
            If the `assigned_to` type is `metadata_template`,
            this field can be a date field's metadata attribute key id.
        :type start_date_field: Optional[str], optional
        """
        request_body: BaseObject = BaseObject(policy_id=policy_id, assign_to=assign_to, filter_fields=filter_fields, start_date_field=start_date_field)
        response: FetchResponse = fetch(''.join(['https://api.box.com/2.0/retention_policy_assignments']), FetchOptions(method='POST', body=json.dumps(request_body.to_dict()), content_type='application/json', response_format='json', auth=self.auth, network_session=self.network_session))
        return RetentionPolicyAssignment.from_dict(json.loads(response.text))
    def get_retention_policy_assignment_by_id(self, retention_policy_assignment_id: str, fields: Optional[str] = None) -> RetentionPolicyAssignment:
        """
        Retrieves a retention policy assignment
        :param retention_policy_assignment_id: The ID of the retention policy assignment.
            Example: "1233123"
        :type retention_policy_assignment_id: str
        :param fields: A comma-separated list of attributes to include in the
            response. This can be used to request fields that are
            not normally returned in a standard response.
            Be aware that specifying this parameter will have the
            effect that none of the standard fields are returned in
            the response unless explicitly specified, instead only
            fields for the mini representation are returned, additional
            to the fields requested.
        :type fields: Optional[str], optional
        """
        query_params_map: Dict[str, str] = prepare_params({'fields': to_string(fields)})
        response: FetchResponse = fetch(''.join(['https://api.box.com/2.0/retention_policy_assignments/', retention_policy_assignment_id]), FetchOptions(method='GET', params=query_params_map, response_format='json', auth=self.auth, network_session=self.network_session))
        return RetentionPolicyAssignment.from_dict(json.loads(response.text))
    def delete_retention_policy_assignment_by_id(self, retention_policy_assignment_id: str) -> None:
        """
        Removes a retention policy assignment
        
        applied to content.

        :param retention_policy_assignment_id: The ID of the retention policy assignment.
            Example: "1233123"
        :type retention_policy_assignment_id: str
        """
        response: FetchResponse = fetch(''.join(['https://api.box.com/2.0/retention_policy_assignments/', retention_policy_assignment_id]), FetchOptions(method='DELETE', response_format=None, auth=self.auth, network_session=self.network_session))
        return None
    def get_retention_policy_assignment_file_under_retention(self, retention_policy_assignment_id: str, marker: Optional[str] = None, limit: Optional[int] = None) -> FilesUnderRetention:
        """
        Returns a list of files under retention for a retention policy assignment.
        :param retention_policy_assignment_id: The ID of the retention policy assignment.
            Example: "1233123"
        :type retention_policy_assignment_id: str
        :param marker: Defines the position marker at which to begin returning results. This is
            used when paginating using marker-based pagination.
            This requires `usemarker` to be set to `true`.
        :type marker: Optional[str], optional
        :param limit: The maximum number of items to return per page.
        :type limit: Optional[int], optional
        """
        query_params_map: Dict[str, str] = prepare_params({'marker': to_string(marker), 'limit': to_string(limit)})
        response: FetchResponse = fetch(''.join(['https://api.box.com/2.0/retention_policy_assignments/', retention_policy_assignment_id, '/files_under_retention']), FetchOptions(method='GET', params=query_params_map, response_format='json', auth=self.auth, network_session=self.network_session))
        return FilesUnderRetention.from_dict(json.loads(response.text))
    def get_retention_policy_assignment_file_version_under_retention(self, retention_policy_assignment_id: str, marker: Optional[str] = None, limit: Optional[int] = None) -> FilesUnderRetention:
        """
        Returns a list of file versions under retention for a retention policy
        
        assignment.

        :param retention_policy_assignment_id: The ID of the retention policy assignment.
            Example: "1233123"
        :type retention_policy_assignment_id: str
        :param marker: Defines the position marker at which to begin returning results. This is
            used when paginating using marker-based pagination.
            This requires `usemarker` to be set to `true`.
        :type marker: Optional[str], optional
        :param limit: The maximum number of items to return per page.
        :type limit: Optional[int], optional
        """
        query_params_map: Dict[str, str] = prepare_params({'marker': to_string(marker), 'limit': to_string(limit)})
        response: FetchResponse = fetch(''.join(['https://api.box.com/2.0/retention_policy_assignments/', retention_policy_assignment_id, '/file_versions_under_retention']), FetchOptions(method='GET', params=query_params_map, response_format='json', auth=self.auth, network_session=self.network_session))
        return FilesUnderRetention.from_dict(json.loads(response.text))