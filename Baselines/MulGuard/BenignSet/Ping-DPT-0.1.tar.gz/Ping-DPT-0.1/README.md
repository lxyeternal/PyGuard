# Ping-DPT
Use Ping-Python and pynmea2 to generate Humminbird DPT sentences

# Install
