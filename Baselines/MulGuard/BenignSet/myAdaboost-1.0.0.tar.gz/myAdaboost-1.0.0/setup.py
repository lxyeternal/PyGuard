from distutils.core import setup

setup(
	name = 'myAdaboost',
	version = '1.0.0',
	py_modules = ['myAdaboost'],
	author = 'chenliyu',
	author_email = '2572065090@qq.com',
	url = 'http://pypi.python.org/ ',
	description = 'implimention of myAdaboost and ROC in python,and a test of it',
)

