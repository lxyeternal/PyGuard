INSTALL = ('FlashSite',)

default_app_config = 'flashboard.apps.FlashboardConfig'
