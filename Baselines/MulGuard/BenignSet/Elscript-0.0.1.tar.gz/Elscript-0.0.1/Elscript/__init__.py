import Esparser as Es

# access all attributes
