from django_fabric.base import App
from django_fabric.uwsgi import UwsgiApp
