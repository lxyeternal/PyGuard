"""The classes which can represent a legacy model reference file."""
from collections.abc import Mapping

from pydantic import BaseModel, ConfigDict


class RawLegacy_DownloadRecord(BaseModel):
    """An entry in the `config` field of a `RawLegacy_StableDiffusion_ModelRecord`."""

    file_name: str
    file_path: str
    file_url: str


class RawLegacy_FileRecord(BaseModel):
    """An entry in the `config` field of a `RawLegacy_StableDiffusion_ModelRecord`."""

    path: str
    md5sum: str | None = None
    sha256sum: str | None = None


class RawLegacy_StableDiffusion_ModelRecord(BaseModel):
    """A model entry in the legacy model reference."""

    # This is a better representation of the legacy model reference than the one in `staging_model_database_records.py`
    # which is a hybrid representation of the legacy model reference and the new model reference format.

    model_config = ConfigDict(extra="forbid")

    name: str
    baseline: str
    type: str  # noqa: A003
    inpainting: bool
    description: str | None = None
    tags: list[str] | None = None
    showcases: list[str] | None = None
    min_bridge_version: int | None = None
    version: str
    style: str | None = None
    trigger: list[str] | None = None
    homepage: str | None = None
    nsfw: bool
    download_all: bool
    config: Mapping[str, list[RawLegacy_FileRecord | RawLegacy_DownloadRecord]]
    available: bool | None = None
