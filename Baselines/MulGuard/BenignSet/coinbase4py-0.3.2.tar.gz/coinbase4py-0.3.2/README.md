coinbase4py
===========

python &amp; Django include project for anybody who wants to use coinbase.com


A small Django app that provides a client to coinbase.com


# Installation

- Get a git clone of the source tree:

        git clone https://github.com/claytantor/coinbase4py.git

    Then you'll need the "lib" subdir on your PYTHONPATH:

        cd coinbase4py
        python setup.py install


# Django project setup

1. Add `coinbase4py` to `INSTALLED_APPS` in your project's "settings.py".


