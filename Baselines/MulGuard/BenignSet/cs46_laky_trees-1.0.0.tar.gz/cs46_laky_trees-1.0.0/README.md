# Trees ![](https://api.travis-ci.com/lakyli0818/trees.svg?branch=master)

This is a homework for CMC's [CS46: data structures](https://github.com/mikeizbicki/cmc-csci046) course.
