from setuptools import setup
setup(name='kista',
      version='1.0.0',
      description='miscellaneous stuff, old norse for bag',
      url='https://github.com/circleclick-labs/kista.git',
      author='Joel Ward',
      author_email='jmward+python@gmail.com',
      license='MIT',
      packages=['kista'],
      zip_safe=False)
