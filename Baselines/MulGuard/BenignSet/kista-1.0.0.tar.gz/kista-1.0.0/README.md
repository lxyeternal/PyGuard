# kista
kista (old norse for bag)
