# milosmooth
## Descripcion
Esta libreria contiene funciones para suavizar curvas de datos y para calcular el area bajo la curva por montecarlo.
### Integración por montecarlo
Clase que calcula la integral de una función f en el intervalo [a,b] por el método de montecarlo y compara con la solución analítica.
### Suavizado de curvas
clase lee un archivo csv y genera un ajuste suave de los datos.