importscan: recursively import Python packages
==============================================

``importscan`` provides a ``scan`` function that lets you recursively
import a package and its sub-modules and sub-packages.

Documentation_.

.. _Documentation: http://importscan.readthedocs.org
