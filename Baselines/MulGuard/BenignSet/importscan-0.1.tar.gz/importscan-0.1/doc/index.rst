.. importscan documentation master file, created by
   sphinx-quickstart on Tue Mar 15 14:21:46 2016.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

importscan
==========

.. py:module:: importscan

.. autofunction:: scan

.. include:: ../CHANGES.txt

Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`

