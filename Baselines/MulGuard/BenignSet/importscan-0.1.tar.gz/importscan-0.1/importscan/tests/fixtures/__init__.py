calls = 0

def call():
    global calls
    calls += 1

def reset():
    global calls
    calls = 0
