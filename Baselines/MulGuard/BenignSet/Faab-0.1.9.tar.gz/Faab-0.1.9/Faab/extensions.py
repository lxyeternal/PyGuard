# @FileName: extensions
from flask_sqlalchemy import SQLAlchemy

# 扩展类实例化
db = SQLAlchemy()
# ......
