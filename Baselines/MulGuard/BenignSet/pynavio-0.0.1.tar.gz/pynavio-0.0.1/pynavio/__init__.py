"""Top-level package for pynavio."""

__author__ = """craftworks"""
__email__ = 'dev-accounts@craftworks.at'
__version__ = '0.0.1'
