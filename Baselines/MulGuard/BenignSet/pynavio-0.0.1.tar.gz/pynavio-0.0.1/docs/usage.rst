=====
Usage
=====

To use pynavio in a project::

    import pynavio
