=======
pynavio
=======


.. image:: https://img.shields.io/pypi/v/pynavio.svg
        :target: https://pypi.python.org/pypi/pynavio

.. image:: https://img.shields.io/travis/craftworksgmbh/pynavio.svg
        :target: https://travis-ci.com/craftworksgmbh/pynavio

.. image:: https://readthedocs.org/projects/pynavio/badge/?version=latest
        :target: https://pynavio.readthedocs.io/en/latest/?version=latest
        :alt: Documentation Status




Python lib for navio


* Free software: MIT license
* Documentation: https://pynavio.readthedocs.io.


Features
--------

* TODO

Credits
-------

This package was created with Cookiecutter_ and the `audreyr/cookiecutter-pypackage`_ project template.

.. _Cookiecutter: https://github.com/audreyr/cookiecutter
.. _`audreyr/cookiecutter-pypackage`: https://github.com/audreyr/cookiecutter-pypackage
