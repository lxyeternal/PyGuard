=======
History
=======

0.0.1 (2021-09-07)
------------------

* First release on PyPI.
