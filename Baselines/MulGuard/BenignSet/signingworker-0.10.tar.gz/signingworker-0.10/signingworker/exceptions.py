class TaskVerificationError(Exception):
    pass


class ChecksumMismatchError(Exception):
    pass


class SigningServerError(Exception):
    pass
