import unittest

class TestTemp(unittest.TestCase):

    def test_temp_func(self):
        self.assertTrue(True)
