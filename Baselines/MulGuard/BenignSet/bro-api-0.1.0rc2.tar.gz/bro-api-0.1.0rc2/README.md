# Publish
- update changelog with version number
- update bro/__version__.py
- tag with version number
