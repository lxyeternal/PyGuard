def temp_func():
    print('temp_func is called!')
