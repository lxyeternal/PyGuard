# inspired by the requests package
__version__ = '0.1.0rc2'
