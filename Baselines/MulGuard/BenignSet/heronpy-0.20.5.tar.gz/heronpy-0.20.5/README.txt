heronpy is the python API for Heron, the distributed streaming engine.
