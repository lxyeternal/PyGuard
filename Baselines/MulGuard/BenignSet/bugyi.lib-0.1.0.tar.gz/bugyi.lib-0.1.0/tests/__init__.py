"""Tests for the bugyi.lib package."""
