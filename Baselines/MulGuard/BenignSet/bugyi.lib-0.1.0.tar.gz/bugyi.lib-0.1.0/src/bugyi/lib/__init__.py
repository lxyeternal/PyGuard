"""Overly general Python library used when no other library is a good fit."""

__author__ = "Bryan M Bugyi"
__email__ = "bryanbugyi34@gmail.com"
__version__ = "0.1.0"
