lib package
===========

.. automodule:: lib
   :members:
   :undoc-members:
   :show-inheritance:

Submodules
----------

.. toctree::
   :maxdepth: 4

   lib.cli
