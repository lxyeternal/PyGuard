.. bugyi.lib

Welcome to bugyi.lib's documentation!
=====================================

Overly general Python library used when no other library is a good fit.

.. toctree::
   :maxdepth: -1
   :caption: Table of Contents

    API Reference <modules>
    CHANGELOG <changelog>
    CONTRIBUTING <contributing>
    README <readme>


Indices and Tables
==================

* :ref:`genindex`
* :ref:`modindex`
