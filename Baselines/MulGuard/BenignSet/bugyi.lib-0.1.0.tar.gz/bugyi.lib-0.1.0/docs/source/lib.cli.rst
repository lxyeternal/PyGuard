lib.cli module
==============

.. automodule:: lib.cli
   :members:
   :undoc-members:
   :show-inheritance:
