# coding: utf-8

from distutils.core import setup
setup(name='coilcraft',  #打包后的包文件名
      version='1.0',
      description='coilcraft_loss', #说明
      author='felix',
      author_email='qiyu_sjtu@163.com',
      url='',
      py_modules=['coilcraft.coilcraft_loss'],   #你要打包的文件
)