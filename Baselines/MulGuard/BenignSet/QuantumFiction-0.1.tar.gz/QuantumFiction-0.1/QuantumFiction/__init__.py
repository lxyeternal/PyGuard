
def c():
    print(1)
