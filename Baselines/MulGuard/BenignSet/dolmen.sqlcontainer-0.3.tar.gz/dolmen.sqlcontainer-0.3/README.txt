dolmen.sqlcontainer
*******************

``dolmen.sqlcontainer`` is an addon for cromlech and sqlalchemy. It provides
a "containership" abstraction, to work transparently with a hierarchy of 
objects coming from an SQL database.
