pysemver
========

The library provides handy utilities to work with versions that satisfy `Semantic Versioning Specification <http://semver.org/>`_ requirements. Allows validate, parse, compare, increment version numbers, etc.