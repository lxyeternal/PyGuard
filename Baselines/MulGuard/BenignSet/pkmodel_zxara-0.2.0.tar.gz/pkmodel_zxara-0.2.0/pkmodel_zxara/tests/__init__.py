#
# Test module for pkmodel.
#
# To run all tests, use ``python -m unittest discover``.
#
# To run a particular test, use e.g.
#  ``python -m unittest pkmodel.tests.test_model``.
#
# For this project, we chose to place the tests inside the code directory. See
# https://stackoverflow.com/questions/61151/where-do-the-python-unit-tests-go
# for an extended discussion.
#

