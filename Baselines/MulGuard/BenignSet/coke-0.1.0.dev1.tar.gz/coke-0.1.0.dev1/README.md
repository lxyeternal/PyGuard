# Coke

> Coke is a fuel with few impurities and a high carbon content, usually made from coal. -Wikipedia

Coke is a GraphQL library for Python 3.5+
