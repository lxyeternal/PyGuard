import os
import sys

import numpy as np 
from mxnet import image
from scipy.stats import logistic
from scipy.special import softmax