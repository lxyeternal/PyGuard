import os 
import sys
import numpy as np 
import time
import keras.callbacks as krc