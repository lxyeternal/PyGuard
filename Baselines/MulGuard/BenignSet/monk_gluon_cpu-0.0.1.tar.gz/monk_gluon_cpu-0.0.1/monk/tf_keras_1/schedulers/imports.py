import os
import sys
import numpy as np 


import keras.callbacks as krc