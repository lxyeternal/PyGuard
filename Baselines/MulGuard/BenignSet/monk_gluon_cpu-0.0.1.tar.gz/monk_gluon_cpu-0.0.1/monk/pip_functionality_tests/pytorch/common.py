import os



def print_start(exp_name, exp_num):
    print("###################################################")
    print("{}. Exp:         {}".format(exp_num, exp_name));


def print_status(status):
    print("Status:      {}".format(status));
    print("###################################################")
    print("")


    