# Copyright (c) Microsoft Corporation.
# Licensed under the MIT license.

"""Objective-related classes and methods."""
