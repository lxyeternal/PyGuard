# Copyright (c) Microsoft Corporation.
# Licensed under the MIT license.

"""Search spaces-related classes and methods."""
