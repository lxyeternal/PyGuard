# Copyright (c) Microsoft Corporation.
# Licensed under the MIT license.

"""ONNX-related configuration utilities."""
