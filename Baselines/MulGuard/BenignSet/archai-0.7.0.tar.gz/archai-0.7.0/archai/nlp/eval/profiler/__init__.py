# Copyright (c) Microsoft Corporation.
# Licensed under the MIT license.

"""Customizes a profiler tool based on microsoft/DeepSpeed."""

from archai.nlp.eval.profiler.profiler_eval import profile
