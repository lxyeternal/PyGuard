# Copyright (c) Microsoft Corporation.
# Licensed under the MIT license.

"""Evaluation-related classes and methods, such as few-shot and text prediction."""
