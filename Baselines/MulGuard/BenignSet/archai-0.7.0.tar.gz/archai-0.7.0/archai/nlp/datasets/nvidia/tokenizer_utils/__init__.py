# Copyright (c) Microsoft Corporation.
# Licensed under the MIT license.

"""NVIDIA's-related tokenizers, pre-trained tokenizers and token's configuration."""
