# Copyright (c) Microsoft Corporation.
# Licensed under the MIT license.

"""GPT-2 Flexible Transformer."""
