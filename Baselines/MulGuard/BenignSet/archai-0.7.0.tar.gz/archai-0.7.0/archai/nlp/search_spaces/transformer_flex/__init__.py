# Copyright (c) Microsoft Corporation.
# Licensed under the MIT license.

"""Transformer-Flex search space."""
