from datetime import datetime, tzinfo


def now():
    """
    TBD: Return an aware or naive datetime.datetime
    """
    return datetime.now()