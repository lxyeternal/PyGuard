# django-make-secret-key

A Python script that generates a new Django secret key and prints it to stdout.

## Installation

```bash
pip install django-make-secret-key
```
