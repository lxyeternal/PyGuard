# django-dispatcher
Logic engine for determining order of things to execute
