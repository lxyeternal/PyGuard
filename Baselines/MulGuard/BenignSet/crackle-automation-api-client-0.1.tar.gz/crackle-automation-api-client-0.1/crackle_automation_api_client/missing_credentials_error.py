''' MissingCredentialsError Exception Handler '''


class MissingCredentialsError(Exception):
    """ Missing Credentials exception """
