VERSION = (0, 1, '1')

version = __version__ = '.'.join(map(str, VERSION))
