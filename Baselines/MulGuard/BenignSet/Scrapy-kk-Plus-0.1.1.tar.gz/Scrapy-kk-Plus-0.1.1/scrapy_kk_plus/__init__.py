__author__ = 'gchristencen46'
__email__ = 'gchristencen46@gmail.com'

from .dupefilter import RFPDupeFilter
from .scheduler import Scheduler
