from setuptools import setup, find_packages

setup(name="mess_client123client",
      version="0.0.2",
      description="mess_client123client",
      author="aaaa123",
      author_email="wepori@yandex.ru",
      packages=find_packages(),
      install_requires=['PyQt5', 'sqlalchemy', 'pycryptodome', 'pycryptodomex']
      )
