import sys

from . import __version__


def main():
    print(f"covid19-id versi {__version__}")


if __name__ == "__main__":
    sys.exit(main())
