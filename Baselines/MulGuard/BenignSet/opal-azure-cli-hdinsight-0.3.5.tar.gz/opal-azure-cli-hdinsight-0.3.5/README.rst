Microsoft Azure CLI 'hdinsight' Command Module
==============================================

This package is for the 'hdinsight' module.
i.e. 'az hdinsight'


