
This is filelike, a python module for creating and manipulating file-like
objects.  For details, enter a python shell and do the following:

  >>> import filelike
  >>> help(filelike)


Bugs, comments, questions etc can be sent to the author at:

     ryan@rfk.id.au


