"""
This contains a series of examples to help demonstrate how this
module can be used.

Each example comes with a piece of demonstration code which can be
executed to display the end result. Each example is designed to show
how this module can be utilised to harness the factory/plugin design
pattern with minimal implementation overhead.
"""
