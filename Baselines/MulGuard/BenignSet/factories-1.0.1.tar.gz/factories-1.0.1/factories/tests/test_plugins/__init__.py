"""
This holds files specifically designed to test various parts of the
factory.

Any plugins in this location SHOULD NOT be utilised outside of the 
unittests.
"""
