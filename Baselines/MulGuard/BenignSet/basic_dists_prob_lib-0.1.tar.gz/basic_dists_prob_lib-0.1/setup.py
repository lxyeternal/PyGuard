from setuptools import setup

setup(name='basic_dists_prob_lib',
      version='0.1',
      description='Gaussian distributions',
      author='Patrick Hofmann',
      packages=['basic_dists_prob_lib'],
      zip_safe=False)
