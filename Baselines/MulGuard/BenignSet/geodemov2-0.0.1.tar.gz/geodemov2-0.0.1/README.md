# geodemov2


[![image](https://img.shields.io/pypi/v/geodemov2.svg)](https://pypi.python.org/pypi/geodemov2)
[![image](https://img.shields.io/conda/vn/conda-forge/geodemov2.svg)](https://anaconda.org/conda-forge/geodemov2)


**example geo python packages**


-   Free software: MIT license
-   Documentation: https://Hamilton97.github.io/geodemov2
    

## Features

-   TODO
