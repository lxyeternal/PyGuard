"""Top-level package for geodemoV2."""

__author__ = """Ryan Hamilton"""
__email__ = 'ryangilberthamilton@gmail.com'
__version__ = '0.0.1'
