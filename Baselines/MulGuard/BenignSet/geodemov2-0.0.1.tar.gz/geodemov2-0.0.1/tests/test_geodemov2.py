#!/usr/bin/env python

"""Tests for `geodemov2` package."""


import unittest

from geodemov2 import geodemov2


class TestGeodemov2(unittest.TestCase):
    """Tests for `geodemov2` package."""

    def setUp(self):
        """Set up test fixtures, if any."""

    def tearDown(self):
        """Tear down test fixtures, if any."""

    def test_000_something(self):
        """Test something."""
