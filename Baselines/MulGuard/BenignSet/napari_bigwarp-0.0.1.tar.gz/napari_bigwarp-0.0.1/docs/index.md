# Welcome to napari-bigwarp

BigWarp-like interface for napari
