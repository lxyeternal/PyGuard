from django.apps import AppConfig


class TcknConfig(AppConfig):
    name = 'tckn'
