# flake8:noqa
from urllib.error import HTTPError
from urllib.parse import urlencode
from urllib.request import Request, urlopen
