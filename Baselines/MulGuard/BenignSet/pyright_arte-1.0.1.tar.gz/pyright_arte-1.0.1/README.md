# pyright
Arteglaive's proprietary copyright checker
