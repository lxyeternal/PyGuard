import numpy as np


def create_test_data(N, D):
    return np.random.rand(N, D).astype(np.float32)
