YTS_API_URL = "http://yts.re/api/v2/"
YTS_DEFAULT_RESPONSE_FORMAT = "json"
YTS_STATUS_OK = "ok"
YTS_STATUS_ERROR = "error"

YTS_RESPONSE = {
    "status": YTS_STATUS_ERROR,
    "status_message": "",
    "data": {}
}