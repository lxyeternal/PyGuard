from .pyyts_client import *

__version__ = "1.0"
__app_name__ = "pyyts"
__description__ = "YTS API client"
__author__ = "Ferdinand Silva"
__author_email__ = "ferdinandsilva@ferdinandsilva.com"
__app_url__ = "http://ferdinandsilva.com"
__download_url__ = "https://github.com/six519/pyyts"