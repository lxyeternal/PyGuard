from fitterpp.fitterpp import Fitterpp
from fitterpp.constants import METHOD_LEASTSQ, \
    METHOD_DIFFERENTIAL_EVOLUTION,  \
    METHOD_BOTH, METHOD_FITTER_DEFAULTS, MAX_NFEV
