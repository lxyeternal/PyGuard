class PseudoDefaultLogger:
    def __init__(self):
        pass

    @staticmethod
    def log_info(*args, **kwargs):
        pass

    @staticmethod
    def log_debug(*args, **kwargs):
        pass
