__project__ = "nerblackbox"
__author__ = "Felix Stollenwerk"
__version__ = "0.0.10"
__license__ = "Apache 2.0"
