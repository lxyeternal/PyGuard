# (C) 2016, MIT license

'''
Module to stream through a bzip2 compressed text file and yield its lines.
'''
from .bz2_rl import BZ2TextFileStreamer
