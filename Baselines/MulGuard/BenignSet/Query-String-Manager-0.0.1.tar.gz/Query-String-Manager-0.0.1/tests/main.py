import sys
import unittest

from .utilities_tests.test_is_valid_single_level_dict import *
from .encoders_tests.test_generate_query_string import *
from .encoders_tests.test_generate_base64_query_string import *

unittest.main(argv=sys.argv)