"""**Step 2**: Typesystem static decorator
"""
