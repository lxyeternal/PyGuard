"""Reads datablocks.
"""
