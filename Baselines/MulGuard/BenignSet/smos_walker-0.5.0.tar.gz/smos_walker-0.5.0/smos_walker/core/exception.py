class SmosWalkerException(Exception):
    """Generic exception related to the project."""


class DynamicLengthMismatchSmosWalkerException(SmosWalkerException):
    pass
