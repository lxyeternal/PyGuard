"""Contains core smos_walker's logic
"""
