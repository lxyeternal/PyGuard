"""**Step 1**: Typesystem parser
"""
