"""Command-line interface for smos_walker

The module's facade does expose an entrypoint.
"""
