"""Logic to convert nodes to numpy arrays (after dyanamic decoration)
"""
