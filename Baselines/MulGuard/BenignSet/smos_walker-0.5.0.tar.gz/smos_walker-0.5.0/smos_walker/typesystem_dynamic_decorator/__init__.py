"""**Step 3**: Typesystem dynamic decorator
"""
