def test_validate_config():
    pass


def test_list_input_files_when_no_source():
    pass


def test_list_input_files_when_source_is_file():
    pass


def test_list_input_files_when_source_is_dir():
    pass


def test_get_walltime():
    pass


def test_gen_pull_headers_when_no_source():
    pass


def test_gen_pull_headers_when_source():
    pass


def test_gen_push_headers_when_no_sink():
    pass


def test_gen_push_headers_when_sink():
    pass


def test_gen_job_headers():
    pass


def test_gen_pull_command():
    pass


def test_gen_push_command():
    pass


def test_gen_job_command():
    pass


def test_gen_pull_script():
    pass


def test_gen_push_script():
    pass


def test_gen_job_script():
    pass


def test_gen_launcher_script():
    pass


def test_gen_singularity_invocation():
    pass
