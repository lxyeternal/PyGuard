import pytest
from click.testing import CliRunner


@pytest.mark.skip(reason="todo")
def test_scripts_slurm_no_source_no_sink():
    pass


@pytest.mark.skip(reason="todo")
def test_scripts_slurm_with_source():
    pass


@pytest.mark.skip(reason="todo")
def test_scripts_slurm_with_sink():
    pass


@pytest.mark.skip(reason="todo")
def test_scripts_slurm_with_source_and_sink():
    pass


@pytest.mark.skip(reason="todo")
@pytest.mark.slow
def test_submit_slurm():
    runner = CliRunner()
    # result = runner.invoke(cli.submit, [""])
    # todo
