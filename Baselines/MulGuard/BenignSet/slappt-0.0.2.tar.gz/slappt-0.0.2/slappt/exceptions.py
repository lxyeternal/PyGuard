class ExitStatusException(Exception):
    pass
