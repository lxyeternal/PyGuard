# -*- coding: utf-8 -*-

"""Top-level package for chaptermarkers."""

__author__ = 'Colin Bitterfield'
__email__ = 'cbitterfield@gmail.com'
__version__ = '0.1.0'
