chaptermarkers package
======================

Submodules
----------

chaptermarkers.chaptermarkers module
------------------------------------

.. automodule:: chaptermarkers.chaptermarkers
   :members:
   :undoc-members:
   :show-inheritance:

Module contents
---------------

.. automodule:: chaptermarkers
   :members:
   :undoc-members:
   :show-inheritance:
