import disc_riider_py

disc_riider_py.rebuild_from_directory('out-extract', 'new.iso', lambda x: print(f"perc: {x}"))
