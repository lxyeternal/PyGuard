library to read/build wii ISOs, focussed on being used in patching an ISO for randomizers

Currently, the api is **NOT** considered stable and can break between versions
