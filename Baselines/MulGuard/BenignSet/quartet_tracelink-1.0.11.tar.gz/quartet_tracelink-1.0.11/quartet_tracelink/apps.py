# -*- coding: utf-8
from django.apps import AppConfig


class QuartetTr4c3l1nkConfig(AppConfig):
    name = 'quartet_tracelink'
    verbose_name = 'QU4RTET Tracelink'


class QuartetTracelinkConfig(AppConfig):
    name = 'quartet_tracelink'
    verbose_name = 'QU4RTET Tracelink'
