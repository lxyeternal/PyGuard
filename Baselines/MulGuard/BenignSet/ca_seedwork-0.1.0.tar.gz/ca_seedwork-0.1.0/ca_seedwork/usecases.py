class UseCase:
    pass
