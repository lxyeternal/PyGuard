def init(token, app_name, service_name, **kwargs):
    """
    inits the authorizon client
    """
    print(f"app name: {app_name}")