"""
Basic github repository setup for python projects.
"""

__version__ = "0.1.4"
