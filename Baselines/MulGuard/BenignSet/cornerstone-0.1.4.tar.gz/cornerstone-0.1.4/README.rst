.. image:: http://github.com/kraymer/cornerstone/workflows/build/badge.svg
   :target: https://github.com/kraymer/cornerstone/actions   
.. image:: http://img.shields.io/pypi/v/cornerstone.svg
   :target: https://pypi.python.org/pypi/cornerstone
.. image:: https://codecov.io/gh/Kraymer/cornerstone/branch/master/graph/badge.svg?token=NWHZ0T10O2
   :target: https://codecov.io/gh/Kraymer/cornerstone
.. image:: https://pepy.tech/badge/cornerstone  
   :target: https://pepy.tech/project/cornerstone
.. image:: https://img.shields.io/badge/releases-atom-orange.svg
   :target: https://github.com/Kraymer/cornerstone/releases.atom
   
.. pypi

cornerstone
===========

    **/kɔrˈneːrston/**
    
    | *n.* an indispensable and fundamental basis


``cornerstone`` is a basic repository setup to start your python project.

Features
--------

- README.rst processing to make it compatible with pypi strict formatting rules
- CI/CD coverage report
- CI/CD unit tests report
