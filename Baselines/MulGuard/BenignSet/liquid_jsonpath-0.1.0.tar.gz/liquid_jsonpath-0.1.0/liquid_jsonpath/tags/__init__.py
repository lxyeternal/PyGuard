from liquid_jsonpath.tags.for_tag import JSONPathForTag

__all__ = ("JSONPathForTag",)
