# django-handy-utils

`django-handy-utils` contains various model, view, filter, and other miscellaneous utilities that are standardized across projects.

## Installation

```shell
pip install django-handy-utils
```

## Usage in Django

TO COME
