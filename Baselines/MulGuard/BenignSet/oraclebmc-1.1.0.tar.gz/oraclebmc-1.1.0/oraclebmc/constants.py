# coding: utf-8
# Copyright (c) 2017 Oracle and/or its affiliates. All rights reserved.

HEADER_NEXT_PAGE = 'opc-next-page'
HEADER_REQUEST_ID = 'opc-request-id'
HEADER_CLIENT_INFO = 'opc-client-info'
HEADER_USER_AGENT = 'user-agent'
