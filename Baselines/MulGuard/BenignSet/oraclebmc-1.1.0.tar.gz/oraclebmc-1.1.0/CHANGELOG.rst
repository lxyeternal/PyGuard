Change Log
~~~~~~~~~~
All notable changes to this project will be documented in this file.

The format is based on `Keep a Changelog <http://keepachangelog.com/>`_.

============
 Unreleased
============


====================
 1.1.0 - 2017-02-03
====================

* Support added for Core Services:

  * Block Storage
  * Compute
  * Virtual Network

====================
 1.0.0 - 2017-01-17
====================

-------
 Added
-------

* Initial Release
* Support added for Identity Service, Object Storage Service
