from ._version import get_version

__version__ = get_version()


if __name__ == '__main__':
    print("version is: " + __version__)
