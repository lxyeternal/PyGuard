#!/usr/bin/env python3

from sqlalchemy.ext.declarative import declarative_base
Base = declarative_base()


