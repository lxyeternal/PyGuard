# Classy Data

meta model to define and persist object oriented models and code

