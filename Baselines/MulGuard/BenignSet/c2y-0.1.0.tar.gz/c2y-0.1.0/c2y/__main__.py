"""
main entry
"""
import fire

from c2y import Xcoco

if __name__ == "__main__":
    fire.Fire(Xcoco)
