# -*- coding: utf-8 -*-
#

__author__ = "Tianyi Li"
__email__ = "tianyikillua@gmail.com"
__copyright__ = u"Copyright (c) 2019 {} <{}>".format(__author__, __email__)
__license__ = "License :: OSI Approved :: MIT License"
__version__ = "0.0.1"
__status__ = "Development Status :: 4 - Beta"
