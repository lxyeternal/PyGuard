from distutils.core import setup

setup(
    name = 'python_tuto',
    version = '1.0.0',
    py_modules = ['python_tuto'],
    author = 'ls25370',
    author_email = 'ls25370@gmail.com',
    url = 'http://www.muzrang.com',
    description = 'A simple printer of nested list',
    )
