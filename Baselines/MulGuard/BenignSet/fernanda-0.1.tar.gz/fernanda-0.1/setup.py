from setuptools import setup, find_packages

setup(
    name="fernanda",
    version="0.1",
    license="MIT",
    description="Juego que nos ayuda a ver nuestro nivel de aprendizaje",
    author="Silvia leon",
    packages=find_packages(),
    url="https://github.com/12silvia/repositorio"

)
