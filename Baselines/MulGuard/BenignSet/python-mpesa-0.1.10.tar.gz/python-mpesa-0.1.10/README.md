# python-mpesa
M-Pesa G2 API Python adapter
