# Copyright (C) 2017-2019 by Vd.
# This file is part of Periodic package.
# Periodic is released under the MIT License (see LICENSE).

from .periodic import Periodic


def version():
    return "2019.02"
