# odious
Compares optimizers 
