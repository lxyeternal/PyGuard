#!/usr/bin/env python3

'''definition of class Empty'''

from . import Node


class Empty(Node):
    '''Empty nodes are ... empty nodes'''
