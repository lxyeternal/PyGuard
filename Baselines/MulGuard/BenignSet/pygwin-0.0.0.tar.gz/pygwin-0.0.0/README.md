#  Pygwin

Pygwin (pygame window system) provides a set of classes to program
very basic window interfaces with pygame.

## license

Pygwin is published under the term of
[GPLv3](https://www.gnu.org/licenses/gpl-3.0.txt).

## installation

Install pygwin using pip.  In the root directory:

```
pip3 install .
```

## testing

To see the some of the features provided by the module:

```python
from pygwin.test import test
test.go()
```
