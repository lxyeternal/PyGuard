"""A RESTArt extension for integrating RESTArt into Falcon, which has the benefit of high performance."""

__version__ = '0.1.0'
__author__ = 'RussellLuo'
__email__ = 'luopeng.he@gmail.com'
__license__ = 'MIT'
