# `basicpkg`

The `basicpkg` is a simple testing example to understand the basics of developing your first Python package. 