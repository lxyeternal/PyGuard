pandio = {
    'FUNCTION_NAME': 'exampleFunction123',
    'INPUT_TOPICS': ['non-persistent://public/default/in'],
    'OUTPUT_TOPICS': ['non-persistent://public/default/out'],
    'LOG_TOPIC': 'non-persistent://public/default/log',
}
