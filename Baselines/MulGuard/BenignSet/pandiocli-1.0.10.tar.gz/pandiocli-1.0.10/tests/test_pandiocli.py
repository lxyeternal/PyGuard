def test_pandiocli():
    assert 1 == 1
