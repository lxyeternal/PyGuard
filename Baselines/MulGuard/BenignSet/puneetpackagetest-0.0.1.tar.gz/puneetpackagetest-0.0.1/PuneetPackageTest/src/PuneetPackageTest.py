def SayLoud() :
    print("This greet is from Puneet Package ")
def SayLouder(message) :
    print("This louder message from puneet package "+ message)
def WhatIsYourName(message) :
    print("Your Name is : "+ message)
def PrintHello() :
    print("Hello")