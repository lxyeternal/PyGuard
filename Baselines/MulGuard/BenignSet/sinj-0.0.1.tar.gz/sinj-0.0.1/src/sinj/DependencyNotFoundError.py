class DependencyNotFoundError(Exception):
    pass
