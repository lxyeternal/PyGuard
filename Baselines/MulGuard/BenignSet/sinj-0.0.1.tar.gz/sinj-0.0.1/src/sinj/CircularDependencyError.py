class CircularDependencyError(Exception):
    pass
