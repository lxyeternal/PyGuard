class DependencyNotMappedError(Exception):
    pass
