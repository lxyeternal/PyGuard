class DependencyConflictError(Exception):
    pass
