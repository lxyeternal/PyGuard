# `as_easy_as_pie`
![Replace with your own inspirational logo here](https://github.com/PFython/easypypi/blob/main/easypypi.png?raw=true)

# 1. OVERVIEW
Really easy

# 2. INSTALLATION

    pip install as_easy_as_pie


# 3. BASIC USE

    >>> import as_easy_as_pie


# 4. UNDER THE BONNET

# 5. CONTRIBUTING

Contact Peter peter@gmail.com or feel free to raise Pull Requests / Issue in the normal Github way.

# 6. CREDITS

# 7. PAYING IT FORWARD


If `as_easy_as_pie` helps you save time and focus on more important things, please feel free to to show your appreciation by starring the repository on Github.

I'd also be delighted if you wanted to:

<a href="https://www.buymeacoffee.com/{self.Github_username}" target="_blank"><img src="https://cdn.buymeacoffee.com/buttons/v2/arial-yellow.png" alt="Buy Me A Coffee" width="217px" ></a>
