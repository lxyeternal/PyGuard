from gascompressibility.zfactor import zfactor
#from gascompressibility import Zfactor
