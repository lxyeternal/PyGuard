Inplat package for masking data
===============================

Докумментация в [GitLab Pages](https://sivanov.pages.app.ipl/masking_sensetive_data/).