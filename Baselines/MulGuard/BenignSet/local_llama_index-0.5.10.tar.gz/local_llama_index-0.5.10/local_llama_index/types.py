from typing import Generator, Union


RESPONSE_TEXT_TYPE = Union[str, Generator]
