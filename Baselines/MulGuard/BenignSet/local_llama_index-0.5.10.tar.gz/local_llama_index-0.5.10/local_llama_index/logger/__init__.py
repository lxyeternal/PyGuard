"""Init params."""

from local_llama_index.logger.base import LlamaLogger

__all__ = ["LlamaLogger"]
