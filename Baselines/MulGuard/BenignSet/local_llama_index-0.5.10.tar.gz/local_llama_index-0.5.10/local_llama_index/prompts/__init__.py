"""Prompt class."""

from local_llama_index.prompts.base import Prompt

__all__ = ["Prompt"]
