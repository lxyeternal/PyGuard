# 功能

这里 fork 了 jerryjliu 的仓库，主要改动是修改了 openai 的域名，提升访问速度。

# 说明

引用自 https://github.com/jerryjliu/llama_index
