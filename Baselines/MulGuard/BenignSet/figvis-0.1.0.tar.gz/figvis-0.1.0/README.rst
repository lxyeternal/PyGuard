figvis
======

Figment Visualization is a framework to visualize data using templates

Requirements
++++++++++++

Installation
++++++++++++

Usage
+++++

Command line
------------

Programmatic
------------

Example
-------