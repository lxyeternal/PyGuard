
manipulate bazaar, fossil, git, mercurial repositories
