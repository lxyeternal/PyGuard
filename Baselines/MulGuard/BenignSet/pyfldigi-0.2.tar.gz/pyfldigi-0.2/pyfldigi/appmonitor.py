'''TBD
'''


class ApplicationMonitor(object):

    def __init__(self):
        pass

    def launch(self):
        pass

    def get_pid(self):
        '''Get the process ID from the operating system'''
        pass
