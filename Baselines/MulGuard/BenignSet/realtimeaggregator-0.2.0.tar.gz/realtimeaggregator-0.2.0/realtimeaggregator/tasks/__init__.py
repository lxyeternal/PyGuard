"""This module provides the tasks."""

from . import download
from . import filter
from . import compress
from . import archive
