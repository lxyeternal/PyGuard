from pylond import lang_lookup
from pprint import pprint

k = lang_lookup('albaníska', lang='is', lev_ratio=0.9)
pprint(k)