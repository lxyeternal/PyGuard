from __future__ import print_function, division

from coffea import hist
from coffea.util import numpy as np

def test_import():
    from coffea.hist import plot
