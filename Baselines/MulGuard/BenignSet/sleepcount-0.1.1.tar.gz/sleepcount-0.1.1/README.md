# sleepcount

just as a simple 'sleep' CLI util but with countdown option and HH:MM:SS target time
