#### Anodot metric monitor

## Configure
- Provide the Anodot data collection token as ANODOT_TOKEN environment variable
- Provide the stack name as STACK environment variable
- You can modify ANODOT_URL if needed