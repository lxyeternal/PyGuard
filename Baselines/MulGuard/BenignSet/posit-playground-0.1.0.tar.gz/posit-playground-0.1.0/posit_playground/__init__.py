from .posit import from_bits
from .mul import mul
