__version__ = "1.0.2"

if __name__ == "__main__":
    print(__version__)