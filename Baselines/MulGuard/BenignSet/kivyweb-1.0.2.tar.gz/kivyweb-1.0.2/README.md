# KivyWeb
Python 3 library
# Description
KivyWeb, make your website with framework 
# Features 1.0.0
Support OS (Android,Windows)
# Quickstart & Installation
KivyWeb requires an installation of Python 3.6 or greater, as well as pip. (Pip is typically bundled with Python 
To install from the source with pip:
```
pip install kivyweb
```