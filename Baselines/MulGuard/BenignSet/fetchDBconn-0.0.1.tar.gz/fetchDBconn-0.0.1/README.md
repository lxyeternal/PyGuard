##fetchDBconn
This package allows to fetch db connection details from secrets manager AWS.