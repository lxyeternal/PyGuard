# pyvoices
python package supporting data curation for "* Voices"-like data.
