import logging

from stardate.tests.test_models import *
from stardate.tests.test_backends import *
from stardate.tests.test_parsers import *

logging.disable(logging.CRITICAL)
