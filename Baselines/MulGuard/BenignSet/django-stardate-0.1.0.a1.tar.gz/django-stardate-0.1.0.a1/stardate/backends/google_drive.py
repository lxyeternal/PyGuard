"""
A django-stardate backend for Google Drive.
"""
