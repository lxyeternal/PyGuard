class Controller:

    def __init__():
        print("Created a Controller instance.")