# geocam
Camera control software for geotechnical research applications.
