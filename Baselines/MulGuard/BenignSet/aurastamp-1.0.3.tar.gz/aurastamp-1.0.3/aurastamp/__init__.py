from .main import *

__all__=['Aurastamp']
__version__ = '1.0.3'