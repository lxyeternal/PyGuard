# Formula dispersion

A fast formula-parsing dispersion written in rust with python bindings.