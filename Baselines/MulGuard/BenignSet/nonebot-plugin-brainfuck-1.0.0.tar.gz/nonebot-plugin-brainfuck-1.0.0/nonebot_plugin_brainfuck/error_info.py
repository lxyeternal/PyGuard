# !/usr/bin/env python
# -*-coding:utf-8 -*-
# Author     ：Campanula 梦芸 何
POINT_CANNOT_MOVE = '指针无法移动'
TAPE_LIMIT = '纸带长度已达到'
INVALID_COMMAND = '打孔纸带不允许使用'
INBOX_ERR = '输入数据错误'