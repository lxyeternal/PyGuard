# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['p3man']

package_data = \
{'': ['*']}

install_requires = \
['click>=8.1.3,<9.0.0', 'cryptography>=37.0.4,<38.0.0']

entry_points = \
{'console_scripts': ['p3man = p3man:cli']}

setup_kwargs = {
    'name': 'p3man',
    'version': '0.1.0',
    'description': 'Password manager. Manage your passwords through encryption.',
    'long_description': None,
    'author': 'curtis',
    'author_email': 'curtis.hu688@gmail.com',
    'maintainer': None,
    'maintainer_email': None,
    'url': None,
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'entry_points': entry_points,
    'python_requires': '>=3.10,<4.0',
}


setup(**setup_kwargs)
