def init():
    global my_models
    global model_cross_validation
    global model_score
    global model_cm
    global model_cap_scores
    global model_roc_auc
    global model_fpr_tpr_thresholds
    my_models = {}
    model_roc_auc = {}
    model_cap_scores = {}
    model_cross_validation = {}
    model_score = {}
    model_cm = {}
    model_fpr_tpr_thresholds = {}
