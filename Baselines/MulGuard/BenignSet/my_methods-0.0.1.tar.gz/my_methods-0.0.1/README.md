# These methods are created by Nousahd Ali
to follow DRY principle 
and for my simplicity
