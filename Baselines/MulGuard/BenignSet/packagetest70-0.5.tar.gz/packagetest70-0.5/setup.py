#!/usr/bin/env python
# -*- coding: utf-8 -*-

from setuptools import setup

setup(name='packagetest70',
      version='0.5',
      description='Test2',
      url='http://github.com/storborg/funniest',
      author='PulStar',
      author_email='pulstar@gmail.com',
      license='MIT',
      packages=['devdoo'],
      zip_safe=False)
