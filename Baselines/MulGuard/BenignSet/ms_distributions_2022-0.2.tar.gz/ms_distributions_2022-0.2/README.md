Summary of the package

It does distributions :)