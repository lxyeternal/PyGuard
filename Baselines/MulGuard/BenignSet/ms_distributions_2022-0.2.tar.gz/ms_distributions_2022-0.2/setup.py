from setuptools import setup

setup(name='ms_distributions_2022',
      version='0.2',
      description='Gaussian and Binomial distributions',
      packages=['ms_distributions_2022'],
      author = 'Maximilian Schulz',
      author_email = 'maxi.schulz@gmx.net',
      zip_safe=False)
