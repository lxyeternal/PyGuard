"""Python Wrapper for the Aruba Instant API"""

from instantpy.instantpy import InstantVC