from gtlang_detection.gtlang_detection import *
