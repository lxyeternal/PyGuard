Core package for the PanDA server


** Documentation

https://twiki.cern.ch/twiki/bin/view/PanDA/PanDA


** How to install

See INSTALL.txt


** Release Note

See ChangeLog.txt
