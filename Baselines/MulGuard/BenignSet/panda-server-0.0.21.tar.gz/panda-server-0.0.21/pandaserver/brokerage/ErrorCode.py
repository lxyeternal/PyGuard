############## errror code

# release is not found
EC_Release = 100

# voms authentication failure
EC_Voms    = 101


