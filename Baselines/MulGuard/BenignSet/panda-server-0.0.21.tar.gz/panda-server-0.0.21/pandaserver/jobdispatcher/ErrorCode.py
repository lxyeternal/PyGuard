############## errror code

# Watcher
EC_Watcher = 100

# recovery failed
EC_Recovery = 101

# send failed
EC_SendError = 102

