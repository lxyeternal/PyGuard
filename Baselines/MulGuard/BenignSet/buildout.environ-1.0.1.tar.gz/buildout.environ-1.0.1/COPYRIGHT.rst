Copyright Holder
----------------

Klein & Partner KG, Innsbruck, Austria
