Changelog
=========

1.0.1 (2019-01-15)
------------------

- Fix misformated readme.
  [jensens]


1.0 (2019-01-15)
----------------

- Initial release. Make it work.
  [jensens]

