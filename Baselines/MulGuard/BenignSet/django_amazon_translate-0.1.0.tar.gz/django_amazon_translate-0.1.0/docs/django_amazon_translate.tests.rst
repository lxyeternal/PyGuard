django\_amazon\_translate.tests package
=======================================

Subpackages
-----------

.. toctree::

    django_amazon_translate.tests.testapp

Submodules
----------

django\_amazon\_translate.tests.test\_auto\_translate module
------------------------------------------------------------

.. automodule:: django_amazon_translate.tests.test_auto_translate
    :members:
    :undoc-members:
    :show-inheritance:

django\_amazon\_translate.tests.test\_translator module
-------------------------------------------------------

.. automodule:: django_amazon_translate.tests.test_translator
    :members:
    :undoc-members:
    :show-inheritance:


Module contents
---------------

.. automodule:: django_amazon_translate.tests
    :members:
    :undoc-members:
    :show-inheritance:
