django\_amazon\_translate.tests.testapp package
===============================================

Submodules
----------

django\_amazon\_translate.tests.testapp.admin module
----------------------------------------------------

.. automodule:: django_amazon_translate.tests.testapp.admin
    :members:
    :undoc-members:
    :show-inheritance:

django\_amazon\_translate.tests.testapp.models module
-----------------------------------------------------

.. automodule:: django_amazon_translate.tests.testapp.models
    :members:
    :undoc-members:
    :show-inheritance:

django\_amazon\_translate.tests.testapp.translation module
----------------------------------------------------------

.. automodule:: django_amazon_translate.tests.testapp.translation
    :members:
    :undoc-members:
    :show-inheritance:

django\_amazon\_translate.tests.testapp.urls module
---------------------------------------------------

.. automodule:: django_amazon_translate.tests.testapp.urls
    :members:
    :undoc-members:
    :show-inheritance:


Module contents
---------------

.. automodule:: django_amazon_translate.tests.testapp
    :members:
    :undoc-members:
    :show-inheritance:
