django\_amazon\_translate.management package
============================================

Subpackages
-----------

.. toctree::

    django_amazon_translate.management.commands

Module contents
---------------

.. automodule:: django_amazon_translate.management
    :members:
    :undoc-members:
    :show-inheritance:
