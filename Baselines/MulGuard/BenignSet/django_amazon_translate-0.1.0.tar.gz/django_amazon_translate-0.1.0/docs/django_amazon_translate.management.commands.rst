django\_amazon\_translate.management.commands package
=====================================================

Submodules
----------

django\_amazon\_translate.management.commands.auto\_translate\_text module
--------------------------------------------------------------------------

.. automodule:: django_amazon_translate.management.commands.auto_translate_text
    :members:
    :undoc-members:
    :show-inheritance:


Module contents
---------------

.. automodule:: django_amazon_translate.management.commands
    :members:
    :undoc-members:
    :show-inheritance:
