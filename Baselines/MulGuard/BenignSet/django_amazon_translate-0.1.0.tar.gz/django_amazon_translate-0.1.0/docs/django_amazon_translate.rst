django\_amazon\_translate package
=================================

Subpackages
-----------

.. toctree::

    django_amazon_translate.management
    django_amazon_translate.tests

Submodules
----------

django\_amazon\_translate.apps module
-------------------------------------

.. automodule:: django_amazon_translate.apps
    :members:
    :undoc-members:
    :show-inheritance:

django\_amazon\_translate.models module
---------------------------------------

.. automodule:: django_amazon_translate.models
    :members:
    :undoc-members:
    :show-inheritance:

django\_amazon\_translate.translator module
-------------------------------------------

.. automodule:: django_amazon_translate.translator
    :members:
    :undoc-members:
    :show-inheritance:


Module contents
---------------

.. automodule:: django_amazon_translate
    :members:
    :undoc-members:
    :show-inheritance:
