=====
Usage
=====

To use Django Amazon Translate in a project::

    import django_amazon_translate
