django_amazon_translate
=======================

.. toctree::
   :maxdepth: 4

   django_amazon_translate
