=======
History
=======

0.1.0 (2019-05-23)
------------------

* First release on PyPI.
