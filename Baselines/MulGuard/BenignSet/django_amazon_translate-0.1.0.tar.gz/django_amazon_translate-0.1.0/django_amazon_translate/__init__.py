# -*- coding: utf-8 -*-

"""Top-level package for Django Amazon Translate."""

__author__ = """Lee Packham"""
__email__ = 'leepac@amazon.co.uk'
__version__ = '0.1.0'
