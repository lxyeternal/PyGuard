import unittest
import heare.container

class BasicTest(unittest.TestCase):
    def test_function(self):
        config = heare.container.get_config()