NuDB is a database and search engine.
For more detail: https://github.com/WuSzHs/nudb.git
