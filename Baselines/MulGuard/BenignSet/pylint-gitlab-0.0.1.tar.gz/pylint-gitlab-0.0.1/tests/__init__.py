#
# Copyright 2019 Stephan Müller
#
# Licensed under the MIT license
