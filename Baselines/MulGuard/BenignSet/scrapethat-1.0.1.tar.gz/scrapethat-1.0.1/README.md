# scrapethat

scrapethat makes your scraping python codes faster and more readable

## Installation

You can install your package using pip:

```bash
pip install scrapethat
```
