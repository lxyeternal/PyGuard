YELLOW_BLUE_THEME =  ( '#ffffdd','#86a666')
"""
Classic blue - yellow theme.
"""

BROWN_YELLOW_THEME = ('#f0d9b5', '#b58863')
"""
Classic brown - yellow theme.
"""

ICE_THEME = ('#dee3e6','#8ca2ad')
"""
Classic ice theme.
"""