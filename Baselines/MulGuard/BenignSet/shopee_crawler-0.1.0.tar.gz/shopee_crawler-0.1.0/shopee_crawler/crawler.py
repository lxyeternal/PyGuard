from .toolkit.crawl_by_shop_url import crawl_by_shop_url





















if __name__ == "__main__":
    print(crawl_by_shop_url("https://shopee.vn/abbie.oh"))