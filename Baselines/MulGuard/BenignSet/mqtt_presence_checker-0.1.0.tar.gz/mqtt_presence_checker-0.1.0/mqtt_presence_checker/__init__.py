"""
DOcsting docu of mqq-presence-checker
"""