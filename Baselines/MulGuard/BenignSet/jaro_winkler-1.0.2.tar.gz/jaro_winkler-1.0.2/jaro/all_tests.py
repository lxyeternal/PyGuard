import compare_strcmp95
import compare_jaro
import jaro_tests

compare_strcmp95.test()
compare_jaro.test()
jaro_tests.test()