"""
Here are all training-related functions.
"""

from .run_test import run_test
from .run_tests import run_tests
