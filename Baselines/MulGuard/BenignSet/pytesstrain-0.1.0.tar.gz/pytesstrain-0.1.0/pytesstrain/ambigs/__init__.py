from .properties import (
    AmbiguityProperties,
    is_mandatory,
    dump_properties
)
from .extract import extract
