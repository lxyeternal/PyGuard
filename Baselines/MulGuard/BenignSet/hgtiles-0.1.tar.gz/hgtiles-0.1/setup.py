from setuptools import setup, find_packages

setup(
    name='hgtiles',
    version='0.1',
    description='Tile loading for higlass-server',
    author='Peter Kerpedjiev',
    author_email='pkerpedjiev@gmail.com',
    url='',
    packages=['hgtiles'],
)
