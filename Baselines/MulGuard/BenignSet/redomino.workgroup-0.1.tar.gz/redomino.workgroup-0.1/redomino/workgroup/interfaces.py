from zope.interface import Interface

class IWorkgroup(Interface):
    """ Marker interface for workgroupish folders """

class IWorkgroupLayer(Interface):
    """ IWorkgroup Layer """
