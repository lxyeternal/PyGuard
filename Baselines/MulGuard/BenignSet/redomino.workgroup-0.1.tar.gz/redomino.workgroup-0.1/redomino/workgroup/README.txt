==================
redomino.workgroup
==================

redomino.workgroup is a policy product for Plone. It will install automatically all his dependencies.

redomino.workgroup is based on membrane/remember and you'll be able to create easily workgroup sections and restricted
areas with local Members and with local search capabilities.
redomino.workgroup doesn't introduce new folderish content types (you can enable or disable each existing plone folders).

For more info, questions and support, please see the home page of the project:
http://www.redomino.com/it/labs/progetti/redomino-workgroup

============
INSTALLATION
============

redomino.workgroup installs automatically all dependencies.

============
REQUIREMENTS
============
Tested and developed against:
- Plone 3.0.5
- membrane
- remember

=======
CREDITS
=======
Main authors:
-Davide Moro (davide.moro@redomino.com)
-Fabrizio Reale (fabrizio.reale@redomino.com)

