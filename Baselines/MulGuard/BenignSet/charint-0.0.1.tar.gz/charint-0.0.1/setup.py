from setuptools import setup

setup(
    name='charint',
    version='0.0.1',
    install_requires=[],
    packages=['charint'],
    extras_require={},
    entry_points={}
)
