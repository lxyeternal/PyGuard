# dsnd_distributions_yh - Readme 

This is a test project for Gaussian and Binomial distributions.