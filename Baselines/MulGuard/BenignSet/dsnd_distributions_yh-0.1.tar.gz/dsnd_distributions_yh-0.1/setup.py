from setuptools import setup

setup(name='dsnd_distributions_yh',
      version='0.1',
      description='Gaussian and Binomial distributions',
      packages=['dsnd_distributions_yh'],
      zip_safe=False)
