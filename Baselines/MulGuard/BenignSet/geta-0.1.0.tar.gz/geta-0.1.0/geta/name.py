from enum import Enum, auto
import names


def first_name():
    return names.get_first_name()


def last_name():
    return names.get_last_name()


def full_name():
    return names.get_full_name()
