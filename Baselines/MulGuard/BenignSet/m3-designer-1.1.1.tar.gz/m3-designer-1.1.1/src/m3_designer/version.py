#coding:utf-8

__version__ = '1.1'
__appname__ = u'IDE платформы М3'

__require__ = {
  'm3': '1.0',
  'rope':'0.9.3'
}
