Дизайнер
===============================

Contents:

.. toctree::
   :maxdepth: 2

   architecture.rst
   components.rst
   todo.rst

Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`

