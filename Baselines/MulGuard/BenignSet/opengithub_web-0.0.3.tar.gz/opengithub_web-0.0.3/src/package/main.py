import webbrowser

url = 'https://github.com'
webbrowser.open