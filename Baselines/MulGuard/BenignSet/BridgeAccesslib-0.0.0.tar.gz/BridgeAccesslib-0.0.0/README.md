# Commlib for DeepDetection FPGA 
## Introduction
Allow the communication with deepDetection FPGA.
## Technologies
<ul>
  <li>Python</li>
</ul>

