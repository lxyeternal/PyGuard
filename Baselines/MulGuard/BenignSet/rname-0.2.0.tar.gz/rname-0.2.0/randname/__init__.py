# __init__.py
from randname.randname import *

__title__ = 'randname'
__version__ = "0.1.1"
__author__ = 'Adam Walkiewicz'
__license__ = 'MIT'

