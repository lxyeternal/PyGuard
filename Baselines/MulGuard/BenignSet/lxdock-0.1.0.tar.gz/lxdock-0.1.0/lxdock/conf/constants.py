ALLOWED_FILENAMES = [
    '.lxdock.yml',
    '.lxdock.yaml',
    'lxdock.yml',
    'lxdock.yaml',
    '.nomad.yml',
    '.nomad.yaml',
    'nomad.yml',
    'nomad.yaml',
]
