# Ensure all fixtures are discovered by py.test.
from lxdock.test import *  # noqa
