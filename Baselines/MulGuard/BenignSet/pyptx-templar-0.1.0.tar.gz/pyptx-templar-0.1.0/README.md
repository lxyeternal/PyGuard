# pyptx-templar
Easily fill PowerPoint templates with Python
