#!/usr/bin/env python

from distutils.core import setup

setup(name='py2g_utils',
      version='1.0.0',
      description='Some python utilities',
      author='Yannick Habecker',
      author_email='dev@y2g.de',
      url='https://github.com/habecker/py2g-utils',
      packages=['py2g_utils'],
     )
