# Some Python utils

``python -m samples.metrics``
``python -m samples.parameters --except_types '[1, 2, 3, 4]'``