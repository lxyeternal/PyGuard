from setuptools import setup

setup(
    name='Scenario_Library',
    version='1.0.0',
    description='A simple Python library',
    author='Sina Sohrab',
    author_email='sinasohrab84@gmail.com',
    packages=[''],
)
