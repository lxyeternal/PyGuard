""" init """
from .delstats import DelStats

__author__ = 'GrindSa'
__version__ = '0.0.1'