import logging
logger = logging.getLogger('collective.elasticsearch')


def initialize(context):
    pass
