"""Plugin to supply Kicad with metadata."""
