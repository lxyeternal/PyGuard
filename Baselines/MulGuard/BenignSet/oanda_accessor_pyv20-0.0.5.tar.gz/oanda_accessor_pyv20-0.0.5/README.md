# oanda_accessor_pyv20
This app lets you easily load candle data of Foreign Currency from Oanda API.

## Dependencies

You have to setup followging packages or modules on your host machine.

- docker
- docker compose

## Setup development environment

```bash
$ docker compose build
$ docker compose run package_base bash

# Run unit test
/opt# pipenv run pytest
```
