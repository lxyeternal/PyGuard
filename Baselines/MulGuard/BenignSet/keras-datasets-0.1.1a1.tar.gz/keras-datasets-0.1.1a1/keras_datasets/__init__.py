#!/usr/bin/env python
# -*- coding: utf-8 -*-

__version__ = '0.1.1a1'
VERSION = tuple(__version__.split('.'))
