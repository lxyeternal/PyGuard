#!/usr/bin/env python
# -*- coding: utf-8 -*-

class ImageDataset():
    def download_dataset(self, path):
        return True