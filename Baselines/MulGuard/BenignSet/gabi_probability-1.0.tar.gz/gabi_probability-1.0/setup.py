from setuptools import setup

setup(name='gabi_probability',
      version='1.0',
      description='Gaussian and Binomial distributions',
      packages=['gabi_probability'],
      author="Sparsh Garg",
      author_email="sparsh.garg2019@outlook.com",
      zip_safe=False)
