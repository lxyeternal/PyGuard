import pagidantic


def test_version() -> None:
    assert pagidantic.__version__ == "1.0.0"
