"""
Utility types to hold weatherapi information.
"""

from .raw import *
from .data_point import *
