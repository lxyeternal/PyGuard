

class KeycloakOpenIdProfileNotFound(Exception):
    pass


class TokensExpired(Exception):
    pass
