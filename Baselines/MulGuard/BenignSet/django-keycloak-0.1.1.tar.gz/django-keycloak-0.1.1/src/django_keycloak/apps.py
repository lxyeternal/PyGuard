from django.apps.config import AppConfig


class KeycloakAppConfig(AppConfig):
    name = 'django_keycloak'
    verbose_name = 'Keycloak'
