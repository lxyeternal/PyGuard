.. QuickClus documentation master file, created by
   sphinx-quickstart on Wed Mar 16 22:13:29 2022.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

Welcome to QuickClus's documentation!
=====================================

.. toctree::
   :maxdepth: 2
   :caption: Python API:

   source/api/quickclus



Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`
