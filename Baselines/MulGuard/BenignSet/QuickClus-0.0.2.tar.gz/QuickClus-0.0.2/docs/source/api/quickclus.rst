==============
QuickClus
==============

.. currentmodule:: quickclus.QuickClus

.. Don't include inherited members to keep the doc short
.. autoclass:: quickclus.QuickClus
    :members: