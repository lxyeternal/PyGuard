def err(txt):
	raise Exception(txt)