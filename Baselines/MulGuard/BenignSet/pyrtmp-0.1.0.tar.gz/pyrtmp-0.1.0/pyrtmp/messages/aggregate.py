from pyrtmp.messages import Chunk


class AggregateMessage(Chunk):
    pass
