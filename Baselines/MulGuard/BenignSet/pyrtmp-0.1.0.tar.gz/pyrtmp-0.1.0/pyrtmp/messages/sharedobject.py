from pyrtmp.messages import Chunk


class SharedObjectMessage(Chunk):
    pass

