"""Add support for MongoDB backups on monsoon.
"""

from .mongo import MongoBackup
