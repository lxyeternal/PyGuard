# cli.py: command line interface to grok

def main():
    print("grok build 0.0.1 (Dec-13-2022, copyright (c) 2022 Microsoft)")

if __name__ == "__main__":
    main()