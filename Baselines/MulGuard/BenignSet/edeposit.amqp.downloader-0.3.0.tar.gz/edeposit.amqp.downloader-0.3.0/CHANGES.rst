Changelog
=========

0.3.0
-----
    - Connected to AMQP.

0.2.0
-----
    - First almost working version.
    - ``reactToAMQPMessage()`` parameters modified.

0.1.0
-----
    - Project created.