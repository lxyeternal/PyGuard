Introduction
============

.. image:: https://badge.fury.io/py/edeposit.amqp.downloader.png
    :target: http://badge.fury.io/py/edeposit.amqp.downloader

.. image:: https://pypip.in/d/edeposit.amqp.downloader/badge.png
        :target: https://crate.io/packages/edeposit.amqp.downloader?version=latest

Download worker for the Edeposit project.

Documentation
-------------

Full module documentation and description can be found at Read the Docs:

- http://edeposit-amqp-downloader.rtfd.org
