pyLEDSign – A LED message board library for Python
==================================================

License
-------
This program is licensed under the AGPLv3. See the `LICENSE` file for more information.

Installation
------------
You can easily install pyLEDSign using the Python Package Index. Just type:

	sudo pip install pyledsign

To use it in your code, just `import ledsign`.