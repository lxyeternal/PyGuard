from setuptools import setup

setup(
    name='lgbtq',
    version='1.1.2',
    description='LGBTQ+ Expander',
    long_description='Example:\n\nbtq(\'_l = +fr\').qfy()',
    packages=['lgbtq']
    )
    
