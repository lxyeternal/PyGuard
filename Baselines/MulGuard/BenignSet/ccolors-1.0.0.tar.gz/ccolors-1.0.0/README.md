```python
from ccolors import *

print(R+"Hello World")
print(R+BW+"Hello Developer!")
```