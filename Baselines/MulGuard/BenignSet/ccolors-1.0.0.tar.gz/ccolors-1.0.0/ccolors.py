from colorama import *
R = Fore.RED
G = Fore.GREEN
B = Fore.BLUE
C = Fore.CYAN
W = Fore.WHITE
M = Fore.MAGENTA
RESET = Fore.RESET
BR = Back.RED
BG = Back.GREEN
BB = Back.BLUE
BC = Back.CYAN
BW = Back.WHITE
BM = Back.MAGENTA
BRESET = Back.RESET