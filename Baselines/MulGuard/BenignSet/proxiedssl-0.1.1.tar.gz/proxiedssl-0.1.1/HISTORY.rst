0.1.1 (2012/01/05)
------------------

* Added debug logging output for all possibilities

0.1 (2011/04/18)
----------------

* Initial code
