API wrapper for [princess connect re:dive(tw server)](http://www.princessconnect.so-net.tw/)

originated from [cc004/pcrjjc2](https://github.com/cc004/pcrjjc2)
