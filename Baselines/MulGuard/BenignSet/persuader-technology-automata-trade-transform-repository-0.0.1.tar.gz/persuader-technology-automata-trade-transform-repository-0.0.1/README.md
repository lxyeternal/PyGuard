# Automata Trade Transform Repository

## Packaging
`python3 -m build`

