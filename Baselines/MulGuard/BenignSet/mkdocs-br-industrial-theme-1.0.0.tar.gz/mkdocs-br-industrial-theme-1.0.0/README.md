# B&R Industrial Automation Theme

This is a base theme for use with MkDocs in the style of B&R Industrial Automation's documentation. You can see the style in action with this documentation. 

Example of documentation can be found here: [Example](https://brcclark.github.io/)

```
pip install mkdocs-br-industrial-theme
```

