A REST interface from Python.

This is just a work in progress and is not yet useable.
