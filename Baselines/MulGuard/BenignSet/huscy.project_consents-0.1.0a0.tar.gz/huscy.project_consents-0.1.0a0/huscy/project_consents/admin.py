from django.contrib import admin

from .models import ProjectConsent, ProjectConsentFile


admin.site.register(ProjectConsent)
admin.site.register(ProjectConsentFile)
