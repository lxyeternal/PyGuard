# PyROQ

This software can be used to generate reduced basis and ROQ data for gravitational wave waveforms. 
