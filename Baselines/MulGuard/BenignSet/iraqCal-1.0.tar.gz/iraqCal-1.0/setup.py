import setuptools

setuptools.setup(
	name = 'iraqCal',
	version = '1.0',
	author = 'slour',
	description = 'simple calculator func is cul()',
	packages= setuptools.find_packages(),
	classifiers=[
	"Programming Language :: Python :: 3",
	"Operating System :: OS Independent",
	"License :: OSI Approved :: MIT License"
	]
)