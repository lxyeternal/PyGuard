from setuptools import setup

setup(name='Gaus_Bi_dis_vis',
      version='0.1.1',
      description='Gaussian and binomial distributions',
      packages=['Gaus_Bi_dis_vis'],
      author = "Rahul Powar",
      author_email = "rahulpower2012@gmail.com",
      zip_safe=False)