=====
Usage
=====

To use pyehik in a project::

    import pyehik
