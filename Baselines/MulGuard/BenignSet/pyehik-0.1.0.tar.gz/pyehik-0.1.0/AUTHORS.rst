=======
Credits
=======

Development Lead
----------------

* Jovany Leandro G.C <bit4bit@riseup.net>

Contributors
------------

None yet. Why not be the first?
