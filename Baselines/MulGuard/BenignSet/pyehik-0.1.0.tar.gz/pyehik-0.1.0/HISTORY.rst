=======
History
=======

0.1.0 (2019-07-09)
------------------

* First release on PyPI.
