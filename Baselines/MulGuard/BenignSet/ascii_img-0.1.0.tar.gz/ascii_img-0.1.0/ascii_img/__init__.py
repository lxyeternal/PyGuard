name = "ascii_img"
