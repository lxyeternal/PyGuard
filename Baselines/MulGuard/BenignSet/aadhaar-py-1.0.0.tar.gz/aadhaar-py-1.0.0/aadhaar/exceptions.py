class NumberOutOfRangeException(Exception):

    pass


class MalformedIntegerReceived(Exception):

    pass


class EmptyArchiveException(Exception):

    pass


class NoXMLFileFound(Exception):

    pass
