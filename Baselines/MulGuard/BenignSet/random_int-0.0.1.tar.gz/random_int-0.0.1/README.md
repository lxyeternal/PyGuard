# fakername
Get a random number

# 安装
pip install random_int

# 准备工作
随机获取一个数字