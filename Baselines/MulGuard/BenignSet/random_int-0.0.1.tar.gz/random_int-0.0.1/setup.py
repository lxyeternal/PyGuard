from setuptools import setup, find_packages

setup(
    name="random_int",
    version="0.0.1",
    author="Rtt.01_-v",
    author_email="2835836810@qq.com",
    description="Get a random number",

    # 项目主页
    # url="https://github.com/sunjian-github/ezface",
    # 你要安装的包，通过 setuptools.find_packages 找到当前目录下有哪些包
    packages=find_packages(),
)

