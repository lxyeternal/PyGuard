# e_ok_api

Unofficial API wrapper for Liantis e-OK

* Free software: GNU General Public License v3

