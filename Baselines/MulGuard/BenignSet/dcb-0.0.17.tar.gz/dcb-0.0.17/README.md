dcb: A Docker container image family building CLI
=================================================

# Upstream Image Family
* upstream-registry.com/upstream-groupname/upstream-appname:platform

# Target Image 
* target-registry.com/target-groupname/target-appname:platform
