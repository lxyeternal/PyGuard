# HESL STUDIO - Official HESL lang IDE

Please join to [LexChen Linux Community](https://t.me/LexChen_Chat) chat

---


## Installing Hesl Studio

```sh
pip install HeslStudio
```
