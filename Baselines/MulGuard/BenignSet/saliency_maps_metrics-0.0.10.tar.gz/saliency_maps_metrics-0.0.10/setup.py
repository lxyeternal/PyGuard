
from setuptools import setup

setup(
    packages=['saliency_maps_metrics']
)
