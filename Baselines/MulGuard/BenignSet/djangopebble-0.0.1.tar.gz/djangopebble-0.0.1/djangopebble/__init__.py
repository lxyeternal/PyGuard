from warnings import warn
from .pure import *


def version():
    """
    * 2022/10/14
    - [pypi_url](https://pypi.org/project/djangopebble/)
    """
    v = "0.0.1"     # 当前: 0.0.1
    return v
