# bddjango

## 安装  

```
pip install bddjango
```


