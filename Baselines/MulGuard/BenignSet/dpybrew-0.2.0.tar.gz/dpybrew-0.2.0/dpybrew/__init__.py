"""Top-level package for dpybrew."""

__author__ = """sizumita"""
__email__ = 'None'
__version__ = '0.2.0'
