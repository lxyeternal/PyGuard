=======
dpybrew
=======


.. image:: https://img.shields.io/pypi/v/dpybrew.svg
        :target: https://pypi.python.org/pypi/dpybrew

.. image:: https://img.shields.io/travis/sizumita/dpybrew.svg
        :target: https://travis-ci.com/sizumita/dpybrew

.. image:: https://readthedocs.org/projects/dpybrew/badge/?version=latest
        :target: https://dpybrew.readthedocs.io/en/latest/?badge=latest
        :alt: Documentation Status




A discord.py extension/service manager


* Free software: MIT license
* Documentation: https://dpybrew.readthedocs.io.


Features
--------

* TODO

Credits
-------

This package was created with Cookiecutter_ and the `audreyr/cookiecutter-pypackage`_ project template.

.. _Cookiecutter: https://github.com/audreyr/cookiecutter
.. _`audreyr/cookiecutter-pypackage`: https://github.com/audreyr/cookiecutter-pypackage
