=======
History
=======

0.1.0 (2020-03-29)
------------------

* First release on PyPI.
