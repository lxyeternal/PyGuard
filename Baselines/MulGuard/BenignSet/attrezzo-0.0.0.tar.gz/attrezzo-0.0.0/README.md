Test doubles for Python
