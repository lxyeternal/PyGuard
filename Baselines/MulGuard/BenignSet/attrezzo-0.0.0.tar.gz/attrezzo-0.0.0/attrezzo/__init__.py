"Test doubles for Python"
