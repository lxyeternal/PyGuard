from setuptools import setup

setup(name='EasyStats',
      version='0.1',
      description='Gaussian and Binomial distributions',
      packages=['EasyStats'],
      author='Rucha Yagnik',
      zip_safe=False)
