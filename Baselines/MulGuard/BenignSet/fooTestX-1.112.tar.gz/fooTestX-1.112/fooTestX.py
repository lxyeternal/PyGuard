def hello():
    print "Hello Wold!"
