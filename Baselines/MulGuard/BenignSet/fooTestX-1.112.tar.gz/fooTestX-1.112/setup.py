from distutils.core import setup
setup(name='fooTestX',
      version='1.112',
      url='www.quadlane.com/fooTestX',
      author='Regimantas Baublys',
      author_email='regtech0@gmail.com',
      license='GPL3',
      description='UNKNOWN',
      py_modules=['fooTestX'],
      )
