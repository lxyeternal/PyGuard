#!/usr/bin/env python

from setuptools import setup

setup(name='ezThread',
      version='0.0.1',
      description='Threading in Python made ez',
      author='Vilsol',
      author_email='me@vil.so',
      url='https://github.com/Vilsol/ezThread',
      packages=[
          "ezthread"
      ],
      )
