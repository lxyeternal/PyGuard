# PasSQL ORM - *really simple mapping for PYTHON*
#### © 2021 Vladislav Mironov

### Description

PasSQL is a library that provides simple ORM tools for executing template SQL queries from Python 3.7
<br> 
using other database interface libraries (e.g. asyncpg or PyMySQL).
