#define ZERO 0
# define ONE 1

int zero();
int one();
