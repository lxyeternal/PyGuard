int zero() {
    return 0;
}

int one() {
    return 1;
}
