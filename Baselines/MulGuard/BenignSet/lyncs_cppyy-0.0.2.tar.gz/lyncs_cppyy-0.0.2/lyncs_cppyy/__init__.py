__version__ = "0.0.2"

from cppyy import nullptr, cppdef, gbl
from .lib import *
from . import ll
