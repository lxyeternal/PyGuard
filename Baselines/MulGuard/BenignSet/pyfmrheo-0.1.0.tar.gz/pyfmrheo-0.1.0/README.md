# pyafmrheo
Package for performing afm data analysis.
