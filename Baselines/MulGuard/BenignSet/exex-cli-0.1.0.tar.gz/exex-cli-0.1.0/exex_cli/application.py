from cleo import Application as CleoApplication

application = CleoApplication(name="exex-cli", version="0.1.0")
