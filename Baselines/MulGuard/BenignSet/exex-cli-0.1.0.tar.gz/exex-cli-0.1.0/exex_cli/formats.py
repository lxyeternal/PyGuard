CSV = "csv"
JSON = "json"
TABLE = "table"
TEXT = "text"
