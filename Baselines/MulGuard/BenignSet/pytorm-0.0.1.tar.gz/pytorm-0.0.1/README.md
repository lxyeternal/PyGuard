# PytORM

[![Release](https://img.shields.io/github/release/flaiers/pytorm.svg)](https://github.com/flaiers/pytorm/releases/latest)
[![Licence](https://img.shields.io/github/license/flaiers/pytorm)](https://github.com/flaiers/pytorm/blob/main/LICENSE)


## Introduction

Implementation of repository pattern over SQLAlchemy

## Installation

```shell
poetry add pytorm
```

```shell
pip install pytorm
```
