SERPRO_API_GATEWAY = "https://apigateway.serpro.gov.br"
SERPRO_PUBLIC_JWKS = "https://d-biodata.estaleiro.serpro.gov.br/api/v1/jwks"
AUTHENTICATE_ENDPOINT = "/token"
# biodata endpoints
BIODATA_TOKEN_ENDPOINT = "/biodata/v1/token"
JWT_AUDIENCE = '35284162000183'
