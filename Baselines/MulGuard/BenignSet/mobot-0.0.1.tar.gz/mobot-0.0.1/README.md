<p align="center">
  <img src="./media/mobot_banner.png" alt="Mobot Banner"/>
</p>

[![Open Source Love svg1](https://badges.frapsoft.com/os/v1/open-source.svg?v=103)](https://github.com/ellerbrock/open-source-badges/)
[![MIT license](https://img.shields.io/badge/License-MIT-blue.svg)](https://lbesson.mit-license.org/)

Mobot is a mobile robot which uses **Smartphone** as its sensor and **Laptop** as its brain.

Visit [Project Website](http://mobotx.github.io/) to get started :sunglasses:.
