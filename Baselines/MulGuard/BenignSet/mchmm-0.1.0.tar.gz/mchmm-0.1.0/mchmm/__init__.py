__version__ = "0.1.0"

from mchmm._hmm import HiddenMarkovModel
from mchmm._mc import MarkovChain
