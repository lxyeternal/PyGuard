#!/usr/bin/env python3

import warnings

warnings.warn(f"Please make sure to run pip with --extra-index-url pointing to the internal repo")
