[![banner](https://raw.githubusercontent.com/oceanprotocol/art/master/github/repo-banner%402x.png)](https://oceanprotocol.com)

# Plecos

> Help publishers validate metadata
> [oceanprotocol.com](https://oceanprotocol.com)


___"🌊 Plecos are fish which mostly eat green surface algae and are excellent window cleaners."___


**🐲🦑 THERE BE DRAGONS AND SQUIDS. This is in alpha state and you can expect running into problems. If you run into them, please open up [a new issue](https://github.com/oceanprotocol/brizo/issues). 🦑🐲**

---

## Table of Contents

- [Features](#features)
- [Get Started](#getstarted)
- [License](#license) 

---

## Features 

Plecos contains functions that validate metadata formatted as json according to OEP-8. 
You can validate a single json containg metadata or a list with with multiple links 
which contain metadata. 

## Get Started 

__TBD__

## License

```text
Copyright 2018 Ocean Protocol Foundation Ltd.

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

   http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
```

