"""Operatpr table."""
# Global operator table.
from numbers import Number
from typing import Optional, List
from .autograd import NDArray
from .autograd import Op, Tensor, Value, TensorOp
from .autograd import TensorTuple, TensorTupleOp
import numpy

import numpy as array_api


class MakeTensorTuple(TensorTupleOp):

    def compute(self, *args) -> tuple:
        return tuple(args)

    def gradient(self, out_grad, node):
        assert isinstance(out_grad, TensorTuple)
        return tuple(*[out_grad[i] for i in range(len(out_grad))])


def make_tuple(*args):
    return MakeTensorTuple()(*args)


class TupleGetItem(TensorOp):

    def __init__(self, index):
        self.index = index

    def __call__(self, a: TensorTuple, fold_const=True) -> Value:
        assert isinstance(a, TensorTuple)
        # constant folding
        if fold_const and isinstance(a.op, MakeTensorTuple):
            return a.inputs[self.index]
        return Tensor.make_from_op(self, [a])

    def compute(self, a):
        return a[self.index]

    def gradient(self, out_grad, node):
        index = self.index
        in_grad = []
        for i, value in enumerate(node.inputs[0]):
            if i != index:
                in_grad.append(zeros_like(value))
            else:
                in_grad.append(out_grad)
        return MakeTensorTuple()(*in_grad)


def tuple_get_item(value, index):
    return TupleGetItem(index)(value)


class FusedAddScalars(TensorTupleOp):

    def __init__(self, c0: float, c1: float):
        self.c0 = c0
        self.c1 = c1

    def compute(self, a):
        return a + self.c0, a + self.c1

    def gradient(self, out_grad, node):
        return out_grad[0] + out_grad[1]


def fused_add_scalars(x, c0, c1):
    return FusedAddScalars(c0, c1)(x)


class EWiseAdd(TensorOp):

    def compute(self, a: NDArray, b: NDArray):
        return a + b

    def gradient(self, out_grad: Tensor, node: Tensor):
        return out_grad, out_grad


def add(a, b):
    return EWiseAdd()(a, b)


class AddScalar(TensorOp):

    def __init__(self, scalar):
        self.scalar = scalar

    def compute(self, a: NDArray):
        return a + self.scalar

    def gradient(self, out_grad: Tensor, node: Tensor):
        return out_grad


def add_scalar(a, scalar):
    return AddScalar(scalar)(a)


class EWiseMul(TensorOp):

    def compute(self, a: NDArray, b: NDArray):
        return a * b

    def gradient(self, out_grad: Tensor, node: Tensor):
        lhs, rhs = node.inputs
        return out_grad * rhs, out_grad * lhs


def multiply(a, b):
    return EWiseMul()(a, b)


class MulScalar(TensorOp):

    def __init__(self, scalar):
        self.scalar = scalar

    def compute(self, a: NDArray):
        return a * self.scalar

    def gradient(self, out_grad: Tensor, node: Tensor):
        return (out_grad * self.scalar, )


def mul_scalar(a, scalar):
    return MulScalar(scalar)(a)


class PowerScalar(TensorOp):
    """Op raise a tensor to an (integer) power."""

    def __init__(self, scalar: int):
        self.scalar = scalar

    def compute(self, a: NDArray) -> NDArray:

        return array_api.power(a, self.scalar)

    def gradient(self, out_grad, node):

        input_a = node.inputs[0]
        return out_grad * self.scalar * power_scalar(input_a, self.scalar - 1)


def power_scalar(a, scalar):
    return PowerScalar(scalar)(a)


class EWiseDiv(TensorOp):
    """Op to element-wise divide two nodes."""

    def compute(self, a, b):

        return a / b

    def gradient(self, out_grad, node):

        a, b = node.inputs
        return (out_grad / b, -out_grad * a / b**2)


def divide(a, b):
    return EWiseDiv()(a, b)


class DivScalar(TensorOp):

    def __init__(self, scalar):
        self.scalar = scalar

    def compute(self, a):

        return a / self.scalar

    def gradient(self, out_grad, node):

        return out_grad / self.scalar


def divide_scalar(a, scalar):
    return DivScalar(scalar)(a)


class Transpose(TensorOp):

    def __init__(self, axes: Optional[tuple] = None):
        self.axes = axes

    def compute(self, a):

        if self.axes == None:
            return array_api.swapaxes(a, -1, -2)
        return array_api.swapaxes(a, self.axes[0], self.axes[1])

    def gradient(self, out_grad, node):

        return transpose(out_grad, self.axes)


def transpose(a, axes=None):
    return Transpose(axes)(a)


class Reshape(TensorOp):

    def __init__(self, shape):
        self.shape = shape

    def compute(self, a):

        return a.reshape(self.shape)

    def gradient(self, out_grad, node):

        return reshape(out_grad, node.inputs[0].shape)


def reshape(a, shape):
    return Reshape(shape)(a)


class BroadcastTo(TensorOp):

    def __init__(self, shape):
        self.shape = shape

    def compute(self, a):
        return array_api.broadcast_to(a, self.shape)

    def gradient(self, out_grad, node):

        # a:(2,3) -> (5,2,3)
        # 1.(2,3) -> (1,2,3)
        # 2.(1,2,3) -> (5,2,3)
        a_shape = node.inputs[0].shape
        shape = [1] * (len(self.shape) - len(a_shape)) + list(a_shape)
        dele_shape = []
        for i in range(len(self.shape)):
            if self.shape[i] != shape[i]:
                dele_shape.append(i)
        return reshape(summation(out_grad, tuple(dele_shape)), a_shape)


def broadcast_to(a, shape):
    return BroadcastTo(shape)(a)


class Summation(TensorOp):

    def __init__(self, axes: Optional[tuple] = None):
        self.axes = axes

    def compute(self, a):

        return a.sum(axis=self.axes)

    def gradient(self, out_grad: Tensor, node: Tensor):

        # a = node.inputs[0]
        # old_shape = out_grad.shape
        # new_shape = [1] * len(a.shape)
        # j = 0
        # for i in range(len(a.shape)):
        #   if j < len(old_shape) and old_shape[j] == a.shape[i]:
        #     new_shape[i] = a.shape[i]
        #     j += 1
        # return broadcast_to(reshape(out_grad, tuple(new_shape)), a.shape)

        shape = node.inputs[0].shape
        new_shape = [1] * len(shape)
        if self.axes:
            s = set(self.axes)
        else:
            s = set(range(len(shape)))
        j = 0
        for i in range(len(shape)):
            if i not in s:
                new_shape[i] = out_grad.shape[j]
                j += 1
        result = broadcast_to(reshape(out_grad, tuple(new_shape)), shape)
        return result


def summation(a, axes=None):
    return Summation(axes)(a)


class MatMul(TensorOp):

    def compute(self, a, b):

        return array_api.matmul(a, b)

    def gradient(self, out_grad, node):

        a, b = node.inputs
        grad_a = matmul(out_grad, transpose(b))
        grad_b = matmul(transpose(a), out_grad)
        if len(grad_a.shape) != len(a.shape):
            grad_a = summation(grad_a,
                               tuple(range(len(grad_a.shape) - len(a.shape))))
        if len(grad_b.shape) != len(b.shape):
            grad_b = summation(grad_b,
                               tuple(range(len(grad_b.shape) - len(b.shape))))
        return (grad_a, grad_b)


def matmul(a, b):
    return MatMul()(a, b)


class Negate(TensorOp):

    def compute(self, a):
        return array_api.negative(a)

    def gradient(self, out_grad, node):
        return mul_scalar(out_grad, -1)


def negate(a):
    return Negate()(a)


class Log(TensorOp):

    def compute(self, a):
        return array_api.log(a)

    def gradient(self, out_grad, node):
        return out_grad / node.inputs[0]


def log(a):
    return Log()(a)


class Exp(TensorOp):

    def compute(self, a):
        return array_api.exp(a)

    def gradient(self, out_grad, node):
        return out_grad * (exp(node.inputs[0]))


def exp(a):
    return Exp()(a)


class ReLU(TensorOp):

    def compute(self, a):

        return array_api.maximum(a, 0)

    def gradient(self, out_grad, node):

        a = node.inputs[0].realize_cached_data()
        return out_grad * Tensor(a > 0)


def relu(a):
    return ReLU()(a)


class LogSumExp(TensorOp):

    def __init__(self, axes: Optional[tuple] = None):
        self.axes = axes

    def compute(self, Z):

        maxz = array_api.max(Z, axis=self.axes, keepdims=True)
        expz = array_api.exp(Z - maxz)
        return array_api.log(array_api.sum(
            expz, axis=self.axes)) + array_api.max(
                Z, axis=self.axes, keepdims=False)

    def gradient(self, out_grad, node):

        Z = node.inputs[0]
        if self.axes:
            shape = [1] * len(Z.shape)
            j = 0
            for i in range(len(shape)):
                if i not in self.axes:
                    shape[i] = node.shape[j]
                    j += 1
            node_new = node.reshape(shape)
            grad_new = out_grad.reshape(shape)
        else:
            node_new = node
            grad_new = out_grad
        return grad_new * exp(Z - node_new)


def logsumexp(a, axes=None):
    return LogSumExp(axes=axes)(a)
