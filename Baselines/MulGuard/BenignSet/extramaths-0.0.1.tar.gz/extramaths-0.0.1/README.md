# extramaths
 A custom Python package that simplifies complex equations.
