default_app_config = "buybacks2.apps.BuybacksConfig"

__version__ = "0.2.0"
__title__ = "Buybacks2"
