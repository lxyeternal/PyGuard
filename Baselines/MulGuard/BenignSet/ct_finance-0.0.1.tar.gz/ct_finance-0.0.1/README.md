# docopt finance manager with sqlite backend
