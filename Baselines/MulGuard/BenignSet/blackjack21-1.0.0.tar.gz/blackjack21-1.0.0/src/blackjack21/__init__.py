"""
blackjack21
Documentation: https://github.com/rahul-nanwani/blackjack21/wiki
"""
from .table import Table

__title__ = "blackjack21"
__version__ = "1.0.0"
__author__ = "Rahul Nanwani"
__license__ = "MIT License"
