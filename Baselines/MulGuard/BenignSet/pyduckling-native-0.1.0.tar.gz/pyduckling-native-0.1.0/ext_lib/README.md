
# Building binaries for duckling-ffi
Please generate the shared library (`libducklingffi.so/dylib/dll`) produced after compilling [duckling-ffi](https://github.com/treble-ai/duckling-ffi) and put it in this folder.
