# duckling-ffi
Foreign Function Interface for Facebook's duckling library
