"""Command line interface for entelecheia"""

# Importing the libraries
from hyfi import hydra_main


def main() -> None:
    hydra_main()


if __name__ == "__main__":
    main()
