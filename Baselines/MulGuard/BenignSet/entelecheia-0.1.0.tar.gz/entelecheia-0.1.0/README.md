# ἐντελέχεια 【en.te.lé.kʰeː.a】
[![home-img]][home-url]
[![course-img]][course-url]
[![lecture-img]][lecture-url]
[![research-img]][research-url]
[![linkedin-img]][linkedin-url]

[home-img]: https://img.shields.io/badge/home-entelecheia.me-blue
[home-url]: https://entelecheia.me
[course-img]: https://img.shields.io/badge/course-entelecheia.ai-blue
[course-url]: https://course.entelecheia.ai
[lecture-img]: https://img.shields.io/badge/lecture-entelecheia.ai-blue
[lecture-url]: https://lecture.entelecheia.ai
[research-img]: https://img.shields.io/badge/research-entelecheia.ai-blue
[research-url]: https://research.entelecheia.ai
[linkedin-img]: https://img.shields.io/badge/LinkedIn-blue?logo=linkedin
[linkedin-url]: https://www.linkedin.com/in/entelecheia/

Coined by Aristotle from ἐντελής (entelḗs, “complete, full, accomplished”) + ἔχειν (ékhein, “have, hold”).

https://user-images.githubusercontent.com/1177283/224186183-4f1fe765-d2f9-4c37-8d7b-078bf9c879c6.mp4
