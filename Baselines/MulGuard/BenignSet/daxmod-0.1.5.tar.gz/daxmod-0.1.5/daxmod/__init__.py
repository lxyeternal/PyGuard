"""
daxmod

text classification module
"""

__version__ = "0.1.5"
