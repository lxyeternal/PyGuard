Hasher
======================================

A single code base to run various hashing algorithms against files, modeled on
the GNU md5sum program.