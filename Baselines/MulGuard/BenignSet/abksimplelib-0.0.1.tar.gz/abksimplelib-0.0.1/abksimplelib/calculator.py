class Calculator:
	def __init__(self, accurate=True):
		self.accurate = accurate

	def add_numbers(self, num1, num2):
		return num1 + num2

	def subtract_numbers(self, num1, num2):
		return num1 - num2

	def multiply_numbers(self, num1, num2):
		return num1 * num2

	def divide_numbers(self, num1, num2):
		return num1 / num2

