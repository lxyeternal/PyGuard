from setuptools import setup

setup(
	name='abksimplelib',
	version='0.0.1',
	description='A simple calculator',
	author='Andrew King',
	author_email='andrewking1597@gmail.com',
	url='',
	packages=['abksimplelib'])