## 概述

梅子行老师那里来的一个 `lightgbm` 自动建模的方法，配合 `scorecardpipeline` 一起使用非常方便，效果也非常可以，值得推荐

## lightgbm
![运行示例](./.assets/run.png)
