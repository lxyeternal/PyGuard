This is CruscoPoetry
