from warnings import warn

from talkylabs.reach.rest.api.ApiBase import ApiBase

class Api(ApiBase):
    pass
