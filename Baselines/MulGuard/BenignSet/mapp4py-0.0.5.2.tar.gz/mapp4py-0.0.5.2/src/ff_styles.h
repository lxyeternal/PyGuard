#include "ff_lj.h"
#include "ff_eam.h"

#include "ff_fs.h"
#include "ff_eam_dmd.h"

#include "ff_eam_func.h"

#ifdef POTFIT
#include "ff_eam_potfit.h"
#endif
