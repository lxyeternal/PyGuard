from .line_profiler import LineProfiler
from .profile import profile, profile_every, set_target_gpu, clear_global_line_profiler
