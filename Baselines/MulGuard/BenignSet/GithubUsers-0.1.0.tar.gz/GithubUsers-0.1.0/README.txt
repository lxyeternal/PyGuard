
create a config file in `/etc/github_users.conf` that looks like this:
```json
{
    "organization": "my-org",
    "github_token" : "token",
    "global_user" : "globalorguser",
    "team":"ssh-team"
}
```

