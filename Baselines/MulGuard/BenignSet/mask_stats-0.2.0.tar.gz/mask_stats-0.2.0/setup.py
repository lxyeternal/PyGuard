# -*- coding: utf-8 -*-

"""The setup script."""

from setuptools import find_packages, setup

setup()
