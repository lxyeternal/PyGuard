==========
Mask stats
==========


.. image:: https://img.shields.io/travis/yngvem/mask_stats.svg
        :target: https://travis-ci.org/yngvem/mask_stats

.. image:: https://readthedocs.org/projects/mask-stats/badge/?version=latest
        :target: https://mask-stats.readthedocs.io/en/latest/?badge=latest
        :alt: Documentation Status


Compute summary statistics between two binary masks.


* Free software: MIT license
* Documentation: https://mask-stats.readthedocs.io.


Features
--------

* TODO

Credits
-------

This package was created with Cookiecutter_ and the `audreyr/cookiecutter-pypackage`_ project template.

.. _Cookiecutter: https://github.com/audreyr/cookiecutter
.. _`audreyr/cookiecutter-pypackage`: https://github.com/audreyr/cookiecutter-pypackage
