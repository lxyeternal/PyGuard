# -*- coding: utf-8 -*-

__author__ = """Yngve Mardal Moe"""
__email__ = "yngve.m.moe@gmail.com"
__version__ = "__version__ = '0.2.0'"


from .mask_stats import *
