=====
Usage
=====

To use Mask stats in a project::

    import mask_stats
