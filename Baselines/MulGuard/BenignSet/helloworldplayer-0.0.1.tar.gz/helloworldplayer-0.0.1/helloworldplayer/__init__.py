"""
This is the package's documentation
"""