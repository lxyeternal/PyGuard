"""cubicweb-pyramid application package

Add the 'pyramid' command to cubicweb-ctl"
"""
