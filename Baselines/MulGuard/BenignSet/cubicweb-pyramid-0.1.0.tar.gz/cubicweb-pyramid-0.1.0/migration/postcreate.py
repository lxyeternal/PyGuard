# Check the CW versions and add the entity only if needed ?
add_entity_type('CWSession')
