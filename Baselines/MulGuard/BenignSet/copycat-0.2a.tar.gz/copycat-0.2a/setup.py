'''
Created on May 20, 2010

@author: felipe
'''

from distutils.core import setup

setup(name='copycat',
      version='0.2a',
      description='copycat - simple, transparent and non-intrusive python persistence',
      author='Felipe Cruz',
      author_email='felipecruz@loogica.net',
      url='http://copycat.loogica.net/',
      packages=['copycat'],
     )
