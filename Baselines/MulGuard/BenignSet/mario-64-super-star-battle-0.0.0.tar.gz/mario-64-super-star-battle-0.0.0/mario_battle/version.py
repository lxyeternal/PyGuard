"""Contains name, version, description."""

NAME = 'mario-64-super-star-battle'
VERSION = '0.0.0'
DESCRIPTION = "the ultimate competition between Mario 64 superstars"
