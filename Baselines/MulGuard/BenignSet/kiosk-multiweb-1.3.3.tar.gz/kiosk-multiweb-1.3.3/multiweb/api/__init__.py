

from .applications import MultiWebApplicationsEngine


class MultiWebApiEngine(MultiWebApplicationsEngine):
    pass
