=====
Usage
=====

To use EC2 Proxy in a project::

    import ec2_proxy
