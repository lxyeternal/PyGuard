=========
EC2 Proxy
=========


.. image:: https://img.shields.io/pypi/v/ec2_proxy.svg
        :target: https://pypi.python.org/pypi/ec2_proxy

.. image:: https://img.shields.io/travis/AG4lyf/ec2_proxy.svg
        :target: https://travis-ci.com/AG4lyf/ec2_proxy

.. image:: https://readthedocs.org/projects/ec2-proxy/badge/?version=latest
        :target: https://ec2-proxy.readthedocs.io/en/latest/?version=latest
        :alt: Documentation Status




This package provides ability to use amazon aws as proxy with everchanging IP.


* Free software: Apache Software License 2.0
* Documentation: https://ec2-proxy.readthedocs.io.


Features
--------

* TODO

Credits
-------

This package was created with Cookiecutter_ and the `audreyr/cookiecutter-pypackage`_ project template.

.. _Cookiecutter: https://github.com/audreyr/cookiecutter
.. _`audreyr/cookiecutter-pypackage`: https://github.com/audreyr/cookiecutter-pypackage
