#!/usr/bin/env python

"""Tests for `ec2_proxy` package."""


import unittest

from ec2_proxy import ec2_proxy


class TestEc2_proxy(unittest.TestCase):
    """Tests for `ec2_proxy` package."""

    def setUp(self):
        """Set up test fixtures, if any."""

    def tearDown(self):
        """Tear down test fixtures, if any."""

    def test_000_something(self):
        """Test something."""
