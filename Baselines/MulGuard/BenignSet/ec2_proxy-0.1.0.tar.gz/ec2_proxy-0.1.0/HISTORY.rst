=======
History
=======

0.1.0 (2023-06-02)
------------------

* First release on PyPI.
