"""Top-level package for Temp Proxy EC2."""

__author__ = """Suraj Bhari"""
__email__ = 'surajbhari159@gmail.com'
__version__ = '0.1.0'

from .temp_proxy_ec2 import TProxy
