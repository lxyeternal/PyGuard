from pck_thyagomota import mod

print(mod.add_one(5))