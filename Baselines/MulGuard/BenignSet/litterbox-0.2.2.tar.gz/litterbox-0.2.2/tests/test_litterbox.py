#!/usr/bin/env python
# -*- coding: utf-8 -*-

"""
test_litterbox
----------------------------------

Tests for `litterbox` module.
"""

import unittest

from litterbox import litterbox


class TestLitterbox(unittest.TestCase):

    def setUp(self):
        pass

    def test_something(self):
        pass

    def tearDown(self):
        pass

if __name__ == '__main__':
    unittest.main()
