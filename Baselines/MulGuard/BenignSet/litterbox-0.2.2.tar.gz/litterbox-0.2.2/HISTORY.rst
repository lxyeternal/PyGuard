.. :changelog:

History
-------


0.2.2 (2021-07-12)
________________________

* Moved ownership from xesscorp to devbisme.


0.2.1 (2016-09-07)
________________________

* Removed dependency on spi module (python-spi).


0.2.0 (2016-09-07)
________________________

* python-spi package was incorporated into litterbox and modified to increase transfer rates.
* Documentation moved to Github pages.


0.1.0 (2016-05-07)
________________________

* First release on PyPI.
