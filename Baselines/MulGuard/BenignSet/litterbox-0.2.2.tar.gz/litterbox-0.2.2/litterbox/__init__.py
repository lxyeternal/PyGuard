# -*- coding: utf-8 -*-

__author__ = 'Dave Vandenbout'
__email__ = 'devb@xess.com'
__version__ = '0.2.2'
