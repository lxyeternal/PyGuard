============
Installation
============

At the command line::

    $ easy_install litterbox

Or, if you have virtualenvwrapper installed::

    $ mkvirtualenv litterbox
    $ pip install litterbox
