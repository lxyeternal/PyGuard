from setuptools import setup

setup(name='redistribution',
      version='0.1',
      description='Gaussian distributions',
      packages=['redistribution'],
      zip_safe=False)
