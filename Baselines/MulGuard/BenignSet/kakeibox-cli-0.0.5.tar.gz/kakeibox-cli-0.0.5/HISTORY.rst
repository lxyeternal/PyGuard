=======
History
=======

0.1.0 (2019-08-28)
------------------

* First release on PyPI.
