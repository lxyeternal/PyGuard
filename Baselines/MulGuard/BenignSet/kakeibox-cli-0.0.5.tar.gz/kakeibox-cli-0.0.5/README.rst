===============================
kakeibox_cli
===============================


.. image:: https://img.shields.io/pypi/v/kakeibox_cli.svg
        :target: https://pypi.python.org/pypi/kakeibox-cli



A package description.


* Free software: GNU General Public License v3


Features
--------

* TODO

