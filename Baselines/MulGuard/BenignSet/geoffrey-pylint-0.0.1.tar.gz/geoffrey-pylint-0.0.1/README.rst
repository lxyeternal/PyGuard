============================
geoffrey-pylint
============================

.. image:: https://badge.fury.io/py/geoffrey-pylint.png
    :target: http://badge.fury.io/py/geoffrey-pylint
    
.. image:: https://travis-ci.org/GeoffreyCI/geoffrey-pylint.png?branch=master
        :target: https://travis-ci.org/GeoffreyCI/geoffrey-pylint

.. image:: https://pypip.in/d/geoffrey-pylint/badge.png
        :target: https://pypi.python.org/pypi/geoffrey-pylint


python code static checker

Geoffrey wrapper for pylint utility: http://www.pylint.org/

* Free software: GPLv3
* Documentation: http://geoffrey-pylint.readthedocs.org.


Configuration
-------------

To correctly use this plugin you must define the variable *pyflakes_path* in the plugin's section of your project


Features
--------

* TODO
