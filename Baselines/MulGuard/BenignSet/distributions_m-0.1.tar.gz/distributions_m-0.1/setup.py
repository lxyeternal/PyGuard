from setuptools import setup

setup(name='distributions_m',
      version='0.1',
      description='Distributions',
      packages=['distributions_m'],
      zip_safe=False)
