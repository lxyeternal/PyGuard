# AMQP-AIO

Wrapper around existing `aiormq` in an attempt to simplify the handling of 
all elements, bindings and connections.

