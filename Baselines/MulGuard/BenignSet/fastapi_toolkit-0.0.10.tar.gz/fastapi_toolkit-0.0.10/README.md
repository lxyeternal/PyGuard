# FastAPI Toolkit

## Includes

- async sqlalchemy
- manage.py commands
- ...


## How to start

```
pip install fastapi-toolkit
fastapi-toolkit startproject
cd <project_name>
python manage.py runserver
```