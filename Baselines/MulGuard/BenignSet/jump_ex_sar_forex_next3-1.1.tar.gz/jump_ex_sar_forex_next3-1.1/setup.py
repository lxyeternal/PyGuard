from setuptools import setup

setup (name='jump_ex_sar_forex_next3' ,
       version = '1.1' ,
       description = 'jump_ex_sar_forex_next3' ,
       author = 'omid' ,
       packages =['jump_ex_sar_forex_next3'] ,
       zip_safe = False
       )