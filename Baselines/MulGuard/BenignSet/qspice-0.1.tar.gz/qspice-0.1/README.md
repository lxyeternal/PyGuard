# README.md #

## COMMING SOON ##

QSPICE is a toolchain of python utilities design to interact specifically with QSPICE.

This project is derived from the PyLTspice library by its own author, wiht the intentt of awarding QSPICE users same functionality as is done by PyLTSpice. The difference is that all defaults will point to QSPICE.

## How to Install ##

`pip install qspice`
