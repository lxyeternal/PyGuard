import imp
from .pystaticconfig import BaseConfig
