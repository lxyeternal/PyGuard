# PyStaticConfig
 JSON config with static class in python  
