import setuptools


setuptools.setup(
    name="dennis-systems-auth",
    version="0.0.2",
    author="Denis Oleshko",
    author_email="dennis.oleshko@gmail.com",
    description="Authorization model",
    long_description='All about authorization',
    long_description_content_type="text/markdown",
    setup_requires=['wheel'],
    url="https://github.com/pypa/sampleproject",
    packages=setuptools.find_packages(),
    classifiers=[
        "Programming Language :: Python :: 3",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
    ],
)