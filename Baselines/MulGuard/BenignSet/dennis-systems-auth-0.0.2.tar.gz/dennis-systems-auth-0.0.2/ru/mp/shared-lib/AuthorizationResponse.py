import string


class AuthorizationResponse:
    login: string
    name: string
    email: string
