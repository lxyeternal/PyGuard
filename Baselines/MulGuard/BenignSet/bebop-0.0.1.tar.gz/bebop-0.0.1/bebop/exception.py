'''
Created on Jun 29, 2011

@author: al
'''

class BebopError(Exception):
    pass

class SolrTypeError(BebopError):
    pass