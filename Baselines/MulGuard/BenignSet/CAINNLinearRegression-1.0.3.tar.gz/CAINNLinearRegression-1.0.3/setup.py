from setuptools import setup 

setup(name='CAINNLinearRegression',
    version='1.0.3',
    description='Linear Regression modeling algorithm',
    packages=['CAINNLinearRegression'],
    author='Christopher Weaver',
    author_email='crweaver225@yahoo.com',
    zip_safe=False
)