__title__ = 'adbgui'
__version__ = '0.1'
__author__ = 'Zhangfeng.Zou'
__copyright__ = 'Copyright by Zhangfeng.Zou'
