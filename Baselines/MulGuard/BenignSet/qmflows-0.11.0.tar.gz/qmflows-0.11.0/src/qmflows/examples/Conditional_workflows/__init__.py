"""Various examples involving conditional workflows."""

from .calc_freqs import example_freqs

__all__ = ['example_freqs']
