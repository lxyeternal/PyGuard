# artix-news
Artix's news CLI. Give to you a fast summary of the new artix changes

![demo](https://i.imgur.com/HEiOr3n.png)


# Install && Usage

``` bash
pip install --user artix-news
```

If installed with pip just call as `artix-news` from command-line.


# Author
Manoel Vilela
