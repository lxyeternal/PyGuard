"""
Apps.
"""
# flake8: noqa
# pylint: disable-all
from django.apps import AppConfig


class DjangoTelegramLoginConfig(AppConfig):
    """
    DjangoTelegramLoginConfig.
    """
    name = 'django_telegram_login'
