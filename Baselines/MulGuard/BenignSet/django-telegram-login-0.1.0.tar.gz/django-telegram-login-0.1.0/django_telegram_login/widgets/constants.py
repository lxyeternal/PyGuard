"""
Constants for creation widgets.
"""
SMALL = 'small'
MEDIUM = 'medium'
LARGE = 'large'

DISABLE_USER_PHOTO = False
