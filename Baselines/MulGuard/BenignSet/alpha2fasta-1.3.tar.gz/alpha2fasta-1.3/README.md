# alpha2fasta
The alpha2fasta library can be used to encode texts written in natural language to a FASTA-based format. The purpose of coding is to enable the application of various bioinformatics tools in text mining.

Functions
--------------------------------------------------------------------------------------------------------------------------------
- aminocode
- dnabits
