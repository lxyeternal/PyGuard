"""
setup() stub for compatibility with legacy builds (not using the PEP 517 build API)
"""

import setuptools

setuptools.setup()
