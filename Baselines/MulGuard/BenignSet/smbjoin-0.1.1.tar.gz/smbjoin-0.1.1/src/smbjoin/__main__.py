"""
Python package entry point module
"""

from .cli import net_ads_join

if __name__ == "__main__":
    net_ads_join()
