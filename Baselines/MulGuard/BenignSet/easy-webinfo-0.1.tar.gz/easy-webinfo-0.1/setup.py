from setuptools import setup

setup(
name='easy-webinfo',
version='0.1',
scripts=['webinfo']
)
