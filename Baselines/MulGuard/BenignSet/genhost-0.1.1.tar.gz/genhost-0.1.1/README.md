# Genhost

Small python application to generate hostnames based on a wordlist. Inspired by https://github.com/elasticdog/genhost

The original wordlist is taken from here, https://web.archive.org/web/20090918202746/http://tothink.com/mnemonic/wordlist.html and there is a version ready to go here in this repo.
