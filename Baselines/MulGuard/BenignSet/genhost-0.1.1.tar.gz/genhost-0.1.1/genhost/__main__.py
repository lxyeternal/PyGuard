from genhost.main import main

main()
