class CardCodeAndCount:
    def __init__(self, card_code, count):
        self.card_code = card_code
        self.count = count
