from fasgan.gencore import Core as gencore
from fasgan.discore import Core as discore
from fasgan.generator import Generator
from fasgan.discriminator import Discriminator