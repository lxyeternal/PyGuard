from setuptools import setup

setup(
    name='fastpython',
    version='1.0.0',
    packages=['fastpython'],
    install_requires=[]
)