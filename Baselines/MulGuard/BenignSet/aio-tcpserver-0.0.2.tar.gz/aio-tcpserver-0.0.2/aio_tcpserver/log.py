"""设置服务器的默认log形式
可以使用server_logger获取设置中的`aio-tcpseve`作为logger

"""
import logging

server_logger = logging.getLogger('aio-tcpsever')
