print('This is the __init__ file for mypackage')
