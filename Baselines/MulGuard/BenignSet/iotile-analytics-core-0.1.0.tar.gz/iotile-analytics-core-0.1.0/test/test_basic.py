"""Tests of basic functionality."""
from __future__ import (absolute_import, division,
                        print_function, unicode_literals)
from builtins import *

def test_basic_import():
    """Make sure we can import."""

    import iotile_analytics.core
