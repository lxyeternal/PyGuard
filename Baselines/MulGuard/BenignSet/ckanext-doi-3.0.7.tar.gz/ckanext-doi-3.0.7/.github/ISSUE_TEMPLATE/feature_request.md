---
name: Feature request
about: Suggest an feature or improvement for this extension
title: ''
labels: enhancement
assignees: ''

---

**Overview**
Give a brief description of what the feature or improvement should do and why.

**Possible Solutions**
Do you have any ideas for how you'd want to implement it?

**Anything Else?**
Add any other information here.
