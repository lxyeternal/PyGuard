SAVE_IMAGE_DIR = "./outputs"
CHECKPOINT_DIR = 'training_checkpoints'
