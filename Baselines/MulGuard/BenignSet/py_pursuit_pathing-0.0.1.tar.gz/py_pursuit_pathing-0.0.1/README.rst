py-pursuit-pathing
===
A library for path following using the pure pursuit algorithm.