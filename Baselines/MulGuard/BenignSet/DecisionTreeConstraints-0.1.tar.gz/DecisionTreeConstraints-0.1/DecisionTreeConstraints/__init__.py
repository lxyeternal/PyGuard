from DecisionTreeConstraints.SizeConstraintPruning import SizeConstraintPruning

__all__ = [
    'SizeConstraintPruning'
]
