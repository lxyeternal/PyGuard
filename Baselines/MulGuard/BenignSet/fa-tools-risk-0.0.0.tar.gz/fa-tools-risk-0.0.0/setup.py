from setuptools import setup, find_packages

setup(
    author="none",
    author_email="none@none.com",
    python_requires="==3.9.*",
    classifiers=[
        "Programming Language :: Python :: 3.9",
        "Development Status :: 1 - Planning"
    ],
    packages=find_packages(include=[]),
    description="placeholder repo",
    include_package_data=True,
    name="fa-tools-risk",
    version="0.0.0",
)
