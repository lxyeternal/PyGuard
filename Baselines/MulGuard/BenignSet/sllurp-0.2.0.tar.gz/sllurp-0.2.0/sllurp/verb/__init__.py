"""Verbs for use in sllurp commands.
"""

__all__ = ('inventory', 'reset')
