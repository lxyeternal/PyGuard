"""Module contains the version of dag-dq-generator"""
__version__ = "1.0.1" #"1.0.1-alpha"