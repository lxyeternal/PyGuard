A test package to initialize a python package
