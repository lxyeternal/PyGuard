def hello():

	print("I am just an example")
