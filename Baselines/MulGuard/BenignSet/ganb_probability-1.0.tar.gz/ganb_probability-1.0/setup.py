from setuptools import setup

setup(name='ganb_probability',
      version='1.0',
      description='Gaussian distributions',
      packages=['ganb_probability'],
      author = 'Cecil Wiafe',
      zip_safe=False)
