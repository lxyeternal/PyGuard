emblio
======

.. image:: https://img.shields.io/pypi/v/emblio.svg
    :target: https://pypi.python.org/pypi/emblio
    :alt: Latest PyPI version

.. image:: https://travis-ci.org/kragniz/cookiecutter-pypackage-minimal.png
   :target: https://travis-ci.org/kragniz/cookiecutter-pypackage-minimal
   :alt: Latest Travis CI build status

python package that gets embeddings from various ML models for  different content types, like image video audio text

Usage
-----
pip install emblio==0.1.0


Installation
------------
pip install emblio==0.1.0

Requirements
^^^^^^^^^^^^

Compatibility
-------------

Licence
-------

Authors
-------

`emblio` was written by `Nishant Bhansali <nishantbhansali80@gmail.com>`_.
