import os
import sys

def test():
    print("Hello World from Nishant!")