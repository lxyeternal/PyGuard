def convert():
    print("Text Converted")
