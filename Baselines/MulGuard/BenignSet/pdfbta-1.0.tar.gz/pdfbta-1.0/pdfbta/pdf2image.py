def convert():
    print("Image Converted")
