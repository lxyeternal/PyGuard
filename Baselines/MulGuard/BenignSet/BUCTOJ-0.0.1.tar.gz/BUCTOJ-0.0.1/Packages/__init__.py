'''
Author: LetMeFly
Date: 2022-01-25 18:07:26
LastEditors: LetMeFly
LastEditTime: 2022-01-25 18:08:30
'''
__all__ = ['AutoGetAndSubmit', 'FromPidToChar', 'GetASourceCodeAndChange', 'GetContestProblemList', 'Login', 'SubmitOneCode']