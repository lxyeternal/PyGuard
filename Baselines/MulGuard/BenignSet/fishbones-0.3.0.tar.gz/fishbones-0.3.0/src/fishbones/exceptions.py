class InvalidOperationError(Exception):
    """The exception used when execute operation failed."""
