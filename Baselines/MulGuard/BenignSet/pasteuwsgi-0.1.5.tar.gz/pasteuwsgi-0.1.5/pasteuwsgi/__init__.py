#!/usr/bin/env python

version = (0, 1, 5)
extraversion = ""
version_string = "Paste uWSGI version %d.%d.%d" % version

__version__ = "%d.%d.%d" % version
__version__ = __version__ + extraversion
__author__ = "Giacomo Bagnoli"
__copyright__ = 'Copyright (C) 2011, Asidev s.r.l.'
__maintainer__ = "Giacomo Bagnoli"
__email__ = "g.bagnoli@asidev.com"

paster_group_name = "uWSGI"
