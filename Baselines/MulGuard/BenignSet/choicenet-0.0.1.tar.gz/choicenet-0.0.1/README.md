# Wellcome to Choice Net
> Choice Net is a combination of discrete choice models and deep neural networks.


This file will become your README and also the index of your documentation.

## Install

`pip install choicenet`

## How to use

Fill me in please! Don't forget code examples:

```python
1+1
```




    2



Test if it work

```python
say_hello("Dan")
```




    'Hello Dan!'


