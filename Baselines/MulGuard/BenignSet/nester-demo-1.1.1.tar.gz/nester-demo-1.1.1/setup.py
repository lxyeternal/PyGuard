from distutils.core import setup

setup(
    name          = 'nester-demo',
    version       = '1.1.1',
    py_modules    = ['nester'],
    author        = 'hfpython',
    author_email  = 'test@headfirstlabs.com',
    url           = 'http://wwww.test.com',
    description   = 'a simple test',
    )
