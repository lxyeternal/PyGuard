=====================
Pdfmate
=====================
* `Terminalkitten <https://github.com/terminalkitten>`_



=====================
Forked from Python-PDFKit authors
=====================

* `Shivansh Saini <https://github.com/shivanshs9>`_
* `Stanislav Golovanov <https://github.com/JazzCore>`_


Python-PDFKit Contributors
------------

* `Tomscytale <https://github.com/tomscytale>`_
* `Matheus Marchini <https://github.com/mmarchini>`_
* `Rory McCann <https://github.com/rory>`_
* `Matheus Marchini <https://github.com/mmarchini>`_
* `signalkraft <https://github.com/signalkraft>`_
* `Pietro Delsante <https://github.com/pdelsante>`_
* `Hung Le <https://github.com/lexhung>`_
* `Zachary Kazanski <https://github.com/Kazanz>`_
* `Fasih Ahmad Fakhri <https://github.com/fasihahmad>`_
* `Alan Hamlett <https://github.com/alanhamlett>`_
