from analysis.question_categorization_analysis import *
study='question-categories'
run_question_categories_batch_analysis(study)

