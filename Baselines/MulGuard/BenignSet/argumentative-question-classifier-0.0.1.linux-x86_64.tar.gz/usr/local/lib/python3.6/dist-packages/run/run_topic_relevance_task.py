from annotation.topic_relevance_task import *



# Don't !
generate_topic_relevance_annotation_task()