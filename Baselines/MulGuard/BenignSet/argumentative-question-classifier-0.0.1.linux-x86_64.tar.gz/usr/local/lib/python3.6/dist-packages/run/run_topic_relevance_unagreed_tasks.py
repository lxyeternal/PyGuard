from annotation.topic_relevance_task import *

filter_questions_with_missing_annotations()
generate_topic_relevance_annotation_task_iteration('topic-relevance-2nd')
