from annotation.pilot_question_categories import *
from annotation.pilot_question_categories_training import *
prepare_pilot_question_categories('pilot-question-categories',True)
prepare_training_set('pilot-question-categories',True)