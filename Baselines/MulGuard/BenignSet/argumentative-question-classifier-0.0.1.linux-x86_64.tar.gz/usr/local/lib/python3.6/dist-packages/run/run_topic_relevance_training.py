from annotation.topic_relevance_task import *
generate_training_dataset()