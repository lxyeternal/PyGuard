from analysis.topic_relevance_analysis import *
produce_dataset('topic-relevance')