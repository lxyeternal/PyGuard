from annotation.topic_relevance_task import *
import logging

add_agreed_annotations_to_quality_checks(15)
add_agreed_annotations_to_quality_checks(7)

