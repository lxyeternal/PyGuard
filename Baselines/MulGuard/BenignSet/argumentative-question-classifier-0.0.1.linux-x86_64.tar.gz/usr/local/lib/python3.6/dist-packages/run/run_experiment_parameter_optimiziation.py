from experiments.parameter_optimization import *
#optimize_logisitc()
optimize_svm()