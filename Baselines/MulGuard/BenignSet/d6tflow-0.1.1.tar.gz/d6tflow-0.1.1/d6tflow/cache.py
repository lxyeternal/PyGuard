data = {}

api = None
pipe_default_name = None
pipes = {}
