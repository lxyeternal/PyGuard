# BBB: Django < 1.7 app discovery
