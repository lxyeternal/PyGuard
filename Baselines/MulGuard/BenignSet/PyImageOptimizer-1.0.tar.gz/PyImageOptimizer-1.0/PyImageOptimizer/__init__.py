# -*- coding: utf-8 -*-

__author__ = 'Shantanu Khandelwal'
__email__ = 'shantanu561993@gmail.com'
__version__ = '1.0'

from .PyImageOptimizer import optimize_jpg,optimize_png,optimize
