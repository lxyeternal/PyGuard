#!/usr/bin/env python
# -*- coding: utf-8 -*-

"""
test_PyImageOptimizer
----------------------------------

Tests for `PyImageOptimizer` module.
"""

import unittest

from PyImageOptimizer import PyImageOptimizer


class TestPyimageoptimizer(unittest.TestCase):

    def setUp(self):
        pass

    def test_something(self):
        pass

    def tearDown(self):
        pass

if __name__ == '__main__':
    unittest.main()
