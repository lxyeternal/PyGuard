===============================
PyImageOptimizer
===============================

.. image:: https://img.shields.io/travis/shantanu561993/PyImageOptimizer.svg
        :target: https://travis-ci.org/shantanu561993/PyImageOptimizer

.. image:: https://img.shields.io/pypi/v/PyImageOptimizer.svg
        :target: https://pypi.python.org/pypi/PyImageOptimizer


Python Image Optimzer . Uses jpgoptimizer.com  and pngcrush.com to optimize the images. 

* Free software: BSD license
* Documentation: https://PyImageOptimizer.readthedocs.org.

Features
--------

* TODO
    - Expose Api to resize images
