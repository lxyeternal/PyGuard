============
Installation
============

At the command line::

    $ easy_install PyImageOptimizer

Or, if you have virtualenvwrapper installed::

    $ mkvirtualenv PyImageOptimizer
    $ pip install PyImageOptimizer
