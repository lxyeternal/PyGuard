========
Usage
========

To use PyImageOptimizer in a project::

    import PyImageOptimizer
