# Flask-IPFS
IPFS Plugin for Flask
