.. :changelog:

History
-------

0.1.0 (2013-12-20)
++++++++++++++++++

* First release on PyPI.