django-cachedpaginator
================

Please read https://github.com/arsham/django-cachedpaginator/blob/master/README.md
