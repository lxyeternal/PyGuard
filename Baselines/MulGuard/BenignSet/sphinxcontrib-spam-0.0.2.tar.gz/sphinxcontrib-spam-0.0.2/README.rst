==================
sphinxcontrib-spam
==================

1. What's this?
===============
``sphinxcontrib-spam`` output **spam! spam! spam!**

This module is under development for a while.


2. License
==========
This module is distributed under New BSD License. See LICENSE file for detailed conditions.
