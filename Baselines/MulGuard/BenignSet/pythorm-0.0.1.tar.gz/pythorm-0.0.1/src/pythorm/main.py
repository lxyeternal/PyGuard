# Probably project that I won't finish
# This is useless library for claiming name
