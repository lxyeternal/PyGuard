Welcome to butterflow |release|!
=============================================

Contents
--------

.. toctree::
   :maxdepth: 1

   README <readme>
   Authors <authors>
   Contributing <contributing>

Navigation
----------

:ref:`genindex`

:ref:`modindex`

:ref:`search`
