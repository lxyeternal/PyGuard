.. fedcloudclient documentation master file, created by
   sphinx-quickstart on Sun Dec 27 22:25:01 2020.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

Welcome to fedcloudclient's documentation!
==========================================

.. image:: https://zenodo.org/badge/336671726.svg
   :target: https://zenodo.org/badge/latestdoi/336671726

.. toctree::
   :maxdepth: 2
   :caption: Contents:

   intro
   quickstart
   install
   usage
   development
   fedcloudclient
   FAQ



Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`
