fedcloudclient API references
=============================

fedcloudclient.checkin module
-----------------------------

.. automodule:: fedcloudclient.checkin
   :members:
   :undoc-members:
   :show-inheritance:

fedcloudclient.endpoint module
------------------------------

.. automodule:: fedcloudclient.endpoint
   :members:
   :undoc-members:
   :show-inheritance:

fedcloudclient.sites module
---------------------------

.. automodule:: fedcloudclient.sites
   :members:
   :undoc-members:
   :show-inheritance:

fedcloudclient.openstack module
-------------------------------

.. automodule:: fedcloudclient.openstack
   :members:
   :undoc-members:
   :show-inheritance:

fedcloudclient.cli module
-------------------------

.. automodule:: fedcloudclient.cli
   :members:
   :undoc-members:
   :show-inheritance:

