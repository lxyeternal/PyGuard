#!/usr/bin/env python3

from importlib.metadata import version


__version__ = version('esneft_tools')
