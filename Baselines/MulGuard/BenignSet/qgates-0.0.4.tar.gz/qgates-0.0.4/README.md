# QGates

created by Austin Poor

A small file with some helpful quantum gates represented as numpy matrices.


