#!/usr/bin/env python
# -*- coding:utf-8 -*-
# (c)Ing. Zdenek Dlauhy, Michal Dlauhý, info@dlauhy.cz

try:
    import httplib
except ImportError:
    import http.client as httplib
import socket
import ssl

# Python 2.6's urllib2 does not allow you to select the TLS dialect,
# and by default uses a SSLv23 compatibility negotiation implementation.
# Besides being vulnerable to POODLE, the OSX implementation doesn't
# work correctly, failing to connect to servers that respond only to
# TLS1.0+. These classes help set up TLS support for urllib2.


class HTTPSConnection(httplib.HTTPConnection):
    "This class allows communication via SSL."
    default_port = httplib.HTTPS_PORT

    def __init__(self, host, port=None, key_file=None, cert_file=None,
            strict=None, timeout=socket._GLOBAL_DEFAULT_TIMEOUT,
            source_address=None):
        httplib.HTTPConnection.__init__(self, host, port, strict, timeout,
                source_address)
        self.key_file = key_file
        self.cert_file = cert_file

    def connect(self):
        "Connect to a host on a given (SSL) port."
        sock = socket.create_connection((self.host, self.port),
                self.timeout, self.source_address)
        if self._tunnel_host:
            self.sock = sock
            self._tunnel()
        # this is the only line we modified from the httplib.py file
        # we added the ssl_version variable
        self.sock = ssl.wrap_socket(sock, self.key_file, self.cert_file, ssl_version=ssl.PROTOCOL_TLSv1)

#now we override the one in httplib
httplib.HTTPSConnection = HTTPSConnection
# ssl_version corrections are done
