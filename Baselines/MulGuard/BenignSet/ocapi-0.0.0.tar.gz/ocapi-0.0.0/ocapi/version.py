#!/usr/bin/env python
# -*- coding:utf-8 -*-
# (c)Ing. Zdenek Dlauhy, Michal Dlauhý, info@dlauhy.cz

__revision__='3'
__node__='4228f5fd1a7a'
__updated__='2015-04-16'
