from setuptools import setup

setup(
    name='OverseerPythonAPI',
    version='1.0',
    packages=['OverseerPythonAPI'],
    license='Free to use',
    author='TRTGames',
    author_email='theredtie.games@gmail.com',
    description='API for working with Overseer platform for Python'
)
