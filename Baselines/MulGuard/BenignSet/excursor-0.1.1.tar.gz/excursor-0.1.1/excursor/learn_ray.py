import ray

ray.init()
