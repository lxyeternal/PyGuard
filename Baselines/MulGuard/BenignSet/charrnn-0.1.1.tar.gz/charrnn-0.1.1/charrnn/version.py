# -*- coding: utf-8 -*-
"""
Version file should not be imported outside root module
"""

__version__ = '0.1.1'
__build__ = 'release'
