# Analytic Hierarchy Process Solver in Python
[![license](https://img.shields.io/github/license/mashape/apistatus.svg)]()

## Maintainer
- Abhinav Mishra [@mishrabhinav](https://github.com/mishrabhinav)
