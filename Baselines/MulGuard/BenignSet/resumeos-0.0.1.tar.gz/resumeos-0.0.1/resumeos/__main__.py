# -*- coding: utf-8 -*-

from .resumeos import main
main()
