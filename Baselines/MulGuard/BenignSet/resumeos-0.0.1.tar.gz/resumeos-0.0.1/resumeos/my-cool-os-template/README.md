# {{name}}

```

{{banner}}

```

## Dependancies (for Ubuntu)

```sh
sudo apt-get install nasm
sudo apt-get install xorriso
sudo apt-get install qemu
```

## Running

```sh
make
```

