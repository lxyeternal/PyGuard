# AWS Functions

[![CircleCI](https://circleci.com/gh/productml/awsfunctions/tree/master.svg?style=svg)](https://circleci.com/gh/productml/awsfunctions/tree/master)


A collection of AWS functions based on [boto3](http://boto3.readthedocs.io/en/latest/).

The goal of this library is to provide a higher level abstraction of `boto3` for convenience.
