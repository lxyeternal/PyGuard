#!/usr/bin/env bash

set -e
set -x

cd docs; python docs.py live
