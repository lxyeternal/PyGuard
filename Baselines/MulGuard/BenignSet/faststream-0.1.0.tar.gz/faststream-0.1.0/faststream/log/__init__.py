from faststream.log.logging import access_logger, logger

__all__ = (
    "logger",
    "access_logger",
)
