from typing import Union

TimeoutType = Union[int, float, None]
