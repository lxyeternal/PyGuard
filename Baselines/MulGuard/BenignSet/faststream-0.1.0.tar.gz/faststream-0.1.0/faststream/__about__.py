"""Simple and fast framework to create message brokers based microservices"""
__version__ = "0.1.0"


INSTALL_YAML = """
To generate YAML documentation, please install dependencies:\n
pip install PyYAML
"""
