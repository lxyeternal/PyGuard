from faststream.asyncapi.site import get_asyncapi_html

__all__ = ("get_asyncapi_html",)
