

::: faststream.rabbit.test.PatchedMessage
