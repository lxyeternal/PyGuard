

::: faststream.broker.handler.BaseHandler
