

::: faststream.asyncapi.schema.info.LicenseDict
