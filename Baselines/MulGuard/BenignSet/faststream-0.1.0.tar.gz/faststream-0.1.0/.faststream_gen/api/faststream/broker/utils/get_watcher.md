

::: faststream.broker.utils.get_watcher
