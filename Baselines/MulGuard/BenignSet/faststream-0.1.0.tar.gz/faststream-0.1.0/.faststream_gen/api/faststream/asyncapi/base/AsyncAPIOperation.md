

::: faststream.asyncapi.base.AsyncAPIOperation
