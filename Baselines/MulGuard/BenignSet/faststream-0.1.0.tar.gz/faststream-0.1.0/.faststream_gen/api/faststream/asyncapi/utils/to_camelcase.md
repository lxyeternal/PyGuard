

::: faststream.asyncapi.utils.to_camelcase
