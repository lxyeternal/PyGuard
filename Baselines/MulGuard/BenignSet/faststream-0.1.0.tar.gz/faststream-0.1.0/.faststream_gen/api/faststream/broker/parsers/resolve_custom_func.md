

::: faststream.broker.parsers.resolve_custom_func
