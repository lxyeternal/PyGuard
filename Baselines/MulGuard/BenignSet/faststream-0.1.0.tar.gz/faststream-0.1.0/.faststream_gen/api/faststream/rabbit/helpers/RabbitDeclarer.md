

::: faststream.rabbit.helpers.RabbitDeclarer
