

::: faststream.utils.data.filter_by_dict
