

::: faststream.asyncapi.generate.get_app_broker_server
