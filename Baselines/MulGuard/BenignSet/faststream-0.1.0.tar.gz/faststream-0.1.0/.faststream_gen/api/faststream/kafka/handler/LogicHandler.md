

::: faststream.kafka.handler.LogicHandler
