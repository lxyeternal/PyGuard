

::: faststream.exceptions.NackMessage
