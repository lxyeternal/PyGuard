

::: faststream.broker.types.AsyncPublisherProtocol
