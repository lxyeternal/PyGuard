

::: faststream.broker.core.mixins.LoggingMixin
