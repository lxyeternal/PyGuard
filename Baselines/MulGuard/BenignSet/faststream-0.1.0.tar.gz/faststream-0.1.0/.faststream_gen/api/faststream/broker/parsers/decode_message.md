

::: faststream.broker.parsers.decode_message
