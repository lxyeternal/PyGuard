

::: faststream.kafka.asyncapi.Handler
