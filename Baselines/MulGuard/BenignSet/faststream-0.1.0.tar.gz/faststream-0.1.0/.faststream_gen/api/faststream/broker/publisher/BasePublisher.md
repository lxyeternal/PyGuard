

::: faststream.broker.publisher.BasePublisher
