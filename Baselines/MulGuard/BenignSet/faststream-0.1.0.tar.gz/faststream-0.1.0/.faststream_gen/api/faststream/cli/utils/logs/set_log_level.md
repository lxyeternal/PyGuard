

::: faststream.cli.utils.logs.set_log_level
