

::: faststream.broker.utils.set_message_context
