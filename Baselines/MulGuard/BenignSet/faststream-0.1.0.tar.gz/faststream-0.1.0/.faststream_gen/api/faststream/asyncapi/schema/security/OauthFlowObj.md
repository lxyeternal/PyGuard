

::: faststream.asyncapi.schema.security.OauthFlowObj
