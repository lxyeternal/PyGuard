

::: faststream.kafka.shared.schemas.ConsumerConnectionParams
