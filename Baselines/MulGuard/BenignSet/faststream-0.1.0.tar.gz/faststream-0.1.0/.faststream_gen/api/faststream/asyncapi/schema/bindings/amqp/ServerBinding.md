

::: faststream.asyncapi.schema.bindings.amqp.ServerBinding
