

::: faststream.exceptions.StopConsume
