

::: faststream.kafka.router.KafkaRouter
