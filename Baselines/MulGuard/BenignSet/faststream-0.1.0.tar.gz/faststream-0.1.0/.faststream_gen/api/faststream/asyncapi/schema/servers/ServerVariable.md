

::: faststream.asyncapi.schema.servers.ServerVariable
