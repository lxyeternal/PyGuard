

::: faststream.rabbit.asyncapi.Handler
