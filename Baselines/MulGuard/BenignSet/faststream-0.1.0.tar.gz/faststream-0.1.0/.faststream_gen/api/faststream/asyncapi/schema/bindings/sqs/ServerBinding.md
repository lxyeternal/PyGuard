

::: faststream.asyncapi.schema.bindings.sqs.ServerBinding
