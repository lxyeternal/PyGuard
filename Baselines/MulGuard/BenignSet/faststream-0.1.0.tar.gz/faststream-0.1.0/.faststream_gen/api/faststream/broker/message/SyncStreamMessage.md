

::: faststream.broker.message.SyncStreamMessage
