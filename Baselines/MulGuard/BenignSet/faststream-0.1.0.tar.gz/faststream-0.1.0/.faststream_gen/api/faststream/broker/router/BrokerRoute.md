

::: faststream.broker.router.BrokerRoute
