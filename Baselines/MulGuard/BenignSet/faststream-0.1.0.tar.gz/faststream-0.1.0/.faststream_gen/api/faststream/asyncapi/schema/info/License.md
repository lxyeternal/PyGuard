

::: faststream.asyncapi.schema.info.License
