

::: faststream.kafka.publisher.LogicPublisher
