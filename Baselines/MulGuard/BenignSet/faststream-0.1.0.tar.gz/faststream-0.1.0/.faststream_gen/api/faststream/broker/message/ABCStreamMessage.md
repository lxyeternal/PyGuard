

::: faststream.broker.message.ABCStreamMessage
