

::: faststream.cli.main.main
