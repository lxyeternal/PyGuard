

::: faststream.log.formatter.expand_log_field
