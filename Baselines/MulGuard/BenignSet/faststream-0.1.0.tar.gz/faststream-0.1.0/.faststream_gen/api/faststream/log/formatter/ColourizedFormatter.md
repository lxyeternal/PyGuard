

::: faststream.log.formatter.ColourizedFormatter
