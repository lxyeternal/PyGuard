

::: faststream.broker.core.abc.extend_dependencies
