

::: faststream.rabbit.message.RabbitMessage
