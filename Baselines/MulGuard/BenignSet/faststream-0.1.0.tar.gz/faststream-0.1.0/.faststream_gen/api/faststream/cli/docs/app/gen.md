

::: faststream.cli.docs.app.gen
