

::: faststream.rabbit.asyncapi.Publisher
