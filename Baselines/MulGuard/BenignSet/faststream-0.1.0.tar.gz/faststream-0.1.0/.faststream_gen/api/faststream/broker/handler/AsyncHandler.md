

::: faststream.broker.handler.AsyncHandler
