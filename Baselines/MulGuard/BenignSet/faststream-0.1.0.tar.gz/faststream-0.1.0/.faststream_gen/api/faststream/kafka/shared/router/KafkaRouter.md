

::: faststream.kafka.shared.router.KafkaRouter
