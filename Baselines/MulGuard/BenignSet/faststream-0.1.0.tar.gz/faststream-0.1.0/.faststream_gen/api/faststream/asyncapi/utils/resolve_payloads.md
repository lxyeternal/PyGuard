

::: faststream.asyncapi.utils.resolve_payloads
