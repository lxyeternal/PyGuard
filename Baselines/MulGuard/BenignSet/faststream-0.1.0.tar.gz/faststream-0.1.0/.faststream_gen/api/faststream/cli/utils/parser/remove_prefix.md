

::: faststream.cli.utils.parser.remove_prefix
