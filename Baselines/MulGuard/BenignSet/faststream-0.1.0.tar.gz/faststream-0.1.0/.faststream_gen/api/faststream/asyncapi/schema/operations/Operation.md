

::: faststream.asyncapi.schema.operations.Operation
