

::: faststream.asyncapi.schema.info.Info
