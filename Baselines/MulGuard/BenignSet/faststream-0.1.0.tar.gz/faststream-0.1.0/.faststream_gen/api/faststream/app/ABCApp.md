

::: faststream.app.ABCApp
