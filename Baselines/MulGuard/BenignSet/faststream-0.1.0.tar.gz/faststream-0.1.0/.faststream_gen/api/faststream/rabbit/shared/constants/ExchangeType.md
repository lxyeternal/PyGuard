

::: faststream.rabbit.shared.constants.ExchangeType
