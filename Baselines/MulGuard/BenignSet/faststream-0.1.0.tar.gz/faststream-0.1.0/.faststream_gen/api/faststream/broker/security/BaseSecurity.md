

::: faststream.broker.security.BaseSecurity
