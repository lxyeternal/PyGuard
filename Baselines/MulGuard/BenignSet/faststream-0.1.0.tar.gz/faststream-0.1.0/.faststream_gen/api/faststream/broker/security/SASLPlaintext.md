

::: faststream.broker.security.SASLPlaintext
