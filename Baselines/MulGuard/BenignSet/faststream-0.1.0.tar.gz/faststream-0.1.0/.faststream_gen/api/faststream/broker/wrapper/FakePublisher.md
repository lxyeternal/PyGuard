

::: faststream.broker.wrapper.FakePublisher
