

::: faststream.asyncapi.schema.utils.ExternalDocsDict
