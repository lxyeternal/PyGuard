

::: faststream.asyncapi.generate.get_app_schema
