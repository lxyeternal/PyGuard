

::: faststream.asyncapi.schema.bindings.main.OperationBinding
