

::: faststream.rabbit.test.FakeProducer
