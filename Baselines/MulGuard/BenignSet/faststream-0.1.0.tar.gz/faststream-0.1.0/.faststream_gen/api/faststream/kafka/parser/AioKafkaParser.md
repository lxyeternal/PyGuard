

::: faststream.kafka.parser.AioKafkaParser
