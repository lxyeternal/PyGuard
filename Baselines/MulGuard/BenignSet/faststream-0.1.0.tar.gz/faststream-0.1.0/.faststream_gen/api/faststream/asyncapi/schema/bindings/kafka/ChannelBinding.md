

::: faststream.asyncapi.schema.bindings.kafka.ChannelBinding
