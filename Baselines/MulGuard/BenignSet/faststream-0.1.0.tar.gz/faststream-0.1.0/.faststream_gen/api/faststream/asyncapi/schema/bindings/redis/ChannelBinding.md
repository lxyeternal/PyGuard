

::: faststream.asyncapi.schema.bindings.redis.ChannelBinding
