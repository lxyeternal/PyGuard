

::: faststream.asyncapi.schema.bindings.kafka.ServerBinding
