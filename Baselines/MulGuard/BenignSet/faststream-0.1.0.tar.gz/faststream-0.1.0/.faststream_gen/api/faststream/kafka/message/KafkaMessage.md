

::: faststream.kafka.message.KafkaMessage
