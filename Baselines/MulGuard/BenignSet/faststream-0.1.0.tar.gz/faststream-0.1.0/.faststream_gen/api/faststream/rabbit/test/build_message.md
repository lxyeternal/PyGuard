

::: faststream.rabbit.test.build_message
