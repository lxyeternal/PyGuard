

::: faststream.kafka.shared.logging.KafkaLoggingMixin
