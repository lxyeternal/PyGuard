

::: faststream.asyncapi.schema.message.Message
