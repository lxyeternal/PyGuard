

::: faststream.broker.message.StreamMessage
