

::: faststream.asyncapi.schema.bindings.redis.OperationBinding
