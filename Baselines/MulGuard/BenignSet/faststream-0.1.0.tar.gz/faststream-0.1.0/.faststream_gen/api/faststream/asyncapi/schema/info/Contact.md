

::: faststream.asyncapi.schema.info.Contact
