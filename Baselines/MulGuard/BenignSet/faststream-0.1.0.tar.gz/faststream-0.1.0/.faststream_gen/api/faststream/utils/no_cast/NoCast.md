

::: faststream.utils.no_cast.NoCast
