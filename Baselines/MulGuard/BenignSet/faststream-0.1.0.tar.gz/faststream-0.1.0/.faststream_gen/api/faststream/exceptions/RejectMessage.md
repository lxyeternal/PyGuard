

::: faststream.exceptions.RejectMessage
