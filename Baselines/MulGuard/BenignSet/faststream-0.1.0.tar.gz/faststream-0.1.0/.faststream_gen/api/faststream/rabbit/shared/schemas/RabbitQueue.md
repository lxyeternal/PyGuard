

::: faststream.rabbit.shared.schemas.RabbitQueue
