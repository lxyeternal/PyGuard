

::: faststream.cli.main.version_callback
