

::: faststream.rabbit.shared.publisher.ABCPublisher
