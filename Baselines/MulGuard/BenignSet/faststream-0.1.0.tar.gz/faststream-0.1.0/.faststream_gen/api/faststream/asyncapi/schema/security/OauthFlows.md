

::: faststream.asyncapi.schema.security.OauthFlows
