

::: faststream.asyncapi.schema.bindings.amqp.Queue
