

::: faststream.kafka.shared.publisher.ABCPublisher
