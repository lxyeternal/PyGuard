

::: faststream.asyncapi.schema.bindings.amqp.ChannelBinding
