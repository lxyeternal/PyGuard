

::: faststream.broker.schemas.NameRequired
