

::: faststream.rabbit.router.RabbitRouter
