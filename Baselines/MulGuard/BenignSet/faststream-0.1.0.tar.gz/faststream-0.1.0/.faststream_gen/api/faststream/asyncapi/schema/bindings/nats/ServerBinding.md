

::: faststream.asyncapi.schema.bindings.nats.ServerBinding
