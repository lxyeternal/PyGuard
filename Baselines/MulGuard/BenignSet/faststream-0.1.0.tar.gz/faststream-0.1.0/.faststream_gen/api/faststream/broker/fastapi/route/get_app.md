

::: faststream.broker.fastapi.route.get_app
