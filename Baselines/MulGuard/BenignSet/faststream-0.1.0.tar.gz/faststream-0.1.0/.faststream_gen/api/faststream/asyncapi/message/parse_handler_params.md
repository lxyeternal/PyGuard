

::: faststream.asyncapi.message.parse_handler_params
