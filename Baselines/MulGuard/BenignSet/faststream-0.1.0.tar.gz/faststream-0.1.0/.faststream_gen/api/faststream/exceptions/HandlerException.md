

::: faststream.exceptions.HandlerException
