

::: faststream.asyncapi.schema.bindings.nats.OperationBinding
