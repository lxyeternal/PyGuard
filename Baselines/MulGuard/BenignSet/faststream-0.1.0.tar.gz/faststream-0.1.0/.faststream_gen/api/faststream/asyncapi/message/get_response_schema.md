

::: faststream.asyncapi.message.get_response_schema
