

::: faststream.broker.fastapi.route.StreamMessage
