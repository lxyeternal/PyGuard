

::: faststream.rabbit.shared.schemas.get_routing_hash
