

::: faststream.utils.classes.Singleton
