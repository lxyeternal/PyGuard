

::: faststream.asyncapi.schema.utils.ExternalDocs
