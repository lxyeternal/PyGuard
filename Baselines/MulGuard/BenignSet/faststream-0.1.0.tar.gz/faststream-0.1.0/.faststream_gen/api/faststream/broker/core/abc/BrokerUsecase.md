

::: faststream.broker.core.abc.BrokerUsecase
