

::: faststream.kafka.asyncapi.Publisher
