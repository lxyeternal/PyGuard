

::: faststream.asyncapi.schema.security.SecuritySchemaComponent
