

::: faststream.rabbit.handler.LogicHandler
