

::: faststream.utils.functions.to_async
