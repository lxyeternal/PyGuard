

::: faststream.rabbit.test.TestRabbitBroker
