

::: faststream.asyncapi.schema.main.Components
