

::: faststream.asyncapi.schema.utils.Tag
