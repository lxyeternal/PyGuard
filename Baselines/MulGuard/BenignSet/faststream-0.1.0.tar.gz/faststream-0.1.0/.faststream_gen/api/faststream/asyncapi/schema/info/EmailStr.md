

::: faststream.asyncapi.schema.info.EmailStr
