

::: faststream.asyncapi.schema.info.ContactDict
