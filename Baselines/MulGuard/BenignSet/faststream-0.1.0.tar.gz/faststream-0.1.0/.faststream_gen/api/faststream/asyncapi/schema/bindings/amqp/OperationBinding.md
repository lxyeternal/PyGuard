

::: faststream.asyncapi.schema.bindings.amqp.OperationBinding
