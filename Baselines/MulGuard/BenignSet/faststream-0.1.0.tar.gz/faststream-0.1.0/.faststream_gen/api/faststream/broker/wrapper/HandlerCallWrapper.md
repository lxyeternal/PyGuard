

::: faststream.broker.wrapper.HandlerCallWrapper
