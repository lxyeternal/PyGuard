

::: faststream.broker.middlewares.CriticalLogMiddleware
