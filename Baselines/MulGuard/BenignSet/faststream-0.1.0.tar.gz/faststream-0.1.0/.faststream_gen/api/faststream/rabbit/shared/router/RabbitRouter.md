

::: faststream.rabbit.shared.router.RabbitRouter
