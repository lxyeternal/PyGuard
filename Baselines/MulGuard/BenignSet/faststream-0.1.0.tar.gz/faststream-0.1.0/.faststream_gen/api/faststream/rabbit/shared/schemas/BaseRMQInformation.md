

::: faststream.rabbit.shared.schemas.BaseRMQInformation
