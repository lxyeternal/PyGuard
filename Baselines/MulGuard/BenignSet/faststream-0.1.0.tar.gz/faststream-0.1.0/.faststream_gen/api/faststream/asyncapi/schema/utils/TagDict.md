

::: faststream.asyncapi.schema.utils.TagDict
