

::: faststream.broker.test.TestApp
