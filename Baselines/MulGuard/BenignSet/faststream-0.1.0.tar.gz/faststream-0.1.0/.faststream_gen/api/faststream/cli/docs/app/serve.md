

::: faststream.cli.docs.app.serve
