

::: faststream.rabbit.producer.AioPikaFastProducer
