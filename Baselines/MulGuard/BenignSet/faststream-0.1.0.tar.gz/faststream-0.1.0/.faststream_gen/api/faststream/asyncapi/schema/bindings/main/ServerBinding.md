

::: faststream.asyncapi.schema.bindings.main.ServerBinding
