

::: faststream.broker.fastapi.router.StreamRouter
