

::: faststream.asyncapi.schema.message.CorrelationId
