

::: faststream.rabbit.publisher.LogicPublisher
