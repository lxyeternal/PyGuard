

::: faststream.broker.fastapi.route.StreamRoute
