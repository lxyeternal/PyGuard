

::: faststream.broker.test.patch_broker_calls
