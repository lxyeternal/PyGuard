

::: faststream.broker.test.call_handler
