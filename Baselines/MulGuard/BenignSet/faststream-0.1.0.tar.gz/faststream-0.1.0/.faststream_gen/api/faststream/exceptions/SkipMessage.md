

::: faststream.exceptions.SkipMessage
