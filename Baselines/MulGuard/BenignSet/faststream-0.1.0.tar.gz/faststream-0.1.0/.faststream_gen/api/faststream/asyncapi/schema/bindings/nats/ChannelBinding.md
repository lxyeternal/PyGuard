

::: faststream.asyncapi.schema.bindings.nats.ChannelBinding
