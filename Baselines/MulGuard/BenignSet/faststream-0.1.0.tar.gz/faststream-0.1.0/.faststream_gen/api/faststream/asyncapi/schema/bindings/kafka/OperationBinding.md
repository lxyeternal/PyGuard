

::: faststream.asyncapi.schema.bindings.kafka.OperationBinding
