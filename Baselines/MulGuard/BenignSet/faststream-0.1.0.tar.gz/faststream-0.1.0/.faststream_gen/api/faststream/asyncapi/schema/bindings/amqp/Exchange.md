

::: faststream.asyncapi.schema.bindings.amqp.Exchange
