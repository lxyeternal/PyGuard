

::: faststream.kafka.fastapi.KafkaRouter
