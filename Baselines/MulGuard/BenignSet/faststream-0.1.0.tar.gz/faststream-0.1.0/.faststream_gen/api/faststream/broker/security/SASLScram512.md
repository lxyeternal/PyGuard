

::: faststream.broker.security.SASLScram512
