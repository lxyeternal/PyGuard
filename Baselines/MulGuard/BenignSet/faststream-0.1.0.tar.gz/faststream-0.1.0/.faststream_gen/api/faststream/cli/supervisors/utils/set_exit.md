

::: faststream.cli.supervisors.utils.set_exit
