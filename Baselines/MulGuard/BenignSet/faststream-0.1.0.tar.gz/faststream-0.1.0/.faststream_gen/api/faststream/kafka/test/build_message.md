

::: faststream.kafka.test.build_message
