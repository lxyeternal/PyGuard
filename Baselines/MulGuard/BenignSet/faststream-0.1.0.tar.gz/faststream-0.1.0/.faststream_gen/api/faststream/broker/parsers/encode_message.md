

::: faststream.broker.parsers.encode_message
