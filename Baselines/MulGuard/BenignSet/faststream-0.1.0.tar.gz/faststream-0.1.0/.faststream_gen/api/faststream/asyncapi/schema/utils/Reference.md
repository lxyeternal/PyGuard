

::: faststream.asyncapi.schema.utils.Reference
