

::: faststream.asyncapi.schema.bindings.main.ChannelBinding
