

::: faststream.kafka.test.FakeProducer
