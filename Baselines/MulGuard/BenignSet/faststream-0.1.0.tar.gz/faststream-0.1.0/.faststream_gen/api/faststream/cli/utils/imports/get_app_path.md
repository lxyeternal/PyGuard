

::: faststream.cli.utils.imports.get_app_path
