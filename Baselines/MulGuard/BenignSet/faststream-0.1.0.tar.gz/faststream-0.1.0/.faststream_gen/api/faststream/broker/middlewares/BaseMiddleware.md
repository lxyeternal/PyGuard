

::: faststream.broker.middlewares.BaseMiddleware
