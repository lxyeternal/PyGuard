

::: faststream.rabbit.shared.logging.RabbitLoggingMixin
