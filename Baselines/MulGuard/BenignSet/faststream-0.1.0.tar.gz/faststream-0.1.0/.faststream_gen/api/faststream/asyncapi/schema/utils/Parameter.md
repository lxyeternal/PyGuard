

::: faststream.asyncapi.schema.utils.Parameter
