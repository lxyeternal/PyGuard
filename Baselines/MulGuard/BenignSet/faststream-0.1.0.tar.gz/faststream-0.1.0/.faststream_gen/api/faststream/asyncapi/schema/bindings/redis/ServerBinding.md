

::: faststream.asyncapi.schema.bindings.redis.ServerBinding
