

::: faststream.asyncapi.schema.channels.Channel
