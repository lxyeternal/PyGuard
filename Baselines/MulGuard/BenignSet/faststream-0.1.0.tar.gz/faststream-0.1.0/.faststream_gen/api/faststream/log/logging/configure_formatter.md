

::: faststream.log.logging.configure_formatter
