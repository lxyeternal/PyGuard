

::: faststream.app.FastStream
