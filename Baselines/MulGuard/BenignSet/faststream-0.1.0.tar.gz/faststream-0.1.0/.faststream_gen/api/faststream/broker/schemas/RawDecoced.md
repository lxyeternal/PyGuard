

::: faststream.broker.schemas.RawDecoced
