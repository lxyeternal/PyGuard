

::: faststream.asyncapi.schema.main.Schema
