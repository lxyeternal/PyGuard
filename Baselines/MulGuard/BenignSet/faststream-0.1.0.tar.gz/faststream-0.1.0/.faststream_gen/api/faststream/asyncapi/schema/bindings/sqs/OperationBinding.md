

::: faststream.asyncapi.schema.bindings.sqs.OperationBinding
