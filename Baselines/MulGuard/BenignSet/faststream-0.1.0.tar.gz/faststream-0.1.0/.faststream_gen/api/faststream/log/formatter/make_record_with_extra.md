

::: faststream.log.formatter.make_record_with_extra
