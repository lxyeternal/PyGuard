

::: faststream.rabbit.shared.schemas.RabbitExchange
