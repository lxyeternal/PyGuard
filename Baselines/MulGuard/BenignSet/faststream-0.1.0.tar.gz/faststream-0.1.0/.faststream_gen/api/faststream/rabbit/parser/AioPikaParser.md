

::: faststream.rabbit.parser.AioPikaParser
