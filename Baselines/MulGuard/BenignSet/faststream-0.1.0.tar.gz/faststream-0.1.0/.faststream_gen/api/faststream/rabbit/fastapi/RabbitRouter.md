

::: faststream.rabbit.fastapi.RabbitRouter
