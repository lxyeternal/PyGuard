

::: faststream.asyncapi.message.get_model_schema
