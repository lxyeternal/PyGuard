

::: faststream.rabbit.asyncapi.RMQAsyncAPIChannel
