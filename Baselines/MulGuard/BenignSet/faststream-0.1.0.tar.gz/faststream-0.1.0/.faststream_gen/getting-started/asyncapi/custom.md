# Customize AsyncAPI Schema

* setup custom FastStream app info
* setup custom broker information
* setup custom handler information
* setup payload information via pydantic model
* generate shema.json, customize manually and serve it instead
