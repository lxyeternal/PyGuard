class InvalidMessageBody(Exception):
    pass


class InvalidConnectionURL(Exception):
    pass


class InvalidUser(Exception):
    pass
