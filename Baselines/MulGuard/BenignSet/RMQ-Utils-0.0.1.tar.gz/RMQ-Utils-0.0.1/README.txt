==================
RMQ-Utils
==================

Utilities for managing RabbitMQ.

For documentation: https://github.com/projectweekend/RMQ-Utils
