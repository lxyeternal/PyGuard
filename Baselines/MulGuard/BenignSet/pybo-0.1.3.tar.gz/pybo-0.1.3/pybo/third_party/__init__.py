# coding: utf-8
from .cql import Query


__all__ = ['Query']
