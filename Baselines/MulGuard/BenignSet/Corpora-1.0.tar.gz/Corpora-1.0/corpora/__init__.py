"""Lightweight, fast and scalable text corpus library"""
VERSION = '1.0'
INFO = __doc__

from corpus import Corpus
