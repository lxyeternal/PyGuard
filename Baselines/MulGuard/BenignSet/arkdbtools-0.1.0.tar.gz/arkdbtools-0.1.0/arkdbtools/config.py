CONNECTION = {
    'HOST'    : "localhost",
    'DATABASE': "ark_mainnet",
    'USER'    : None,
    'PASSWORD': None,
    }

DELEGATE = {
    'ADDRESS': None,
    'PUBKEY':  None,
    'SECRET':  None
}

ARK = 100000000

CALCULATION_BLACKLIST = ['AXzEMF7TC1aH3ax1Luxk6XdyKXDRxnBj4f']
CALCULATION_EXCEPTION = {'address': {'replace': 'int else None'},
                         'max': float('inf')}


