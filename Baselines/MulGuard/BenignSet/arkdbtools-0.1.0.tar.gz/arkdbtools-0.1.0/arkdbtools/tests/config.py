CONNECTION = {
    'HOST'    : "localhost",
    'DATABASE': "ark_mainnet",
    'USER'    : None,
    'PASSWORD': None,
    }

DELEGATE = {
    'ADDRESS': None,
    'PUBKEY':  None,
    'SECRET':  None
}

ARK = 100000000

BLACKLIST = []
ULTRABLACKLIST = ['AXzEMF7TC1aH3ax1Luxk6XdyKXDRxnBj4f']