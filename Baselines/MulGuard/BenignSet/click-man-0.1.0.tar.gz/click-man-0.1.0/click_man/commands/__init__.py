from . import man_pages

__all__ = [
    'man_pages'
]
