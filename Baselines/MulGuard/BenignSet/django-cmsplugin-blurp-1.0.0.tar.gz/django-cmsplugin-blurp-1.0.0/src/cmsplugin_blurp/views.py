import json

from django.http import HttpResponse
from django.template import RequestContext, loader

from cms.models import CMSPlugin

def ajax_render(request, plugin_id):
    plugin = CMSPlugin.objects.get(pk=plugin_id)
    context = RequestContext(request)
    context['ajaxy'] = False
    rendered = plugin.render_plugin(context)
    # use another template to render accumulated js and css declarations from sekizai
    content = loader.render_to_string('cmsplugin_blurp/sekizai_render.html',
            {'content': rendered},
            context)
    return HttpResponse(json.dumps({'content': content}))

