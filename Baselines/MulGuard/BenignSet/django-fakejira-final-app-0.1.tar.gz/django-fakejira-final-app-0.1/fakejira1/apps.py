from django.apps import AppConfig


class FakejiraConfig(AppConfig):
    name = 'fakejira1'
