from setuptools import find_packages, setup

setup(
    name='embedchain_albert',  # the name of the package
    version='0.1.0',
    author='Your Name',
    author_email='your.email@domain.com',
    packages=find_packages(),
    include_package_data=True,
    url='https://github.com/embedchain/embedchain',  # link to your github page or website
    description='An example of Python package',
    install_requires=[],  # List of dependencies
)