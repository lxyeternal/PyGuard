from enum import Enum


class VectorDatabases(Enum):
    CHROMADB = "CHROMADB"
    ELASTICSEARCH = "ELASTICSEARCH"
