class BaseLoader:
    def __init__(self):
        pass

    def load_data():
        """
        Implemented by child classes
        """
        pass
