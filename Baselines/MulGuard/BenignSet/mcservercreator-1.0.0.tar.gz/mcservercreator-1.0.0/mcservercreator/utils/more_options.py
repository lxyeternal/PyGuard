MCDR_LANG_ZH_CN = 'I want to use zh_cn as MCDR\'s language'
ALLOW_COMMAND_BLOCKS = 'Allow command blocks'
AGREE_TO_EULA = 'I agree to the EULA'
DISABLE_ONLINE_MODE = 'I want to disable the online mode'
CONFIG_DEFAULT_GAMEMODE = 'I want to config the default gamemode manually'
CONFIG_PORT = 'I want to config the server port manually'
CONFIG_SEED = 'I want to config the world seed manually'
CONFIG_LEVEL_TYPE = 'I want to config the level type manually'
CONFIG_DIFFICULTLY = 'I want to config the difficulty manually'

ALL = [MCDR_LANG_ZH_CN,
       ALLOW_COMMAND_BLOCKS,
       AGREE_TO_EULA,
       DISABLE_ONLINE_MODE,
       CONFIG_DEFAULT_GAMEMODE,
       CONFIG_PORT,
       CONFIG_SEED,
       CONFIG_LEVEL_TYPE,
       CONFIG_DIFFICULTLY]