================
pytest-datafiles
================

py.test plugin to create a `tmpdir` containing a preconfigured set of files
and/or directories.
