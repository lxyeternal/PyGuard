from django.apps import AppConfig


class CacheWithArgsConfig(AppConfig):
    name = 'cache_with_args'
