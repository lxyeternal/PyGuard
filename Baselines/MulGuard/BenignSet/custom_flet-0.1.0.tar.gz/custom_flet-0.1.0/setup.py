from setuptools import setup, find_packages

setup(
    author="Subhradeep Rang",
    author_email="srang992@gmail.com",
    name="custom_flet",
    version="0.1.0",
    packages=find_packages(),
)
