from page_elements import InputField


class TextArea(InputField):
    pass
