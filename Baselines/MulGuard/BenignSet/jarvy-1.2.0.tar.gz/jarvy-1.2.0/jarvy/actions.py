

class Actions:

    def __init__(self):
        pass

    about_jarvy = 1
    direct_address = 2
    about_master = 3
    search_google = 4
    search_wolfram = 5
    search_wikipedia = 6
    say_sorry = 7


# def enum(**enums):
#     return type('Enum', (), enums)
#
# actions = enum(about_jarvy=1,
#                direct_address=2,
#                about_master=3,
#                search_google=4,
#                search_wolfram=5,
#                search_wikipedia=6,
#                say_sorry=7
#                )
