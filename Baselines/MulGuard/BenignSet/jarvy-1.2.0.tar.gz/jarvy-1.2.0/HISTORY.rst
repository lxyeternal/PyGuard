.. :changelog:

Release History
---------------

1.2.0 (2015-07-21)
++++++++++++++++++

* Simplified import
* Fixed bug on that prevents termination

1.1.0 (2015-07-21)
++++++++++++++++++

* Made minor changes for packaging and distribution

1.0.0 (2015-07-21)
++++++++++++++++++

* Jarvy is born!