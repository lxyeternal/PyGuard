from scrapy import Item, Field


class Proxy(Item):
    proxy = Field()
