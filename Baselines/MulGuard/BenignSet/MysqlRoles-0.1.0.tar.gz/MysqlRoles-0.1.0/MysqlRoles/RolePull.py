"""
RolePull:
    Functions to, from a server, check a central source of truth DB and make
    the mysql user table match.

    Input:
        serv: Source of Truth server address
        host: The database address to make match (default: localhost)
"""

class RolePull(object):
    pass
