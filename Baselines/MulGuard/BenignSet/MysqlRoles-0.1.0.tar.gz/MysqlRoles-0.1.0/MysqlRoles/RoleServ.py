"""
RoleServ:
    Functions for intializing the mysql source of truth server
    and functions associated with using it.

    Input:
        serv: Address of source of Truth server (default: localhost)
"""

class RolePull(object):
    pass
