"""
RolePush:
    Functions to, from a source of truth, check a DB and make
    the mysql user table match.

    Input:
        host: Address of server to make match the source of truth
        serv: Address of source of Truth server (default: localhost)
"""

class RolePull(object):
    pass
