#!/bin/bash
xdoctest scriptconfig --style=google all
