scriptconfig package
====================

Module contents
---------------

.. automodule:: scriptconfig
    :members:
    :undoc-members:
    :show-inheritance:
