.. automodule :: nose.selector
:members: