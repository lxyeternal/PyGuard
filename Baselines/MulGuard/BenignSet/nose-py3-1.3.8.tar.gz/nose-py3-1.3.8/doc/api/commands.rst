.. automodule :: nose.commands
:members: