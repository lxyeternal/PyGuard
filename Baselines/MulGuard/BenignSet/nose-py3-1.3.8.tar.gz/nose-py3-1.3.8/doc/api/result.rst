.. automodule :: nose.result
:members: