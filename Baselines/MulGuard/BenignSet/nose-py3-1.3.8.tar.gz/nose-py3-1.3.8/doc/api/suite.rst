.. automodule :: nose.suite
:members: