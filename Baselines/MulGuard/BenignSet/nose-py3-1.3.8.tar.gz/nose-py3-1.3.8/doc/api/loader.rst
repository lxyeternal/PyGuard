.. automodule :: nose.loader
:members: