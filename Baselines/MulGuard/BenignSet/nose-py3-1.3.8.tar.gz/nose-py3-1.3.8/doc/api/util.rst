Utility functions
=================

.. automodule :: nose.util
:members: