def moo():
    print
    'covered'
