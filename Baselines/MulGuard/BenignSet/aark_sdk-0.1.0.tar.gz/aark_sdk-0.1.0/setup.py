from setuptools import find_packages, setup

setup(
    name="aark_sdk",
    version="0.1.0",
    description="",
    url="https://github.com/Aark-Digital/python-aark-sdk",
    author="",
    author_email="",
    license="",
    packages=find_packages(include=['aark_sdk', 'aark_sdk.*']),
    install_requires=[],
    classifiers=[
        'Development Status :: 2 - Pre-Alpha',
        'Environment :: MacOS X',
        'Programming Language :: Python :: 3.12'        
    ]
)