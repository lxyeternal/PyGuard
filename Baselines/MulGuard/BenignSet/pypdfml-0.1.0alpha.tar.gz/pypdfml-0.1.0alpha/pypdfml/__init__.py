__title__ = 'pypdfml'
__version__ = '0.1.0alpha'
__description__ = 'Simple XML wrapper for reportlab.'
__license__ = 'unknown'
__author__ = 'Manuel Badzong'
__author_email__ = 'manuel@andev.ch'

__all__ = ['PyPDFML']
from pypdfml import PyPDFML
