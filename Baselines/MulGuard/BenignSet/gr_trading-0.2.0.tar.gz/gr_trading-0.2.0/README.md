# gr-trading

Comandos para cálculos de gerenciamento de risco no trading


