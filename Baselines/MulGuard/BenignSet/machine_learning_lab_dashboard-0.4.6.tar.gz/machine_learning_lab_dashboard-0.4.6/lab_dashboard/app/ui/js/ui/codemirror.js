// import * as _CodeMirror from "codemirror";
define(["require", "exports"], function (require, exports) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    // let CodeMirror = _CodeMirror
    let CodeMirror = window.CodeMirror;
    exports.CodeMirror = CodeMirror;
});
