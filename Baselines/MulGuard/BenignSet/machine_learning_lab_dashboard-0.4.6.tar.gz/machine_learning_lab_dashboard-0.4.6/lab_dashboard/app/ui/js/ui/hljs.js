define(["require", "exports"], function (require, exports) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    let highlight = window.hljs.highlight;
    exports.highlight = highlight;
});
