from kzphoneme.main import Phoneme
