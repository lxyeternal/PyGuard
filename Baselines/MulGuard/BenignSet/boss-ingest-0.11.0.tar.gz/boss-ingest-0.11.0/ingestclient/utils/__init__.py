from .console import WaitPrinter
