def despedir():
    print("Adios, me despido desde despedidas.despedir()")

class Despedida:
    def __init__(self) :
        print("Adios, me despido desde despedida.__init__()")