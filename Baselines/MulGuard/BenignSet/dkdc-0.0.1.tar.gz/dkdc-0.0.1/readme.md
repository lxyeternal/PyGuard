# dkdc

Don't know, don't care, the tool for me.

