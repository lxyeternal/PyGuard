from django.apps import AppConfig


class VirtualFieldsConfig(AppConfig):
    name = f"{__package__}"
