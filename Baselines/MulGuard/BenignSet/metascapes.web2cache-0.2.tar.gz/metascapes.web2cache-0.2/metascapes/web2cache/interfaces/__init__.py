# -*- extra stuff goes here -*-

from zope.interface import Interface
from zope.i18nmessageid import MessageFactory


class IMetascapesWeb2Tool(Interface):
    """Marker interface
    """
    pass

class IMetascapesWeb2ControlPanelForm(Interface):
    """
    """
    pass