class Nohtml(object):
    pass

if __name__ == "__main__":
    print('It works!')
