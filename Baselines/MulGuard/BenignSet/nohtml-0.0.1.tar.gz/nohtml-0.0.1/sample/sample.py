from nohtml.nohtml import Nohtml


class Nohtml(object):
    pass
