import aws_helper


def main():
    aws_helper.main()
