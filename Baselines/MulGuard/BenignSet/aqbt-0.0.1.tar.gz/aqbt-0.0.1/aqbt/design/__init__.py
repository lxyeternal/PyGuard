"""
design.py

DNA Design Module
"""