"""build_request_parser.py.

Code for parsing the build request document (version ???)
"""
