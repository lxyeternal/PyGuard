"""schema.py.

module containing JSON schemas
"""
