# Common Types

**Generic Aquarium Model**

```json
{
  "__model__": "Sample",
  "uri": "",
  "id": 1
}
```

**Aquarium Sample Properties (?)**

```json
{
    "__model__": "Aquarium Sample",
    "uri": "",
    "id": "",
    "sample_type": {
        "__model__": ""
    },
    "properties": {
        "Haploid(s)": {
            "__ftype__": "array[sample]",
            "values": [
                {
                    "__model__": "Simplified Sample",
                    "uri": ""
                }
            ]
        }
    }
}
```

**DNA JSON**

```json
{
  "__model__": "dna_json"
}
```

**DASi Results JSON**

```json

```

**Terrarium Request JSON**

```json

```

**Aquarium Plan Submission JSON**

```json

```