class LoBioException(Exception):
    """Generic exception."""
