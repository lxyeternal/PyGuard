.. :changelog:


Changelog
---------

v0.1.1 (2013-4-6)
^^^^^^^^^^^^^^^^^^^^

- Fix issue with django logging setup when nose -v.

v0.1 (2013-03-29)
^^^^^^^^^^^^^^^^^^^^

- Initial public (correctly packaged) release. Thanks tox.