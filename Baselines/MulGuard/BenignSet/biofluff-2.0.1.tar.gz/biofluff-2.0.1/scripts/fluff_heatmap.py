#!/usr/bin/env python
import sys

sys.stderr.write("This script is obsolete and has been replaced by:\n\n \033[92mfluff heatmap\033[92m\n\n")
sys.stderr.write("\033[93mType `fluff heatmap -h` for more details\033[0m\n")
sys.exit(0)
