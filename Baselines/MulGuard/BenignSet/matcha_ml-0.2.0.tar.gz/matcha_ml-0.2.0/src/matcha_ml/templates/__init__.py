"""init for the run_template package."""
