"""Docstring to make the cli init visible to the pre commit hooks."""
