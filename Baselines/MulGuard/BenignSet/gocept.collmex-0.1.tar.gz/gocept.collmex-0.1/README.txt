==============
gocept.collmex
==============

A Python binding for the import/export API of Collmex <http://www.collmex.de>.
