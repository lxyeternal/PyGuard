# Copyright (c) 2008 gocept gmbh & co. kg
# See also LICENSE.txt
