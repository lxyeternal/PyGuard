extensions = ["sphinx.ext.autodoc", "sphinxcontrib_django2"]
