__version__ = "0.2"


def version():
    return __version__
