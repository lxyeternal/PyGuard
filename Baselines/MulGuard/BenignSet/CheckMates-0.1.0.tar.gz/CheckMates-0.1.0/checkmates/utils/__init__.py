"""Utility methods."""
from checkmates.utils.gen_utils import classproperty
from checkmates.utils.woodwork_utils import infer_feature_types
