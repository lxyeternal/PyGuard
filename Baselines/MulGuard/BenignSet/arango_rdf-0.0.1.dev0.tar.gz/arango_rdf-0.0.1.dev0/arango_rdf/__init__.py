from arango_rdf.main import ArangoRDF  # noqa: F401
