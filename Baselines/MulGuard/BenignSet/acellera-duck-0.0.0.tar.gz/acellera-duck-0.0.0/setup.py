import setuptools

if __name__ == "__main__":
    setuptools.setup(
        name="acellera-duck",
        version="0.0.0",
        author="Acellera",
        author_email="info@acellera.com",
        description="",
        long_description="",
        long_description_content_type="text/markdown",
        url="",
        classifiers=[
            "Programming Language :: Python :: 3",
            "Operating System :: POSIX :: Linux",
        ],
        packages=setuptools.find_packages(),
        zip_safe=False,
        install_requires=["python"],
    )
