from setuptools import setup, find_packages

setup(
    name='py_in_the_zuel',
    version='0.0.0',
    author='meipulu'
)