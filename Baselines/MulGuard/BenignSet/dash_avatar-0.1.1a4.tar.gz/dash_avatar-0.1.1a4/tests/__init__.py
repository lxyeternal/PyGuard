"""Unit test package for dash_avatar."""
