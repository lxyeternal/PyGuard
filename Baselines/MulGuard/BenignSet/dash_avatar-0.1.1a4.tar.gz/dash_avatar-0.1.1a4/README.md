# Dash Avatar


<p align="center">
<a href="https://pypi.python.org/pypi/dash_avatar">
    <img src="https://img.shields.io/pypi/v/dash_avatar.svg"
        alt = "Release Status">
</a>

<a href="https://github.com/dkedar7/dash_avatar/actions">
    <img src="https://github.com/dkedar7/dash_avatar/actions/workflows/main.yml/badge.svg?branch=release" alt="CI Status">
</a>

<a href="https://dash-avatar.readthedocs.io/en/latest/?badge=latest">
    <img src="https://readthedocs.org/projects/dash-avatar/badge/?version=latest" alt="Documentation Status">
</a>

</p>


Create input-output web applications and user interfaces using Plotly Dash lightning fast


* Free software: MIT
* Documentation: <https://dash-avatar.readthedocs.io>


## Features

* TODO

## Credits

This package was created with [Cookiecutter](https://github.com/audreyr/cookiecutter) and the [zillionare/cookiecutter-pypackage](https://github.com/zillionare/cookiecutter-pypackage) project template.
