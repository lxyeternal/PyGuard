"""Top-level package for Dash Avatar."""

__author__ = """Kedar Dabhadkar"""
__email__ = "kdabhadk@gmail.com"
__version__ = "0.1.0"
