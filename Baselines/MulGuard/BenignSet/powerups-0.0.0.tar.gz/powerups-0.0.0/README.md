Placeholder for an ensemble of upcoming packages
