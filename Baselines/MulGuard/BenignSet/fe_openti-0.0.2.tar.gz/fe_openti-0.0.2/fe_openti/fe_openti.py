def say_hello():
    print("....::...")
