# cmem-plugin-number-conversion

Transform plugin allows users to easily convert numbers from one base to another.

This is a plugin for [eccenca](https://eccenca.com) [Corporate Memory](https://documentation.eccenca.com).

You can install it with the [cmemc](https://eccenca.com/go/cmemc) command line
clients like this:

```
cmemc admin workspace python install cmem-plugin-number-conversion
```

