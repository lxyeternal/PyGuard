python-osinfo
=============

Small python module to retrieve OS information in a unified way
