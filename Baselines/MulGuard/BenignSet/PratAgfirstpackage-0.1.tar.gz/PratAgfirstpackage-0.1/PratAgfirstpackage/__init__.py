from first_module import Education, Name
