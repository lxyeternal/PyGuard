from first_module import Education , Name

a = Education('Prateek', 27,'MCS', 'DCE','UTAustin')
b = Name('Prateek', 27)
print a.get_edu_info()
print a.age_next()
print a.name_len()

print ("It worked!")
