from setuptools import setup

setup(name = 'PratAgfirstpackage' , version = '0.1', description = 'firstpackage' , packages = ['PratAgfirstpackage'] ,
      zip_safe = True)

