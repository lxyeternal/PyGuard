I created this super simple (and also lame) package just to familiarize myself with the process of uploading a package to PypI. Hopefully, better things are in store.

Onwards and Upwards!