from importlib.metadata import version


__title__ = "conspiracies"
__version__ = version(__title__)
__download_url__ = "https://github.com/centre-for-humanities-computing/conspiracies"
