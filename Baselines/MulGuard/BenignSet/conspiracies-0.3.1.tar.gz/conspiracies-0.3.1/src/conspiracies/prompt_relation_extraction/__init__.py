from .data_classes import SpanTriplet, StringTriplet  # noqa F401
from .template_class import (  # noqa F401
    PromptTemplate1,
    PromptTemplate2,
    MarkdownPromptTemplate1,
    MarkdownPromptTemplate2,
    XMLStylePromptTemplate,
)
