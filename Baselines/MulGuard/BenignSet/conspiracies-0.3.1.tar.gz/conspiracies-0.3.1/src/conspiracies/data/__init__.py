from .load import load_gold_triplets  # noqa: F401
