from .knowledge_triplets import KnowledgeTriplets  # noqa F401
from .wrap_model_spacy import SpacyRelationExtractor  # noqa F401
