=====
Usage
=====

To use Search Analysis in a project::

    import search_analysis
