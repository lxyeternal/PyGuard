#!/usr/bin/env python

"""Tests for `search_analysis` package."""


import unittest

from search_analysis import search_analysis


class TestSearch_analysis(unittest.TestCase):
    """Tests for `search_analysis` package."""

    def setUp(self):
        """Set up test fixtures, if any."""

    def tearDown(self):
        """Tear down test fixtures, if any."""

    def test_000_something(self):
        """Test something."""
