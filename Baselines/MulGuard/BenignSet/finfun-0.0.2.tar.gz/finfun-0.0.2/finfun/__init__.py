from finfun.Interest import Interest
