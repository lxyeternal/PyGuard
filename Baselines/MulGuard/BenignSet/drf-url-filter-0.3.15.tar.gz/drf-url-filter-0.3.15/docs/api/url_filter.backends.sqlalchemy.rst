url\_filter.backends.sqlalchemy module
======================================

.. automodule:: url_filter.backends.sqlalchemy
    :members:
    :undoc-members:
    :show-inheritance:
