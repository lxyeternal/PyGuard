url\_filter.backends.base module
================================

.. automodule:: url_filter.backends.base
    :members:
    :undoc-members:
    :show-inheritance:
