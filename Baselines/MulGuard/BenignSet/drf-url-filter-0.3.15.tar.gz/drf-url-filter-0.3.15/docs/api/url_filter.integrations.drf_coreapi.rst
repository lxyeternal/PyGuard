url\_filter.integrations.drf\_coreapi module
============================================

.. automodule:: url_filter.integrations.drf_coreapi
    :members:
    :undoc-members:
    :show-inheritance:
