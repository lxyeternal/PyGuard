url\_filter.integrations.drf module
===================================

.. automodule:: url_filter.integrations.drf
    :members:
    :undoc-members:
    :show-inheritance:
