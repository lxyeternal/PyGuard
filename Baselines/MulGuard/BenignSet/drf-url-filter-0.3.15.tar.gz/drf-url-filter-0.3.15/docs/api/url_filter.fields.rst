url\_filter.fields module
=========================

.. automodule:: url_filter.fields
    :members:
    :undoc-members:
    :show-inheritance:
