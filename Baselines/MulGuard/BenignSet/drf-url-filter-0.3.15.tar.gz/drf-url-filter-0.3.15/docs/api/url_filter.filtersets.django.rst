url\_filter.filtersets.django module
====================================

.. automodule:: url_filter.filtersets.django
    :members:
    :undoc-members:
    :show-inheritance:
