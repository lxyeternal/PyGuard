Changelog
=========

Changes with latest version of libaws
----------------------------------------------

Version 1.0 -------------2016-06-04

1.use boto software to implement base amazon web service
2.enable upload muliti part files to bucket
3.enable max upload retry attemps
4.upload files enable resume from break point
5.real upload speed end progress show
6.enable download files from bucket to local
7.download files enable resume from break point
8.enable max download retry attemps
5.real download speed end progress show



Version 1.0.1 -------------2016-06-04
1.fix tiny bug of init app data path

Version 1.0.2 -------------2016-06-05
1.fix missing logger config file 
2.when download files path is not exist,create it