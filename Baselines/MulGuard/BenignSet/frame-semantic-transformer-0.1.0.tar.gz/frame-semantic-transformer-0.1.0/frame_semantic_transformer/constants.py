MODEL_MAX_LENGTH = 512
OFFICIAL_RELEASES = ["base", "small"]  # TODO: small, large
MODEL_REVISION = "v0.0.1"
