# speach

Managing, annotating, and converting natural language corpuses using popular formats (CoNLL, ELAN, Praat, CSV, JSON, SQLite, VTT, Audacity, TTL, TIG, ISF)

Formerly: [texttaglib](https://pypi.org/project/texttaglib/)
