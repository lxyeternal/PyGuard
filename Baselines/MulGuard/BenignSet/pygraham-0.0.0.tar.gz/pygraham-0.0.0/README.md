# PythonFunctionalMethods
 Purely functional methods for main data structures in python
