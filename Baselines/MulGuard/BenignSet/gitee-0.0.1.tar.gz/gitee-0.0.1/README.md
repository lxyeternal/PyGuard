MyNote

* twine upload dist/*
* python setup.py sdist build