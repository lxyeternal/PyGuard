# Copyright (C) 2015  Custodia Project Contributors - see LICENSE file

from custodia.server import main

if __name__ == '__main__':
    main()
