Custodia Plugins
================

.. toctree::
   :maxdepth: 2

   baseclasses.rst
   authenticators.rst
   authorizers.rst
   consumers.rst
   stores.rst
   clients.rst
