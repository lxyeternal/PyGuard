Clients
=======

.. autosummary::
   :nosignatures:

   custodia.client.CustodiaHTTPClient
   custodia.client.CustodiaSimpleClient
   custodia.client.CustodiaKEMClient

.. autoclass:: custodia.client.CustodiaHTTPClient
    :members:
    :undoc-members:
    :show-inheritance:

.. autoclass:: custodia.client.CustodiaSimpleClient
    :members:
    :undoc-members:
    :show-inheritance:

.. autoclass:: custodia.client.CustodiaKEMClient
    :members:
    :undoc-members:
    :show-inheritance:
