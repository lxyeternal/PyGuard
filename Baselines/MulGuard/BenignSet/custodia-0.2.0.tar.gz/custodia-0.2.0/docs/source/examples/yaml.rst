PyYAML constructor
==================

:download:`yaml_ext.py <yaml_ext.py>`

.. literalinclude:: yaml_ext.py
