from exstats import median, quartileList, quartiles, iqr, mode, mean
