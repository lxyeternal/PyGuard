#!/usr/bin/python3
# -*- coding: utf-8 -*-
def main():
    print('test')
