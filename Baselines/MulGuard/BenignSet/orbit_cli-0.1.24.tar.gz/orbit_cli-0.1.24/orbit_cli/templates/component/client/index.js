import {{ project }} from './src/{{ project }}.vue';
export default {{ project }}