def tup2str(tup):
    return ",".join(map(str, tup))
