# shell-like-cui

```sh
pip install shelllikecui
```

## todo

multithread

linux support
