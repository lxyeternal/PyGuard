class Jolt:
    pass