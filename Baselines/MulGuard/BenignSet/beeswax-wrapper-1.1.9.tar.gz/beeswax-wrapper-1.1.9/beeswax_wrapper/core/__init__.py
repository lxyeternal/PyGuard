"""
Core components of the API
Includes:
- Base components for generic web APIs
- exceptions (beeswax specific)
- beeswax components for the beeswax specific API including authentication
"""
