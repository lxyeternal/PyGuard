"""
API modules for the beeswax API
contains specific access classes for grouped endpoints
can be used as standalone "micro" APIs to the grouped endpoints
"""
