"""
Components for credential management
Specific to beeswax
Can set and get credentials from the keychain
"""
