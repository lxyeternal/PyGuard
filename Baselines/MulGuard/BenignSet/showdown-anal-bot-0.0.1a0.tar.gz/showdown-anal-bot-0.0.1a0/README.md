# Pokemon Showdown analysis bot/tools

`python -m showdown_anal_bot`