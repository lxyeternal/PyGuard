bully_messages  = [
    'Your dad doesn\'t like you.',
    'Your mom doesn\'t like you.',
    'Your parents called, they want a refund.',
    'Your parents called, they want a divorce.',
    'Your parents don\'t like you.',
    'Your parents abondoned you at birth.',
    'How\'s your parents\' divorce?',
    'Don\'t you think you should lose some weight?',
    'You\'re fat.',
    'You\'re ugly.',
    '{}\' parents are disappointed.',

]