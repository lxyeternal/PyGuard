from djongo.exceptions import NotSupportedError, print_warn

print_warn('aggregation')

