class KeraFlowError(Exception):
    pass
