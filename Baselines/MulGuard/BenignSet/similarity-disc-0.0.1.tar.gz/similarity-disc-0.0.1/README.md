# Codigo para la tesis "Algoritmo para el cálculo acelerado de distancias conceptuales"

## Estado
#### En desarrollo
