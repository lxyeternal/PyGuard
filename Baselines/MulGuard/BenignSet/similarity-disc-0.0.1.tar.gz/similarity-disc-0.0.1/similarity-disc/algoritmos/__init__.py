from disc_python.src.algoritmos.aproximacion import *
from disc_python.src.algoritmos.determistas import *
from disc_python.src.algoritmos.paralelos import *
