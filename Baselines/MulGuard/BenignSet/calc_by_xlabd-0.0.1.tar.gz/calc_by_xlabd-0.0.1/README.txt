This is a very basic calculator.
It can add, subtract, multiply, and divide.
