def Divide(x, y):
    return x/y
