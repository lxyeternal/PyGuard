def Multiply(x, y):
    return x*y
