def Subtraction(x, y):
    return x-y
