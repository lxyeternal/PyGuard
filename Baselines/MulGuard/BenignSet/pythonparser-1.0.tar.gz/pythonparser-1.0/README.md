See http://m-labs.hk/pythonparser/.
