import sys
sys.path.append( '../pymarc' )

