security_activate = True

VERIFY_PUBLIC_KEY_PATH = r"__client_config__/public_verify_key.rsa"

CHACK_MESSAGE = "check"