
defulte_ip = "127.0.0.1"
defulte_port = 84
get_dns_address = False

recv_package_size = 10000
upload_package_size = int(recv_package_size * 0.30)
download_package_size = int(recv_package_size * 0.30)

