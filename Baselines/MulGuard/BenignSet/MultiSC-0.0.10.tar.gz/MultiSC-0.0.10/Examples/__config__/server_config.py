# server ip
IP = "0.0.0.0"

# server port
PORT = 84

# connection queue size in the server
QUEUE_SIZE = 50

get_new_connections = True

check_black_list = True
