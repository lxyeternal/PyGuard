ip = "127.0.0.1"

port = 27017

db_name = "managmentServer"

default_name = "server"

default_password = "serverpass"

virtual_db_name = "VirtualDB"

virtual_db_default_name = "virtualserevr"

virtual_db_default_password = "virtualserevrpass"

timeout = 1500  # 5 seconds

USERS_TABLE_NAME = "users"

USERS_INFO_TABLE_NAME = "users_info"

MS_TABLE_NAME = "ms"

LOGS_TABLE_NAME = "ms_logs"

COMPANYS_TABLE_NAME = "companys"

COMPANYS_INFO_TABLE_NAME = "companys_info"

FILE_INFO_TABLE = "files_info"

SERVERS_TABLE = "ServersInfo"
