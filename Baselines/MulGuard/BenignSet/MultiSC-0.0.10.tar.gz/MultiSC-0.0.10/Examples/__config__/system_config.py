root_path = ""  # runtime update
switch_to_root_path = False  # root path updated?

quick_setup_mod = False

debug = False  # debug mod?
