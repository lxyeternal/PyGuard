#  block pentest monitor
BlockPentestActive = True
BlockPentestMaxErrors = 10
