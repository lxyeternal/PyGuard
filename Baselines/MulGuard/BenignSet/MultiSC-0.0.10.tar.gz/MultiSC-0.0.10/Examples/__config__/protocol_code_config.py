arg_not_found = 404

server_error = 500

ok = 200

format_error = 100

argument_invalid = 512

db_error = 969

action_not_allow = 300
