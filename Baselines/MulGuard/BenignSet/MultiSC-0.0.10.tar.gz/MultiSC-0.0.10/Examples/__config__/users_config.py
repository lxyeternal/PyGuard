# new user default info

register_ml_coin = 0

is_admin = False

new_user_values = {
    "ml_coin": register_ml_coin,
    "db_ids": [],
    "is_admin": is_admin,
    "download_list": [],
    "email_address": None,
}
