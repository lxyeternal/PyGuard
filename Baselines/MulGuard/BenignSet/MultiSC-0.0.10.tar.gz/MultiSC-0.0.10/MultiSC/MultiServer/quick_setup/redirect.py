from __config__ import system_config as config


def start_quick_setup_mod():
    config.quick_setup_mod = True
