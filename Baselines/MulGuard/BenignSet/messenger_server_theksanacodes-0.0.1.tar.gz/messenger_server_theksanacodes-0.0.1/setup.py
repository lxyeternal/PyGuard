from setuptools import setup, find_packages

setup(
    name='messenger_server_theksanacodes',
    version='0.0.1',
    description='Messenger server',
    author='oxana',
    author_email='ddd.d@google.com',
    packages=find_packages(),
    install_requires=['PyQt5', 'sqlalchemy']
)
