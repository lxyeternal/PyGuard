//go:build !linux && !windows
// +build !linux,!windows

package pmtud

const (
	DisablePathMTUDiscovery = true
)
