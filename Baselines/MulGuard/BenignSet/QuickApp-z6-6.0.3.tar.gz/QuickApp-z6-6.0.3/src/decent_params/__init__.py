__version__ = '1.2.0'

from .utils import UserError

class Choice(list):
    pass 

from .decent_param import *
from .decent_params_imp import *
from .exceptions import *
