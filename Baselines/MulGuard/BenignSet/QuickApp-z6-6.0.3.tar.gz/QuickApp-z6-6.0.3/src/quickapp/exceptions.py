

class QuickAppException(Exception):
    pass
