# 
# 
# __all__ = ['GeneratedReport']
# 
# 
# class GeneratedReport():
# 
#     def __init__(self, filename, key, report_job_id):
#         self.filename = filename
#         self.key = key
#         self.report_job_id = report_job_id
