from .inject import setup

__all__ = ['setup']
