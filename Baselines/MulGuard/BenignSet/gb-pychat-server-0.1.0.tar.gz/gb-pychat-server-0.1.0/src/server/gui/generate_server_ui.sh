poetry run python -m PyQt6.uic.pyuic -o main_window.py -x server_gui.ui
poetry run python -m PyQt6.uic.pyuic -o history_window.py -x server_gui_history.ui
poetry run python -m PyQt6.uic.pyuic -o clients_window.py -x server_gui_clients.ui
