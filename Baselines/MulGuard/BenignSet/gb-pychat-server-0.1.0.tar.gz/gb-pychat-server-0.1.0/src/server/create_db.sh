poetry run alembic revision --autogenerate -m "initial"
poetry run alembic upgrade head
