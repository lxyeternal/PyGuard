# My Mimic
```
⠀⠀⠀⠀⠀⠀⠀⠀⠀⣀⡀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢀⣴⣶⣶⣦⣄⣀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⢠⢊⢽⣝⡆⣫⣷⣌⣦⣤⡐⠾⣿⣷⣄⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⣠⣾⣿⣿⣾⣯⣿⣯⣷⣦⣄⠀⠀⠀⠀⠀⠀⠀⠀⠀
⠀⡠⢤⣜⠺⢟⡩⡇⢹⣉⡟⣰⠻⣯⢇⣿⣿⣿⣦⣄⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢀⣠⣾⣿⣿⣿⣿⣿⣿⣿⠿⠿⠿⠿⠷⠄⠀⠀⠀⠀⠀⠀⠀
⢸⢰⣻⡟⣄⢈⣖⠹⢺⠰⠷⣏⢱⣾⣿⣿⣿⣿⣾⣿⣷⣶⣶⣤⣤⠠⠐⠂⠀⠀⠐⠒⠠⣄⣤⣤⣶⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠁⠋⠳⣄⠫⡐⣉⠆⡓⢌⢂⢿⢹⣿⡛⢿⣿⣿⣿⣿⣿⣿⠟⠁⠀⠀⠀⠀⠀⢀⠀⢸⣿⣿⣿⣿⣿⣿⣿⣿⣿⡟⠛⠻⠿⠃⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠈⡔⣡⠒⣸⠞⡌⢂⢎⣥⣷⣿⢨⣿⣿⣿⣿⡟⠁⡀⠀⠠⠀⡐⠀⠡⠀⠀⠀⢿⣿⣿⣿⣿⣿⣿⣿⣿⠃⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠸⣦⣳⡆⣞⣴⡿⠃⠀⠘⠛⠛⣿⣿⣿⡿⢀⡞⢣⡇⠀⡀⠰⡴⠟⡄⠆⢃⠘⣿⣿⣿⣿⣿⣿⣿⣿⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⢠⢛⢻⠏⠉⠀⠀⠀⠀⠀⠀⠙⠛⡫⢁⠸⡀⠸⠅⢀⠡⢸⡇⠘⡿⠀⠈⠘⡌⠛⠿⢿⡟⠉⠉⠉⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⡜⠀⢸⠀⠀⠀⠀⠀⠀⠀⠀⠀⢀⣟⡆⢠⠈⠁⢀⠂⠀⡀⠉⢒⠇⠠⢀⣭⣔⡩⢐⠂⡇⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⢇⢀⡦⠀⠀⠀⠀⠀⠀⠀⢀⣀⠀⣯⡇⢀⡘⢷⣶⢶⠶⣶⣚⡟⡄⣴⠻⣭⣟⣷⡈⢒⣃⣀⣀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⢸⡈⠐⠣⠄⣀⡀⠀⣠⡾⣩⢏⡼⣹⢏⣧⡂⠌⡌⠻⣉⠎⡑⢎⢧⡐⢯⣷⢳⡾⡝⣠⠿⣏⡟⣿⣟⣦⡄⠀⠀⣀⣀⡀⠤⣄⠀⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠙⠦⠄⣐⡀⢀⠠⠉⠉⠘⡷⣎⢷⡹⣎⢷⡻⣖⢨⣑⣨⠘⢩⠘⠌⣃⠢⢉⣋⣵⠾⣍⢳⣬⣛⢶⣻⡮⡑⠆⠀⢀⣀⣠⠀⠈⡆⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠉⢱⣧⣥⣾⢿⡜⣯⢳⣝⢮⣳⡇⠁⠒⠤⢋⢏⢩⡙⢭⢉⠧⡈⣿⡝⣮⢳⢮⡝⣮⢷⣻⢾⡏⠉⠀⠀⠘⡦⠀⢹⡀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢿⡽⣯⠿⣽⣞⡷⣞⡷⣯⠛⠀⠀⣠⣤⠾⡶⣞⣤⣅⠂⠀⢻⣽⣎⣟⣮⡽⣯⢿⣹⡿⠀⠀⠀⠀⠀⠸⢄⣈⡇⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠈⠻⣽⣻⠷⣾⡽⣯⠟⠃⠀⢠⣾⢻⣬⢛⡵⢫⡞⣭⢻⡄⠀⠙⠾⣽⢾⣽⣳⡯⠛⠀⠀⠀⠀⠀⡠⠊⠉⠀⠈⠑⠢⡀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠈⠙⣩⠁⠀⠀⠀⠀⣼⣇⡳⣌⠳⣜⢣⡞⣵⣫⢽⠀⠀⢀⠤⡉⠽⠀⠀⠀⠀⡠⠖⠂⠒⠁⠀⡀⠀⡀⠀⠀⣠⠭⡁⠉⡀
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢻⡅⡄⠀⠀⠀⢿⡲⣝⡬⣓⢮⡳⣝⢮⣳⢻⠀⡌⢃⢚⢰⠃⠀⠀⠀⠀⢧⢀⡰⠊⠙⣼⠁⡬⡄⢰⠦⢄⡁⠘⢫⠀
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⣠⡾⣻⢟⣿⣴⠠⢌⠻⣧⣻⣝⣮⣳⣏⡷⡽⣣⡵⣞⠿⣯⢿⣄⠀⠀⠀⠀⠀⠀⠀⠀⡠⠃⠀⡇⢸⠀⠑⢤⠐⠴⠞⠀
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢰⣿⣱⣟⣾⣳⣟⣷⡨⠒⣌⠱⡛⢚⠓⣛⢙⣰⣿⡹⣞⡽⣎⢷⣻⡄⠀⠀⠀⠀⠀⠀⠐⢧⣀⣠⠇⠘⠶⠀⠞⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢀⠽⢷⣻⣞⣧⣟⡾⣽⠧⠣⢄⠣⡘⠤⡉⢤⠃⣼⣷⣻⢾⣵⣻⠞⠉⠓⠤⣀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⣀⡄⠊⠁⠀⢀⣿⣞⣷⣫⣽⡞⠐⢣⣬⣆⣁⣢⣑⣢⣵⡞⣷⣯⣟⣾⣽⠂⣤⣀⠀⠀⢉⡔⠒⣤⡀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠀⠀⣴⠞⠉⠀⢠⣴⠞⠋⠉⠙⠛⠛⠉⠀⠀⠀⠀⠈⠉⠉⠉⠁⠀⠀⠈⠘⠛⠉⠁⠀⠀⠉⠛⠶⡏⠀⠀⠀⣷⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠀⣎⠈⠐⠒⡖⣾⡉⢷⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠑⣫⢭⠶⣋⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠀⠈⠳⠶⠹⢜⡱⡸⢌⡳⢄⡀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠰⣈⢦⠓⡼⡄⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠀⢀⣴⣶⣄⡀⠈⠑⣇⡝⣌⣿⣷⡄⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠈⣣⡛⡔⡻⣄⠀⠀⠀⠀⠀⣀⡀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⢠⣿⣿⠛⢻⣷⣤⣾⣿⣿⣿⣿⣿⡿⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢰⣿⣷⣌⣱⣿⣷⣄⡀⣠⣾⣿⢿⣧⡀⠀
⠀⠀⠀⠀⠀⠀⠀⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⡿⠟⠁⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠺⣿⣿⣿⣿⣿⣿⣿⣿⣿⣷⣾⣿⣻⣷⡀
⠀⠀⠀⠀⠀⠀⠀⠙⠿⣿⣿⣿⣿⣿⣿⡿⠟⠉⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠈⠉⠛⢿⣿⣿⣿⣟⣿⣻⣽⣳⣯⣿⠇
⠀⡀⠀⠀⠀⠀⠀⠀⠀⠀⠉⠉⠉⠉⠁⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠉⠛⠛⠛⠻⠷⠿⠷⠟⠋⠀
                                                                            By CenturyBoys
```


My Mimic is a function decorator for cache/memoization. They use the args and kwargs to create a hash to storage the function call result after the first call all function invoke will use already storage result.  

### Configuration

Using `mr.Mime` from Mimic allowed you to use the default config or create a self one. By default, an in-memory state are used you can implement your own state resolver using the interface IState.

Below you can see the interface contract
```python
from abc import ABC, abstractmethod

class IState(ABC):
    """
    State interface
    """

    @abstractmethod
    def sync_get(self, key: str):
        """
        Sync get implementation
        :param key: Str
        :return:
        """

    @abstractmethod
    def sync_set(self, key: str, value: any, ttl: int = None):
        """
        Sync set implementation
        :param key: Str
        :param value: Any
        :param ttl: int. Seconds that the cache will have to live. Set None to never die
        :return:
        """

    @abstractmethod
    async def async_get(self, key: str):
        """
        Async get implementation
        :param key: Str
        :return:
        """

    @abstractmethod
    async def async_set(self, key: str, value: any, ttl: int = None):
        """
        Async set implementation
        :param key: Str
        :param value: Any
        :param ttl: int. Seconds that the cache will have to live. Set None to never die
        :return:
        """

```

To configure a new state you need to use `mr.Mime.set_config` function passing a config instance.

```python
import mr

class MyState(mr.IState):
    def sync_get(self, key: str):
        pass

    def sync_set(self, key: str, value: any, ttl: int = None):
        pass

    async def async_get(self, key: str):
        pass

    async def async_set(self, key: str, value: any, ttl: int = None):
        pass

mr.Mime.set_config(config=mr.Config(state=MyState))
```

### How to use

For that we use `mr.Mime` as decorator that receive a ttl as argument. That means the ttl is the seconds that the cache will have to live. Set None to never die.

Mime works fine with sync and async functions too.

```python
import time
import mr

@mr.Mime(ttl=1)
def cached_callback(param_a: int, param_b: int):
    print("Function was called")
    return param_a + param_b

result = cached_callback(1, 2)
print(result)
result = cached_callback(1, 2)
print(result)
time.sleep(2)
print("Await 2 seconds")
result = cached_callback(1, 2)
print(result)
```
The output will be

```bash
Function was called
3
3
Await 2 seconds
Function was called
3
```