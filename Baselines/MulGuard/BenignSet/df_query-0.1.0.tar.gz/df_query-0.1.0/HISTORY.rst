=======
History
=======

0.1.0 (2021-05-16)
------------------

* First release on PyPI.
