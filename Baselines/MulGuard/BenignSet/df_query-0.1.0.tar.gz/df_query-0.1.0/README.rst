=======
DFQuery
=======


.. image:: https://img.shields.io/pypi/v/df_query.svg
        :target: https://pypi.python.org/pypi/df_query

.. image:: https://img.shields.io/travis/rjdscott/df_query.svg
        :target: https://travis-ci.com/rjdscott/df_query

.. image:: https://readthedocs.org/projects/df-query/badge/?version=latest
        :target: https://df-query.readthedocs.io/en/latest/?version=latest
        :alt: Documentation Status




A Pandas DataFrame SQL Query Utility


* Free software: MIT license
* Documentation: https://df-query.readthedocs.io.


Features
--------

* TODO

Credits
-------

This package was created with Cookiecutter_ and the `audreyr/cookiecutter-pypackage`_ project template.

.. _Cookiecutter: https://github.com/audreyr/cookiecutter
.. _`audreyr/cookiecutter-pypackage`: https://github.com/audreyr/cookiecutter-pypackage
