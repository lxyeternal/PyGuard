"""Top-level package for DFQuery."""

__author__ = """Rob Scott"""
__email__ = 'rob@rjdscott.com'
__version__ = '0.1.0'

from df_query.query_context import QueryContext
