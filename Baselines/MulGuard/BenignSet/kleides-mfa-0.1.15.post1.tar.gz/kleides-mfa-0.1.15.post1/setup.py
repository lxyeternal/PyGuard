"""The kleides-mfa setup script."""

from setuptools import setup

if __name__ == '__main__':
    setup(use_scm_version=True)
