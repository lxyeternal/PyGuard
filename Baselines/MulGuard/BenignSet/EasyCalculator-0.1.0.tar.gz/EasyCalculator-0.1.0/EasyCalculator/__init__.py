
from .EasyCalculator import add_two_numbers
from .EasyCalculator import subtract_two_numbers

