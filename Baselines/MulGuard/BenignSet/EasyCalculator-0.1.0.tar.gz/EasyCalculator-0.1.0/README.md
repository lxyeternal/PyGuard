Easy Calculator

Add, Subtract, multiply and divide any two numbers.