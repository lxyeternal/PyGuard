logger_level = 3
do_table = False
do_recursive = False
do_boolean_configs = False
unit_pc_format = False
defines = None
