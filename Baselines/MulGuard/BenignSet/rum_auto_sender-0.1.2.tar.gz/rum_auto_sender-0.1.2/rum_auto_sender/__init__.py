from rum_auto_sender.auto_sender import AutoSender

__version__ = "0.1.2"
__author__ = "liujuanjuan1984"
