INSTALLED_APPS = [
    "appomatic_userena",
    "userena",
    "guardian",
    "easy_thumbnails"
]

