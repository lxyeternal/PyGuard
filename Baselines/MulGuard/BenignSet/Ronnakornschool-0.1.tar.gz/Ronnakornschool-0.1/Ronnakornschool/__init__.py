# __init__.py
from Ronnakornschool.Ronschool import Student, SpecialStudent
