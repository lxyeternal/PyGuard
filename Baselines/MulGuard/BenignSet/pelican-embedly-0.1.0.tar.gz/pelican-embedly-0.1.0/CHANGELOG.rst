
Changelog
=========

0.1.0 (2017-07-23)
------------------

* First release on PyPI.
