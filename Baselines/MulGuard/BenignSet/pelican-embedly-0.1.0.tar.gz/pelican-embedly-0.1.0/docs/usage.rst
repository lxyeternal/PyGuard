=====
Usage
=====

To use pelican_embedly in a project::

	import pelican_embedly
