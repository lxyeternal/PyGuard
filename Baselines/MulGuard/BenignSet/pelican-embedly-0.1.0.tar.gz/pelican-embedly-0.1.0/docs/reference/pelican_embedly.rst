pelican_embedly
===============

.. testsetup::

    from pelican_embedly import *

.. automodule:: pelican_embedly
    :members:
