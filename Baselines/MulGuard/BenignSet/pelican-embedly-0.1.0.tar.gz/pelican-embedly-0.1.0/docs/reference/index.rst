Reference
=========

.. toctree::
    :glob:

    pelican_embedly*
