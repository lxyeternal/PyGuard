from pelican_embedly.card_rst import register  # noqa
