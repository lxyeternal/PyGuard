# BitGN MLP Client

Python client for the BitGN Machine Learning Pipelines project.