""" version for exif2findertags """

__version__ = "0.1.4"