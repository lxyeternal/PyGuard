pyhackernews
============

mimicking HN look and feel in terminal


HN in terminal with tmux:

.. image:: http://i.imgur.com/890LAsb.png

instalation and usage:
=====================

``pip install pyhackernews``

and then in terminal:

``hn``
