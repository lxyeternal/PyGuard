""" Interfacing python-canopen-node with python-canopen
"""

from .base import AdapterABC


class CANOpenAdapter(AdapterABC):
    pass
