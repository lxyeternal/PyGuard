import pytest

def test_1():
    assert True
    
def test_2():
    assert True
