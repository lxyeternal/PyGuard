## Parte 2 para la práctica 1 del curso de Optimización 2 2021-1: implementación de método numérico para resolver problemas de optimización convexa.

* Data set: por definir

**Profesor**: Erick Palacios Moreno

**Equipo 5.**
______

| Github User  | Actividad a realizar                                                       |
|:------------:|:--------------------------------------------------------------------------:|
| @carlosrlpzi | 1. Programar el método numérico y seleccionar los ejemplos para los tests. |
| @lobolc      | 1. Programar el método numérico y seleccionar los ejemplos para los tests. |
| @lgarayva    | 2. Construir github workflows (build & push y tests) y documentar paquete. |
| @ZarCorvus   | 3. _Project Manager_. Búsqueda de ejemplos y documentación para las tareas. Crear botón de binder. Publicar documentación del paquete online. |

______

Para una experiencia interactiva con el código de nuestro repositorio, puedes utilizar el botón [binder](https://mybinder.org/):

[![Binder](https://mybinder.org/badge_logo.svg)](https://mybinder.org/v2/gh/optimizacion-2-2021-1-gh-classroom/practica-1-segunda-parte-jlrzarcor.git/main)

______

** Estructura de la información:**
* Por definir

______
**Referencias:**

* Por definir
