=================
Simple Calculator
=================


.. image:: https://img.shields.io/pypi/v/simple_calculator.svg
        :target: https://pypi.python.org/pypi/simple_calculator

.. image:: https://img.shields.io/travis/anilkulkarni87/simple_calculator.svg
        :target: https://travis-ci.com/anilkulkarni87/simple_calculator

.. image:: https://readthedocs.org/projects/simple-calculator-akarni/badge/?version=latest
        :target: https://simple-calculator-akarni.readthedocs.io/en/latest/?version=latest
        :alt: Documentation Status


.. image:: https://pyup.io/repos/github/anilkulkarni87/simple_calculator/shield.svg
     :target: https://pyup.io/repos/github/anilkulkarni87/simple_calculator/
     :alt: Updates



A tutorial package to do simple calculations


* Free software: MIT license
* Documentation: https://simple-calculator-akarni.readthedocs.io.



Features
--------

* TODO

Credits
-------

This package was created with Cookiecutter_ and the `audreyr/cookiecutter-pypackage`_ project template.

.. _Cookiecutter: https://github.com/audreyr/cookiecutter
.. _`audreyr/cookiecutter-pypackage`: https://github.com/audreyr/cookiecutter-pypackage
