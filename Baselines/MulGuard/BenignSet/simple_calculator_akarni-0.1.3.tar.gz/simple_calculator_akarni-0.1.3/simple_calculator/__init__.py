"""Top-level package for Simple Calculator."""

__author__ = """Anil Kulkarni"""
__email__ = 'anil77k@gmail.com'
__version__ = '0.1.3'
