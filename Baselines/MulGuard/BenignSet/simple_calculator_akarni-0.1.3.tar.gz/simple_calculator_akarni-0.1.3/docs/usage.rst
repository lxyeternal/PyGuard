=====
Usage
=====

To use Simple Calculator in a project::

    import simple_calculator
