### @export "list-lexers"
pygmentize -L lexers

### @export "list-styles"
pygmentize -L styles

### @end
