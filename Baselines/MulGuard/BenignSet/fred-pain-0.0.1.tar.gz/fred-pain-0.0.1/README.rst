===========
 fred-pain
===========

`PAIN`_ interface for `FRED`_.

.. _PAIN: https://github.com/stinovlas/django-pain
.. _FRED: https://fred.nic.cz
