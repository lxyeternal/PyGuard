
.. If you created a package, create one automodule per module in the package.

.. automodule:: adafruit_fancyled.adafruit_fancyled
   :members:

.. automodule:: adafruit_fancyled.fastled_helpers
   :members: