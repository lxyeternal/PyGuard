Simple test
------------

Ensure your device works with this simple test.

.. literalinclude:: ../examples/neopixel_rotate.py
    :caption: examples/neopixel_rotate.py
    :linenos:

.. literalinclude:: ../examples/cpx_helper_example.py
    :caption: examples/cpx_helper_example.py
    :linenos:

.. literalinclude:: ../examples/cpx_rotate.py
    :caption: examples/cpx_rotate.py
    :linenos: