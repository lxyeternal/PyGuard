from buildbot.www.plugin import Application
ep = Application(__name__, "Buildbot SiteNav plugin")
