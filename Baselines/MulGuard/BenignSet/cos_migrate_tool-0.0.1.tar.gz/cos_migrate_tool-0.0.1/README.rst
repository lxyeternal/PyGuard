yugong
#############

A simple tool for migrating data between object storage services.

INSTALL
-----------

use pip or easy_install ::

    pip install migrate_tool


HOW TO USE
---------------

hello wold

ISSUE
---------------

send emails to liuchang0812#gmail.com or post an issue

TODO
---------------

1. one
2. two
3. three