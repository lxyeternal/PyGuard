Overview
========

OFSP registers the Zope 2 OFS content types.
