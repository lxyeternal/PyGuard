"""A discord bot talking Japanese. """

from .version import __doc__ as VERSION
