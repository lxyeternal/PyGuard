# NOTE: This file must not contain anything but the string literal of the
# software version!
'0.3.0'
