pygeppetto
==========

Home of the Geeppetto Python API. The API allows to create a Geppetto Model from Python.

Installation
============

Until pygeppetto is still in development, it is highly recommended to use a
virtualenv in order to deploy it. Once you have a dedicated virtualenv, you can
simply install pygeppetto:

.. code-block:: bash

    python setup.py install

For further information please visit: https://github.com/openworm/pygeppetto

