"Main interface for greengrass service"

from mypy_boto3_greengrass.client import Client

__all__ = ("Client",)
