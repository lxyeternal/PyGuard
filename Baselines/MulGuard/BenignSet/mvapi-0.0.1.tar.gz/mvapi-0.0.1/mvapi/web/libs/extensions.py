from flask_cors import CORS


cors = CORS()
