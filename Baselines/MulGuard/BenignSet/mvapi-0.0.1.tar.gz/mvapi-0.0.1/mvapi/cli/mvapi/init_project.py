import click


@click.command()
def init_project():
    """Initialize new project"""

    print('init project')
