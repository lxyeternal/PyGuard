from mvapi.cli.mvapi import cli

__version__ = '0.0.1'


def main():
    cli()
