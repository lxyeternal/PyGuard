# coding: utf-8

name = 'Shottycli - is a command-line interface for Shotty app'

