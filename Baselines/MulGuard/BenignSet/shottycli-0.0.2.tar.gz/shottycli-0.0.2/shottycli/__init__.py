print("I'm Shotty")
