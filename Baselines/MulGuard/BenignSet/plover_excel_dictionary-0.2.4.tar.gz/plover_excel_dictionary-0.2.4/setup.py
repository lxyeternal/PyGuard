#!/usr/bin/env python3

__requires__ = '''
setuptools>=34.4.0
'''

from setuptools import setup


setup()
