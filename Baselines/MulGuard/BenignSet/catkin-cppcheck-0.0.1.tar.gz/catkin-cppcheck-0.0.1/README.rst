Catkin CppCheck
===============

.. image:: https://travis-ci.org/nnarain/catkin-cppcheck.svg?branch=master
    :target: https://travis-ci.org/nnarain/catkin-cppcheck

.. image:: https://img.shields.io/pypi/v/catkin-cppcheck.svg
    :target: https://pypi.python.org/pypi/catkin-cppcheck


Run cppcheck on catkin packages.

Installation
------------

    pip install catkin-cppcheck

Usage
-----

    catkin cppcheck

View help and options:

    catkin cppcheck -h