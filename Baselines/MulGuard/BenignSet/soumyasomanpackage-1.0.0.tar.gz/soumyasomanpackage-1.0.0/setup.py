import setuptools
setuptools.setup(
    name="soumyasomanpackage",
    version="1.0.0",
    author="Soumya Somasundaran",
    author_email="soumyas567@gmail.com",
    description="packt example package",
    long_description="This is the longer description and will appear in the web.",
    py_modules=["packt"],classifiers=["Programming Language :: Python :: 3","Operating System :: OS Independent",],)