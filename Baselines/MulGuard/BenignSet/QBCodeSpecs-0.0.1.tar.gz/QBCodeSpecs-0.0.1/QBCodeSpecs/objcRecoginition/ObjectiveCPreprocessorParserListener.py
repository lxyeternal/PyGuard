# Generated from ObjectiveCPreprocessorParser.g4 by ANTLR 4.7.1
from QBCodeSpecs.antlr4 import *

# This class defines a complete listener for a parse tree produced by ObjectiveCPreprocessorParser.
class ObjectiveCPreprocessorParserListener(ParseTreeListener):

    # Enter a parse tree produced by ObjectiveCPreprocessorParser#preprocessorImport.
    def enterPreprocessorImport(self, ctx):
        pass

    # Exit a parse tree produced by ObjectiveCPreprocessorParser#preprocessorImport.
    def exitPreprocessorImport(self, ctx):
        print ctx
        pass


    # Enter a parse tree produced by ObjectiveCPreprocessorParser#preprocessorConditional.
    def enterPreprocessorConditional(self, ctx):
        pass

    # Exit a parse tree produced by ObjectiveCPreprocessorParser#preprocessorConditional.
    def exitPreprocessorConditional(self, ctx):
        pass


    # Enter a parse tree produced by ObjectiveCPreprocessorParser#preprocessorDef.
    def enterPreprocessorDef(self, ctx):
        pass

    # Exit a parse tree produced by ObjectiveCPreprocessorParser#preprocessorDef.
    def exitPreprocessorDef(self, ctx):
        pass


    # Enter a parse tree produced by ObjectiveCPreprocessorParser#preprocessorPragma.
    def enterPreprocessorPragma(self, ctx):
        pass

    # Exit a parse tree produced by ObjectiveCPreprocessorParser#preprocessorPragma.
    def exitPreprocessorPragma(self, ctx):
        pass


    # Enter a parse tree produced by ObjectiveCPreprocessorParser#preprocessorError.
    def enterPreprocessorError(self, ctx):
        pass

    # Exit a parse tree produced by ObjectiveCPreprocessorParser#preprocessorError.
    def exitPreprocessorError(self, ctx):
        pass


    # Enter a parse tree produced by ObjectiveCPreprocessorParser#preprocessorWarning.
    def enterPreprocessorWarning(self, ctx):
        pass

    # Exit a parse tree produced by ObjectiveCPreprocessorParser#preprocessorWarning.
    def exitPreprocessorWarning(self, ctx):
        pass


    # Enter a parse tree produced by ObjectiveCPreprocessorParser#preprocessorDefine.
    def enterPreprocessorDefine(self, ctx):
        pass

    # Exit a parse tree produced by ObjectiveCPreprocessorParser#preprocessorDefine.
    def exitPreprocessorDefine(self, ctx):
        pass


    # Enter a parse tree produced by ObjectiveCPreprocessorParser#directiveText.
    def enterDirectiveText(self, ctx):
        pass

    # Exit a parse tree produced by ObjectiveCPreprocessorParser#directiveText.
    def exitDirectiveText(self, ctx):
        pass


    # Enter a parse tree produced by ObjectiveCPreprocessorParser#preprocessorParenthesis.
    def enterPreprocessorParenthesis(self, ctx):
        pass

    # Exit a parse tree produced by ObjectiveCPreprocessorParser#preprocessorParenthesis.
    def exitPreprocessorParenthesis(self, ctx):
        pass


    # Enter a parse tree produced by ObjectiveCPreprocessorParser#preprocessorNot.
    def enterPreprocessorNot(self, ctx):
        pass

    # Exit a parse tree produced by ObjectiveCPreprocessorParser#preprocessorNot.
    def exitPreprocessorNot(self, ctx):
        pass


    # Enter a parse tree produced by ObjectiveCPreprocessorParser#preprocessorBinary.
    def enterPreprocessorBinary(self, ctx):
        pass

    # Exit a parse tree produced by ObjectiveCPreprocessorParser#preprocessorBinary.
    def exitPreprocessorBinary(self, ctx):
        pass


    # Enter a parse tree produced by ObjectiveCPreprocessorParser#preprocessorConstant.
    def enterPreprocessorConstant(self, ctx):
        pass

    # Exit a parse tree produced by ObjectiveCPreprocessorParser#preprocessorConstant.
    def exitPreprocessorConstant(self, ctx):
        pass


    # Enter a parse tree produced by ObjectiveCPreprocessorParser#preprocessorConditionalSymbol.
    def enterPreprocessorConditionalSymbol(self, ctx):
        pass

    # Exit a parse tree produced by ObjectiveCPreprocessorParser#preprocessorConditionalSymbol.
    def exitPreprocessorConditionalSymbol(self, ctx):
        pass


    # Enter a parse tree produced by ObjectiveCPreprocessorParser#preprocessorDefined.
    def enterPreprocessorDefined(self, ctx):
        pass

    # Exit a parse tree produced by ObjectiveCPreprocessorParser#preprocessorDefined.
    def exitPreprocessorDefined(self, ctx):
        pass


