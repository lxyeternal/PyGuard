# Generated from ObjectiveCPreprocessorParser.g4 by ANTLR 4.7.1
# encoding: utf-8
from __future__ import print_function
from QBCodeSpecs.antlr4 import *
from io import StringIO
import sys

def serializedATN():
    with StringIO() as buf:
        buf.write(u"\3\u608b\ua72a\u8133\ub9ed\u417c\u3be7\u7786\u5964\3")
        buf.write(u"\u00e0a\4\2\t\2\4\3\t\3\4\4\t\4\3\2\3\2\3\2\3\2\3\2\3")
        buf.write(u"\2\3\2\3\2\3\2\3\2\3\2\3\2\3\2\3\2\3\2\3\2\3\2\3\2\3")
        buf.write(u"\2\3\2\3\2\3\2\3\2\3\2\3\2\3\2\3\2\3\2\3\2\3\2\3\2\3")
        buf.write(u"\2\3\2\3\2\3\2\5\2,\n\2\5\2.\n\2\3\3\6\3\61\n\3\r\3\16")
        buf.write(u"\3\62\3\4\3\4\3\4\3\4\3\4\3\4\3\4\3\4\3\4\3\4\5\4?\n")
        buf.write(u"\4\3\4\3\4\3\4\3\4\3\4\3\4\3\4\3\4\3\4\3\4\3\4\5\4L\n")
        buf.write(u"\4\5\4N\n\4\3\4\3\4\3\4\3\4\3\4\3\4\3\4\3\4\3\4\3\4\3")
        buf.write(u"\4\3\4\7\4\\\n\4\f\4\16\4_\13\4\3\4\2\3\6\5\2\4\6\2\6")
        buf.write(u"\3\2\u00bc\u00bd\3\2\u00df\u00e0\3\2\u00cf\u00d0\3\2")
        buf.write(u"\u00d3\u00d6\2w\2-\3\2\2\2\4\60\3\2\2\2\6M\3\2\2\2\b")
        buf.write(u"\t\7\u00b8\2\2\t\n\t\2\2\2\n.\5\4\3\2\13\f\7\u00b8\2")
        buf.write(u"\2\f\r\7\u00c1\2\2\r.\5\6\4\2\16\17\7\u00b8\2\2\17\20")
        buf.write(u"\7\u00c2\2\2\20.\5\6\4\2\21\22\7\u00b8\2\2\22.\7\u00c3")
        buf.write(u"\2\2\23\24\7\u00b8\2\2\24.\7\u00c7\2\2\25\26\7\u00b8")
        buf.write(u"\2\2\26\27\7\u00c5\2\2\27.\7\u00d8\2\2\30\31\7\u00b8")
        buf.write(u"\2\2\31\32\7\u00c6\2\2\32.\7\u00d8\2\2\33\34\7\u00b8")
        buf.write(u"\2\2\34\35\7\u00c4\2\2\35.\7\u00d8\2\2\36\37\7\u00b8")
        buf.write(u"\2\2\37 \7\u00be\2\2 .\5\4\3\2!\"\7\u00b8\2\2\"#\7\u00ca")
        buf.write(u"\2\2#.\5\4\3\2$%\7\u00b8\2\2%&\7\u00cb\2\2&.\5\4\3\2")
        buf.write(u"\'(\7\u00b8\2\2()\7\u00bf\2\2)+\7\u00d8\2\2*,\5\4\3\2")
        buf.write(u"+*\3\2\2\2+,\3\2\2\2,.\3\2\2\2-\b\3\2\2\2-\13\3\2\2\2")
        buf.write(u"-\16\3\2\2\2-\21\3\2\2\2-\23\3\2\2\2-\25\3\2\2\2-\30")
        buf.write(u"\3\2\2\2-\33\3\2\2\2-\36\3\2\2\2-!\3\2\2\2-$\3\2\2\2")
        buf.write(u"-\'\3\2\2\2.\3\3\2\2\2/\61\t\3\2\2\60/\3\2\2\2\61\62")
        buf.write(u"\3\2\2\2\62\60\3\2\2\2\62\63\3\2\2\2\63\5\3\2\2\2\64")
        buf.write(u"\65\b\4\1\2\65N\7\u00c8\2\2\66N\7\u00c9\2\2\67N\7\u00d9")
        buf.write(u"\2\28N\7\u00d7\2\29>\7\u00d8\2\2:;\7\u00cd\2\2;<\5\6")
        buf.write(u"\4\2<=\7\u00ce\2\2=?\3\2\2\2>:\3\2\2\2>?\3\2\2\2?N\3")
        buf.write(u"\2\2\2@A\7\u00cd\2\2AB\5\6\4\2BC\7\u00ce\2\2CN\3\2\2")
        buf.write(u"\2DE\7\u00cc\2\2EN\5\6\4\bFK\7\u00c0\2\2GL\7\u00d8\2")
        buf.write(u"\2HI\7\u00cd\2\2IJ\7\u00d8\2\2JL\7\u00ce\2\2KG\3\2\2")
        buf.write(u"\2KH\3\2\2\2LN\3\2\2\2M\64\3\2\2\2M\66\3\2\2\2M\67\3")
        buf.write(u"\2\2\2M8\3\2\2\2M9\3\2\2\2M@\3\2\2\2MD\3\2\2\2MF\3\2")
        buf.write(u"\2\2N]\3\2\2\2OP\f\7\2\2PQ\t\4\2\2Q\\\5\6\4\bRS\f\6\2")
        buf.write(u"\2ST\7\u00d1\2\2T\\\5\6\4\7UV\f\5\2\2VW\7\u00d2\2\2W")
        buf.write(u"\\\5\6\4\6XY\f\4\2\2YZ\t\5\2\2Z\\\5\6\4\5[O\3\2\2\2[")
        buf.write(u"R\3\2\2\2[U\3\2\2\2[X\3\2\2\2\\_\3\2\2\2][\3\2\2\2]^")
        buf.write(u"\3\2\2\2^\7\3\2\2\2_]\3\2\2\2\n+-\62>KM[]")
        return buf.getvalue()


class ObjectiveCPreprocessorParser ( Parser ):

    grammarFileName = "ObjectiveCPreprocessorParser.g4"

    atn = ATNDeserializer().deserialize(serializedATN())

    decisionsToDFA = [ DFA(ds, i) for i, ds in enumerate(atn.decisionToState) ]

    sharedContextCache = PredictionContextCache()

    literalNames = [ u"<INVALID>", u"'auto'", u"'break'", u"'case'", u"'char'", 
                     u"'const'", u"'continue'", u"'default'", u"'do'", u"'double'", 
                     u"<INVALID>", u"'enum'", u"'extern'", u"'float'", u"'for'", 
                     u"'goto'", u"<INVALID>", u"'inline'", u"'int'", u"'long'", 
                     u"'register'", u"'restrict'", u"'return'", u"'short'", 
                     u"'signed'", u"'sizeof'", u"'static'", u"'struct'", 
                     u"'switch'", u"'typedef'", u"'union'", u"'unsigned'", 
                     u"'void'", u"'volatile'", u"'while'", u"'_Bool'", u"'_Complex'", 
                     u"'_Imaginery'", u"'true'", u"'false'", u"'BOOL'", 
                     u"'Class'", u"'bycopy'", u"'byref'", u"'id'", u"'IMP'", 
                     u"'in'", u"'inout'", u"'nil'", u"'NO'", u"'NULL'", 
                     u"'oneway'", u"'out'", u"'Protocol'", u"'SEL'", u"'self'", 
                     u"'super'", u"'YES'", u"'@autoreleasepool'", u"'@catch'", 
                     u"'@class'", u"'@dynamic'", u"'@encode'", u"'@end'", 
                     u"'@finally'", u"'@implementation'", u"'@interface'", 
                     u"'@import'", u"'@package'", u"'@protocol'", u"'@optional'", 
                     u"'@private'", u"'@property'", u"'@protected'", u"'@public'", 
                     u"'@required'", u"'@selector'", u"'@synchronized'", 
                     u"'@synthesize'", u"'@throw'", u"'@try'", u"'atomic'", 
                     u"'nonatomic'", u"'retain'", u"'__attribute__'", u"'__autoreleasing'", 
                     u"'__block'", u"'__bridge'", u"'__bridge_retained'", 
                     u"'__bridge_transfer'", u"'__covariant'", u"'__contravariant'", 
                     u"'__deprecated'", u"'__kindof'", u"'__strong'", u"<INVALID>", 
                     u"'__unsafe_unretained'", u"'__unused'", u"'__weak'", 
                     u"<INVALID>", u"<INVALID>", u"<INVALID>", u"'null_resettable'", 
                     u"'NS_INLINE'", u"'NS_ENUM'", u"'NS_OPTIONS'", u"'assign'", 
                     u"'copy'", u"'getter'", u"'setter'", u"'strong'", u"'readonly'", 
                     u"'readwrite'", u"'weak'", u"'unsafe_unretained'", 
                     u"'IBOutlet'", u"'IBOutletCollection'", u"'IBInspectable'", 
                     u"'IB_DESIGNABLE'", u"<INVALID>", u"<INVALID>", u"<INVALID>", 
                     u"<INVALID>", u"<INVALID>", u"'__TVOS_PROHIBITED'", 
                     u"<INVALID>", u"<INVALID>", u"<INVALID>", u"'{'", u"'}'", 
                     u"'['", u"']'", u"';'", u"','", u"'.'", u"'->'", u"'@'", 
                     u"'='", u"<INVALID>", u"<INVALID>", u"<INVALID>", u"'~'", 
                     u"'?'", u"':'", u"<INVALID>", u"<INVALID>", u"<INVALID>", 
                     u"<INVALID>", u"<INVALID>", u"<INVALID>", u"'++'", 
                     u"'--'", u"'+'", u"'-'", u"'*'", u"'/'", u"'&'", u"'|'", 
                     u"'^'", u"'%'", u"'+='", u"'-='", u"'*='", u"'/='", 
                     u"'&='", u"'|='", u"'^='", u"'%='", u"'<<='", u"'>>='", 
                     u"'...'", u"<INVALID>", u"<INVALID>", u"<INVALID>", 
                     u"<INVALID>", u"<INVALID>", u"<INVALID>", u"<INVALID>", 
                     u"<INVALID>", u"<INVALID>", u"<INVALID>", u"'\\'", 
                     u"<INVALID>", u"<INVALID>", u"<INVALID>", u"<INVALID>", 
                     u"<INVALID>", u"<INVALID>", u"<INVALID>", u"<INVALID>", 
                     u"'defined'", u"<INVALID>", u"'elif'", u"<INVALID>", 
                     u"'undef'", u"'ifdef'", u"'ifndef'", u"'endif'" ]

    symbolicNames = [ u"<INVALID>", u"AUTO", u"BREAK", u"CASE", u"CHAR", 
                      u"CONST", u"CONTINUE", u"DEFAULT", u"DO", u"DOUBLE", 
                      u"ELSE", u"ENUM", u"EXTERN", u"FLOAT", u"FOR", u"GOTO", 
                      u"IF", u"INLINE", u"INT", u"LONG", u"REGISTER", u"RESTRICT", 
                      u"RETURN", u"SHORT", u"SIGNED", u"SIZEOF", u"STATIC", 
                      u"STRUCT", u"SWITCH", u"TYPEDEF", u"UNION", u"UNSIGNED", 
                      u"VOID", u"VOLATILE", u"WHILE", u"BOOL_", u"COMPLEX", 
                      u"IMAGINERY", u"TRUE", u"FALSE", u"BOOL", u"Class", 
                      u"BYCOPY", u"BYREF", u"ID", u"IMP", u"IN", u"INOUT", 
                      u"NIL", u"NO", u"NULL", u"ONEWAY", u"OUT", u"PROTOCOL_", 
                      u"SEL", u"SELF", u"SUPER", u"YES", u"AUTORELEASEPOOL", 
                      u"CATCH", u"CLASS", u"DYNAMIC", u"ENCODE", u"END", 
                      u"FINALLY", u"IMPLEMENTATION", u"INTERFACE", u"IMPORT", 
                      u"PACKAGE", u"PROTOCOL", u"OPTIONAL", u"PRIVATE", 
                      u"PROPERTY", u"PROTECTED", u"PUBLIC", u"REQUIRED", 
                      u"SELECTOR", u"SYNCHRONIZED", u"SYNTHESIZE", u"THROW", 
                      u"TRY", u"ATOMIC", u"NONATOMIC", u"RETAIN", u"ATTRIBUTE", 
                      u"AUTORELEASING_QUALIFIER", u"BLOCK", u"BRIDGE", u"BRIDGE_RETAINED", 
                      u"BRIDGE_TRANSFER", u"COVARIANT", u"CONTRAVARIANT", 
                      u"DEPRECATED", u"KINDOF", u"STRONG_QUALIFIER", u"TYPEOF", 
                      u"UNSAFE_UNRETAINED_QUALIFIER", u"UNUSED", u"WEAK_QUALIFIER", 
                      u"NULL_UNSPECIFIED", u"NULLABLE", u"NONNULL", u"NULL_RESETTABLE", 
                      u"NS_INLINE", u"NS_ENUM", u"NS_OPTIONS", u"ASSIGN", 
                      u"COPY", u"GETTER", u"SETTER", u"STRONG", u"READONLY", 
                      u"READWRITE", u"WEAK", u"UNSAFE_UNRETAINED", u"IB_OUTLET", 
                      u"IB_OUTLET_COLLECTION", u"IB_INSPECTABLE", u"IB_DESIGNABLE", 
                      u"NS_ASSUME_NONNULL_BEGIN", u"NS_ASSUME_NONNULL_END", 
                      u"EXTERN_SUFFIX", u"IOS_SUFFIX", u"MAC_SUFFIX", u"TVOS_PROHIBITED", 
                      u"IDENTIFIER", u"LP", u"RP", u"LBRACE", u"RBRACE", 
                      u"LBRACK", u"RBRACK", u"SEMI", u"COMMA", u"DOT", u"STRUCTACCESS", 
                      u"AT", u"ASSIGNMENT", u"GT", u"LT", u"BANG", u"TILDE", 
                      u"QUESTION", u"COLON", u"EQUAL", u"LE", u"GE", u"NOTEQUAL", 
                      u"AND", u"OR", u"INC", u"DEC", u"ADD", u"SUB", u"MUL", 
                      u"DIV", u"BITAND", u"BITOR", u"BITXOR", u"MOD", u"ADD_ASSIGN", 
                      u"SUB_ASSIGN", u"MUL_ASSIGN", u"DIV_ASSIGN", u"AND_ASSIGN", 
                      u"OR_ASSIGN", u"XOR_ASSIGN", u"MOD_ASSIGN", u"LSHIFT_ASSIGN", 
                      u"RSHIFT_ASSIGN", u"ELIPSIS", u"CHARACTER_LITERAL", 
                      u"STRING_START", u"HEX_LITERAL", u"OCTAL_LITERAL", 
                      u"BINARY_LITERAL", u"DECIMAL_LITERAL", u"FLOATING_POINT_LITERAL", 
                      u"WS", u"MULTI_COMMENT", u"SINGLE_COMMENT", u"BACKSLASH", 
                      u"SHARP", u"STRING_NEWLINE", u"STRING_END", u"STRING_VALUE", 
                      u"DIRECTIVE_IMPORT", u"DIRECTIVE_INCLUDE", u"DIRECTIVE_PRAGMA", 
                      u"DIRECTIVE_DEFINE", u"DIRECTIVE_DEFINED", u"DIRECTIVE_IF", 
                      u"DIRECTIVE_ELIF", u"DIRECTIVE_ELSE", u"DIRECTIVE_UNDEF", 
                      u"DIRECTIVE_IFDEF", u"DIRECTIVE_IFNDEF", u"DIRECTIVE_ENDIF", 
                      u"DIRECTIVE_TRUE", u"DIRECTIVE_FALSE", u"DIRECTIVE_ERROR", 
                      u"DIRECTIVE_WARNING", u"DIRECTIVE_BANG", u"DIRECTIVE_LP", 
                      u"DIRECTIVE_RP", u"DIRECTIVE_EQUAL", u"DIRECTIVE_NOTEQUAL", 
                      u"DIRECTIVE_AND", u"DIRECTIVE_OR", u"DIRECTIVE_LT", 
                      u"DIRECTIVE_GT", u"DIRECTIVE_LE", u"DIRECTIVE_GE", 
                      u"DIRECTIVE_STRING", u"DIRECTIVE_ID", u"DIRECTIVE_DECIMAL_LITERAL", 
                      u"DIRECTIVE_FLOAT", u"DIRECTIVE_NEWLINE", u"DIRECTIVE_MULTI_COMMENT", 
                      u"DIRECTIVE_SINGLE_COMMENT", u"DIRECTIVE_BACKSLASH_NEWLINE", 
                      u"DIRECTIVE_TEXT_NEWLINE", u"DIRECTIVE_TEXT" ]

    RULE_directive = 0
    RULE_directiveText = 1
    RULE_preprocessorExpression = 2

    ruleNames =  [ u"directive", u"directiveText", u"preprocessorExpression" ]

    EOF = Token.EOF
    AUTO=1
    BREAK=2
    CASE=3
    CHAR=4
    CONST=5
    CONTINUE=6
    DEFAULT=7
    DO=8
    DOUBLE=9
    ELSE=10
    ENUM=11
    EXTERN=12
    FLOAT=13
    FOR=14
    GOTO=15
    IF=16
    INLINE=17
    INT=18
    LONG=19
    REGISTER=20
    RESTRICT=21
    RETURN=22
    SHORT=23
    SIGNED=24
    SIZEOF=25
    STATIC=26
    STRUCT=27
    SWITCH=28
    TYPEDEF=29
    UNION=30
    UNSIGNED=31
    VOID=32
    VOLATILE=33
    WHILE=34
    BOOL_=35
    COMPLEX=36
    IMAGINERY=37
    TRUE=38
    FALSE=39
    BOOL=40
    Class=41
    BYCOPY=42
    BYREF=43
    ID=44
    IMP=45
    IN=46
    INOUT=47
    NIL=48
    NO=49
    NULL=50
    ONEWAY=51
    OUT=52
    PROTOCOL_=53
    SEL=54
    SELF=55
    SUPER=56
    YES=57
    AUTORELEASEPOOL=58
    CATCH=59
    CLASS=60
    DYNAMIC=61
    ENCODE=62
    END=63
    FINALLY=64
    IMPLEMENTATION=65
    INTERFACE=66
    IMPORT=67
    PACKAGE=68
    PROTOCOL=69
    OPTIONAL=70
    PRIVATE=71
    PROPERTY=72
    PROTECTED=73
    PUBLIC=74
    REQUIRED=75
    SELECTOR=76
    SYNCHRONIZED=77
    SYNTHESIZE=78
    THROW=79
    TRY=80
    ATOMIC=81
    NONATOMIC=82
    RETAIN=83
    ATTRIBUTE=84
    AUTORELEASING_QUALIFIER=85
    BLOCK=86
    BRIDGE=87
    BRIDGE_RETAINED=88
    BRIDGE_TRANSFER=89
    COVARIANT=90
    CONTRAVARIANT=91
    DEPRECATED=92
    KINDOF=93
    STRONG_QUALIFIER=94
    TYPEOF=95
    UNSAFE_UNRETAINED_QUALIFIER=96
    UNUSED=97
    WEAK_QUALIFIER=98
    NULL_UNSPECIFIED=99
    NULLABLE=100
    NONNULL=101
    NULL_RESETTABLE=102
    NS_INLINE=103
    NS_ENUM=104
    NS_OPTIONS=105
    ASSIGN=106
    COPY=107
    GETTER=108
    SETTER=109
    STRONG=110
    READONLY=111
    READWRITE=112
    WEAK=113
    UNSAFE_UNRETAINED=114
    IB_OUTLET=115
    IB_OUTLET_COLLECTION=116
    IB_INSPECTABLE=117
    IB_DESIGNABLE=118
    NS_ASSUME_NONNULL_BEGIN=119
    NS_ASSUME_NONNULL_END=120
    EXTERN_SUFFIX=121
    IOS_SUFFIX=122
    MAC_SUFFIX=123
    TVOS_PROHIBITED=124
    IDENTIFIER=125
    LP=126
    RP=127
    LBRACE=128
    RBRACE=129
    LBRACK=130
    RBRACK=131
    SEMI=132
    COMMA=133
    DOT=134
    STRUCTACCESS=135
    AT=136
    ASSIGNMENT=137
    GT=138
    LT=139
    BANG=140
    TILDE=141
    QUESTION=142
    COLON=143
    EQUAL=144
    LE=145
    GE=146
    NOTEQUAL=147
    AND=148
    OR=149
    INC=150
    DEC=151
    ADD=152
    SUB=153
    MUL=154
    DIV=155
    BITAND=156
    BITOR=157
    BITXOR=158
    MOD=159
    ADD_ASSIGN=160
    SUB_ASSIGN=161
    MUL_ASSIGN=162
    DIV_ASSIGN=163
    AND_ASSIGN=164
    OR_ASSIGN=165
    XOR_ASSIGN=166
    MOD_ASSIGN=167
    LSHIFT_ASSIGN=168
    RSHIFT_ASSIGN=169
    ELIPSIS=170
    CHARACTER_LITERAL=171
    STRING_START=172
    HEX_LITERAL=173
    OCTAL_LITERAL=174
    BINARY_LITERAL=175
    DECIMAL_LITERAL=176
    FLOATING_POINT_LITERAL=177
    WS=178
    MULTI_COMMENT=179
    SINGLE_COMMENT=180
    BACKSLASH=181
    SHARP=182
    STRING_NEWLINE=183
    STRING_END=184
    STRING_VALUE=185
    DIRECTIVE_IMPORT=186
    DIRECTIVE_INCLUDE=187
    DIRECTIVE_PRAGMA=188
    DIRECTIVE_DEFINE=189
    DIRECTIVE_DEFINED=190
    DIRECTIVE_IF=191
    DIRECTIVE_ELIF=192
    DIRECTIVE_ELSE=193
    DIRECTIVE_UNDEF=194
    DIRECTIVE_IFDEF=195
    DIRECTIVE_IFNDEF=196
    DIRECTIVE_ENDIF=197
    DIRECTIVE_TRUE=198
    DIRECTIVE_FALSE=199
    DIRECTIVE_ERROR=200
    DIRECTIVE_WARNING=201
    DIRECTIVE_BANG=202
    DIRECTIVE_LP=203
    DIRECTIVE_RP=204
    DIRECTIVE_EQUAL=205
    DIRECTIVE_NOTEQUAL=206
    DIRECTIVE_AND=207
    DIRECTIVE_OR=208
    DIRECTIVE_LT=209
    DIRECTIVE_GT=210
    DIRECTIVE_LE=211
    DIRECTIVE_GE=212
    DIRECTIVE_STRING=213
    DIRECTIVE_ID=214
    DIRECTIVE_DECIMAL_LITERAL=215
    DIRECTIVE_FLOAT=216
    DIRECTIVE_NEWLINE=217
    DIRECTIVE_MULTI_COMMENT=218
    DIRECTIVE_SINGLE_COMMENT=219
    DIRECTIVE_BACKSLASH_NEWLINE=220
    DIRECTIVE_TEXT_NEWLINE=221
    DIRECTIVE_TEXT=222

    def __init__(self, input, output=sys.stdout):
        super(ObjectiveCPreprocessorParser, self).__init__(input, output=output)
        self.checkVersion("4.7.1")
        self._interp = ParserATNSimulator(self, self.atn, self.decisionsToDFA, self.sharedContextCache)
        self._predicates = None



    class DirectiveContext(ParserRuleContext):

        def __init__(self, parser, parent=None, invokingState=-1):
            super(ObjectiveCPreprocessorParser.DirectiveContext, self).__init__(parent, invokingState)
            self.parser = parser


        def getRuleIndex(self):
            return ObjectiveCPreprocessorParser.RULE_directive

     
        def copyFrom(self, ctx):
            super(ObjectiveCPreprocessorParser.DirectiveContext, self).copyFrom(ctx)



    class PreprocessorDefContext(DirectiveContext):

        def __init__(self, parser, ctx): # actually a ObjectiveCPreprocessorParser.DirectiveContext)
            super(ObjectiveCPreprocessorParser.PreprocessorDefContext, self).__init__(parser)
            self.copyFrom(ctx)

        def SHARP(self):
            return self.getToken(ObjectiveCPreprocessorParser.SHARP, 0)
        def DIRECTIVE_IFDEF(self):
            return self.getToken(ObjectiveCPreprocessorParser.DIRECTIVE_IFDEF, 0)
        def DIRECTIVE_ID(self):
            return self.getToken(ObjectiveCPreprocessorParser.DIRECTIVE_ID, 0)
        def DIRECTIVE_IFNDEF(self):
            return self.getToken(ObjectiveCPreprocessorParser.DIRECTIVE_IFNDEF, 0)
        def DIRECTIVE_UNDEF(self):
            return self.getToken(ObjectiveCPreprocessorParser.DIRECTIVE_UNDEF, 0)

        def enterRule(self, listener):
            if hasattr(listener, "enterPreprocessorDef"):
                listener.enterPreprocessorDef(self)

        def exitRule(self, listener):
            if hasattr(listener, "exitPreprocessorDef"):
                listener.exitPreprocessorDef(self)


    class PreprocessorErrorContext(DirectiveContext):

        def __init__(self, parser, ctx): # actually a ObjectiveCPreprocessorParser.DirectiveContext)
            super(ObjectiveCPreprocessorParser.PreprocessorErrorContext, self).__init__(parser)
            self.copyFrom(ctx)

        def SHARP(self):
            return self.getToken(ObjectiveCPreprocessorParser.SHARP, 0)
        def DIRECTIVE_ERROR(self):
            return self.getToken(ObjectiveCPreprocessorParser.DIRECTIVE_ERROR, 0)
        def directiveText(self):
            return self.getTypedRuleContext(ObjectiveCPreprocessorParser.DirectiveTextContext,0)


        def enterRule(self, listener):
            if hasattr(listener, "enterPreprocessorError"):
                listener.enterPreprocessorError(self)

        def exitRule(self, listener):
            if hasattr(listener, "exitPreprocessorError"):
                listener.exitPreprocessorError(self)


    class PreprocessorConditionalContext(DirectiveContext):

        def __init__(self, parser, ctx): # actually a ObjectiveCPreprocessorParser.DirectiveContext)
            super(ObjectiveCPreprocessorParser.PreprocessorConditionalContext, self).__init__(parser)
            self.copyFrom(ctx)

        def SHARP(self):
            return self.getToken(ObjectiveCPreprocessorParser.SHARP, 0)
        def DIRECTIVE_IF(self):
            return self.getToken(ObjectiveCPreprocessorParser.DIRECTIVE_IF, 0)
        def preprocessorExpression(self):
            return self.getTypedRuleContext(ObjectiveCPreprocessorParser.PreprocessorExpressionContext,0)

        def DIRECTIVE_ELIF(self):
            return self.getToken(ObjectiveCPreprocessorParser.DIRECTIVE_ELIF, 0)
        def DIRECTIVE_ELSE(self):
            return self.getToken(ObjectiveCPreprocessorParser.DIRECTIVE_ELSE, 0)
        def DIRECTIVE_ENDIF(self):
            return self.getToken(ObjectiveCPreprocessorParser.DIRECTIVE_ENDIF, 0)

        def enterRule(self, listener):
            if hasattr(listener, "enterPreprocessorConditional"):
                listener.enterPreprocessorConditional(self)

        def exitRule(self, listener):
            if hasattr(listener, "exitPreprocessorConditional"):
                listener.exitPreprocessorConditional(self)


    class PreprocessorImportContext(DirectiveContext):

        def __init__(self, parser, ctx): # actually a ObjectiveCPreprocessorParser.DirectiveContext)
            super(ObjectiveCPreprocessorParser.PreprocessorImportContext, self).__init__(parser)
            self.copyFrom(ctx)

        def SHARP(self):
            return self.getToken(ObjectiveCPreprocessorParser.SHARP, 0)
        def directiveText(self):
            return self.getTypedRuleContext(ObjectiveCPreprocessorParser.DirectiveTextContext,0)

        def DIRECTIVE_IMPORT(self):
            return self.getToken(ObjectiveCPreprocessorParser.DIRECTIVE_IMPORT, 0)
        def DIRECTIVE_INCLUDE(self):
            return self.getToken(ObjectiveCPreprocessorParser.DIRECTIVE_INCLUDE, 0)

        def enterRule(self, listener):
            if hasattr(listener, "enterPreprocessorImport"):
                listener.enterPreprocessorImport(self)

        def exitRule(self, listener):
            if hasattr(listener, "exitPreprocessorImport"):
                listener.exitPreprocessorImport(self)


    class PreprocessorPragmaContext(DirectiveContext):

        def __init__(self, parser, ctx): # actually a ObjectiveCPreprocessorParser.DirectiveContext)
            super(ObjectiveCPreprocessorParser.PreprocessorPragmaContext, self).__init__(parser)
            self.copyFrom(ctx)

        def SHARP(self):
            return self.getToken(ObjectiveCPreprocessorParser.SHARP, 0)
        def DIRECTIVE_PRAGMA(self):
            return self.getToken(ObjectiveCPreprocessorParser.DIRECTIVE_PRAGMA, 0)
        def directiveText(self):
            return self.getTypedRuleContext(ObjectiveCPreprocessorParser.DirectiveTextContext,0)


        def enterRule(self, listener):
            if hasattr(listener, "enterPreprocessorPragma"):
                listener.enterPreprocessorPragma(self)

        def exitRule(self, listener):
            if hasattr(listener, "exitPreprocessorPragma"):
                listener.exitPreprocessorPragma(self)


    class PreprocessorDefineContext(DirectiveContext):

        def __init__(self, parser, ctx): # actually a ObjectiveCPreprocessorParser.DirectiveContext)
            super(ObjectiveCPreprocessorParser.PreprocessorDefineContext, self).__init__(parser)
            self.copyFrom(ctx)

        def SHARP(self):
            return self.getToken(ObjectiveCPreprocessorParser.SHARP, 0)
        def DIRECTIVE_DEFINE(self):
            return self.getToken(ObjectiveCPreprocessorParser.DIRECTIVE_DEFINE, 0)
        def DIRECTIVE_ID(self):
            return self.getToken(ObjectiveCPreprocessorParser.DIRECTIVE_ID, 0)
        def directiveText(self):
            return self.getTypedRuleContext(ObjectiveCPreprocessorParser.DirectiveTextContext,0)


        def enterRule(self, listener):
            if hasattr(listener, "enterPreprocessorDefine"):
                listener.enterPreprocessorDefine(self)

        def exitRule(self, listener):
            if hasattr(listener, "exitPreprocessorDefine"):
                listener.exitPreprocessorDefine(self)


    class PreprocessorWarningContext(DirectiveContext):

        def __init__(self, parser, ctx): # actually a ObjectiveCPreprocessorParser.DirectiveContext)
            super(ObjectiveCPreprocessorParser.PreprocessorWarningContext, self).__init__(parser)
            self.copyFrom(ctx)

        def SHARP(self):
            return self.getToken(ObjectiveCPreprocessorParser.SHARP, 0)
        def DIRECTIVE_WARNING(self):
            return self.getToken(ObjectiveCPreprocessorParser.DIRECTIVE_WARNING, 0)
        def directiveText(self):
            return self.getTypedRuleContext(ObjectiveCPreprocessorParser.DirectiveTextContext,0)


        def enterRule(self, listener):
            if hasattr(listener, "enterPreprocessorWarning"):
                listener.enterPreprocessorWarning(self)

        def exitRule(self, listener):
            if hasattr(listener, "exitPreprocessorWarning"):
                listener.exitPreprocessorWarning(self)



    def directive(self):

        localctx = ObjectiveCPreprocessorParser.DirectiveContext(self, self._ctx, self.state)
        self.enterRule(localctx, 0, self.RULE_directive)
        self._la = 0 # Token type
        try:
            self.state = 43
            self._errHandler.sync(self)
            la_ = self._interp.adaptivePredict(self._input,1,self._ctx)
            if la_ == 1:
                localctx = ObjectiveCPreprocessorParser.PreprocessorImportContext(self, localctx)
                self.enterOuterAlt(localctx, 1)
                self.state = 6
                self.match(ObjectiveCPreprocessorParser.SHARP)
                self.state = 7
                _la = self._input.LA(1)
                if not(_la==ObjectiveCPreprocessorParser.DIRECTIVE_IMPORT or _la==ObjectiveCPreprocessorParser.DIRECTIVE_INCLUDE):
                    self._errHandler.recoverInline(self)
                else:
                    self._errHandler.reportMatch(self)
                    self.consume()
                self.state = 8
                self.directiveText()
                pass

            elif la_ == 2:
                localctx = ObjectiveCPreprocessorParser.PreprocessorConditionalContext(self, localctx)
                self.enterOuterAlt(localctx, 2)
                self.state = 9
                self.match(ObjectiveCPreprocessorParser.SHARP)
                self.state = 10
                self.match(ObjectiveCPreprocessorParser.DIRECTIVE_IF)
                self.state = 11
                self.preprocessorExpression(0)
                pass

            elif la_ == 3:
                localctx = ObjectiveCPreprocessorParser.PreprocessorConditionalContext(self, localctx)
                self.enterOuterAlt(localctx, 3)
                self.state = 12
                self.match(ObjectiveCPreprocessorParser.SHARP)
                self.state = 13
                self.match(ObjectiveCPreprocessorParser.DIRECTIVE_ELIF)
                self.state = 14
                self.preprocessorExpression(0)
                pass

            elif la_ == 4:
                localctx = ObjectiveCPreprocessorParser.PreprocessorConditionalContext(self, localctx)
                self.enterOuterAlt(localctx, 4)
                self.state = 15
                self.match(ObjectiveCPreprocessorParser.SHARP)
                self.state = 16
                self.match(ObjectiveCPreprocessorParser.DIRECTIVE_ELSE)
                pass

            elif la_ == 5:
                localctx = ObjectiveCPreprocessorParser.PreprocessorConditionalContext(self, localctx)
                self.enterOuterAlt(localctx, 5)
                self.state = 17
                self.match(ObjectiveCPreprocessorParser.SHARP)
                self.state = 18
                self.match(ObjectiveCPreprocessorParser.DIRECTIVE_ENDIF)
                pass

            elif la_ == 6:
                localctx = ObjectiveCPreprocessorParser.PreprocessorDefContext(self, localctx)
                self.enterOuterAlt(localctx, 6)
                self.state = 19
                self.match(ObjectiveCPreprocessorParser.SHARP)
                self.state = 20
                self.match(ObjectiveCPreprocessorParser.DIRECTIVE_IFDEF)
                self.state = 21
                self.match(ObjectiveCPreprocessorParser.DIRECTIVE_ID)
                pass

            elif la_ == 7:
                localctx = ObjectiveCPreprocessorParser.PreprocessorDefContext(self, localctx)
                self.enterOuterAlt(localctx, 7)
                self.state = 22
                self.match(ObjectiveCPreprocessorParser.SHARP)
                self.state = 23
                self.match(ObjectiveCPreprocessorParser.DIRECTIVE_IFNDEF)
                self.state = 24
                self.match(ObjectiveCPreprocessorParser.DIRECTIVE_ID)
                pass

            elif la_ == 8:
                localctx = ObjectiveCPreprocessorParser.PreprocessorDefContext(self, localctx)
                self.enterOuterAlt(localctx, 8)
                self.state = 25
                self.match(ObjectiveCPreprocessorParser.SHARP)
                self.state = 26
                self.match(ObjectiveCPreprocessorParser.DIRECTIVE_UNDEF)
                self.state = 27
                self.match(ObjectiveCPreprocessorParser.DIRECTIVE_ID)
                pass

            elif la_ == 9:
                localctx = ObjectiveCPreprocessorParser.PreprocessorPragmaContext(self, localctx)
                self.enterOuterAlt(localctx, 9)
                self.state = 28
                self.match(ObjectiveCPreprocessorParser.SHARP)
                self.state = 29
                self.match(ObjectiveCPreprocessorParser.DIRECTIVE_PRAGMA)
                self.state = 30
                self.directiveText()
                pass

            elif la_ == 10:
                localctx = ObjectiveCPreprocessorParser.PreprocessorErrorContext(self, localctx)
                self.enterOuterAlt(localctx, 10)
                self.state = 31
                self.match(ObjectiveCPreprocessorParser.SHARP)
                self.state = 32
                self.match(ObjectiveCPreprocessorParser.DIRECTIVE_ERROR)
                self.state = 33
                self.directiveText()
                pass

            elif la_ == 11:
                localctx = ObjectiveCPreprocessorParser.PreprocessorWarningContext(self, localctx)
                self.enterOuterAlt(localctx, 11)
                self.state = 34
                self.match(ObjectiveCPreprocessorParser.SHARP)
                self.state = 35
                self.match(ObjectiveCPreprocessorParser.DIRECTIVE_WARNING)
                self.state = 36
                self.directiveText()
                pass

            elif la_ == 12:
                localctx = ObjectiveCPreprocessorParser.PreprocessorDefineContext(self, localctx)
                self.enterOuterAlt(localctx, 12)
                self.state = 37
                self.match(ObjectiveCPreprocessorParser.SHARP)
                self.state = 38
                self.match(ObjectiveCPreprocessorParser.DIRECTIVE_DEFINE)
                self.state = 39
                self.match(ObjectiveCPreprocessorParser.DIRECTIVE_ID)
                self.state = 41
                self._errHandler.sync(self)
                _la = self._input.LA(1)
                if _la==ObjectiveCPreprocessorParser.DIRECTIVE_TEXT_NEWLINE or _la==ObjectiveCPreprocessorParser.DIRECTIVE_TEXT:
                    self.state = 40
                    self.directiveText()


                pass


        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx

    class DirectiveTextContext(ParserRuleContext):

        def __init__(self, parser, parent=None, invokingState=-1):
            super(ObjectiveCPreprocessorParser.DirectiveTextContext, self).__init__(parent, invokingState)
            self.parser = parser

        def DIRECTIVE_TEXT(self, i=None):
            if i is None:
                return self.getTokens(ObjectiveCPreprocessorParser.DIRECTIVE_TEXT)
            else:
                return self.getToken(ObjectiveCPreprocessorParser.DIRECTIVE_TEXT, i)

        def DIRECTIVE_TEXT_NEWLINE(self, i=None):
            if i is None:
                return self.getTokens(ObjectiveCPreprocessorParser.DIRECTIVE_TEXT_NEWLINE)
            else:
                return self.getToken(ObjectiveCPreprocessorParser.DIRECTIVE_TEXT_NEWLINE, i)

        def getRuleIndex(self):
            return ObjectiveCPreprocessorParser.RULE_directiveText

        def enterRule(self, listener):
            if hasattr(listener, "enterDirectiveText"):
                listener.enterDirectiveText(self)

        def exitRule(self, listener):
            if hasattr(listener, "exitDirectiveText"):
                listener.exitDirectiveText(self)




    def directiveText(self):

        localctx = ObjectiveCPreprocessorParser.DirectiveTextContext(self, self._ctx, self.state)
        self.enterRule(localctx, 2, self.RULE_directiveText)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 46 
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            while True:
                self.state = 45
                _la = self._input.LA(1)
                if not(_la==ObjectiveCPreprocessorParser.DIRECTIVE_TEXT_NEWLINE or _la==ObjectiveCPreprocessorParser.DIRECTIVE_TEXT):
                    self._errHandler.recoverInline(self)
                else:
                    self._errHandler.reportMatch(self)
                    self.consume()
                self.state = 48 
                self._errHandler.sync(self)
                _la = self._input.LA(1)
                if not (_la==ObjectiveCPreprocessorParser.DIRECTIVE_TEXT_NEWLINE or _la==ObjectiveCPreprocessorParser.DIRECTIVE_TEXT):
                    break

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx

    class PreprocessorExpressionContext(ParserRuleContext):

        def __init__(self, parser, parent=None, invokingState=-1):
            super(ObjectiveCPreprocessorParser.PreprocessorExpressionContext, self).__init__(parent, invokingState)
            self.parser = parser


        def getRuleIndex(self):
            return ObjectiveCPreprocessorParser.RULE_preprocessorExpression

     
        def copyFrom(self, ctx):
            super(ObjectiveCPreprocessorParser.PreprocessorExpressionContext, self).copyFrom(ctx)


    class PreprocessorParenthesisContext(PreprocessorExpressionContext):

        def __init__(self, parser, ctx): # actually a ObjectiveCPreprocessorParser.PreprocessorExpressionContext)
            super(ObjectiveCPreprocessorParser.PreprocessorParenthesisContext, self).__init__(parser)
            self.copyFrom(ctx)

        def DIRECTIVE_LP(self):
            return self.getToken(ObjectiveCPreprocessorParser.DIRECTIVE_LP, 0)
        def preprocessorExpression(self):
            return self.getTypedRuleContext(ObjectiveCPreprocessorParser.PreprocessorExpressionContext,0)

        def DIRECTIVE_RP(self):
            return self.getToken(ObjectiveCPreprocessorParser.DIRECTIVE_RP, 0)

        def enterRule(self, listener):
            if hasattr(listener, "enterPreprocessorParenthesis"):
                listener.enterPreprocessorParenthesis(self)

        def exitRule(self, listener):
            if hasattr(listener, "exitPreprocessorParenthesis"):
                listener.exitPreprocessorParenthesis(self)


    class PreprocessorNotContext(PreprocessorExpressionContext):

        def __init__(self, parser, ctx): # actually a ObjectiveCPreprocessorParser.PreprocessorExpressionContext)
            super(ObjectiveCPreprocessorParser.PreprocessorNotContext, self).__init__(parser)
            self.copyFrom(ctx)

        def DIRECTIVE_BANG(self):
            return self.getToken(ObjectiveCPreprocessorParser.DIRECTIVE_BANG, 0)
        def preprocessorExpression(self):
            return self.getTypedRuleContext(ObjectiveCPreprocessorParser.PreprocessorExpressionContext,0)


        def enterRule(self, listener):
            if hasattr(listener, "enterPreprocessorNot"):
                listener.enterPreprocessorNot(self)

        def exitRule(self, listener):
            if hasattr(listener, "exitPreprocessorNot"):
                listener.exitPreprocessorNot(self)


    class PreprocessorBinaryContext(PreprocessorExpressionContext):

        def __init__(self, parser, ctx): # actually a ObjectiveCPreprocessorParser.PreprocessorExpressionContext)
            super(ObjectiveCPreprocessorParser.PreprocessorBinaryContext, self).__init__(parser)
            self.op = None # Token
            self.copyFrom(ctx)

        def preprocessorExpression(self, i=None):
            if i is None:
                return self.getTypedRuleContexts(ObjectiveCPreprocessorParser.PreprocessorExpressionContext)
            else:
                return self.getTypedRuleContext(ObjectiveCPreprocessorParser.PreprocessorExpressionContext,i)

        def DIRECTIVE_EQUAL(self):
            return self.getToken(ObjectiveCPreprocessorParser.DIRECTIVE_EQUAL, 0)
        def DIRECTIVE_NOTEQUAL(self):
            return self.getToken(ObjectiveCPreprocessorParser.DIRECTIVE_NOTEQUAL, 0)
        def DIRECTIVE_AND(self):
            return self.getToken(ObjectiveCPreprocessorParser.DIRECTIVE_AND, 0)
        def DIRECTIVE_OR(self):
            return self.getToken(ObjectiveCPreprocessorParser.DIRECTIVE_OR, 0)
        def DIRECTIVE_LT(self):
            return self.getToken(ObjectiveCPreprocessorParser.DIRECTIVE_LT, 0)
        def DIRECTIVE_GT(self):
            return self.getToken(ObjectiveCPreprocessorParser.DIRECTIVE_GT, 0)
        def DIRECTIVE_LE(self):
            return self.getToken(ObjectiveCPreprocessorParser.DIRECTIVE_LE, 0)
        def DIRECTIVE_GE(self):
            return self.getToken(ObjectiveCPreprocessorParser.DIRECTIVE_GE, 0)

        def enterRule(self, listener):
            if hasattr(listener, "enterPreprocessorBinary"):
                listener.enterPreprocessorBinary(self)

        def exitRule(self, listener):
            if hasattr(listener, "exitPreprocessorBinary"):
                listener.exitPreprocessorBinary(self)


    class PreprocessorConstantContext(PreprocessorExpressionContext):

        def __init__(self, parser, ctx): # actually a ObjectiveCPreprocessorParser.PreprocessorExpressionContext)
            super(ObjectiveCPreprocessorParser.PreprocessorConstantContext, self).__init__(parser)
            self.copyFrom(ctx)

        def DIRECTIVE_TRUE(self):
            return self.getToken(ObjectiveCPreprocessorParser.DIRECTIVE_TRUE, 0)
        def DIRECTIVE_FALSE(self):
            return self.getToken(ObjectiveCPreprocessorParser.DIRECTIVE_FALSE, 0)
        def DIRECTIVE_DECIMAL_LITERAL(self):
            return self.getToken(ObjectiveCPreprocessorParser.DIRECTIVE_DECIMAL_LITERAL, 0)
        def DIRECTIVE_STRING(self):
            return self.getToken(ObjectiveCPreprocessorParser.DIRECTIVE_STRING, 0)

        def enterRule(self, listener):
            if hasattr(listener, "enterPreprocessorConstant"):
                listener.enterPreprocessorConstant(self)

        def exitRule(self, listener):
            if hasattr(listener, "exitPreprocessorConstant"):
                listener.exitPreprocessorConstant(self)


    class PreprocessorConditionalSymbolContext(PreprocessorExpressionContext):

        def __init__(self, parser, ctx): # actually a ObjectiveCPreprocessorParser.PreprocessorExpressionContext)
            super(ObjectiveCPreprocessorParser.PreprocessorConditionalSymbolContext, self).__init__(parser)
            self.copyFrom(ctx)

        def DIRECTIVE_ID(self):
            return self.getToken(ObjectiveCPreprocessorParser.DIRECTIVE_ID, 0)
        def DIRECTIVE_LP(self):
            return self.getToken(ObjectiveCPreprocessorParser.DIRECTIVE_LP, 0)
        def preprocessorExpression(self):
            return self.getTypedRuleContext(ObjectiveCPreprocessorParser.PreprocessorExpressionContext,0)

        def DIRECTIVE_RP(self):
            return self.getToken(ObjectiveCPreprocessorParser.DIRECTIVE_RP, 0)

        def enterRule(self, listener):
            if hasattr(listener, "enterPreprocessorConditionalSymbol"):
                listener.enterPreprocessorConditionalSymbol(self)

        def exitRule(self, listener):
            if hasattr(listener, "exitPreprocessorConditionalSymbol"):
                listener.exitPreprocessorConditionalSymbol(self)


    class PreprocessorDefinedContext(PreprocessorExpressionContext):

        def __init__(self, parser, ctx): # actually a ObjectiveCPreprocessorParser.PreprocessorExpressionContext)
            super(ObjectiveCPreprocessorParser.PreprocessorDefinedContext, self).__init__(parser)
            self.copyFrom(ctx)

        def DIRECTIVE_DEFINED(self):
            return self.getToken(ObjectiveCPreprocessorParser.DIRECTIVE_DEFINED, 0)
        def DIRECTIVE_ID(self):
            return self.getToken(ObjectiveCPreprocessorParser.DIRECTIVE_ID, 0)
        def DIRECTIVE_LP(self):
            return self.getToken(ObjectiveCPreprocessorParser.DIRECTIVE_LP, 0)
        def DIRECTIVE_RP(self):
            return self.getToken(ObjectiveCPreprocessorParser.DIRECTIVE_RP, 0)

        def enterRule(self, listener):
            if hasattr(listener, "enterPreprocessorDefined"):
                listener.enterPreprocessorDefined(self)

        def exitRule(self, listener):
            if hasattr(listener, "exitPreprocessorDefined"):
                listener.exitPreprocessorDefined(self)



    def preprocessorExpression(self, _p=0):
        _parentctx = self._ctx
        _parentState = self.state
        localctx = ObjectiveCPreprocessorParser.PreprocessorExpressionContext(self, self._ctx, _parentState)
        _prevctx = localctx
        _startState = 4
        self.enterRecursionRule(localctx, 4, self.RULE_preprocessorExpression, _p)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 75
            self._errHandler.sync(self)
            token = self._input.LA(1)
            if token in [ObjectiveCPreprocessorParser.DIRECTIVE_TRUE]:
                localctx = ObjectiveCPreprocessorParser.PreprocessorConstantContext(self, localctx)
                self._ctx = localctx
                _prevctx = localctx

                self.state = 51
                self.match(ObjectiveCPreprocessorParser.DIRECTIVE_TRUE)
                pass
            elif token in [ObjectiveCPreprocessorParser.DIRECTIVE_FALSE]:
                localctx = ObjectiveCPreprocessorParser.PreprocessorConstantContext(self, localctx)
                self._ctx = localctx
                _prevctx = localctx
                self.state = 52
                self.match(ObjectiveCPreprocessorParser.DIRECTIVE_FALSE)
                pass
            elif token in [ObjectiveCPreprocessorParser.DIRECTIVE_DECIMAL_LITERAL]:
                localctx = ObjectiveCPreprocessorParser.PreprocessorConstantContext(self, localctx)
                self._ctx = localctx
                _prevctx = localctx
                self.state = 53
                self.match(ObjectiveCPreprocessorParser.DIRECTIVE_DECIMAL_LITERAL)
                pass
            elif token in [ObjectiveCPreprocessorParser.DIRECTIVE_STRING]:
                localctx = ObjectiveCPreprocessorParser.PreprocessorConstantContext(self, localctx)
                self._ctx = localctx
                _prevctx = localctx
                self.state = 54
                self.match(ObjectiveCPreprocessorParser.DIRECTIVE_STRING)
                pass
            elif token in [ObjectiveCPreprocessorParser.DIRECTIVE_ID]:
                localctx = ObjectiveCPreprocessorParser.PreprocessorConditionalSymbolContext(self, localctx)
                self._ctx = localctx
                _prevctx = localctx
                self.state = 55
                self.match(ObjectiveCPreprocessorParser.DIRECTIVE_ID)
                self.state = 60
                self._errHandler.sync(self)
                la_ = self._interp.adaptivePredict(self._input,3,self._ctx)
                if la_ == 1:
                    self.state = 56
                    self.match(ObjectiveCPreprocessorParser.DIRECTIVE_LP)
                    self.state = 57
                    self.preprocessorExpression(0)
                    self.state = 58
                    self.match(ObjectiveCPreprocessorParser.DIRECTIVE_RP)


                pass
            elif token in [ObjectiveCPreprocessorParser.DIRECTIVE_LP]:
                localctx = ObjectiveCPreprocessorParser.PreprocessorParenthesisContext(self, localctx)
                self._ctx = localctx
                _prevctx = localctx
                self.state = 62
                self.match(ObjectiveCPreprocessorParser.DIRECTIVE_LP)
                self.state = 63
                self.preprocessorExpression(0)
                self.state = 64
                self.match(ObjectiveCPreprocessorParser.DIRECTIVE_RP)
                pass
            elif token in [ObjectiveCPreprocessorParser.DIRECTIVE_BANG]:
                localctx = ObjectiveCPreprocessorParser.PreprocessorNotContext(self, localctx)
                self._ctx = localctx
                _prevctx = localctx
                self.state = 66
                self.match(ObjectiveCPreprocessorParser.DIRECTIVE_BANG)
                self.state = 67
                self.preprocessorExpression(6)
                pass
            elif token in [ObjectiveCPreprocessorParser.DIRECTIVE_DEFINED]:
                localctx = ObjectiveCPreprocessorParser.PreprocessorDefinedContext(self, localctx)
                self._ctx = localctx
                _prevctx = localctx
                self.state = 68
                self.match(ObjectiveCPreprocessorParser.DIRECTIVE_DEFINED)
                self.state = 73
                self._errHandler.sync(self)
                token = self._input.LA(1)
                if token in [ObjectiveCPreprocessorParser.DIRECTIVE_ID]:
                    self.state = 69
                    self.match(ObjectiveCPreprocessorParser.DIRECTIVE_ID)
                    pass
                elif token in [ObjectiveCPreprocessorParser.DIRECTIVE_LP]:
                    self.state = 70
                    self.match(ObjectiveCPreprocessorParser.DIRECTIVE_LP)
                    self.state = 71
                    self.match(ObjectiveCPreprocessorParser.DIRECTIVE_ID)
                    self.state = 72
                    self.match(ObjectiveCPreprocessorParser.DIRECTIVE_RP)
                    pass
                else:
                    raise NoViableAltException(self)

                pass
            else:
                raise NoViableAltException(self)

            self._ctx.stop = self._input.LT(-1)
            self.state = 91
            self._errHandler.sync(self)
            _alt = self._interp.adaptivePredict(self._input,7,self._ctx)
            while _alt!=2 and _alt!=ATN.INVALID_ALT_NUMBER:
                if _alt==1:
                    if self._parseListeners is not None:
                        self.triggerExitRuleEvent()
                    _prevctx = localctx
                    self.state = 89
                    self._errHandler.sync(self)
                    la_ = self._interp.adaptivePredict(self._input,6,self._ctx)
                    if la_ == 1:
                        localctx = ObjectiveCPreprocessorParser.PreprocessorBinaryContext(self, ObjectiveCPreprocessorParser.PreprocessorExpressionContext(self, _parentctx, _parentState))
                        self.pushNewRecursionContext(localctx, _startState, self.RULE_preprocessorExpression)
                        self.state = 77
                        if not self.precpred(self._ctx, 5):
                            from QBCodeSpecs.antlr4.error.Errors import FailedPredicateException
                            raise FailedPredicateException(self, "self.precpred(self._ctx, 5)")
                        self.state = 78
                        localctx.op = self._input.LT(1)
                        _la = self._input.LA(1)
                        if not(_la==ObjectiveCPreprocessorParser.DIRECTIVE_EQUAL or _la==ObjectiveCPreprocessorParser.DIRECTIVE_NOTEQUAL):
                            localctx.op = self._errHandler.recoverInline(self)
                        else:
                            self._errHandler.reportMatch(self)
                            self.consume()
                        self.state = 79
                        self.preprocessorExpression(6)
                        pass

                    elif la_ == 2:
                        localctx = ObjectiveCPreprocessorParser.PreprocessorBinaryContext(self, ObjectiveCPreprocessorParser.PreprocessorExpressionContext(self, _parentctx, _parentState))
                        self.pushNewRecursionContext(localctx, _startState, self.RULE_preprocessorExpression)
                        self.state = 80
                        if not self.precpred(self._ctx, 4):
                            from QBCodeSpecs.antlr4.error.Errors import FailedPredicateException
                            raise FailedPredicateException(self, "self.precpred(self._ctx, 4)")
                        self.state = 81
                        localctx.op = self.match(ObjectiveCPreprocessorParser.DIRECTIVE_AND)
                        self.state = 82
                        self.preprocessorExpression(5)
                        pass

                    elif la_ == 3:
                        localctx = ObjectiveCPreprocessorParser.PreprocessorBinaryContext(self, ObjectiveCPreprocessorParser.PreprocessorExpressionContext(self, _parentctx, _parentState))
                        self.pushNewRecursionContext(localctx, _startState, self.RULE_preprocessorExpression)
                        self.state = 83
                        if not self.precpred(self._ctx, 3):
                            from QBCodeSpecs.antlr4.error.Errors import FailedPredicateException
                            raise FailedPredicateException(self, "self.precpred(self._ctx, 3)")
                        self.state = 84
                        localctx.op = self.match(ObjectiveCPreprocessorParser.DIRECTIVE_OR)
                        self.state = 85
                        self.preprocessorExpression(4)
                        pass

                    elif la_ == 4:
                        localctx = ObjectiveCPreprocessorParser.PreprocessorBinaryContext(self, ObjectiveCPreprocessorParser.PreprocessorExpressionContext(self, _parentctx, _parentState))
                        self.pushNewRecursionContext(localctx, _startState, self.RULE_preprocessorExpression)
                        self.state = 86
                        if not self.precpred(self._ctx, 2):
                            from QBCodeSpecs.antlr4.error.Errors import FailedPredicateException
                            raise FailedPredicateException(self, "self.precpred(self._ctx, 2)")
                        self.state = 87
                        localctx.op = self._input.LT(1)
                        _la = self._input.LA(1)
                        if not(((((_la - 209)) & ~0x3f) == 0 and ((1 << (_la - 209)) & ((1 << (ObjectiveCPreprocessorParser.DIRECTIVE_LT - 209)) | (1 << (ObjectiveCPreprocessorParser.DIRECTIVE_GT - 209)) | (1 << (ObjectiveCPreprocessorParser.DIRECTIVE_LE - 209)) | (1 << (ObjectiveCPreprocessorParser.DIRECTIVE_GE - 209)))) != 0)):
                            localctx.op = self._errHandler.recoverInline(self)
                        else:
                            self._errHandler.reportMatch(self)
                            self.consume()
                        self.state = 88
                        self.preprocessorExpression(3)
                        pass

             
                self.state = 93
                self._errHandler.sync(self)
                _alt = self._interp.adaptivePredict(self._input,7,self._ctx)

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.unrollRecursionContexts(_parentctx)
        return localctx



    def sempred(self, localctx, ruleIndex, predIndex):
        if self._predicates == None:
            self._predicates = dict()
        self._predicates[2] = self.preprocessorExpression_sempred
        pred = self._predicates.get(ruleIndex, None)
        if pred is None:
            raise Exception("No predicate with index:" + str(ruleIndex))
        else:
            return pred(localctx, predIndex)

    def preprocessorExpression_sempred(self, localctx, predIndex):
            if predIndex == 0:
                return self.precpred(self._ctx, 5)
         

            if predIndex == 1:
                return self.precpred(self._ctx, 4)
         

            if predIndex == 2:
                return self.precpred(self._ctx, 3)
         

            if predIndex == 3:
                return self.precpred(self._ctx, 2)
         




