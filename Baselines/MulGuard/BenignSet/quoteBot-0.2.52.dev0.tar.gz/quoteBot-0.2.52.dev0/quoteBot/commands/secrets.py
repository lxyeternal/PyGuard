"""
secrets.py
~~~~~~~~~~

Consumer credentials to use quoteBot for authentification with twitter.

:copyright: @ 2018
:author: elias julian marko garcia
:license: MIT, see LICENSE
"""

# ENSURE .GITIGNORE HAS THIS FILE

CONSUMER_KEY = 'sSSCfh1FHXmEHwF9RCgCL6Fn9'
CONSUMER_SECRET = 'r7YGWj9FTKh5y7TQJzRXMHksIvX2nB7iIJN1RdCG7TnBqNWA0h'
