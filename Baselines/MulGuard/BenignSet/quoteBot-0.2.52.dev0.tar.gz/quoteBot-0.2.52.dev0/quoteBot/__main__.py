"""

__main__.py
~~~~~~~~

executed when quoteBot is called as a script.

:copyright: @ 2018
:author: elias julian marko garcia
:license: MIT, see LICENSE
"""

from quoteBot.quoteBot import cli

cli()
