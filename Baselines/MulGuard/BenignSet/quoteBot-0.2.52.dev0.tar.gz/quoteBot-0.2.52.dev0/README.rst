quoteBot
========

this package will allow you to quickly make a twitter bot that tweets
quotes with options for image generation of said quote.
.

inspired heavily by my previous creations, `@Baudrillard\_Bot <https://github.com/ejmg/baudrillardBot>`_ and `@TOUGHLOVEBOT <https://github.com/ejmg/toughLoveBot/>`_.

WORK IN PROGRESS
----------------
