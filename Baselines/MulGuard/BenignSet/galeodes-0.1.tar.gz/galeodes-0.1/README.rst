Install
=======

.. code:: bash

    pip3 install galeodes


Other projects
==============
.. image:: https://raw.githubusercontent.com/qeeqbox/.github/main/data//social-analyzer.png
    :target: https://github.com/qeeqbox/social-analyzer

.. image:: https://raw.githubusercontent.com/qeeqbox/.github/main/data//analyzer.png
    :target: https://github.com/qeeqbox/analyzer

.. image:: https://raw.githubusercontent.com/qeeqbox/.github/main/data//chameleon.png
    :target: https://github.com/qeeqbox/chameleon

.. image:: https://raw.githubusercontent.com/qeeqbox/.github/main/data//osint.png
    :target: https://github.com/qeeqbox/osint

.. image:: https://raw.githubusercontent.com/qeeqbox/.github/main/data//url-sandbox.png
    :target: https://github.com/qeeqbox/url-sandbox

.. image:: https://raw.githubusercontent.com/qeeqbox/.github/main/data//mitre-visualizer.png
    :target: https://github.com/qeeqbox/mitre-visualizer

.. image:: https://raw.githubusercontent.com/qeeqbox/.github/main/data//woodpecker.png
    :target: https://github.com/qeeqbox/woodpecker

.. image:: https://raw.githubusercontent.com/qeeqbox/.github/main/data//docker-images.png
    :target: https://github.com/qeeqbox/docker-images

.. image:: https://raw.githubusercontent.com/qeeqbox/.github/main/data//seahorse.png
    :target: https://github.com/qeeqbox/seahorse

.. image:: https://raw.githubusercontent.com/qeeqbox/.github/main/data//rhino.png
    :target: https://github.com/qeeqbox/rhino
