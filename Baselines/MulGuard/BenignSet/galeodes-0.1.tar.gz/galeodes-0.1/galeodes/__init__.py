#!/usr/bin/env python
from .__main__ import main_logic
from .galeodes import Galeodes