=====
Usage
=====

To use EKS crutch in a project::

    import eks_crutch
