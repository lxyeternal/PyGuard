"""Top-level package for EKS crutch."""

__author__ = """Sean R. Lynch"""
__email__ = 'sean@foghornconsulting.com'
__version__ = '0.1.0'
