==========
EKS crutch
==========


.. image:: https://img.shields.io/pypi/v/eks_crutch.svg
        :target: https://pypi.python.org/pypi/eks_crutch

.. image:: https://img.shields.io/travis/seanlynch/eks_crutch.svg
        :target: https://travis-ci.com/seanlynch/eks_crutch

.. image:: https://readthedocs.org/projects/eks-crutch/badge/?version=latest
        :target: https://eks-crutch.readthedocs.io/en/latest/?badge=latest
        :alt: Documentation Status




Wrapper script to run programs using the IAM role associated with a ServiceAccount


* Free software: Apache Software License 2.0
* Documentation: https://eks-crutch.readthedocs.io.


Features
--------

* TODO

Credits
-------

This package was created with Cookiecutter_ and the `audreyr/cookiecutter-pypackage`_ project template.

.. _Cookiecutter: https://github.com/audreyr/cookiecutter
.. _`audreyr/cookiecutter-pypackage`: https://github.com/audreyr/cookiecutter-pypackage
