===========================
README for PyBOL 
===========================

|build| |cov|

.. |build| image:: https://travis-ci.org/ianmkenney/manifest_parser.svg?branch=master
    :alt: Build status
    :target: https://travis-ci.org/ianmkenney/manifest_parser

.. |cov| image:: https://codecov.io/gh/ianmkenney/manifest_parser/branch/master/graph/badge.svg
    :alt: Coverage status
    :target: https://codecov.io/gh/ianmkenney/manifest_parser
