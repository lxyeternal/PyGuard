from setuptools import setup

setup(name='distributions_AMG11',
      version='0.1',
      description='Gaussian distributions',
      packages=['distributions_AMG11'],
      zip_safe=False)
