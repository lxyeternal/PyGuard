# shinny-parsing-settlement
把结算单转为 json 对象
