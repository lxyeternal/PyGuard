from gdalos.gdalos import gdalos_trans, OvrType, RasterKind
from gdalos.rectangle import GeoRectangle
from gdalos.__data__ import __version__, __author__
