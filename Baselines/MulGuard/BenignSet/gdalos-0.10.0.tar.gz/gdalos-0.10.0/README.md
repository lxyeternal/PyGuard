# gdalos
a simple gdal translate/warp/addo python wrapper for raster batch processing.
It uses the gdal python interface and on top of it many rules to automate the batch processing.
I hope some of you might find it useful.
look at example.py for some examples.
