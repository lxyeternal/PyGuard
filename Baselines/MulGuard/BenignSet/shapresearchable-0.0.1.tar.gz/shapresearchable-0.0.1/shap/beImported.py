#This is used for testing being imported

def giveName():
	print('giveName')