#This is main

print('main')