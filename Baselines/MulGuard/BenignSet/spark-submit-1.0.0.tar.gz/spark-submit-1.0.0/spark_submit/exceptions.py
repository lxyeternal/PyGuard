"""Exceptions raised by SparkJob class"""

class SparkSubmitError(Exception):
    pass


class SparkJobKillError(Exception):
    pass
