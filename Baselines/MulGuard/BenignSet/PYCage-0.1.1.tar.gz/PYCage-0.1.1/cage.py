#!/usr/bin/env python3
import cage


if __name__ == "__main__":
    cage.main()
