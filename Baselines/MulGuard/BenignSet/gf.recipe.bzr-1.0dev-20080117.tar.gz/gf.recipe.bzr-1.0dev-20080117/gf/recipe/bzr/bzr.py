
import logging, os, zc.buildout, subprocess, re

def execute(cmd, logger):
    logger.debug('Calling bazaar in %s:\n  %s', 
        os.getcwd(), cmd)
    # Feed it a bunch of newlines, in case it asks for password
    # (if you use password authentication, install pycurl
    # and specify the newlines in .netrc
    proc = subprocess.Popen(cmd.split(),
                            stdin=subprocess.PIPE,
                            stdout=subprocess.PIPE,
                            stderr=subprocess.PIPE)
    stdout, stderr = proc.communicate(input="\n\n\n")
    return stdout, stderr

def setup_logging(logger):
    # Set the same level as the zc
    zc_logger = logging.getLogger('zc.buildout')
    level = zc_logger.level
    logger.setLevel(level)

re_add_passwd = re.compile(r'^(https?://)([^@]*@)?(.*)$')

def add_password(options, location):
    http_authentication = options.get('http_authentication', None)
    if http_authentication:
        match = re_add_passwd.match(location)
        if match is not None:
            location = '%s%s@%s' % (match.group(1), http_authentication, match.group(3))
    return location

re_extra_rev = re.compile(r'(^|\n)You have \d+ extra revision\(s\):')
re_push_location = re.compile(r'push branch: ([^\n]*)\n')
re_pull_location = re.compile(r'parent branch: ([^\n]*)\n')

class BzrRecipe(object):
    """bzr recipe

    Example::
                
        [bzr]
        recipe = gf.recipe.bzr
        urls =
            http://bazaar.launchpad.net/~kissbooth/kss.plugin.sdnd/trunk kss.plugin.sdnd 
            http://bazaar.launchpad.net/~kissbooth/kss.plugin.livesearch/trunk kss.plugin.livesearch
        in_parts = False
        http_authentication = username:password

    For more information, consult the file docs/README.txt in the egg.
    """

    def __init__(self, buildout, name, options):
        self.buildout, self.name, self.options = buildout, name, options
        self.setup_logging()
        in_parts = options.get('in_parts', 'False')
        if in_parts not in ('True', 'False', 'true', 'false'):
            self.logger.error(
                'Bad in_parts parameter "%s", allowed values: True or False',
                in_parts)
            raise zc.buildout.UserError('Bad in_parts parameter')
        root_dir = buildout['buildout']['directory']
        if in_parts.capitalize() == 'True':
            root_dir =  os.path.join(root_dir, 'parts')
        options['root_dir'] = root_dir = os.path.join(root_dir, name)
        # Process the branches.
        branches = []
        for line in options['urls'].splitlines():
            if line and not line.isspace():
                words = line.split()
                try:
                    repo, egg = words
                except ValueError:
                    self.logger.error(
                       'Bad line in urls, "%s". Each line must contain the bzr branch url followed by a space and the egg name.',
                       line)
                    raise zc.buildout.UserError('Bad bzr branch url specification')

                # Add password (if any) to location
                repo = add_password(self.options, repo)
                #
                branches.append(dict(
                    egg = egg, 
                    repo = repo,
                    path = os.path.join(root_dir, egg),
                    ))    
        self.branches = branches
        options['develop-eggs-directory'] = buildout['buildout']['develop-eggs-directory']
 
    def setup_logging(self):
        # Set the same level as the zc
        self.logger = logging.getLogger(self.name)
        setup_logging(self.logger)

    def execute(self, cmd):
        stdout, stderr = execute(cmd, self.logger)
        return stdout, stderr

    def install(self):
        root_dir = self.options['root_dir']
        if not os.path.isdir(root_dir):
            os.mkdir(root_dir)

        # process required branches
        for branch in self.branches:
            if not os.path.isdir(branch['path']):
                self.logger.info('Getting %s from bzr repository %s',
                    branch['egg'], branch['repo'])
                self.bzr_get(branch)
            else:
                self.bzr_update(branch)
            # setup.py develop the egg.
            self.egg_develop(branch)

        # XXX Never uninstall anything.
        # However checks are done ans uninstall is aborted
        # in case there are pending changes, but still
        # we don't delete anything, really.
        return []

    # same as install, since we need to update each one.
    update = install

    def bzr_get(self, branch):

        # Getting by calling bazaar
        cmd = 'bzr get %(repo)s %(path)s' % branch
        stdout, stderr = self.execute(cmd)

        # check for errors
        # stderr may be multi line, we check last line
        stderr_lines = stderr.splitlines()
        if not stderr_lines or not stderr_lines[-1].startswith('Branched'):
            self.logger.error(
                'Error calling bazaar in "%s", detailed output follows:\n"""\n%s\n%s"""',
                branch['egg'], stdout, stderr)
            raise zc.buildout.UserError('Error calling bzr')

    def bzr_update(self, branch):
        # Updating by calling bazaar
        os.chdir(branch['path'])

        # We need to acquire the pull location,
        # mainly because we may want to add the password to it.
        cmd = 'bzr info'
        stdout, stderr = self.execute(cmd)
        match = re_pull_location.search(stdout)
        if stderr or match is None:
            self.logger.error(
                'Abort uninstalling "%s" (not a bzr branch, or no pull location?), detailed bzr output follows:\n"""\n%s\n%s"""',
                branch['egg'], stdout, stderr)
            raise zc.buildout.UserError('Error calling bzr')
        location = match.group(1)

        # Add password (if any) to location
        location = add_password(self.options, location)

        # Do the pull now
        cmd = 'bzr pull %s' % (location, )
        stdout, stderr = self.execute(cmd)

        # check for errors

        # This is accepted. Needed if we created a local branch.
        if "No pull location known or specified" in stderr:
            self.logger.debug(
                'Ignore problem in "%s" and continue, detailed output follows:\n"""\n%s\n%s"""',
                branch['egg'], stdout, stderr)
            return

        # This is ok.
        if "No revisions to pull" in stdout:
            return
    
        # This is ok as well.
        if 'All changes applied successfully' in stderr:
            return

        self.logger.error(
            'Error calling bazaar in "%s", detailed output follows:\n"""\n%s\n%s"""',
            branch['egg'], stdout, stderr)
        raise zc.buildout.UserError('Error calling bzr')

    def egg_develop(self, branch):
        zc.buildout.easy_install.develop(branch['path'],
            self.options['develop-eggs-directory'],
            )
        self.logger.info("Develop: '%s'",
            branch['repo'])

def uninstallBzrRecipe(name, options):
    # Set the same level as the zc
    logger = logging.getLogger(name)
    setup_logging(logger)
    # Iterate on all subdirs.
    root_dir = options['root_dir']
    # If the root dir does not exist, we have nothing to check.
    if not os.path.isdir(root_dir):
        return
    for dirname in os.listdir(root_dir):
        path = os.path.join(root_dir, dirname)
        os.chdir(path)
        # See if there are uncommitted changes
        cmd = 'bzr st'
        stdout, stderr = execute(cmd, logger)
        if stdout or stderr:
            logger.error(
                'Abort uninstalling "%s" (commit or adjust .bzrignore?), detailed bzr output follows:\n"""\n%s\n%s"""',
                dirname, stdout, stderr)
            break
        # We need to acquire the push location, since bzr missing otherwise would
        # act on the pull location.
        cmd = 'bzr info'
        stdout, stderr = execute(cmd, logger)
        match = re_push_location.search(stdout)
        if stderr:
            logger.error(
                'Abort uninstalling "%s" (not a bzr branch, or no push and pull location?), detailed bzr output follows:\n"""\n%s\n%s"""',
                dirname, stdout, stderr)
            break
        if match is not None:
            location = match.group(1)
        else:
            match = re_pull_location.search(stdout)
            if match is None:
                logger.error(
                    'Abort uninstalling "%s" (not a bzr branch, or no push and pull location?), detailed bzr output follows:\n"""\n%s\n%s"""',
                    dirname, stdout, stderr)
                break
            location = match.group(1)
            logger.debug(
                'Push location not found, using pull location for "%s", detailed bzr output follows:\n"""\n%s\n%s"""',
                dirname, stdout, stderr)
        # Add password (if any) to location
        location = add_password(options, location)
        # See if something is not pushed to upstream
        cmd = 'bzr missing %s' % (location, )
        stdout, stderr = execute(cmd, logger)
        if stderr or re_extra_rev.search(stdout):
            logger.error(
                'Abort uninstalling "%s" (push or adjust push location?), detailed bzr output follows:\n"""\n%s\n%s"""',
                dirname, stdout, stderr)
            break
    else:
        # Ok.
        return
    raise zc.buildout.UserError('Abort uninstalling, because of pending local changes.')
