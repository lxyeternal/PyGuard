==============================
gf.recipe.bzr buildout recipee
==============================

This recipe can be used to get development checkouts from Bazaar repositories
for zc.buildout.

Installation and Setup
======================

Read INSTALL.txt


Documentation
=============

Goals
-----

- Allow fetching eggs directly from bzr repositories.

- The specified repositories are branched locally on the first buildout run. It
  is possible to use these local branches for development and make local
  changes. The local changes can be committed locally, and can be pushed back
  to the remote repository or to any other location.

- When buildout is run again, the branches are updated (pulled) automatically
  from the remote location. If pulling would cause conflicts, buildout stops
  with an error. The parent branch (pull) location remembered by bazaar will be
  used for pulling, so it is possible to change this any time from bzr.

- Local changes can be pushed back to the remote branches. This is also enforced:
  When buildout wants to uninstall the local branches, they are checked. If
  they contain uncommitted or unpushed local changes, buildout stops with an
  error. This forces developers to save local changes to upstream and avoids
  loosing local work.

- When buildout checks if the branches contain local changes, the parent (pull)
  location and the push location, remembered by bazaar, are used (in this
  order). This makes it possible to switch existing branches during
  development, without changing the buildout configuration.

- Parameters are similar to those used with "infrae.subversion" and also
  compatible with the "bazaarrecipe" package.

- With bzr-svn, the remote branch can also be an svn branch. So it actually can
  be used to branch off native svn repository branches as well (although,
  performance of updates and sanity checks may depend on bzr-svn's performance,
  thus infrae.subversion may provide faster operation for svn.)


Usage
-----

Usage example::
        
    [bzr]
    recipe = gf.recipe.bzr
    urls =
        http://bazaar.launchpad.net/~kissbooth/kss.plugin.sdnd/trunk kss.plugin.sdnd 
        http://bazaar.launchpad.net/~kissbooth/kss.plugin.livesearch/trunk kss.plugin.livesearch
    in_parts = False
    http_authentication = username:password

This will ``bzr get`` the branches to ``bzr/kss.plugin.sdnd`` and
``bzr/kss.plugin.livesearch``.  Branches are pulled if buildout is called.
Uninstall is protected, if there are local modifications, or modifications that
are missing in the upstream, an error will be raised. In case you create a
local bzr directory, make sure it has a push location, otherwise uninstall will
fail.

No directories are really removed on uninstall, this has the consequence that
if the setup is changed, the local repositories will not follow it.

``in_parts`` is by default false, which means the directory that holds the branches
is created in the buildout root. This is the default mode as it is handy for
development. If in_parts = True is specified, then the directory will be
created in the parts directory (compatible with infrae.subversion).

If http authentication is specified as ``username:password``, it will be used for
authenticating into http and https realms. This is rarely needed as ssh offers
a more confortable repository access, but it allows password protected http
access that would not be easy (or possible at all) otherwise.

Offline mode is _not_ supported, because there seems to be no way of detecting
during uninstall, if we are in offline mode.

Other configuration needed
--------------------------

In addition you also need to include the eggs you configured with the recipe,
in the buildout section::

    [buildout]
    ...
    eggs =
        ...
        kss.plugin.sdnd
        kss.plugin.livesearch


