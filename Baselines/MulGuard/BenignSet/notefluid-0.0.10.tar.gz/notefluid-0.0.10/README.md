## install

```python
pip install git+https://github.com/notechats/notefluid.git
pip install git+https://gitee.com/notechats/notefluid.git
```


