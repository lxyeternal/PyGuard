NVIDIA-DALI-TF-PLUGIN-CUDA113
=============================

**WARNING:** This project is not functional and is a placeholder from NVIDIA.
Please refer to https://docs.nvidia.com/deeplearning/dali/user-guide/docs/installation.html for additional information.

.. code-block:: bash

    pip install nvidia-pyindex
    pip install nvidia-dali-tf-plugin-cuda113
