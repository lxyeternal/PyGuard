# -*- coding: utf-8 -*-

"""Top-level package for Capital Finder."""

__author__ = """Vuyisile Ndlovu"""
__email__ = 'terrameijar@gmail.com'
__version__ = '0.1.0'
