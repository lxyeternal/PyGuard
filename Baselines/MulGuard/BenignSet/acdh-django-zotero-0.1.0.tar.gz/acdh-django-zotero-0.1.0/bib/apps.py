# -*- coding: utf-8
from django.apps import AppConfig


class BibConfig(AppConfig):
    name = 'bib'
