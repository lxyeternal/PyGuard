.. :changelog:

History
-------

0.1.0 (2018-07-05)
++++++++++++++++++

* First release on PyPI.
