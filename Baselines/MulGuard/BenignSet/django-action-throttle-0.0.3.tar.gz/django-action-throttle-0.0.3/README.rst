Django Action Throttle
