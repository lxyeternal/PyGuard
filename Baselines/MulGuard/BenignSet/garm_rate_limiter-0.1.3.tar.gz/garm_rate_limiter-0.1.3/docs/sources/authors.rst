.. mdinclude:: ../../AUTHORS.md
