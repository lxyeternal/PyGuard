RATE_LIMIT_KEY_TEMPLATE_PREFIX = "RATE-LIMIT-{endpoint}-{ip_address}-{time}"
