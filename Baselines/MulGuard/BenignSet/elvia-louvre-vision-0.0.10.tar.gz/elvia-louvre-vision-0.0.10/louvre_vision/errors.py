class LouvreVisionValueError(ValueError):
    """Custom ValueError exception class."""
    pass
