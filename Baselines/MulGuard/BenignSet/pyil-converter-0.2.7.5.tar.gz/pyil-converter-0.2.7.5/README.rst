pyil-converter:
The better and easier way to convert the
format of a file.

Basic usage:
    For now, pyil only support text file, but
more will be added.
to use, simply do:
>>>import pyil
>>>pyil.text_file('C:\\example.txt','c:\\example_file without extension')
>>>pyil.what_ever()
>>>pyil.close()

If you have any suggestion, contact me at my email, G.Mpydev@gmail.com,
my site is https://wasted123.github.io/pyil/  :)
