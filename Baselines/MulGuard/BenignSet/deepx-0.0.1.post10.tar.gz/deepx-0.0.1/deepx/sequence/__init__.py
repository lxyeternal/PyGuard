from charrnn import CharacterRNN
