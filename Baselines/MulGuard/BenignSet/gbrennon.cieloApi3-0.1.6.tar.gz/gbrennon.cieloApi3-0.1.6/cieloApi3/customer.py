
class Customer(object):

    def __init__(self, name):

        self.name = name
        self.email = None
        self.birth_date = None
        self.identity = None
        self.identity_type = None
        self.address = None
        self.delivery_adress = None
