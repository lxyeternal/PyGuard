
class Address(object):

    def __init__(self):

        self.street = None
        self.number = None
        self.complement = None
        self.zip_code = None
        self.city = None
        self.state = None
        self.country = None
