class Merchant(object):

    def __init__(self, id, key):
        self.id = id
        self.key = key
