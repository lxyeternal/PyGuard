# Image Printer

Image Printer can convert and print an image as colored text.

## Example

Simply run the example:

```shell
    python example.py --path=nene.jpeg
```
