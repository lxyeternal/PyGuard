from setuptools import setup

setup(name='distributions-edu',
      version='0.1',
      description='Gaussian distributions',
      packages=['distributions-edu'],
      zip_safe=False)
