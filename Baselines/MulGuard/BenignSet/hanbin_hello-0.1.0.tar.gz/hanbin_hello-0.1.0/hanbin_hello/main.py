def hello():
    print("Hello from Hanbin!")