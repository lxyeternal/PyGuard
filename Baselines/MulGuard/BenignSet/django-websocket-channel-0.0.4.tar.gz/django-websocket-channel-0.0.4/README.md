# django-websocket-channel
Websocket support for Django using Redis
