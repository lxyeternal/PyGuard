from ipih import FACADE_FOLDER_NAME

from pih.tools import j

class FACADE:
    NAME: str = FACADE_FOLDER_NAME
    SERVICE_FOLDER_SUFFIX: str = "Service"