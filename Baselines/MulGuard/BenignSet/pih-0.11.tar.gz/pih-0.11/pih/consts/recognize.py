import ipih

from pih import A

A.A_RCG.recognize_document