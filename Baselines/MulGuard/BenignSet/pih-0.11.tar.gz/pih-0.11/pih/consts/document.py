from enum import Enum, auto

class DocumentTypes(Enum):
    POLIBASE: int = auto()
    MEDICAL_DIRECTION: int = auto()
    #PERSONAL: int = auto()

