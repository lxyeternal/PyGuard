import os

SERVER_API_HOST = os.environ["SERVER_API_HOST"]
SERVER_API_PORT = int(os.environ["SERVER_API_PORT"])
