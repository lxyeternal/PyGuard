This packages ontains all modules of lykkelle that are pertaining to the statistical information
Contents:
    1. Returns
    2. statistics
    3. Moving average

