from setuptools import setup

setup(name='dsnd_probability_ivllt',
      version='1.0',
      description='Gaussian and Binomial distributions',
      packages=['dsnd_probability_ivllt'],
      author = 'Ivan Lau',
      author_email = 'testing@hotmail.com',
      zip_safe=False)
