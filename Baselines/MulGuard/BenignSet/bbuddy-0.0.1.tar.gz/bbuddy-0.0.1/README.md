## bbuddy

The finest bash buddy on the internet

Home page: [bbuddy.org](http://bbuddy.org)

bbuddy is a graphical tool for typing your long commands.

Special thanks to [xdotool](https://www.semicomplete.com/projects/xdotool/), which does the heavy lifting.
xdotool is available on github [here](https://github.com/jordansissel/xdotool).

Also included in this distribution are the command line tools 'fffind', 'ppgrep', 'dbdump'.
