# misbehave
A Python Behavior Tree implementation.
