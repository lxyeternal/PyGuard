# -*- coding: utf-8 -*-

"""Versioning information."""

VERSION = '1.0.1'
