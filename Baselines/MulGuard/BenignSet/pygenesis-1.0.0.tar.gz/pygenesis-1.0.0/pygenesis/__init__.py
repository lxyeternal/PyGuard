"""
PyGenesis package
"""
from .main import info
