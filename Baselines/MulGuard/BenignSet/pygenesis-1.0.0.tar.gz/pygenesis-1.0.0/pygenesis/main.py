"""
Main module
"""


def info():
    """
    PyGenesis info
    :return: PyGenesis usage info
    """
    result = ('Just use this GitHub repository as template: '
                          'https://github.com/libresource/pygenesis and enjoy yourself')
    return result
