"""
Package info
"""
name = 'pygenesis'
version = '1.0.0'
status = '4 - Beta'
