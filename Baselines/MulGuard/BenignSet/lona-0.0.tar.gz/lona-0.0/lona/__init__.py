VERSION = (0, 0)
VERSION_STRING = '{}'.format('.'.join([str(i) for i in VERSION]))
