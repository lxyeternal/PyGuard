Installation
============

Invenio-Records-Marc21 is on PyPI so all you need is:

.. code-block:: console

   $ pip install invenio-records-marc21
