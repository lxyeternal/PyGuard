Introduction
============

The ContentLicensing tool allows for both a site wide copyright license to be set by default, and the ablility to set licenses on individual objects. It supports a number of licenses including all rights reserved, GFDL, and Creative Commons (with an integrated license picker). You can also enter and select licenses not supported by default, or configure new licenses that will appear in the selection widget for your Plone instance.[
