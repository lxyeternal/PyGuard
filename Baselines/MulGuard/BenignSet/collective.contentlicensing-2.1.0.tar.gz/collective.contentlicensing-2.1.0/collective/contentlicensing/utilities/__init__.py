# Make this directory a product.
