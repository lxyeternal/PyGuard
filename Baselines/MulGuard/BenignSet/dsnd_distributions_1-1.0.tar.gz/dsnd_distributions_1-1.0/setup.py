from setuptools import setup

setup(name='dsnd_distributions_1',
        version='1.0',
        description='Gaussian and Binomial distributions',
        packages=['dsnd_distributions_1'],
        author='Ahmad Sheikhzada',
        author_email='',
        zip_safe = False)

