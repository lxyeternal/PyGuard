# -*- coding: utf-8 -*-

def import_rtm(rtm_client, lists, tasks, verbose=False, dry_run=False):

    raise Exception("Sorry this is not yet implemented")

