"""
A quick way to check out the importpodcast.com site.
"""

import webbrowser

webbrowser.open_new_tab('http://importpodcast.com')
