from django.contrib import admin

from shortener.models import Url


admin.site.register(Url)
