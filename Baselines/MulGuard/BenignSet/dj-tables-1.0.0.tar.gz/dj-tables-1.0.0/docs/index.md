## dj-tables

### Introduction
A template only and DRY solution for creating tables.

Specifying how data is displayed should be exclusively done by the template, and this library
aims to do this by providing powerful template tags for constructing complex tables.