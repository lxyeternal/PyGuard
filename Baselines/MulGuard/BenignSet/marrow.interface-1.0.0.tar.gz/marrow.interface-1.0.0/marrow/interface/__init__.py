# encoding: utf-8

from marrow.interface.core import Interface
