from django.apps import AppConfig


class MediaAlbumsConfig(AppConfig):
    name = 'media_albums'
    verbose_name = 'Media Albums'
