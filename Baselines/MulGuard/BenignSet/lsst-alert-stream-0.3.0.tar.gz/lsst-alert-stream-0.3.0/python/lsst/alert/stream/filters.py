# This file is part of alert_stream.
#
# Developed for the LSST Data Management System.
# This product includes software developed by the LSST Project
# (https://www.lsst.org).
# See the COPYRIGHT file at the top-level directory of this distribution
# for details of code ownership.
#
# This program is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program.  If not, see <https://www.gnu.org/licenses/>.

from .filterBase import AlertFilter

class Filter001(AlertFilter):
    def filter(self, alert):
        if ((alert['diaSource']['snr'] > 5) &
           (alert['diaSource']['diffFlux'] > 0.00003631)):  # 20th mag
            return True
        else:
            return False


class Filter002(AlertFilter):
    def filter(self, alert):
        if ((alert['diaSource']['snr'] > 5) &
           (alert['diaSource']['diffFlux'] > 0.00003631)):
            return True
        else:
            return False


class Filter003(AlertFilter):
    def filter(self, alert):
        if ((alert['diaSource']['snr'] > 5) &
           (alert['diaSource']['diffFlux'] > 0.00003631)):
            return True
        else:
            return False


class Filter004(AlertFilter):
    def filter(self, alert):
        if ((alert['diaSource']['snr'] > 5) &
           (alert['diaSource']['diffFlux'] > 0.00003631)):
            return True
        else:
            return False


class Filter005(AlertFilter):
    def filter(self, alert):
        if ((alert['diaSource']['snr'] > 5) &
           (alert['diaSource']['diffFlux'] > 0.00003631)):
            return True
        else:
            return False


class Filter006(AlertFilter):
    def filter(self, alert):
        if ((alert['diaSource']['snr'] > 5) &
           (alert['diaSource']['diffFlux'] > 0.00003631)):
            return True
        else:
            return False


class Filter007(AlertFilter):
    def filter(self, alert):
        if ((alert['diaSource']['snr'] > 5) &
           (alert['diaSource']['diffFlux'] > 0.00003631)):
            return True
        else:
            return False


class Filter008(AlertFilter):
    def filter(self, alert):
        if ((alert['diaSource']['snr'] > 5) &
           (alert['diaSource']['diffFlux'] > 0.00003631)):
            return True
        else:
            return False


class Filter009(AlertFilter):
    def filter(self, alert):
        if ((alert['diaSource']['snr'] > 5) &
           (alert['diaSource']['diffFlux'] > 0.00003631)):
            return True
        else:
            return False


class Filter010(AlertFilter):
    def filter(self, alert):
        if ((alert['diaSource']['snr'] > 5) &
           (alert['diaSource']['diffFlux'] > 0.00003631)):
            return True
        else:
            return False


class Filter011(AlertFilter):
    def filter(self, alert):
        if ((alert['diaSource']['snr'] > 5) &
           (alert['diaSource']['diffFlux'] > 0.00003631)):
            return True
        else:
            return False


class Filter012(AlertFilter):
    def filter(self, alert):
        if ((alert['diaSource']['snr'] > 5) &
           (alert['diaSource']['diffFlux'] > 0.00003631)):
            return True
        else:
            return False


class Filter013(AlertFilter):
    def filter(self, alert):
        if ((alert['diaSource']['snr'] > 5) &
           (alert['diaSource']['diffFlux'] > 0.00003631)):
            return True
        else:
            return False


class Filter014(AlertFilter):
    def filter(self, alert):
        if ((alert['diaSource']['snr'] > 5) &
           (alert['diaSource']['diffFlux'] > 0.00003631)):
            return True
        else:
            return False


class Filter015(AlertFilter):
    def filter(self, alert):
        if ((alert['diaSource']['snr'] > 5) &
           (alert['diaSource']['diffFlux'] > 0.00003631)):
            return True
        else:
            return False


class Filter016(AlertFilter):
    def filter(self, alert):
        if ((alert['diaSource']['snr'] > 5) &
           (alert['diaSource']['diffFlux'] > 0.00003631)):
            return True
        else:
            return False


class Filter017(AlertFilter):
    def filter(self, alert):
        if ((alert['diaSource']['snr'] > 5) &
           (alert['diaSource']['diffFlux'] > 0.00003631)):
            return True
        else:
            return False


class Filter018(AlertFilter):
    def filter(self, alert):
        if ((alert['diaSource']['snr'] > 5) &
           (alert['diaSource']['diffFlux'] > 0.00003631)):
            return True
        else:
            return False


class Filter019(AlertFilter):
    def filter(self, alert):
        if ((alert['diaSource']['snr'] > 5) &
           (alert['diaSource']['diffFlux'] > 0.00003631)):
            return True
        else:
            return False


class Filter020(AlertFilter):
    def filter(self, alert):
        if ((alert['diaSource']['snr'] > 5) &
           (alert['diaSource']['diffFlux'] > 0.00003631)):
            return True
        else:
            return False


class Filter021(AlertFilter):
    def filter(self, alert):
        if ((alert['diaSource']['snr'] > 5) &
           (alert['diaSource']['diffFlux'] > 0.00003631)):
            return True
        else:
            return False


class Filter022(AlertFilter):
    def filter(self, alert):
        if ((alert['diaSource']['snr'] > 5) &
           (alert['diaSource']['diffFlux'] > 0.00003631)):
            return True
        else:
            return False


class Filter023(AlertFilter):
    def filter(self, alert):
        if ((alert['diaSource']['snr'] > 5) &
           (alert['diaSource']['diffFlux'] > 0.00003631)):
            return True
        else:
            return False


class Filter024(AlertFilter):
    def filter(self, alert):
        if ((alert['diaSource']['snr'] > 5) &
           (alert['diaSource']['diffFlux'] > 0.00003631)):
            return True
        else:
            return False


class Filter025(AlertFilter):
    def filter(self, alert):
        if ((alert['diaSource']['snr'] > 5) &
           (alert['diaSource']['diffFlux'] > 0.00003631)):
            return True
        else:
            return False


class Filter026(AlertFilter):
    def filter(self, alert):
        if ((alert['diaSource']['snr'] > 5) &
           (alert['diaSource']['diffFlux'] > 0.00003631)):
            return True
        else:
            return False


class Filter027(AlertFilter):
    def filter(self, alert):
        if ((alert['diaSource']['snr'] > 5) &
           (alert['diaSource']['diffFlux'] > 0.00003631)):
            return True
        else:
            return False


class Filter028(AlertFilter):
    def filter(self, alert):
        if ((alert['diaSource']['snr'] > 5) &
           (alert['diaSource']['diffFlux'] > 0.00003631)):
            return True
        else:
            return False


class Filter029(AlertFilter):
    def filter(self, alert):
        if ((alert['diaSource']['snr'] > 5) &
           (alert['diaSource']['diffFlux'] > 0.00003631)):
            return True
        else:
            return False


class Filter030(AlertFilter):
    def filter(self, alert):
        if ((alert['diaSource']['snr'] > 5) &
           (alert['diaSource']['diffFlux'] > 0.00003631)):
            return True
        else:
            return False


class Filter031(AlertFilter):
    def filter(self, alert):
        if ((alert['diaSource']['snr'] > 5) &
           (alert['diaSource']['diffFlux'] > 0.00003631)):
            return True
        else:
            return False


class Filter032(AlertFilter):
    def filter(self, alert):
        if ((alert['diaSource']['snr'] > 5) &
           (alert['diaSource']['diffFlux'] > 0.00003631)):
            return True
        else:
            return False


class Filter033(AlertFilter):
    def filter(self, alert):
        if ((alert['diaSource']['snr'] > 5) &
           (alert['diaSource']['diffFlux'] > 0.00003631)):
            return True
        else:
            return False


class Filter034(AlertFilter):
    def filter(self, alert):
        if ((alert['diaSource']['snr'] > 5) &
           (alert['diaSource']['diffFlux'] > 0.00003631)):
            return True
        else:
            return False


class Filter035(AlertFilter):
    def filter(self, alert):
        if ((alert['diaSource']['snr'] > 5) &
           (alert['diaSource']['diffFlux'] > 0.00003631)):
            return True
        else:
            return False


class Filter036(AlertFilter):
    def filter(self, alert):
        if ((alert['diaSource']['snr'] > 5) &
           (alert['diaSource']['diffFlux'] > 0.00003631)):
            return True
        else:
            return False


class Filter037(AlertFilter):
    def filter(self, alert):
        if ((alert['diaSource']['snr'] > 5) &
           (alert['diaSource']['diffFlux'] > 0.00003631)):
            return True
        else:
            return False


class Filter038(AlertFilter):
    def filter(self, alert):
        if ((alert['diaSource']['snr'] > 5) &
           (alert['diaSource']['diffFlux'] > 0.00003631)):
            return True
        else:
            return False


class Filter039(AlertFilter):
    def filter(self, alert):
        if ((alert['diaSource']['snr'] > 5) &
           (alert['diaSource']['diffFlux'] > 0.00003631)):
            return True
        else:
            return False


class Filter040(AlertFilter):
    def filter(self, alert):
        if ((alert['diaSource']['snr'] > 5) &
           (alert['diaSource']['diffFlux'] > 0.00003631)):
            return True
        else:
            return False


class Filter041(AlertFilter):
    def filter(self, alert):
        if ((alert['diaSource']['snr'] > 5) &
           (alert['diaSource']['diffFlux'] > 0.00003631)):
            return True
        else:
            return False


class Filter042(AlertFilter):
    def filter(self, alert):
        if ((alert['diaSource']['snr'] > 5) &
           (alert['diaSource']['diffFlux'] > 0.00003631)):
            return True
        else:
            return False


class Filter043(AlertFilter):
    def filter(self, alert):
        if ((alert['diaSource']['snr'] > 5) &
           (alert['diaSource']['diffFlux'] > 0.00003631)):
            return True
        else:
            return False


class Filter044(AlertFilter):
    def filter(self, alert):
        if ((alert['diaSource']['snr'] > 5) &
           (alert['diaSource']['diffFlux'] > 0.00003631)):
            return True
        else:
            return False


class Filter045(AlertFilter):
    def filter(self, alert):
        if ((alert['diaSource']['snr'] > 5) &
           (alert['diaSource']['diffFlux'] > 0.00003631)):
            return True
        else:
            return False


class Filter046(AlertFilter):
    def filter(self, alert):
        if ((alert['diaSource']['snr'] > 5) &
           (alert['diaSource']['diffFlux'] > 0.00003631)):
            return True
        else:
            return False


class Filter047(AlertFilter):
    def filter(self, alert):
        if ((alert['diaSource']['snr'] > 5) &
           (alert['diaSource']['diffFlux'] > 0.00003631)):
            return True
        else:
            return False


class Filter048(AlertFilter):
    def filter(self, alert):
        if ((alert['diaSource']['snr'] > 5) &
           (alert['diaSource']['diffFlux'] > 0.00003631)):
            return True
        else:
            return False


class Filter049(AlertFilter):
    def filter(self, alert):
        if ((alert['diaSource']['snr'] > 5) &
           (alert['diaSource']['diffFlux'] > 0.00003631)):
            return True
        else:
            return False


class Filter050(AlertFilter):
    def filter(self, alert):
        if ((alert['diaSource']['snr'] > 5) &
           (alert['diaSource']['diffFlux'] > 0.00003631)):
            return True
        else:
            return False


class Filter051(AlertFilter):
    def filter(self, alert):
        if ((alert['diaSource']['snr'] > 5) &
           (alert['diaSource']['diffFlux'] > 0.00003631)):
            return True
        else:
            return False


class Filter052(AlertFilter):
    def filter(self, alert):
        if ((alert['diaSource']['snr'] > 5) &
           (alert['diaSource']['diffFlux'] > 0.00003631)):
            return True
        else:
            return False


class Filter053(AlertFilter):
    def filter(self, alert):
        if ((alert['diaSource']['snr'] > 5) &
           (alert['diaSource']['diffFlux'] > 0.00003631)):
            return True
        else:
            return False


class Filter054(AlertFilter):
    def filter(self, alert):
        if ((alert['diaSource']['snr'] > 5) &
           (alert['diaSource']['diffFlux'] > 0.00003631)):
            return True
        else:
            return False


class Filter055(AlertFilter):
    def filter(self, alert):
        if ((alert['diaSource']['snr'] > 5) &
           (alert['diaSource']['diffFlux'] > 0.00003631)):
            return True
        else:
            return False


class Filter056(AlertFilter):
    def filter(self, alert):
        if ((alert['diaSource']['snr'] > 5) &
           (alert['diaSource']['diffFlux'] > 0.00003631)):
            return True
        else:
            return False


class Filter057(AlertFilter):
    def filter(self, alert):
        if ((alert['diaSource']['snr'] > 5) &
           (alert['diaSource']['diffFlux'] > 0.00003631)):
            return True
        else:
            return False


class Filter058(AlertFilter):
    def filter(self, alert):
        if ((alert['diaSource']['snr'] > 5) &
           (alert['diaSource']['diffFlux'] > 0.00003631)):
            return True
        else:
            return False


class Filter059(AlertFilter):
    def filter(self, alert):
        if ((alert['diaSource']['snr'] > 5) &
           (alert['diaSource']['diffFlux'] > 0.00003631)):
            return True
        else:
            return False


class Filter060(AlertFilter):
    def filter(self, alert):
        if ((alert['diaSource']['snr'] > 5) &
           (alert['diaSource']['diffFlux'] > 0.00003631)):
            return True
        else:
            return False


class Filter061(AlertFilter):
    def filter(self, alert):
        if ((alert['diaSource']['snr'] > 5) &
           (alert['diaSource']['diffFlux'] > 0.00003631)):
            return True
        else:
            return False


class Filter062(AlertFilter):
    def filter(self, alert):
        if ((alert['diaSource']['snr'] > 5) &
           (alert['diaSource']['diffFlux'] > 0.00003631)):
            return True
        else:
            return False


class Filter063(AlertFilter):
    def filter(self, alert):
        if ((alert['diaSource']['snr'] > 5) &
           (alert['diaSource']['diffFlux'] > 0.00003631)):
            return True
        else:
            return False


class Filter064(AlertFilter):
    def filter(self, alert):
        if ((alert['diaSource']['snr'] > 5) &
           (alert['diaSource']['diffFlux'] > 0.00003631)):
            return True
        else:
            return False


class Filter065(AlertFilter):
    def filter(self, alert):
        if ((alert['diaSource']['snr'] > 5) &
           (alert['diaSource']['diffFlux'] > 0.00003631)):
            return True
        else:
            return False


class Filter066(AlertFilter):
    def filter(self, alert):
        if ((alert['diaSource']['snr'] > 5) &
           (alert['diaSource']['diffFlux'] > 0.00003631)):
            return True
        else:
            return False


class Filter067(AlertFilter):
    def filter(self, alert):
        if ((alert['diaSource']['snr'] > 5) &
           (alert['diaSource']['diffFlux'] > 0.00003631)):
            return True
        else:
            return False


class Filter068(AlertFilter):
    def filter(self, alert):
        if ((alert['diaSource']['snr'] > 5) &
           (alert['diaSource']['diffFlux'] > 0.00003631)):
            return True
        else:
            return False


class Filter069(AlertFilter):
    def filter(self, alert):
        if ((alert['diaSource']['snr'] > 5) &
           (alert['diaSource']['diffFlux'] > 0.00003631)):
            return True
        else:
            return False


class Filter070(AlertFilter):
    def filter(self, alert):
        if ((alert['diaSource']['snr'] > 5) &
           (alert['diaSource']['diffFlux'] > 0.00003631)):
            return True
        else:
            return False


class Filter071(AlertFilter):
    def filter(self, alert):
        if ((alert['diaSource']['snr'] > 5) &
           (alert['diaSource']['diffFlux'] > 0.00003631)):
            return True
        else:
            return False


class Filter072(AlertFilter):
    def filter(self, alert):
        if ((alert['diaSource']['snr'] > 5) &
           (alert['diaSource']['diffFlux'] > 0.00003631)):
            return True
        else:
            return False


class Filter073(AlertFilter):
    def filter(self, alert):
        if ((alert['diaSource']['snr'] > 5) &
           (alert['diaSource']['diffFlux'] > 0.00003631)):
            return True
        else:
            return False


class Filter074(AlertFilter):
    def filter(self, alert):
        if ((alert['diaSource']['snr'] > 5) &
           (alert['diaSource']['diffFlux'] > 0.00003631)):
            return True
        else:
            return False


class Filter075(AlertFilter):
    def filter(self, alert):
        if ((alert['diaSource']['snr'] > 5) &
           (alert['diaSource']['diffFlux'] > 0.00003631)):
            return True
        else:
            return False


class Filter076(AlertFilter):
    def filter(self, alert):
        if ((alert['diaSource']['snr'] > 5) &
           (alert['diaSource']['diffFlux'] > 0.00003631)):
            return True
        else:
            return False


class Filter077(AlertFilter):
    def filter(self, alert):
        if ((alert['diaSource']['snr'] > 5) &
           (alert['diaSource']['diffFlux'] > 0.00003631)):
            return True
        else:
            return False


class Filter078(AlertFilter):
    def filter(self, alert):
        if ((alert['diaSource']['snr'] > 5) &
           (alert['diaSource']['diffFlux'] > 0.00003631)):
            return True
        else:
            return False


class Filter079(AlertFilter):
    def filter(self, alert):
        if ((alert['diaSource']['snr'] > 5) &
           (alert['diaSource']['diffFlux'] > 0.00003631)):
            return True
        else:
            return False


class Filter080(AlertFilter):
    def filter(self, alert):
        if ((alert['diaSource']['snr'] > 5) &
           (alert['diaSource']['diffFlux'] > 0.00003631)):
            return True
        else:
            return False



class Filter081(AlertFilter):
    def filter(self, alert):
        if ((alert['diaSource']['snr'] > 5) &
           (alert['diaSource']['diffFlux'] > 0.00003631)):
            return True
        else:
            return False


class Filter082(AlertFilter):
    def filter(self, alert):
        if ((alert['diaSource']['snr'] > 5) &
           (alert['diaSource']['diffFlux'] > 0.00003631)):
            return True
        else:
            return False


class Filter083(AlertFilter):
    def filter(self, alert):
        if ((alert['diaSource']['snr'] > 5) &
           (alert['diaSource']['diffFlux'] > 0.00003631)):
            return True
        else:
            return False


class Filter084(AlertFilter):
    def filter(self, alert):
        if ((alert['diaSource']['snr'] > 5) &
           (alert['diaSource']['diffFlux'] > 0.00003631)):
            return True
        else:
            return False


class Filter085(AlertFilter):
    def filter(self, alert):
        if ((alert['diaSource']['snr'] > 5) &
           (alert['diaSource']['diffFlux'] > 0.00003631)):
            return True
        else:
            return False


class Filter086(AlertFilter):
    def filter(self, alert):
        if ((alert['diaSource']['snr'] > 5) &
           (alert['diaSource']['diffFlux'] > 0.00003631)):
            return True
        else:
            return False


class Filter087(AlertFilter):
    def filter(self, alert):
        if ((alert['diaSource']['snr'] > 5) &
           (alert['diaSource']['diffFlux'] > 0.00003631)):
            return True
        else:
            return False


class Filter088(AlertFilter):
    def filter(self, alert):
        if ((alert['diaSource']['snr'] > 5) &
           (alert['diaSource']['diffFlux'] > 0.00003631)):
            return True
        else:
            return False


class Filter089(AlertFilter):
    def filter(self, alert):
        if ((alert['diaSource']['snr'] > 5) &
           (alert['diaSource']['diffFlux'] > 0.00003631)):
            return True
        else:
            return False


class Filter090(AlertFilter):
    def filter(self, alert):
        if ((alert['diaSource']['snr'] > 5) &
           (alert['diaSource']['diffFlux'] > 0.00003631)):
            return True
        else:
            return False


class Filter091(AlertFilter):
    def filter(self, alert):
        if ((alert['diaSource']['snr'] > 5) &
           (alert['diaSource']['diffFlux'] > 0.00003631)):
            return True
        else:
            return False


class Filter092(AlertFilter):
    def filter(self, alert):
        if ((alert['diaSource']['snr'] > 5) &
           (alert['diaSource']['diffFlux'] > 0.00003631)):
            return True
        else:
            return False


class Filter093(AlertFilter):
    def filter(self, alert):
        if ((alert['diaSource']['snr'] > 5) &
           (alert['diaSource']['diffFlux'] > 0.00003631)):
            return True
        else:
            return False


class Filter094(AlertFilter):
    def filter(self, alert):
        if ((alert['diaSource']['snr'] > 5) &
           (alert['diaSource']['diffFlux'] > 0.00003631)):
            return True
        else:
            return False


class Filter095(AlertFilter):
    def filter(self, alert):
        if ((alert['diaSource']['snr'] > 5) &
           (alert['diaSource']['diffFlux'] > 0.00003631)):
            return True
        else:
            return False


class Filter096(AlertFilter):
    def filter(self, alert):
        if ((alert['diaSource']['snr'] > 5) &
           (alert['diaSource']['diffFlux'] > 0.00003631)):
            return True
        else:
            return False


class Filter097(AlertFilter):
    def filter(self, alert):
        if ((alert['diaSource']['snr'] > 5) &
           (alert['diaSource']['diffFlux'] > 0.00003631)):
            return True
        else:
            return False


class Filter098(AlertFilter):
    def filter(self, alert):
        if ((alert['diaSource']['snr'] > 5) &
           (alert['diaSource']['diffFlux'] > 0.00003631)):
            return True
        else:
            return False


class Filter099(AlertFilter):
    def filter(self, alert):
        if ((alert['diaSource']['snr'] > 5) &
           (alert['diaSource']['diffFlux'] > 0.00003631)):
            return True
        else:
            return False


class Filter100(AlertFilter):
    def filter(self, alert):
        if ((alert['diaSource']['snr'] > 5) &
           (alert['diaSource']['diffFlux'] > 0.00003631)):
            return True
        else:
            return False
