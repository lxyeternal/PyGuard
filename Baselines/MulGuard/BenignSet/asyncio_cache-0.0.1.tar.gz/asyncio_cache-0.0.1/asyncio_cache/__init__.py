from asyncio_cache.asyncio_cache import cache, lru_cache
