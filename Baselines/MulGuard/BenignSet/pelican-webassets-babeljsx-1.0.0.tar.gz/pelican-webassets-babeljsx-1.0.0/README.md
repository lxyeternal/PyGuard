# Pelican-webassets-babeljsx

Enables the webassets babeljsx filter (provided by dukpy)
