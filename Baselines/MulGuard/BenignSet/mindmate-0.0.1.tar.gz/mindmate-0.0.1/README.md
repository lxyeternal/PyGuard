# build package
```
python setup.py sdist
```
# install package
```
pip install .
```

# usage
```
mindmate [ARGUMENT] [OPTIONS] [OPTIONS] [OPTIONS] --help
```

# compatibility

__Not tested__ yet, but should be compatible with any Python > 3.8