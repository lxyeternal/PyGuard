#!/usr/bin/env python

"""The setup script."""

# Third party modules
from setuptools import setup

setup()
