"""Top-level package for pizazz."""

__title__ = "pynnacle"
__author__ = "Stephen R A King"
__description__ = "A utility class to simplify the sending of emails"
__version__ = "1.0.0"
__license__ = "MIT"
__copyright__ = "Copyright 2022 Stephen R A King"
