from setuptools import setup, find_packages

setup(
    author = 'Lukas Heinrich',
    author_email = 'lukas.heinrich@gmail.com',
    name = 'cap-schemas',
    version = '0.0.1',
    description = 'schemas for analysis preservation',
    include_package_data = True,
    packages = find_packages()
)
