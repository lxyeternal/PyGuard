# pypluggy
Pypluggy is a lightweight python plugin framework
