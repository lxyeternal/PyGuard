from distutils.core import setup
setup(
    name='forpublish',
    version='1.0',
    author='yangwh',
    author_email='1971649894@qq.com',
    description='to test package dist',
    py_modules=['CREATE.root','CREATE.a.module_a2','CREATE.a.module_a3','CREATE.a.aa.module_aa','CREATE.b.module_b2','CREATE.b.module_b1']
)