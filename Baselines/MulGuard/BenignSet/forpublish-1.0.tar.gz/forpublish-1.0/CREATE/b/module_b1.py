print('b1')
from a.aa.module_aa import fun_aa
fun_aa()