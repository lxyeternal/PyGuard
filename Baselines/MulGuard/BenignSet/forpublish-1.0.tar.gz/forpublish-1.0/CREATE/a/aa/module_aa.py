print('aa')
def fun_aa():
    print('have fun aa')