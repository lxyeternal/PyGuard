print('a2')
import math