PyScada SM Bus Extension
========================

This is a extension for PyScada to support SM Bus devices.


What is Working
---------------

 - nothing is test


What is not Working/Missing
---------------------------

 - Documentation

Installation
------------

 - pip install pyscada-smbus


Contribute
----------

 - Issue Tracker: https://github.com/pyscada/PyScada-smbus/issues
 - Source Code: https://github.com/pyscada/PyScada-smbus


License
-------

The project is licensed under the _GNU AFFERO GENERAL PUBLIC LICENSE Version 3 (AGPLv3)_.

