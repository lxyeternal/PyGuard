import pejecoins as peje

test = peje.suma(1,2)
print(test)