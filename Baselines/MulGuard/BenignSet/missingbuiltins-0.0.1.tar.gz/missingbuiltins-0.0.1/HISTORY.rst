=======
History
=======

0.0.1 (2020-03-04)
------------------

* First release on PyPI.
