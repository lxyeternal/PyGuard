=====
Usage
=====

To use Missing Builtins in a project::

    import missingbuiltins
