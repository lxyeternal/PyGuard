import pandas as pd

def asd():

    print('asd')


if __name__ == '__main__':
    asd()