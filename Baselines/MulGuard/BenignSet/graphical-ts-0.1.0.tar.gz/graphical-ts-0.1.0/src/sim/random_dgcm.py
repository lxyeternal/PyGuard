import numpy as np
from sim.dgcm import DGCM



# Goals: 

# [ ] manage perturbation graph
# [ ] manage mapping functions for different graph
# [ ] return ground truth
class PertDGCM(object):
    
    def __init__(self, DGCM):
        pass
        
    
    