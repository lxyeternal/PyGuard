from setuptools import find_packages, setup

setup(
    name='pezBowl',
    packages=find_packages(),
)