#!/usr/bin/python
# -*- coding: utf-8 -*-

from components import (Table, TableView, TablePage,
                        NameColumn, Column, GetAttrColumn,
			CheckBoxColumn, LinkColumn, Values,
			ModifiedColumn)
from z3c.table.interfaces import (ITable, IColumn)
