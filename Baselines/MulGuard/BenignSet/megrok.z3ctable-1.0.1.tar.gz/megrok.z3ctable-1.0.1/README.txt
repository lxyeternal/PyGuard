===============
megrok.z3ctable
===============

Introduction
============

The `megrok.z3ctable` package is a wrapper for the most
components of z3c.table [1]. This means you can configure 
this components:

  - Tables
  - Columns
  - Value (Adapters)

in a grok specific way.


Views
-----

There are two special *Table Views" which renders the
Table in a BrowserView.

  - TableView 
  - TablePage


For more information please look on the existing functional doctests!

[1] http://pypi.python.org/pypi/z3c.table/0.6.1
