from django import dispatch

presence_changed = dispatch.Signal()
