========================
django-channels-presence-4.0
========================

A reusable Django app for implementing "presence" and "rooms" using
`django-channels <https://github.com/andrewgodwin/channels>`_.

- Docs: https://django-channels-presence.readthedocs.org

Compatible with Django 4.2 and django-channels 4.0.0

Quick install::

    pip install django-channels-presence-4.0


