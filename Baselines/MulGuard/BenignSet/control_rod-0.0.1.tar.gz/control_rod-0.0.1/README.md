# control_rod

Tool to Create Technical Controls in AB Product based on AWS Control Datum.
