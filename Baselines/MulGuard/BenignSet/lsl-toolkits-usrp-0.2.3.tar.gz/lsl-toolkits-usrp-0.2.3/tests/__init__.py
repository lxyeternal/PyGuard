# -*- coding: utf-8 -*-

"""
Modules defining package tests.
"""

__revision__  = "$Rev: 1404 $"
__version__   = "0.1"
__author__    = "Jayce Dowell"

import test_usrp
