# -*- coding: utf-8 -*-

__version__ = '0.1'
__revision__ = '$Rev: 1397 $'

from reader import *



