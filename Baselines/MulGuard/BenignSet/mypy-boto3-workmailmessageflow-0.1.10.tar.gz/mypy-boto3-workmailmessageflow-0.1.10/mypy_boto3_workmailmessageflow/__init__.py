"Main interface for workmailmessageflow service"

from mypy_boto3_workmailmessageflow.client import Client

__all__ = ("Client",)
