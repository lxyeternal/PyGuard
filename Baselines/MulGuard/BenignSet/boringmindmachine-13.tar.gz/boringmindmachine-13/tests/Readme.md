# boring-rainbow-mind-machine tests

These are tests of basic functionality,
no authorization or bot activities involved.

