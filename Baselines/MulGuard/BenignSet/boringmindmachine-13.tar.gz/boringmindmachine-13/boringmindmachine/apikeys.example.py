consumer_key    = '123456'
consumer_secret = '123456'
flickr_key      = '123456'
flickr_secret   = '123456'
