class Mypkg:
    def __init__(self):
        print("you have choosed Mypkg")
    def author(self):
        return "Dr.DhanaSekhar"
    def sumof2(self, a,b):
        return a+b
