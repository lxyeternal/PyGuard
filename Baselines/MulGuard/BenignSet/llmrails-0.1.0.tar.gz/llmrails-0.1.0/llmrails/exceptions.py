

class RequestException(Exception):
    pass