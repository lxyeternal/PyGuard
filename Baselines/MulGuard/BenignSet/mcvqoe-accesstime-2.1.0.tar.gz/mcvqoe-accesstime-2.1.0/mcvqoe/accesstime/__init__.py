from .access_time import measure
from .version import version,version_tuple
from .access_time_eval import evaluate, AccessData, FitData, default_correction_data
