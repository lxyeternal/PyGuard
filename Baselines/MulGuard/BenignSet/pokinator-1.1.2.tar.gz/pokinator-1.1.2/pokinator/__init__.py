from . import pokemons
from .pokinator import Pokinator
