"""Boards definition from HardKernel"""
