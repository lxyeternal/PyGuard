"""Definition for the Rockchip RK3328 chip"""
