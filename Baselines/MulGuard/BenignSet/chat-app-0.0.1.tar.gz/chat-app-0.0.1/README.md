# chat-app

Allows people to chat through terminal

## Installation

### Install Using Git:

```bash
git clone https://github.com/lol-cubes/chat-app.git
pip install cryptography
cd chat-app
python3 chat-app  # configure password
```
### Install Using Pip:

*Coming soon*

## Usage

*Coming soon*

## System Requirements and Dependencies
- Python 3.x installed
- Unix-based OS
