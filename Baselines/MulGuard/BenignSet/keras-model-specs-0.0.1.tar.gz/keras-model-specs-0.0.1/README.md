A helper package for managing Keras model base architectures with overrides for target size and preprocessing functions.

[![Build Status](https://travis-ci.org/triagemd/keras-model-specs.svg?branch=master)](https://travis-ci.org/triagemd/keras-model-specs) [![PyPI version](https://badge.fury.io/py/keras-model-specs.svg)](https://badge.fury.io/py/keras-model-specs)
