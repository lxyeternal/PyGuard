from .model_spec import ModelSpec


__all__ = ['ModelSpec', ]
