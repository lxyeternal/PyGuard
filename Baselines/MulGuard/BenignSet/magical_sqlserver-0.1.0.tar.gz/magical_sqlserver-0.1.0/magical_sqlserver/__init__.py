# flake8: noqa
from magical_sqlserver.api import SQLServer


name = "magical_sqlserver"
