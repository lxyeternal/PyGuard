from setuptools import setup

setup (name='saylani46165db',
version='0.1',
description='This is the Saylani DB Package',
author = "Shahzad Ahmed Khan",
packages = ['saylani46165db'],
zip_safe=False,
install_packages = []
)