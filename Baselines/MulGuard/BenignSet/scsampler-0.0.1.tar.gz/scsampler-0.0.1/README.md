# scSampler
`scSampler` is a Python pacakge for fast divese subsampling cells in large scale single-cell datasets.
