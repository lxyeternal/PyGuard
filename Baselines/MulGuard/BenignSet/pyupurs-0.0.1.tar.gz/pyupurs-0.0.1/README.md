# pyupurs

Yet another python library for useful utilities.

- **How do you pronounce pyupurs ?** - "pie-up-yuurs"

# List of modules and their features
## file_ops : For operations on various files
### schema_audit.py -> A module to audit structured