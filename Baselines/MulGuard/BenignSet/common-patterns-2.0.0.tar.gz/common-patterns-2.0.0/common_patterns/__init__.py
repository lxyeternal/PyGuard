#!/usr/bin/env python
# encoding: utf-8

from .common_patterns import *

name = 'common-patterns'
