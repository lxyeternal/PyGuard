# Python: Common Patterns

[![PyPI Version](http://img.shields.io/pypi/v/common-patterns.svg)](https://pypi.python.org/pypi/common-patterns/)

Common Patterns


## Installation

``` console
$ pip3 install common-patterns
```


## Usage

``` python
import common-patterns
```

