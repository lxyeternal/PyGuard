==================================
PEP 561 Typing Stubs for PyGObject
==================================

.. image:: https://travis-ci.org/pygobject/pygobject-stubs.svg?branch=master
    :target: https://travis-ci.org/pygobject/pygobject-stubs
