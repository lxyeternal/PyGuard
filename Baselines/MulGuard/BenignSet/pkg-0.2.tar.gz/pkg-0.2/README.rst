.. warning::

   This is work in progress, installing with 'pip' is not supported at this
   point. If you're looking for python scripts to automate the LFS (`Linux From
   Scratch`_) build, please see `github.com/joaomdsc/pkg`_.
   
Documentation for this software can be found on `pkg.readthedocs.io`_.

.. _Linux From Scratch: http://www.linuxfromscratch.org/
.. _github.com/joaomdsc/pkg: https://github.com/joaomdsc/pkg
.. _pkg.readthedocs.io: https://pkg.readthedocs.io
