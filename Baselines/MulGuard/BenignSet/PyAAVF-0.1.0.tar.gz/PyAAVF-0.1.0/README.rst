Pyaavf |Version| |Build| |Coverage| |Health|
===================================================================

|Compatibility| |Implementations| |Format| |Downloads|

An Amino Acid Variant Format parser for Python.

.. code:: python

    # TODO: add super short usage


Installation:

.. code:: console

    $ pip install PyAAVF

.. TODO: longer description


Example
-------

.. code:: python

    # TODO: add example


Changelog
---------

**0.1.0**

- Initial release.


.. |Build| image:: https://travis-ci.org/winhiv/PyAAVF.svg?branch=master
   :target: https://travis-ci.org/winhiv/PyAAVF
.. |Coverage| image:: https://img.shields.io/coveralls/winhiv/PyAAVF.svg
   :target: https://coveralls.io/r/winhiv/PyAAVF
.. |Health| image:: https://codeclimate.com/github/winhiv/PyAAVF/badges/gpa.svg
   :target: https://codeclimate.com/github/winhiv/PyAAVF
.. |Version| image:: https://img.shields.io/pypi/v/PyAAVF.svg
   :target: https://pypi.python.org/pypi/PyAAVF
.. |Downloads| image:: https://img.shields.io/pypi/dm/PyAAVF.svg
   :target: https://pypi.python.org/pypi/PyAAVF
.. |Compatibility| image:: https://img.shields.io/pypi/pyversions/PyAAVF.svg
   :target: https://pypi.python.org/pypi/PyAAVF
.. |Implementations| image:: https://img.shields.io/pypi/implementation/PyAAVF.svg
   :target: https://pypi.python.org/pypi/PyAAVF
.. |Format| image:: https://img.shields.io/pypi/format/PyAAVF.svg
   :target: https://pypi.python.org/pypi/PyAAVF
