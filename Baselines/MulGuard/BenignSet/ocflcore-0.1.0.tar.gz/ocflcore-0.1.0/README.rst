..
    Copyright (C) 2021 CERN.

    OCFL Core is free software; you can redistribute it and/or modify it under
    the terms of the MIT License; see LICENSE file for more details.

===========
 OCFL Core
===========

.. image:: https://github.com/inveniosoftware/ocflcore/workflows/CI/badge.svg
        :target: https://github.com/inveniosoftware/ocflcore/actions?query=workflow%3ACI

.. image:: https://img.shields.io/github/tag/inveniosoftware/ocflcore.svg
        :target: https://github.com/inveniosoftware/ocflcore/releases

.. image:: https://img.shields.io/pypi/dm/ocflcore.svg
        :target: https://pypi.python.org/pypi/ocflcore

.. image:: https://img.shields.io/github/license/inveniosoftware/ocflcore.svg
        :target: https://github.com/inveniosoftware/ocflcore/blob/master/LICENSE

Oxford Common Filesystem Layout module for Python.

Further documentation is available on https://ocflcore.readthedocs.io/.
