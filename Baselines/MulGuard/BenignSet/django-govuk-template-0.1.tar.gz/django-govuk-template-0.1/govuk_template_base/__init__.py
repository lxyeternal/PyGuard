VERSION = (0, 1)
__version__ = '.'.join(map(str, VERSION))
__author__ = 'Ministry of Justice'

default_app_config = 'govuk_template_base.apps.TemplateAppConfig'
