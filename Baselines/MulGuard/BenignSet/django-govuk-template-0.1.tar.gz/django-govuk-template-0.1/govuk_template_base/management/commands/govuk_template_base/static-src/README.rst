Optional components and those that need pre-processing, such as SASS files, are collected here from
``govuk_template``, ``govuk-elements-sass`` and ``govuk_frontend_toolkit``.

You can use grunt/gulp or another workflow to build these files.
If [scss] extra was installed, a base CSS file is built from defaults.
