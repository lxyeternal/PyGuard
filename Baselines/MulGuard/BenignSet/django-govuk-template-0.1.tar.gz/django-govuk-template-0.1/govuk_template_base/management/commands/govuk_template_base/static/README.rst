Static assets, such as images and pre-built JS and CSS, are collected here from
``govuk_template``, ``govuk-elements-sass`` and ``govuk_frontend_toolkit``.
