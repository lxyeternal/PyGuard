# CHANGELOG

This is a manually generated log to track changes to the repository for each release. 
Each section should include general headers such as **Implemented enhancements** 
and **Merged pull requests**. 

The versions coincide with releases on pypi.

## [0.0.x](https://github.com/vsoch/codeart/tree/master) (0.0.x)
 - dummy release with base functions without client (0.0.1)

