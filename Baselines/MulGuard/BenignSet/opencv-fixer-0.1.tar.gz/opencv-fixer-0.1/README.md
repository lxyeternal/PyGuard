# OpenCV Fixer

Fix OpenCV Issue for numpy, diffusers, etc.

## Issue Coveraged

- [opencv/opencv-python #884](https://github.com/opencv/opencv-python/issues/884)
