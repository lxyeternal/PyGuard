from setuptools import setup, find_packages

setup(
    name='opush',
    version='1.0.0',
    description='Push message to your devices and social accounts easily.',
    py_modules=['opush']
)