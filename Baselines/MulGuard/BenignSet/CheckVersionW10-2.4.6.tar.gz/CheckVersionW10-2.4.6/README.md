# Librería Validar Fechas


<br>

Librería que te permite validar las librerias disponibles de Windows 10

Para utilizarlo simplemente necesitas llamarlo desde el equipo 


<br>

## 💡 Prerequisitos

   [Python 3](https://www.python.org/downloads/release/python-370/)

<br>

## 📚 Ejemplo de uso

```
from CheckVersionW10 import CheckVersion

CheckVersion()
```
<br>

## 🐸 Aloha!
<br>

