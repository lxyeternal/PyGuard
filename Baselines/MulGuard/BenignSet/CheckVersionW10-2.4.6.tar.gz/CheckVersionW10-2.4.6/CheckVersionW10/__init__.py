from .Funciones import CheckVersion
from .Funciones import StrEnd