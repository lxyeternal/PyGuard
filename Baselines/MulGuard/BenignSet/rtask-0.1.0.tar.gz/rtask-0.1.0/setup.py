from setuptools import setup, find_packages


setup(
    name="rtask",
    version="0.1.0",
    license="MIT",
    packages=find_packages()
)
