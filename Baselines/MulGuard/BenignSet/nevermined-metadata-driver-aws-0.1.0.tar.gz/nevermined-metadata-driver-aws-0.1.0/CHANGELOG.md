History
=======

0.0.2 (January 25th, 2019)
-------------------------
* First working version
* Generate sign url support
