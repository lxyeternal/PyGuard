#!/usr/bin/env python3

import setuptools


setuptools.setup(name='pycom-int-jenkins',
version='0.0.1',
author='Přemysl Šťastný',
author_email='p-w@stty.cz',
)
