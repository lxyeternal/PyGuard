"""asyncio Groonga Client"""

from aiogrn._version import __version__
