import oneibl.examples.tutorial_script

print(oneibl.examples.tutorial_script)
