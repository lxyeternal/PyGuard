# -*- coding:utf-8 -*-
# @Author: Niccolò Bonacchi
# @Date: Wednesday, February 13th 2019, 12:06:17 pm
# @Last Modified by: Niccolò Bonacchi
# @Last Modified time: 13-02-2019 12:06:19.1919
from alf.extractors.training_wheel import *  # noqa
