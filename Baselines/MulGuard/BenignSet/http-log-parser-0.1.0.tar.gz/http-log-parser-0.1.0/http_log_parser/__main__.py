
def main(arg_list=None):
    from http_log_parser._entry_point import main

    main(arg_list)


if __name__ == '__main__':
    main()
