"""UnityCloud Collaboration Command Line Interface
"""

__author__ = 'Unity'
__version__ = '0.0.10'
__license__ = 'BSD'

__all__ = ['CloudConfig', 'Rest', 'Core', 'Auth', 'Collab']
