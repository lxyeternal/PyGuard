default_app_config = "mitol.oauth_toolkit_extensions.apps.OAuthToolkitExtensionsApp"
