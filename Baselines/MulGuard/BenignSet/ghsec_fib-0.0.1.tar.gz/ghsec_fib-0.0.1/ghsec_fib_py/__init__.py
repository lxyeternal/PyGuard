def say_hello() -> None:
    print("The GHSEC Fibonacci modele is saying howdy!")