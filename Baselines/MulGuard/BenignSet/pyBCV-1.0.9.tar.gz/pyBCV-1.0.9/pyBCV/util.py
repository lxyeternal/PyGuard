TASAS_INFORMATIVAS_URL = "https://www.bcv.org.ve/tasas-informativas-sistema-bancario"
PAGINA_PRINCIPAL_URL = "https://www.bcv.org.ve/"