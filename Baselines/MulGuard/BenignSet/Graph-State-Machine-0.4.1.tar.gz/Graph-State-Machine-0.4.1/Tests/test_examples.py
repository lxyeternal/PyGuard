import pytest

def test_simple_example():
    import Tests.self_contained_showcase

def test_dict_state_example():
    import Tests.self_contained_showcase_dict_state


