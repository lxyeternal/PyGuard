"""
Custom [pymoo performance indicators](https://pymoo.org/misc/indicators.html).
* `nmoo.indicators.delta_f.DeltaF`
"""
__docformat__ = "google"

from .delta_f import DeltaF
