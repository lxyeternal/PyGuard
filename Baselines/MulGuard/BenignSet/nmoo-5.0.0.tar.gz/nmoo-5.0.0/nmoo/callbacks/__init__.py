"""
Custom [pymoo callbacks](https://pymoo.org/interface/callback.html).
* `nmoo.callbacks.timer_callback.TimerCallback`
"""
__docformat__ = "google"

from .timer_callback import TimerCallback
