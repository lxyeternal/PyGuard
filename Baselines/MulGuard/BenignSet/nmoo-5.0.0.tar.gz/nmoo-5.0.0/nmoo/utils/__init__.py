"""
Various internal utilities.
* `nmoo.utils.population`
"""
__docformat__ = "google"
