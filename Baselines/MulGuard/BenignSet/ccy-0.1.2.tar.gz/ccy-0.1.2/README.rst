ccy
===========

This is a very small python module for currencies.
Not all currencies in the world are supported yet.
You are welcome to join and add more.

The module compiles a dictionary of currency objects containing
information useful in financial analysis.
