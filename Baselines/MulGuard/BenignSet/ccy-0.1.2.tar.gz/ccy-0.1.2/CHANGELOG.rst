ccy 0.1.2
============
first official release