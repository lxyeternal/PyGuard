from django.apps import AppConfig


class SegnoQrConfig(AppConfig):
    name = 'segno_qr'
