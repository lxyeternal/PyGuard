"""Gaussian Datatypes Plugin for AiiDA.

Provides datatypes to store Gaussian Basis Sets and Pseudopotentials.
"""

__version__ = "0.2.0"
