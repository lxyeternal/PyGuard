<h1 align="center">Gitscrpy</h1>

### _Changelog_

* `v0.1.0`
  * Initial changes
  * Added ```getrepo()``` and ```getuser()```

* `v1.3.2`
  * Added documenation  