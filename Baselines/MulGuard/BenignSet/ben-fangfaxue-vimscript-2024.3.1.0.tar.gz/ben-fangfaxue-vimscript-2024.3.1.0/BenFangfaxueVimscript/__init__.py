#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""ben-fangfaxue-vimscript
https://github.com/apachecn/ben-fangfaxue-vimscript"""

__author__ = "ApacheCN"
__email__ = "apachecn@163.com"
__license__ = "CC BY-NC-SA 4.0"
__version__ = "2024.3.1.0"