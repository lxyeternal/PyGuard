# 笨方法学Vimscript

## 下载

### Docker

```
docker pull apachecn0/ben-fangfaxue-vimscript
docker run -tid -p <port>:80 apachecn0/ben-fangfaxue-vimscript
# 访问 http://localhost:{port} 查看文档
```

### PYPI

```
pip install ben-fangfaxue-vimscript
ben-fangfaxue-vimscript <port>
# 访问 http://localhost:{port} 查看文档
```

### NPM

```
npm install -g ben-fangfaxue-vimscript
ben-fangfaxue-vimscript <port>
# 访问 http://localhost:{port} 查看文档
```