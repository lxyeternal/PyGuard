**EMpyer**

Empyer is an extension of the hyperspy_ package.  It provides additional functionality related to analyszing 4 and 5
dimensional data sets.  Especially STEM diffraction patterns from metallic glasses.


.. _hyperspy: https://github.com/hyperspy