"""
The main *screenmonkey* module.
This module imports ``Sequence``.
"""

from .screenmonkey import *
