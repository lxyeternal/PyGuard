P-Cart 2 Wishlist component
