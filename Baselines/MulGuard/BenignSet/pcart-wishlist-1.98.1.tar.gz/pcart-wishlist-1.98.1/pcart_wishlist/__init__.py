default_app_config = 'pcart_wishlist.apps.PCartWishListConfig'
