# Deep PCT
> A library for combining Deep Learning and Perceptual Control Theory reorganisation.


This file will become your README and also the index of your documentation.

## Install

`pip install dpct`

## How to use

Fill me in please! Don't forget code examples:

```python
1+1
```




    2


