# bamAlignCleaner 

A simple utility tool to remove references with no aligned reads in a `bam`/`cram` file

## Installation

```bash
pip install bamaligncleaner 
```

## Usage

```bash
bamAlignCleaner -o output.bam input.bam
```
