class SchemaInvalidationError(ValueError):
    pass
