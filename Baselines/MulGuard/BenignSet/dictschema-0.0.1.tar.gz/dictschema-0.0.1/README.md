# dictschema

[![Generic badge](https://img.shields.io/badge/python-3.7+-blue.svg)](https://shields.io/)
[![codecov](https://codecov.io/gh/kbeauregard/dictschema/branch/master/graph/badge.svg)](https://codecov.io/gh/kbeauregard/dictschema)
[![Generic badge](https://img.shields.io/badge/code%20style-black-black.svg)](https://github.com/psf/black)

## Install

dictschema is available on PyPi and can be installed using pip

`pip install dictschema`

## Development
#### Setup
```
pip install -r requirements
pre-commit install
```
