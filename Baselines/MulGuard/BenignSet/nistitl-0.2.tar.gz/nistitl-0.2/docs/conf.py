
import nistitl

project = 'nistitl'
copyright = nistitl.__copyright__
version = nistitl.__version__
release = nistitl.__version__

master_doc = 'index'

html_theme = 'alabaster'

extensions = ['sphinx.ext.autodoc']
