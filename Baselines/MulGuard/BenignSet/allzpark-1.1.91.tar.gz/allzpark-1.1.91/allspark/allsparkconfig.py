
# Absolute path to where project packages reside
# Allspark uses this to establish a listing or available projects
projects_dir = "~/projects"

# Absolute path to where applicaion packages reside
# Allspark optionally uses this to enable the "Show all apps" button
applications_dir = None  # (optional)
