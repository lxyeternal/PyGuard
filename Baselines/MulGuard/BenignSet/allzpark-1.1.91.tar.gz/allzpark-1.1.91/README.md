
### Allspark

Application launcher and environment management tool for games and digital post-production, built on [Rez](https://github.com/mottosso/bleeding-rez).

<br>

### Usage

In early development. Stay tuned for a release.

![ALLSPARK_1](https://user-images.githubusercontent.com/2152766/58943971-bee4c600-8778-11e9-8117-f50fe260cee0.gif)

<br>

### More Gifs

> "launchapp2" was the internal working title during development at [Studio Anima](http://studioanima.co.jp)

![ALLSPARK_2](https://user-images.githubusercontent.com/2152766/58943970-be4c2f80-8778-11e9-9344-66007ba5cb5b.gif)
![ALLSPARK_3](https://user-images.githubusercontent.com/2152766/58943973-bee4c600-8778-11e9-809a-cf2aaf7c94c0.gif)
![ALLSPARK_4](https://user-images.githubusercontent.com/2152766/58946617-3cf79b80-877e-11e9-8887-df9a92cb1851.gif)
![ALLSPARK_8](https://user-images.githubusercontent.com/2152766/58959026-16485d80-879c-11e9-8964-e277490dbf5f.gif)
