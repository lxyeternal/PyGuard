OK = 'ok'

WARNING = 'warning'

ERROR = 'error'
