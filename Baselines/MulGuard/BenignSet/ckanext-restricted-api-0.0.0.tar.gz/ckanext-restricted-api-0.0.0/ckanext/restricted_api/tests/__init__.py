"""Tests for ckanext-restricted_api plugin."""
