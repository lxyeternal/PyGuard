"""Plugin ckanext-restricted_api."""
