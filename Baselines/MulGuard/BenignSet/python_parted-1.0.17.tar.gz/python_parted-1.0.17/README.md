python-parted
=============

Python bindings for **libparted** with some additional features.

This is a set of Python bindings for the **libparted** library. It
provides a Python interface to the functionality of **libparted**,
including the ability to create, delete, resize, and move partitions
on hard disks.

[]: # License: BSD-3-Clause
