parted.device module
====================

.. automodule:: parted.device
   :members:
   :undoc-members:
   :show-inheritance:
