parted.geom module
==================

.. automodule:: parted.geom
   :members:
   :undoc-members:
   :show-inheritance:
