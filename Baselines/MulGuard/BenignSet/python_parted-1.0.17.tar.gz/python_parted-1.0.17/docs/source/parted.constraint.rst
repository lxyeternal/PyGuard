parted.constraint module
========================

.. automodule:: parted.constraint
   :members:
   :undoc-members:
   :show-inheritance:
