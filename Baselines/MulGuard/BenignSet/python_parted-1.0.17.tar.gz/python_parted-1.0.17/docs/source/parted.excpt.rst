parted.excpt module
===================

.. automodule:: parted.excpt
   :members:
   :undoc-members:
   :show-inheritance:
