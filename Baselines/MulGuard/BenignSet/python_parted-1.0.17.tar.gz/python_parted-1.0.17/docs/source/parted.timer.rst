parted.timer module
===================

.. automodule:: parted.timer
   :members:
   :undoc-members:
   :show-inheritance:
