from flask_spaproxy.spa_proxy import SpaProxy
