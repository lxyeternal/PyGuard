from setuptools import setup


setup(name='DiscordBar',
      version='0.0.3',
      description='Progressbar for discord, docs here https://github.com/Animatea/DiscordProgressbar',
      long_description='Documentation - https://github.com/Animatea/DiscordProgressbar',
      packages=['DiscordBar'],
      author_email='den25340@gmail.com',
      zip_safe=False)
