'''
Created on 03-Mar-2020

@author: rahuljain
'''
name = 'screener'