=====
Portfoliotools
=====

Portfoliotools is a python utility to perform stock/index/mutual fund screening analytics.

Detailed documentation is in the "docs" directory.

Quick start
-----------

1. pip install --upgrade git+git://github.com/rahulspsec/portfoliotools.git
2. Load Jupyter Notebooks to see the usage.
