import setuptools

with open("README.rst", "r") as fh:
    long_description = fh.read()

setuptools.setup(
    name="portfoliotools", # Replace with your own username
    version="0.0.1",
    author="Rahul Jain",
    author_email="rahulspsec@gmail.com",
    description="StockScreener API util for Django web app",
    long_description=long_description,
    long_description_content_type="text/markdown",
    url="https://github.com/rahulspsec/StockScreener/",
    packages=setuptools.find_packages(),
    #package_dir = {'portfoliotools/screener':'screener'},
    #namespace_packages=['screener'],
    install_requires=[
        "beautifulsoup4",
        "pandas",
        "numpy",
        "mftool",
        "requests",
        "TA-Lib",
        "plotly",
        "stocktrends",
        "scipy",
        "scikit-learn",
        "seaborn"
    ],
    classifiers=[
	    'Development Status :: 5 - Production/Stable',
        'Intended Audience :: Developers',
        'Intended Audience :: Financial and Insurance Industry',
        'Topic :: Office/Business :: Financial :: Investment',
        'Topic :: Software Development :: Libraries :: Python Modules',
        'Operating System :: OS Independent',
        "License :: OSI Approved :: MIT License",
        'Programming Language :: Python :: 3.7'
    ],
    python_requires='>=3.7',
    zip_safe=False,
)