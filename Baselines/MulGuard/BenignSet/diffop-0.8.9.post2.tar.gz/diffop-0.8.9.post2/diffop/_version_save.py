#!/usr/bin/env python
# This file was created automatically
longversion = 'v0.8.9-2-g2019462'
