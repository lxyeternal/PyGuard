# -*- coding: utf-8 -*

import sandbox

sandbox.edf2hdf5('../tests/test_generator.edf')
