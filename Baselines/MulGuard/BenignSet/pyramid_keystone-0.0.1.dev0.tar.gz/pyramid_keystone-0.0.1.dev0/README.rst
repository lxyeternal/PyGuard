`Keystone <http://docs.openstack.org/developer/keystone/>`_ bindings for Pyramid
================================================================================

This provides helpers that allow authentication within Pyramid against Keystone.
