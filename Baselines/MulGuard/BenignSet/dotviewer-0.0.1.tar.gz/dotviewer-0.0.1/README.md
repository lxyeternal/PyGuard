
# Dotviewer

An interactive Pygame-based viewer for Graphviz graphs.

Usage:

```
$ python -m dotviewer <filename.dot/plain>
```


