class Error(Exception):
    pass


class AMQPPublishError(Error):
    pass
