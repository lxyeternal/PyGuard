# fluentogram

A proper way to create multilanguage bots via Aiogram3 using Project Fluent by Mozilla.

Check examples directory for more information.