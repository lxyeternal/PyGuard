# coding=utf-8
"""A couple of CLI-access functions"""
from .cli import cli

__all__ = ["cli"]
