# coding=utf-8
"""Custom exceptions"""
from .root_locale_translator import NotImplementedRootLocaleTranslator

__all__ = ["NotImplementedRootLocaleTranslator"]
