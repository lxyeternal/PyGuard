# coding=utf-8
"""
An example of i18n with this module.
"""


