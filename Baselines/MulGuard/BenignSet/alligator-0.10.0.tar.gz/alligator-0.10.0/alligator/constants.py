# Statuses a task can be in.
WAITING = 0
SUCCESS = 1
FAILED = 2
DELAYED = 3
RETRYING = 4
CANCELED = 5

# The default queue name for Alligator.
ALL = 'all'
