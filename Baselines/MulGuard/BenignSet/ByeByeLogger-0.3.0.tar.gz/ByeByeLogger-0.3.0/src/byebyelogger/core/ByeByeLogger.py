from presets.datascience import LogRepository, PRESET_INFO, PRESET_ERROR

INFO = LogRepository(PRESET_INFO)
ERROR = LogRepository(PRESET_ERROR)
    
