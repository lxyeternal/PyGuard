# ByeByeLogger

### Oh, great! Another logging package, because obviously, we need more of those, right? Well, let me introduce you to ByeByeLogger, the one that's going to make you say goodbye to your current logger (whether you like it or not).


## Installation
- To get this totally groundbreaking package, just do the usual `pip` dance:
```bash
pip install byebyelogger
```
