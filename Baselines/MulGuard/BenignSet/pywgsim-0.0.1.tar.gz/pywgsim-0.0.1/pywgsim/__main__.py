"""
This module exists only to make module level execution also viable.

python -m pywgsim

"""

from pywgsim.main import run

if __name__ == '__main__':
    run()
