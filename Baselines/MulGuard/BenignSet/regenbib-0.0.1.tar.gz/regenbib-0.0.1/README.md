# regenbib
(Re-)generate tidy .bib files from online sources
