# -*- coding: utf-8 -*-

# python imports
from time import time


def utcnowts():
    return time()
