from .pyqrlew import *


__doc__ = pyqrlew.__doc__
if hasattr(pyqrlew, "__all__"):
    __all__ = pyqrlew.__all__