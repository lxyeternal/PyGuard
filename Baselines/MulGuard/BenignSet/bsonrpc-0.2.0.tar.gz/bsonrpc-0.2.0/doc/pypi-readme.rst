Key Features:

* For TCP/TCP+TLS sockets.
* threading or gevent based concurrency.
* JSON-RPC 2.0 protocol with JSON or BSON messages.


:Project Home: https://github.com/seprich/py-bson-rpc
:API Doc:      http://seprich.github.io/py-bson-rpc/index.html
