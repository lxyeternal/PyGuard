#!/usr/bin/env python3

__author__ = "Yxzh"

from .training import Train