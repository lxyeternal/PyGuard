#!/usr/bin/env python3

__author__ = "Yxzh"


import tensorflow as tf
import numpy as np

from tensorflow import keras

class Train(object):
	pass