#!/usr/bin/env python3

__author__ = "Yxzh"

from .game import Game
from .UI import UI