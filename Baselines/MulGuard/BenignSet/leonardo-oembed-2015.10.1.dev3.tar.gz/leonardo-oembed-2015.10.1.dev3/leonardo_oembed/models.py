
from .widget.oembed.models import OembedWidget
from .widget.feed.models import FeedWidget
