class ExchangeRateUnavailable(Exception):
    pass
