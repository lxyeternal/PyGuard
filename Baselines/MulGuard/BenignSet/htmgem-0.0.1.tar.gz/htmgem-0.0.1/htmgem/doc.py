# import re
# import importlib.resources as pkg_resources
# from htmgem import resources


# class Doc:

#     # def __init__(self, base_html=None):
        
#         # if base_html: 
#         #     with open(base_html, 'r') as h: base_html = h.read() 

#         # self._base_html = base_html or pkg_resources.read_text(resources, "index.html")


#     def append(self, child):
#         """ """

