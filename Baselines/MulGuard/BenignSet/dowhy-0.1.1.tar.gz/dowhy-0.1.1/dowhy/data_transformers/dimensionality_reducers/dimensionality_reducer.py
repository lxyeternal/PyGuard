class DimensionalityReducer:
    def __init__(self):
        pass
