"Package information file"
# Format and usage strongly inspired by AGProjects/python-application.


__project__ = "callooktools"
__summary__ = "callook.info API interface in Python"
__webpage__ = "https://callooktools.miaow.io"

__version__ = "1.0.0"

__author__ = "classabbyamp, 0x5c"
__email__ = "dev@kb6.ee, dev@0x5c.io"

__license__ = "BSD 3-Clause"
