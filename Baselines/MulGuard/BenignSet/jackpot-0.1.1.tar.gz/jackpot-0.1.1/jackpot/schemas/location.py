
location = {
    "properties": {
        "name": {"type": "string", "minLength": 1},
        "type": {"type": "string"},
    },
}
