# NS-Map
Official codebase for NS-Map, as defined in the paper Identifying Nonstationarity in Ecological Time Series.
