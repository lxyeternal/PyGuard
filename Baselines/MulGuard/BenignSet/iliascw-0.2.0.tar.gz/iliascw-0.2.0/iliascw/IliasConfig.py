#!/usr/bin/env python3

ILIAS_USERNAME = "MYUSERNAME"
ILIAS_PASSWORD = "MYPASSWORD"
ILIAS_DOMAIN = "https://www.studon.fau.de"
