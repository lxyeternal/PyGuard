from __future__ import annotations

from .__main__ import main  # NOQA
