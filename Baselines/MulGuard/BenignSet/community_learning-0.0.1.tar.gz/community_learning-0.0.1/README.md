# CommunityLearning
This project is an example of transfer learning.

## Baseline 
Die Daten werden

## Variante 1
Prediktoren werden ausgetauscht.

## Variante 2
Ein Model wird für beide Banken trainiert
