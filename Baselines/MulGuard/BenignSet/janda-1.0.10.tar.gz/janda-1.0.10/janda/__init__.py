__version__ = "1.0.10"
from janda.pururin import Pururin
from janda.nhentai import Nhentai
from janda.utils import *