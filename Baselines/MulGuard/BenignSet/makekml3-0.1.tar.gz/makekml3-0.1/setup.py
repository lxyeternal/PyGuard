from setuptools import setup

setup(name='makekml3',
      version='0.1',
      description='This is a library designed to create kml. it also has a number of useful features, such as getting the intersection and union of polygons etc',
      url='',
      author='Steve Mohr',
      author_email='steve.h.mohr@gmail.com',
      packages=['makekml3'],
      zip_safe=False)
