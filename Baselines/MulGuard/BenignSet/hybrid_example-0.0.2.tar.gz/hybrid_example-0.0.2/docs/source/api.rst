API
===

.. autosummary::
   :toctree: generated

   hybrid_programming
