"""Tests for horast package."""

from horast import _logging
