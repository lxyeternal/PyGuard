"""Version of horast package."""

import version_query

VERSION = version_query.generate_version_str()
