rm  ${TASK}.*.${EXT_MYOUT} ${FILE_EXEC} &> /dev/null
