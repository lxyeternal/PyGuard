g++ -lm -s -x c++ -O2 -o "$FILE_EXEC" "${TASK}.${EXT_SRC}"
