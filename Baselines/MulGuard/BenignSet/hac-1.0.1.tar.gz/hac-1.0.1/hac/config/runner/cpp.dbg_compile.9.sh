g++ -g -O0 -o "$FILE_EXEC" "${TASK}.${EXT_SRC}"
