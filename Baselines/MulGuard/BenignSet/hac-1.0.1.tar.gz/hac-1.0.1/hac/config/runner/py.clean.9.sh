rm ${TASK}.*.${EXT_MYOUT} &> /dev/null
