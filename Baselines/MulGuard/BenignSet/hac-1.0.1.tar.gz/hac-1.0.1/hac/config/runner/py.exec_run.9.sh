python "$FILE_EXEC" <"$FILE_IN" >"$FILE_MYOUT"
