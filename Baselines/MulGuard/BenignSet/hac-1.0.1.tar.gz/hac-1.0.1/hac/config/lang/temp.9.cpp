#include <iostream>
#include <fstream>
using namespace std;

int main() {
  //ifstream cin("in1");
  cin.sync_with_stdio(false);

  //here
}
