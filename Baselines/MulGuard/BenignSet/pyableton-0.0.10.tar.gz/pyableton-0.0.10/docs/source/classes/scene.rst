Scene
============

.. automodule:: pyableton.Scene
    :members: