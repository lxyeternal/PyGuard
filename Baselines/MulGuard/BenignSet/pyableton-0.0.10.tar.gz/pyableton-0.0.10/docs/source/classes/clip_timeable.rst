ClipTimeable
============

.. automodule:: pyableton.ClipTimeable
    :members: