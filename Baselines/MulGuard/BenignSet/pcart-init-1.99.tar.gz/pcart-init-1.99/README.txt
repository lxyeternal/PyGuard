P-Cart 2 Init component
