<h1 align="center">dgsolvdb</h1> 
<h3 align="center">Free energy of solvation database wrapper - no dependencies.</h3>

<p align="center">  
  <img alt="dgsolvdblogo" src="https://github.com/QuantumPioneer/dgsolvdb/blob/main/dgsolvdb_logo.png">
</p> 
<p align="center">
  <img alt="GitHub Repo Stars" src="https://img.shields.io/github/stars/QuantumPioneer/dgsolvdb?style=social">
  <img alt="PyPI - Downloads" src="https://img.shields.io/pypi/dm/dgsolvdb">
  <img alt="PyPI" src="https://img.shields.io/pypi/v/dgsolvdb">
  <img alt="PyPI - License" src="https://img.shields.io/github/license/QuantumPioneer/dgsolvdb">
</p>

## Online Documentation
[Click here to read the documentation](https://QuantumPioneer.github.io/dgsolvdb/)
