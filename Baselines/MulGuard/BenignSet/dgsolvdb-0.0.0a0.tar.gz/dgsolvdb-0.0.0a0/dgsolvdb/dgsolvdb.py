
def placeholder():
    return
