import os
import sys
import unittest

# from dgsolvdb import dgsolvdb


class Test_dgsolvdb(unittest.TestCase):
    """
    Test the various functionalities of dgsolvdb.
    """

    @classmethod
    def setUpClass(self):
        return

    def test_placeholder(self):
        """
        """
        self.assertTrue(1+1 == 2)


if __name__ == '__main__':
    unittest.main()
