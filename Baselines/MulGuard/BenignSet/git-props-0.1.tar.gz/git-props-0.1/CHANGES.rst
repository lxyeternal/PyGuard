Changelog
=========

0.1 (2023-12-28)
~~~~~~~~~~~~~~~~

Initial release.
