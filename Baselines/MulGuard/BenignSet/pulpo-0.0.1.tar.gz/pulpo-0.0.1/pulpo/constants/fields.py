# Top fields
BANDIT_TYPE = 'bandit_type'
BANDIT_ID = 'bandit_id'
PRIORS = 'priors'
ARM_IDS = 'arm_ids'
PARAMETERS = 'parameters'

# Values
N = 'n'
REWARD_SUM = 'reward_sum'
SQUARED_REWARD_SUM = 'squared_reward_sum'
N_REWARDS = 'n_rewards'

# Parametres
EPSILON = 'epsilon'
