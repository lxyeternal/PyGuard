from .config import get_config
from .flame import FLAME
