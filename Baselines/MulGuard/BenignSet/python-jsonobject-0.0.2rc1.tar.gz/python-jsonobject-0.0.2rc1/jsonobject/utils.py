class JSONObjectError(Exception):
    pass

