"""py30303_disc library."""
