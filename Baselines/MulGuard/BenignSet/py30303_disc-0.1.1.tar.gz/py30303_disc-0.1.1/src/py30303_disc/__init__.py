"""Initial documentation of py30303_disc."""

__version__ = '0.1.1'

from .libs import py30303_disc
