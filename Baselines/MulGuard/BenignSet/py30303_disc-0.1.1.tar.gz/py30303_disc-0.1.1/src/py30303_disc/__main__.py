"""
Package interface.

This is the main package interface.
"""
from py30303_disc import d30303_discover


if __name__ == '__main__':
    d30303_discover.main()
