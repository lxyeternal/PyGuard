Authors
=======

* Tim Rightnour (`webpage`_, `github`_)

.. _webpage: https://www.garbled.net/
.. _github: https://github.com/garbled1
