============
Installation
============

**This is an example page for a real project.** In this page you can describe the installation steps required for end-users, use the :ref:`Contribution page<Contributing>` to provide the guidelines for developers.

Installation Example
--------------------

At the command line::

    pip install py30303_disc
