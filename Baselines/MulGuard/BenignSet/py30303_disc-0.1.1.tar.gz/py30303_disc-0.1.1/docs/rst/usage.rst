=====
Usage
=====

To use ``py30303_disc``::

	import py30303_disc
