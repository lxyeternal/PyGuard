# Doc string - sirve para documentar paquetes
# cuando se importe mostrar la información que estas poniendo
# Python entiende que este texto es para documentar y cada vez que pases el mause sobre el nombre de tu carpeta o paquete
# mostrara ese texto
"""
Esta es la documentación del paquete
"""