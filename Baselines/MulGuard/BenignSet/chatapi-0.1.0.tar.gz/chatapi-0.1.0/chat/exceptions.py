class Rejected(Exception):
    """
    Raised when the server rejects with a ctrl.code of 400-499.
    """

    pass