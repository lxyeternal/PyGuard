from zope.interface import Interface, Attribute
from plone.theme.interfaces import IDefaultPloneLayer

class ISolgemaBlinksLayer(IDefaultPloneLayer):
    """Solgema portlets manager layer""" 
