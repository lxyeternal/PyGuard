__author__ = """Martronic SA"""
__docformat__ = 'plaintext'

from zope.i18nmessageid import MessageFactory
_ = MessageFactory('Solgema.blinks')
