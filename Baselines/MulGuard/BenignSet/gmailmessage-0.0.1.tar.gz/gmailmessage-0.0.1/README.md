# **GmailMessage**

> _This is a package built to make it easy for  
people trying to send Gmail messages with  
Python script._

**https://forms.gle/5kGhetUhktNpJUJV7** is where you can ask any question about the package.
