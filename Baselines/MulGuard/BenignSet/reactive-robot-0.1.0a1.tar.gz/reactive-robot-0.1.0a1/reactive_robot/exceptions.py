class InjectionException(BaseException):
    pass


class InvalidConfigurationFileException(BaseException):
    pass


class ConfigurationFileNotExists(BaseException):
    pass
