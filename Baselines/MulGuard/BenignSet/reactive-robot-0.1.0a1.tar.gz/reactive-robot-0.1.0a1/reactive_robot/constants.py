from multiprocessing import cpu_count

MAX_WORKER = cpu_count() * 2
