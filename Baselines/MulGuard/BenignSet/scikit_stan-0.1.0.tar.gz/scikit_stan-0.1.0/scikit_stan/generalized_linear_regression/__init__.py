"""
Module for generalized linear model.
"""

from .glm import GLM

__all__ = ["GLM"]
