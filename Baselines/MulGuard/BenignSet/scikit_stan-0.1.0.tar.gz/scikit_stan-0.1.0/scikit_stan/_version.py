__version__ = "0.1.0"
# single source of truth used in __init__.py and setup.py
