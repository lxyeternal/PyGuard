from ._version import __version__  # noqa
from .generalized_linear_regression import GLM

__all__ = ["GLM"]
