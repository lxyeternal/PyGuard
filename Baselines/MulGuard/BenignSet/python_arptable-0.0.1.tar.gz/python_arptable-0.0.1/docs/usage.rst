========
Usage
========

To use Python simple arp table reader in a project::

    import python_arptable
