============
Installation
============

At the command line::

    $ easy_install python_arptable

Or, if you have virtualenvwrapper installed::

    $ mkvirtualenv python_arptable
    $ pip install python_arptable
