#!/usr/bin/env python
# -*- coding: utf-8 -*-

"""
test_python_arptable
----------------------------------

Tests for `python_arptable` module.
"""

import unittest

from python_arptable import python_arptable


class TestPython_arptable(unittest.TestCase):

    def setUp(self):
        pass

    def test_something(self):
        pass

    def tearDown(self):
        pass

if __name__ == '__main__':
    unittest.main()
