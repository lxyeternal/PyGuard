.. :changelog:

History
-------

0.0.1 (2015-06-14)
---------------------

* First release on PyPI.
