This package provides a way to directly transfer a datalist from txt or csv file to a database.

Enter file path (or just the name if it's in the same directory with the program.) to the function and you are all set.

After installing the package.

import database_creator as dbc
dbc.create_database(text_file_path)

steps will generate your database. Function will take inputs for database name and table name.