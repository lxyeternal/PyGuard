#!/usr/bin/env python

from shipane_sdk.scheduler import Scheduler

Scheduler().start()
