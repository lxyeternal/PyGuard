# geomapzw


[![image](https://img.shields.io/pypi/v/geomapzw.svg)](https://pypi.python.org/pypi/geomapzw)


**This package is for generating web maps**


-   Free software: MIT license
-   Documentation: https://faraigit.github.io/geomapzw
    

## Features

-   TODO

## Credits

This package was created with [Cookiecutter](https://github.com/cookiecutter/cookiecutter) and the [giswqs/pypackage](https://github.com/giswqs/pypackage) project template.
