"""Top-level package for geomapzw."""

__author__ = """Farai Maxwell Marumbwa"""
__email__ = 'faraimax@gmail.com'
__version__ = '0.0.1'
