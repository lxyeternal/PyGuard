=====
Usage
=====

To use Dspace usage stats collector in a project::

    import dspace_stats_collector
