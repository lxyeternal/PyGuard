# bohs
Bayesian Optimisation for Heterogeneous Spaces
