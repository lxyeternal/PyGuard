from .locks import locked, lock

default_app_config = 'db_locks.apps.DBLocksConfig'
