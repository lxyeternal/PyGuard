#!/usr/bin/env python
# coding:utf-8
# code by : Yasser BDJ
# email : by.root96@gmail.com
#s
from ashar.__version__ import __version__
from ashar.ashar import ashar
#e