from setuptools import setup

setup(name='probdistributions0816',
      version='0.1',
      description='Gaussian distributions',
      packages=['probdistributions0816'],
      zip_safe=False)
