# pydd: mv (using dd followed by rm) with a progressbar

Sometimes you want to use [`dd`](https://unix.stackexchange.com/questions/12532/dd-vs-cat-is-dd-still-relevant-these-days) instead of mv or cp. This package helps you use `dd` to move emtire contents of a dir to another dir. 

## Installation
Installable via pip`