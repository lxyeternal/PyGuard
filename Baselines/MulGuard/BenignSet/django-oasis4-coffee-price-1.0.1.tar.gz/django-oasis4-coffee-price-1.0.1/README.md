# Coffee Price Module

This module has been created to offer access to the coffee price table via REST services. The system requires the
CHFL-OASIS module for its operation.

## Service directory
coffee_price/list/: Return a product list with its price for 125Kg.
coffee_price/