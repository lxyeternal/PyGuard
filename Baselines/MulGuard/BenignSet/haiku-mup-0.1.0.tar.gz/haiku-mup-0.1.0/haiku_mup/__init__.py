""""A simple port of μP  to Haiku/JAX."""

from .mup import get_shapes, Mup, apply_mup
from .module import Readout

__version__ = "0.1.1"
