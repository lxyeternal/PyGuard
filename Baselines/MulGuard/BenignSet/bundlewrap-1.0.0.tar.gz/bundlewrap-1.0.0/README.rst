BundleWrap is a decentralized configuration management system that is designed to be powerful, easy to extend and extremely versatile.

For more information, have a look at `bundlewrap.org <http://bundlewrap.org/>`_.

------------------------------------------------------------------------

.. image:: http://img.shields.io/pypi/dm/bundlewrap.svg
    :target: https://pypi.python.org/pypi/bundlewrap/
    :alt: Downloads per month

.. image:: http://img.shields.io/pypi/v/bundlewrap.svg
    :target: https://pypi.python.org/pypi/bundlewrap/
    :alt: Latest Version

.. image:: http://img.shields.io/travis/bundlewrap/bundlewrap.svg
    :target: https://travis-ci.org/bundlewrap/bundlewrap
    :alt: Build status

.. image:: http://img.shields.io/coveralls/bundlewrap/bundlewrap.svg
    :target: https://coveralls.io/r/bundlewrap/bundlewrap
    :alt: Code coverage

.. image:: http://img.shields.io/badge/Python-2.7-green.svg
    :target: https://pypi.python.org/pypi/bundlewrap/
    :alt: Python 2.7

.. image:: http://img.shields.io/badge/License-GPLv3-red.svg
    :target: https://pypi.python.org/pypi/bundlewrap/
    :alt: License

BundleWrap is Copyright © 2014 `Torsten Rehn <mailto:torsten@rehn.email>`_
