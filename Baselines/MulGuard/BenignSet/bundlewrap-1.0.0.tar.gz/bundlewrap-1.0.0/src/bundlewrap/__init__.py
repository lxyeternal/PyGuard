VERSION = (1, 0, 0)
VERSION_STRING = ".".join([str(v) for v in VERSION])
