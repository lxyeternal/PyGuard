===================
Flask Fluentd Event
===================


.. image:: https://img.shields.io/pypi/v/flask_fluentd_event.svg
        :target: https://pypi.python.org/pypi/flask_fluentd_event

.. image:: https://img.shields.io/travis/yoophi/flask_fluentd_event.svg
        :target: https://travis-ci.com/yoophi/flask_fluentd_event

.. image:: https://readthedocs.org/projects/flask-fluentd-event/badge/?version=latest
        :target: https://flask-fluentd-event.readthedocs.io/en/latest/?badge=latest
        :alt: Documentation Status




Flask Plugin to handle event with fluentd.


* Free software: MIT license
* Documentation: https://flask-fluentd-event.readthedocs.io.


Features
--------

* TODO

Credits
-------

This package was created with Cookiecutter_ and the `audreyr/cookiecutter-pypackage`_ project template.

.. _Cookiecutter: https://github.com/audreyr/cookiecutter
.. _`audreyr/cookiecutter-pypackage`: https://github.com/audreyr/cookiecutter-pypackage
