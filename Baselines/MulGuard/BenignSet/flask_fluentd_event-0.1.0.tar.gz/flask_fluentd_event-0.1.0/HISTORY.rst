=======
History
=======

0.1.0 (2021-02-17)
------------------

* First release on PyPI.
