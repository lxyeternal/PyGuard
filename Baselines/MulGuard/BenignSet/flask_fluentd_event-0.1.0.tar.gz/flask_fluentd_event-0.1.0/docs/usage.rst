=====
Usage
=====

To use Flask Fluentd Event in a project::

    import flask_fluentd_event
