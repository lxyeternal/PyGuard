"""Unit test package for flask_fluentd_event."""
