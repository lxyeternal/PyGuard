from __future__ import absolute_import

from paralelocs_qlikapi.method import *