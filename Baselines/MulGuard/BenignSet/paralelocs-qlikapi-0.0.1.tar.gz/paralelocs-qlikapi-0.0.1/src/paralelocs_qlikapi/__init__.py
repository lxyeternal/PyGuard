"""Top-level package for Paralelo CS Beam Packages."""

from __future__ import absolute_import
from paralelocs_qlikapi import api
from paralelocs_qlikapi import method

__author__ = """Paralelo Consultoria e Serviços Ltda"""
__email__ = 'contato@paralelocs.com.br'
__version__ = '0.0.1'
