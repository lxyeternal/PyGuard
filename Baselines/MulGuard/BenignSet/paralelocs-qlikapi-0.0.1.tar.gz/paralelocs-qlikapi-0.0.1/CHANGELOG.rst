
Changelog
=========

0.0.0 (2019-10-23)
------------------

* First release on PyPI.
