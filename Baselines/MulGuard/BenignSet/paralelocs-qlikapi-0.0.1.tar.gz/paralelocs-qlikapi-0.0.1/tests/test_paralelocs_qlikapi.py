
from paralelocs_qlikapi.cli import main


def test_main():
    main([])
