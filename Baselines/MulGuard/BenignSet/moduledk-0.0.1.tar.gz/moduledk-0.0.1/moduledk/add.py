#!/usr/bin/env python
def add(a,b):
    return a + b
