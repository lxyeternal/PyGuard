"""hrpc module."""
