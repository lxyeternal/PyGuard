# Kolombo

![Kolombo Logo](https://raw.githubusercontent.com/HarrySky/kolombo/master/logo.png "Kolombo Logo")

Easy to manage mail server 💌

**NB! Work in progress, not ready!**

## Introduction

TODO
