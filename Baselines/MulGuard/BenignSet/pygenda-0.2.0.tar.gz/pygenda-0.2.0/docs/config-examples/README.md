Pygenda config-examples
=======================

This directory contains some example configuration files.

See defaults.ini for a (hopefully) complete list of settings.

Either use them as provided by soft-linking to them from the
~/.config/pygenda/ directory as pygenda.css or pygenda.ini, copy to
that directory and edit to your own taste, or for css files @import
the files and make your own additions.

You can also check the default css for ideas: css/pygenda.css from
the source directory.
