===
API
===

.. note:: ADD DOCUMENTATION FOR SECTIONS BELOW!


iso.transform
==============

.. autoclass:: iso.transform.Transform
    :members:

.. autoclass:: iso.transform.ComplexTransform
    :members:

.. autoclass:: iso.transform.Simulator
    :members:

.. autoclass:: iso.transform.ComplexSimulator
    :members:

.. autoclass:: iso.transform.Reduce
    :members:

.. autoclass:: iso.transform.TransformChain
    :members:


iso.feature
============

.. autoclass:: iso.feature.Feature
    :members:

.. autoclass:: iso.feature.FeatureTransform
    :members:


iso.learn
==========

.. autoclass:: iso.learn.Learner
    :members:
