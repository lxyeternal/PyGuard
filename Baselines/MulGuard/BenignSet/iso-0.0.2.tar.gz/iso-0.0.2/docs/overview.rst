========
Overview
========


The sections below detail the internal API used by ``iso`` and other low-level concepts behind how the module works. If you're just looking to use the command line tool, see the `Command Line <./cli.html>`_ section of the documentation.

In a nutshell, iso was designed to ...




Questions/Feedback
==================

If you have any questions about the concepts throughout this documentation, or have feedback on how things could be implemented differently, contact the `developers <mailto:bprinty@gmail.com>`_.
