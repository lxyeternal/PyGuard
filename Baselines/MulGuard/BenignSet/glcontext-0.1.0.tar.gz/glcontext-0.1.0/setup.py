from setuptools import setup

setup(
    name='glcontext',
    version='0.1.0',
)
