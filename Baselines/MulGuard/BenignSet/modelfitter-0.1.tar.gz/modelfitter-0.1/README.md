# Base_ModelFitter
 
# Installation:
...

...
# Description:
A modified gradient descent fitting alrgorithm. Designed with large data spaces in mind and can be manually interacted with while fitting. 
# Dependencies:
* Easier_Plot_Lib
* * can be found here: https://github.com/zkdavis/Easier_Plot_Lib.git
* matplotlib
* numpy
* scipy

# How To Run
TBD
# Example
In the repository, there is an example called sinfit. This example fits a sin functions and should give you an understanding of how to run the code.
