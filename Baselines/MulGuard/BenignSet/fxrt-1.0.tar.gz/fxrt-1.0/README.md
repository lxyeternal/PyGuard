## FXRT
 *Retrieve realtime FX prices* 