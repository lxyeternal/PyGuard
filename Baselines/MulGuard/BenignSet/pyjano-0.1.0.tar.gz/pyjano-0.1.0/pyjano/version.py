
# Stringified version. Used both for setup.py and for internal code
version = '0.01.00'

# version as the tuple of ints
version_tuple = tuple(int(val) for val in version.split('.'))
