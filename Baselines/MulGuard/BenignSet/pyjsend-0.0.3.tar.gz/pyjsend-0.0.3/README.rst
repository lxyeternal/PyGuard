py-jsend
========
python jsend

About jsend
-----------
http://labs.omniti.com/labs/jsend