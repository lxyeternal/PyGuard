Simple test
------------

Ensure your device works with this simple test.

.. literalinclude:: ../examples/blinka_bleio_simpletest.py
    :caption: examples/blinka_bleio_simpletest.py
    :linenos:
