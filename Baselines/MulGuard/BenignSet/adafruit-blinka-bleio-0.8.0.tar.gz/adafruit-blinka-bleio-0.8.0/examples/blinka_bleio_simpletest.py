# Please use https://github.com/adafruit/Adafruit_CircuitPython_BLE instead of this library
# directly.
