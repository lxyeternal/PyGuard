from django.apps import AppConfig


class OptimerConfig(AppConfig):
    name = 'allianceauth.optimer'
    label = 'optimer'
