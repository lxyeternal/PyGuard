from django.contrib import admin

from allianceauth.optimer.models import OpTimer

admin.site.register(OpTimer)
