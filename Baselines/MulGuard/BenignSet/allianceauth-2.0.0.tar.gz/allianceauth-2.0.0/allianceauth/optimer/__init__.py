default_app_config = 'allianceauth.optimer.apps.OptimerConfig'
