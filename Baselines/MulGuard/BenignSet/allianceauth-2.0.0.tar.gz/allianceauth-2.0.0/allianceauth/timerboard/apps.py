from django.apps import AppConfig


class TimerBoardConfig(AppConfig):
    name = 'allianceauth.timerboard'
    label = 'timerboard'
