default_app_config = 'allianceauth.timerboard.apps.TimerBoardConfig'
