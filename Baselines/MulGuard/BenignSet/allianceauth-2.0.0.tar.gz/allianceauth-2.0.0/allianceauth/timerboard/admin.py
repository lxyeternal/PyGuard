from django.contrib import admin

from allianceauth.timerboard.models import Timer

admin.site.register(Timer)
