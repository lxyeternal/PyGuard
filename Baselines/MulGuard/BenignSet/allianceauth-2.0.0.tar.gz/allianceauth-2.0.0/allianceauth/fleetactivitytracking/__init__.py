default_app_config = 'allianceauth.fleetactivitytracking.apps.FatConfig'
