
from django.apps import AppConfig


class FatConfig(AppConfig):
    name = 'allianceauth.fleetactivitytracking'
    label = 'fleetactivitytracking'
