
from django.contrib import admin

from allianceauth.fleetactivitytracking.models import Fatlink, Fat

admin.site.register(Fatlink)
admin.site.register(Fat)
