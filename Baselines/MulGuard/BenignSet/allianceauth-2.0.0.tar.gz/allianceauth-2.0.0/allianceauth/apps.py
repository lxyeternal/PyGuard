from django.apps import AppConfig


class AllianceAuthConfig(AppConfig):
    name = 'allianceauth'
