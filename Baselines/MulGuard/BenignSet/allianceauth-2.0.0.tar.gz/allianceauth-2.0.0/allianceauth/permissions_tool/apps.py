from django.apps import AppConfig


class PermissionsToolConfig(AppConfig):
    name = 'allianceauth.permissions_tool'
    label = 'permissions_tool'

