default_app_config = 'allianceauth.fleetup.apps.FleetupConfig'
