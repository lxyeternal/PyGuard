from django.apps import AppConfig


class FleetupConfig(AppConfig):
    name = 'allianceauth.fleetup'
    label = 'fleetup'
