default_app_config = 'allianceauth.groupmanagement.apps.GroupManagementConfig'
