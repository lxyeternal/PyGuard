default_app_config = 'allianceauth.corputils.apps.CorpUtilsConfig'
