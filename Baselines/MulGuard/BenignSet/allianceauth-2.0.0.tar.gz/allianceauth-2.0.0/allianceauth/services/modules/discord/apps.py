from django.apps import AppConfig


class DiscordServiceConfig(AppConfig):
    name = 'allianceauth.services.modules.discord'
    label = 'discord'
