from django.apps import AppConfig


class Phpbb3ServiceConfig(AppConfig):
    name = 'allianceauth.services.modules.phpbb3'
    label = 'phpbb3'
