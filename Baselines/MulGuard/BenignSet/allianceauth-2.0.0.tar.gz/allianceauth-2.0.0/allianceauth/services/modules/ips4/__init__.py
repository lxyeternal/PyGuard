default_app_config = 'allianceauth.services.modules.ips4.apps.Ips4ServiceConfig'
