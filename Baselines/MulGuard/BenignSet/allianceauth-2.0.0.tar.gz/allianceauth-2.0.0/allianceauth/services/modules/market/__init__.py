default_app_config = 'allianceauth.services.modules.market.apps.MarketServiceConfig'
