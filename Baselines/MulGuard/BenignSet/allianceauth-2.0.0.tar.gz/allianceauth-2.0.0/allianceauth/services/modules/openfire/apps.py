from django.apps import AppConfig


class OpenfireServiceConfig(AppConfig):
    name = 'allianceauth.services.modules.openfire'
    label = 'openfire'
