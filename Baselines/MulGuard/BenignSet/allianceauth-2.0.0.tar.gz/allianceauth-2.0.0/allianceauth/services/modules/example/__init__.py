default_app_config = 'allianceauth.services.modules.example.apps.ExampleServiceConfig'
