default_app_config = 'allianceauth.services.modules.openfire.apps.OpenfireServiceConfig'
