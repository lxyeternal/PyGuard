default_app_config = 'allianceauth.services.apps.ServicesConfig'
