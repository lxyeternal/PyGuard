default_app_config = 'allianceauth.authentication.apps.AuthenticationConfig'
