

from celery.app.base import Celery

celeryApp = Celery()