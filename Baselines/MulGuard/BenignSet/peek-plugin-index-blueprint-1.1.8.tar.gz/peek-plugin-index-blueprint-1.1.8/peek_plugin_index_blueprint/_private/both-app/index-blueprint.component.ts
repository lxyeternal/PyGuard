import {Component} from "@angular/core";

@Component({
    selector: 'plugin-index-blueprint',
    templateUrl: 'index-blueprint.component.web.html',
    moduleId: module.id
})
export class ThingIndexComponent {

    constructor() {

    }

}
