indexBlueprintFilt = {"plugin": "peek_plugin_index_blueprint"}
indexBlueprintTuplePrefix = "peek_plugin_index_blueprint."
indexBlueprintObservableName = "peek_plugin_index_blueprint"
indexBlueprintActionProcessorName = "peek_plugin_index_blueprint"
indexBlueprintTupleOfflineServiceName = "peek_plugin_index_blueprint"