import {Component, OnInit} from "@angular/core";


@Component({
    selector: 'index-blueprintadmin',
    templateUrl: 'index-blueprint.component.html'
})
export class ThingIndexComponent implements OnInit {

    ngOnInit() {

    }
}
