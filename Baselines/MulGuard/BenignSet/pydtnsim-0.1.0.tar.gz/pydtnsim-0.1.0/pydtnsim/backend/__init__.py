"""Custom implementation of a discrete simulation backend."""

from .qsim import QSim
