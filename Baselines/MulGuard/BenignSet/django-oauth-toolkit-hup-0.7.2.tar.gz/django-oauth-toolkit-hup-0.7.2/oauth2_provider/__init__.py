__version__ = '0.7.2'

__author__ = "Massimiliano Pippi & Federico Frenguelli"

VERSION = __version__  # synonym
