===============================
PyMaybe
===============================

.. image:: https://img.shields.io/travis/ekampf/pymaybe.svg
        :target: https://travis-ci.org/ekampf/pymaybe

.. image:: https://img.shields.io/pypi/v/pymaybe.svg
        :target: https://pypi.python.org/pypi/pymaybe


A Python implementation of the Maybe pattern.

* Free software: BSD license
* Documentation: https://pymaybe.readthedocs.org.
