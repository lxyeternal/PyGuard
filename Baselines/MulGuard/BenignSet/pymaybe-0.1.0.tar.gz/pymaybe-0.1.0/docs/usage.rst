========
Usage
========

To use PyMaybe in a project::

    import pymaybe
