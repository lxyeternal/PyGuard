============
Installation
============

At the command line::

    $ easy_install pymaybe

Or, if you have virtualenvwrapper installed::

    $ mkvirtualenv pymaybe
    $ pip install pymaybe
