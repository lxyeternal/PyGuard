# -*- coding: utf-8 -*-
__author__ = 'tangke'


class RequesetManager:
    pass
