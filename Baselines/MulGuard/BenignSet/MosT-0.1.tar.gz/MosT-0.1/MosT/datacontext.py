# -*- coding: utf-8 -*-
__author__ = 'tangke'


class SettingManager:
    pass


class DataContext:
    case_list = []
    database_dict = {}
