from setuptools import setup

setup(name='cdreek_funny_jokes',
      version='0.1',
      description='The funniest joke in the world',
      license='MIT',
      packages=['jokeabc'],
      zip_safe=False
)
