from .joke_one import joke_one
from .joke_two import joke_two
