def joke_two():
    return ('How do functions break up?'
            'They stop calling each other......')
