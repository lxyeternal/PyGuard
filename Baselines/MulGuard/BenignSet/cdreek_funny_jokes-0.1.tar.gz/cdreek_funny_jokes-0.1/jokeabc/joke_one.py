def joke_one():
    return ('What\'s red and bad for your teeth?'
            'A brick')
