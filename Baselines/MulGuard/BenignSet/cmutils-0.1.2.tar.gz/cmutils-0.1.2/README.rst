===================
cmutils
===================
 
----------------
Introduction
----------------

1. io.py
    class for deal with path/file

2. log.py
    class for process bar in console and log

3. system.py
    
4. ...