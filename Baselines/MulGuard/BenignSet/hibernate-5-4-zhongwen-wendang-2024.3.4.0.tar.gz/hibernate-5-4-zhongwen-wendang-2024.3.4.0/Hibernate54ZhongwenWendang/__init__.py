#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""hibernate-5-4-zhongwen-wendang
https://github.com/apachecn/hibernate-5-4-zhongwen-wendang"""

__author__ = "ApacheCN"
__email__ = "apachecn@163.com"
__license__ = "CC BY-NC-SA 4.0"
__version__ = "2024.3.4.0"