from locaya.locaya import Locaya
