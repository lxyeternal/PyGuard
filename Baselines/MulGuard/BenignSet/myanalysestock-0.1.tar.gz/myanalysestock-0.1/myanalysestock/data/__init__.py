__all__ =["writedata"]
from analyse.data import *

