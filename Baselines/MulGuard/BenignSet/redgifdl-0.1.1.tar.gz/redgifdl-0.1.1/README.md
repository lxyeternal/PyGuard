# redgifdl

Download from redgif by sending in URL and output file


## Usage

```
from redgifdl import download_url

download_url(redgifs_url="URL", filename="foo.mp4")

```