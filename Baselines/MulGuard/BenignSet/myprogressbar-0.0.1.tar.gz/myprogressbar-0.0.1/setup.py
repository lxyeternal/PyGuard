from setuptools import setup, find_packages

setup(name='myprogressbar',
      version='0.0.1',
      description='Progress bar as a Service',
      author='Kota Uenishi',
      author_email='kuenishi@gmail.com',
      url='https://example.com/',
      packages=find_packages(),
     )