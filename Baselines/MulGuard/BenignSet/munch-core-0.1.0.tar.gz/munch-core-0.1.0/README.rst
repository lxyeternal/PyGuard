Munch
=====

Munch is mostly a REST API which allow you to manage your email campaigns and send it to many recipients.

It allow you to track your recipients opens and clicks and to manage campaigns unsubscribes, bounces, opt-outs, sending domains checking and more.

See documentation_.


.. _documentation: https://crunchmail.github.io/munch-core/
