from .runner import main
main()
