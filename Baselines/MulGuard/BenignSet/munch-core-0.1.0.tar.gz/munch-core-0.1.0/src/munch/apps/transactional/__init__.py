default_app_config = 'munch.apps.transactional.apps.TransactionalConfig'
