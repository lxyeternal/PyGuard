default_app_config = 'munch.apps.optouts.apps.OptOutApp'
