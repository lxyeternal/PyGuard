default_app_config = 'munch.apps.abuse.apps.AbuseApp'
