default_app_config = 'munch.apps.contacts.apps.ContactsApp'
