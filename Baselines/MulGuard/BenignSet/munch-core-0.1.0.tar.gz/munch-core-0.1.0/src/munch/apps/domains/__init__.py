default_app_config = 'munch.apps.domains.apps.DomainsApp'
