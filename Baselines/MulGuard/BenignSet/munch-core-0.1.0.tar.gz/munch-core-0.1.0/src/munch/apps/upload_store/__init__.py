default_app_config = 'munch.apps.upload_store.apps.UploadStoreApp'
