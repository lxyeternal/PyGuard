default_app_config = 'munch.apps.campaigns.apps.CampaignsApp'
