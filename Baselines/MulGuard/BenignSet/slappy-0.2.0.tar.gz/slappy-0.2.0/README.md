# Slappy - framework for workplace bots

TODO - write an actual documentation.
