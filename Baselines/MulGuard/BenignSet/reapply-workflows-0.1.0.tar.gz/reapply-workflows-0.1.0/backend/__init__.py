from backend.inference_core.reapply.reapply import Reapply  # noqa


def test():
    print("Hello")
