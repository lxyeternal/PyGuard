import os

DATASETS_ROOT = os.path.abspath("./datasets")
DATABASE_ROOT = os.path.abspath("./database")
