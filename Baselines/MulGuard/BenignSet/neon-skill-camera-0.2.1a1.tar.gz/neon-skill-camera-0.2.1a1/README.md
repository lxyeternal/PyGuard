# <img src='https://0000.us/klatchat/app/files/neon_images/icons/neon_skill.png' card_color="#FF8600" width="50" style="vertical-align:bottom">Camera 
  
## Summary  

Take pictures and videos.

## Description  
  
The skill allows you to capture pictures and videos and saves them to your local device.

Note: Images and videos can be found in ~/Pictures/Neon and ~/Videos/Neon respectively. Videos aren't currently saved on MyCroft Mark II hardware.
  
## Examples  

- "Take a picture."

## Contact Support
Use the [link](https://neongecko.com/ContactUs) or [submit an issue on GitHub](https://help.github.com/en/articles/creating-an-issue)

## Credits
[NeonGeckoCom](https://github.com/NeonGeckoCom)
[reginaneon](https://github.com/reginaneon)
[NeonDaniel](https://github.com/neondaniel)

## Tags
#NeonGecko Original
#NeonAI
