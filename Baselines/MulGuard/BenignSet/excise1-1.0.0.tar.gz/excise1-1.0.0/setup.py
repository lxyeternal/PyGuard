from distutils.core import setup

setup(
         name   = 'excise1',
         version = '1.0.0',
         py_modules = ['excise1'],
         author = 'hfpython',
         author_email = 'hfpython@headfirtlabs.com',
         url = 'http://www.headfirstlabs.com',
         description = 'A simple printer of nested lists',
      )
