"""
Module containing and example plotter application
"""
from plotter.plotter import main, plot
__all__ = ['main', 'plot']
