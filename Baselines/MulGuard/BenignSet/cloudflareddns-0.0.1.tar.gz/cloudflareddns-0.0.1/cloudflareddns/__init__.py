"""
cloudflareddns
==========
License: BSD, see LICENSE for more details.
"""

__author__ = "Danila Vershinin"

from .cloudflareddns import main
from .cloudflareddns import syno
from .__about__ import (
    __version__,
)
