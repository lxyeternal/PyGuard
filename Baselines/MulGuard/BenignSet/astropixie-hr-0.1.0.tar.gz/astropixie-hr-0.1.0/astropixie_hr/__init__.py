import astropixie
data = astropixie.data

from . import visual
from . import science

from . import config
from .config import setup_notebook, show_with_bokeh_server
