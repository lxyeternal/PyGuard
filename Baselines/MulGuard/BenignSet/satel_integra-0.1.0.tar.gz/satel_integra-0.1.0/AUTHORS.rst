=======
Credits
=======

Development Lead
----------------

* Krzysztof Machelski <krzysztof.machelski+pypi@gmail.com>

Contributors
------------

None yet. Why not be the first?
