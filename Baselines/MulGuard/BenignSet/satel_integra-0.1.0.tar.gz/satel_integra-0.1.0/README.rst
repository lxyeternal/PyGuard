=============
Satel Integra
=============


.. image:: https://img.shields.io/pypi/v/satel_integra.svg
        :target: https://pypi.python.org/pypi/satel_integra

.. image:: https://img.shields.io/travis/c-soft/satel_integra.svg
        :target: https://travis-ci.org/c-soft/satel_integra

.. image:: https://readthedocs.org/projects/satel-integra/badge/?version=latest
        :target: https://satel-integra.readthedocs.io/en/latest/?badge=latest
        :alt: Documentation Status

.. image:: https://pyup.io/repos/github/c-soft/satel_integra/shield.svg
     :target: https://pyup.io/repos/github/c-soft/satel_integra/
     :alt: Updates


Communication library and basic testing tool for Satel Integra alarm system. Communication via tcpip protocol published by SATEL. 


* Free software: MIT license
* Documentation: https://satel-integra.readthedocs.io.


Features
--------

* TODO

Credits
---------

This package was created with Cookiecutter_ and the `audreyr/cookiecutter-pypackage`_ project template.

.. _Cookiecutter: https://github.com/audreyr/cookiecutter
.. _`audreyr/cookiecutter-pypackage`: https://github.com/audreyr/cookiecutter-pypackage

