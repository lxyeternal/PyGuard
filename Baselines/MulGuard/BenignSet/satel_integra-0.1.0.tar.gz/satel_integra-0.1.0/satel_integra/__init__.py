# -*- coding: utf-8 -*-

"""Top-level package for Satel Integra."""

__author__ = """Krzysztof Machelski"""
__email__ = 'krzysztof.machelski+pypi@gmail.com'
__version__ = '0.1.0'
