=====
Usage
=====

To use Satel Integra in a project::

    import satel_integra

