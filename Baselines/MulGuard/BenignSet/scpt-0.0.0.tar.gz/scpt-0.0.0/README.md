[![Get package](https://img.shields.io/pypi/v/scpt)](https://pypi.org/project/scpt/)

A (typed) toolbox to help keep the verbosity down when porting Bash scripts to Python.
