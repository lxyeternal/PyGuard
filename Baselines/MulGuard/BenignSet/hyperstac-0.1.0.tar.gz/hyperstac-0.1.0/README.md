A hyper-fast, safe Python module to read and write STAC. This is alpha software and there will be bugs, so maybe don't deploy to production just yet. 😉
