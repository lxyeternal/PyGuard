class PackTwo:
    def __init__(self):
        self.name = 'PackTwo'

    def process(self):
        print('This is', self.name)
        return 2
