"""IIIF Presentation API implementation."""
from iiif_prezi._version import __version__
