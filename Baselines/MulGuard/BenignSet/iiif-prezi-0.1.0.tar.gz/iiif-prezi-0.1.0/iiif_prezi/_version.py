"""Version number for this IIIF Presentation API library."""
__version__ = '0.1.0'
