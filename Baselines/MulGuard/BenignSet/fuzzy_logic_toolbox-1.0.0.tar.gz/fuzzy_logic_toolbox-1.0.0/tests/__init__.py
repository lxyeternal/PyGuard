from .mf_test import FuzzyVariablesTestCase
