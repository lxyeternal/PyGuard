"""
Luferov Victor <lyferov@yandex.ru>

Fuzzy Transform
"""