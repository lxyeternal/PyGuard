from setuptools import setup

setup(name='my_practice_probability',
      version='1.2',
      description='Gaussian and Binomial distributions',
      packages=['my_practice_probability'],
      author = 'Andrew Paster',
      author_email = 'myemail@something.com',
      zip_safe=False)
