
class ParseError(Exception):
    """
    Unable to parse data type
    """
    pass
