Changelog
=========


1.0a4 (2020-07-22)
------------------

- Avoid an error when middleware response can not be handled
  [mpeeters]


1.0a3 (2020-06-18)
------------------

- Fix an issue with route update
  [mpeeters]


1.0a2 (2019-06-25)
------------------

- Improve route registration by handling url updates
  [mpeeters]

- Add package tests
  [mpeeters]


1.0a1 (2018-12-04)
------------------

- Initial release.
  [mpeeters]
