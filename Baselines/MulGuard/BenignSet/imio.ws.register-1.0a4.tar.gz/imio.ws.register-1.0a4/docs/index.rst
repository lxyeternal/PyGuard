================
imio.ws.register
================

User documentation
