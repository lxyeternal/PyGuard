# Obs2Org Changelog

## Version 0.9.0 (2021-11-09)

First release
