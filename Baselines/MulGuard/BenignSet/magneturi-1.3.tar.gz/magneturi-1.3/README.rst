*********
magneturi
*********

generate magnet URI for Bittorrent files


=====
Usage
=====

.. code-block:: bash

    $ magneturi [<torrent file>] [<torrent file2>]...
    $ cat <torrent file> | magneturi


See also ``magneturi --help``.


=======
Install
=======

.. code-block:: bash

    $ pip3 install magneturi

