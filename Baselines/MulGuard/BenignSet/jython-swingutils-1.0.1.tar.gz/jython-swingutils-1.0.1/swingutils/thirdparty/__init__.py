"""
This package contains helpers and support classes for third party software
packages.

"""
