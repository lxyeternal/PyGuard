
class ZincMergeError(Exception):
    pass


class ZincMergeInvalidInputs(ZincMergeError):
    pass


class ZincMergeFileReadFailed(ZincMergeError):
    pass
