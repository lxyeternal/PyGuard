
=============
CMLibs Merger
=============

CMLibs merger:  This software can be found on PyPi and installed with the following command::

  pip install cmlibs.merger

Distribution
============

This software uses regex to extract the version number information from the package. The version number for this package is stored in 'src/cmlibs/merger/__init__.py'

