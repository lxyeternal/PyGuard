from setuptools import setup

setup(name='distributions_prob2022',
      version='1.0',
      description='Gaussian distributions and Binomial disributions',
      packages=['distributions_prob2022'],
      author = 'James Mugwanya',
      author_email = 'jamesmugwanya90@gmail.com',
      zip_safe=False)
