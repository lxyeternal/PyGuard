phevicol - very good, even in water :)
ps this is a test publish