# Richery-PIL

Supercharged rich text renderer based on Pillow.
