"""An internal file with the version of the `latexgit` package."""
from typing import Final

#: the version string of `latexgit`
__version__: Final[str] = "0.8.0"
