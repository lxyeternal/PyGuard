"""Utilities used by all of the code."""
