# MODULE NAME: alpaca-sqs-listener
from .sqs_listener import SqsListener
