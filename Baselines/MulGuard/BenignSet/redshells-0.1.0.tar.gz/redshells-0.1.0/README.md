# redshells
Machine learning tasks which are used with data pipeline library "luigi" and its wrapper "gokart".
