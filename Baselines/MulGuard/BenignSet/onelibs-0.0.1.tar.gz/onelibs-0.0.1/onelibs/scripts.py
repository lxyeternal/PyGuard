
def main():
    print('onelib')
