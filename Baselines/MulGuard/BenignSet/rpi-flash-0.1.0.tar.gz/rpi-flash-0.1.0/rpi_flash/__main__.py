import typer

from . import flash

typer.run(flash.main)
