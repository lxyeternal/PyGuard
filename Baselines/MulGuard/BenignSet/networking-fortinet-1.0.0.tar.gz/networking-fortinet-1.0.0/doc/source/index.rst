Welcome to networking-fortigate's documentation!
========================================================

Contents:

.. toctree::
   :maxdepth: 2

   readme
   installation
   contributing

Indices and tables
==================

* :ref:`genindex`
* :ref:`search`
