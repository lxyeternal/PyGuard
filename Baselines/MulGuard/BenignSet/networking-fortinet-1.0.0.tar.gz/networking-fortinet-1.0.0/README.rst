===============================
networking-fortinet
===============================

Networking-fortinet contains the Fortinet vendor code for Openstack Neutron.
The project is a connector from Neutron to Fortigate devices, which act as
network node for OpenStack, including L2/L3 capabilities.

* Free software: Apache license
* Documentation: http://docs.openstack.org/developer/networking-fortinet
* Source: http://git.openstack.org/cgit/openstack/networking-fortinet
* Bugs: http://bugs.launchpad.net/networking-fortinet
