# Changelog

<!-- <START NEW CHANGELOG ENTRY> -->

## 4.0.0

First major release working on JupyterLab >= 4.0.0

No merged PRs

<!-- <END NEW CHANGELOG ENTRY> -->

## 1.0.2

No merged PRs

## 1.0.1

No merged PRs

## 1.0.0

No merged PRs
