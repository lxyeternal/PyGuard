export const PLUGIN_ID = 'jupyterlabcodetoc';

export const MARKDOWN_HEADING_COLLAPSED = 'jpcodetoc-MarkdownHeadingCollapsed';
export const UNSYNC_MARKDOWN_HEADING_COLLAPSED = 'jpcodetoc-toc-hr-collapsed';
