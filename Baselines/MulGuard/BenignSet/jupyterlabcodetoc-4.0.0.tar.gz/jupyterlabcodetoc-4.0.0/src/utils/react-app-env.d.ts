// /// <reference types="redux-persist" />
// /// <reference types="react-bootstrap" />
declare module '*.png';
declare module '*.jpeg';
declare module '*.svg';
declare module '*.jpg';
