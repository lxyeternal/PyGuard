from setuptools import setup, find_packages

setup(
    name='Risk_lib_jt393',  # Change to your package name
    version='0.1',
    py_modules=['myfunctions'],  # Name of your Python file
    author='Jingyu Tan',
    author_email='t1169242950@gmail.com',
    description='Risk management',
)