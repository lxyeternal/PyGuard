
from django.apps import AppConfig


class DjangoAdminUserSummaryConfig(AppConfig):
    name = 'django_admin_user_summary'
