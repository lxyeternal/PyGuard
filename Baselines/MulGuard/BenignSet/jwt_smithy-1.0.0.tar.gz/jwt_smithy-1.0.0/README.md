# JWT smithy 🔨

---

Simple cli tool for jwt keys generation
