Changes in sphinx-astropy
=========================

1.0 (2018-02-07)
----------------

- Initial standalone version of this package (formerly packaged as part of astropy-helpers)
