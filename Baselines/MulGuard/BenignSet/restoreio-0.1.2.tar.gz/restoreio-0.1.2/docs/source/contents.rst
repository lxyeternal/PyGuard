
.. toctree::
    :maxdepth: 2

    Install <install>

.. toctree::
   :maxdepth: 2
   
   API Reference <api>
