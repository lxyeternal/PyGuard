﻿restoreio.restore
=================

.. currentmodule:: restoreio

.. autofunction:: restore