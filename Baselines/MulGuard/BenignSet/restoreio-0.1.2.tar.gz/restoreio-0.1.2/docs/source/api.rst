.. _api:

API Reference
*************

.. autosummary::
    :toctree: generated
    :caption: Functions
    :recursive:
    :template: autosummary/member.rst

    restoreio.restore
