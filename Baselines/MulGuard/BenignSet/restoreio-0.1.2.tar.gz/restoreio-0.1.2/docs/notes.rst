*****
Notes
*****

Journals:

- Computers and Geoscience
- Environmental Modeling and Software
- Journal of Atmospheric and Oceanic Technology
- SoftwareX

- Citation:

  * Add Tom's students thesis, some papers used this software
  * Add conferences I went to present this work, including the "poster",
    and "slides".
