# pynterface
A simple text-based user interface for the terminal.
