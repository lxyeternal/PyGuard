# Usage

Example usage with the CU55 from e-con systems:

```bash
record --vendor_id=0x2560 --product_id=0xc155 --fps=30 --width=2592 --height=1944 --time_in_seconds=5 --folder_name=mitch1
```