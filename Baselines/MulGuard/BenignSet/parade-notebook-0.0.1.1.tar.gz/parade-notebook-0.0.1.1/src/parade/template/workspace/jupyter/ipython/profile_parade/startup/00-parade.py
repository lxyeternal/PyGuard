from parade.core.context import Context
from parade.utils.workspace import load_bootstrap

_bootstrap = load_bootstrap()
context = pcxt = Context(_bootstrap)
