# cell-fate
Implementing cell fate models and benchmarks to compare those models. 
