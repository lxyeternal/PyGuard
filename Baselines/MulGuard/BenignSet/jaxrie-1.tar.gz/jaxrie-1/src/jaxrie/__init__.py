# Local
from .manifold import Manifold, Stereographic, math, stereographic

__all__ = ["Stereographic", "stereographic", "math", "Manifold"]
