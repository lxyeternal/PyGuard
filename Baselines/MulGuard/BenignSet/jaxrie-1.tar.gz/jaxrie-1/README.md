# jaxrie

Riemannian with JAX
