# debuglib-py
python debugger tool with easy integration into any program
