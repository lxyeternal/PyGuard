## Python stub for Delta Live Tables

Copyright (2024) Databricks, Inc.

This Software includes software developed at Databricks (https://www.databricks.com/) and its use is subject
to the included LICENSE.md file.
