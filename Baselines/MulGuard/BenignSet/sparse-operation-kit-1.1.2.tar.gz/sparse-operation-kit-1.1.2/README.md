# sparse-operation-kit is now merlin-sok

This package has been renamed. Use `pip install merlin-sok` instead.

New package: https://pypi.org/project/merlin-sok/
