from .asset_parser import *

__version__ = '1.0'