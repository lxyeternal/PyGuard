PyPOM
=====

PyPOM is a Python Page Object Model library for Selenium tests.

.. image:: https://img.shields.io/badge/license-MPL%202.0-blue.svg
   :target: https://github.com/davehunt/PyPOM/blob/master/LICENSE
   :alt: License
.. image:: https://img.shields.io/pypi/v/PyPOM.svg
   :target: https://pypi.python.org/pypi/PyPOM/
   :alt: PyPI
.. image:: https://img.shields.io/travis/davehunt/PyPOM.svg
   :target: https://travis-ci.org/davehunt/PyPOM/
   :alt: Travis
.. image:: https://img.shields.io/coveralls/davehunt/PyPOM.svg
   :target: https://coveralls.io/github/davehunt/PyPOM
   :alt: Coverage
.. image:: https://img.shields.io/github/issues-raw/davehunt/PyPOM.svg
   :target: https://github.com/davehunt/PyPOM/issues
   :alt: Issues
.. image:: https://img.shields.io/requires/github/davehunt/PyPOM.svg
   :target: https://requires.io/github/davehunt/PyPOM/requirements/?branch=master
   :alt: Requirements

Resources
---------

- `Documentation <http://pypom.readthedocs.org/>`_
- `Issue Tracker <http://github.com/davehunt/PyPOM/issues>`_
- `Code <http://github.com/davehunt/PyPOM/>`_
