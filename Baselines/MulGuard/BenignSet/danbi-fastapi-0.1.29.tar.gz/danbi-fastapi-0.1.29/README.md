# danbi-fastapi
fastapi plugin based on danbi library
