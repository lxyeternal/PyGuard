# django-authsignals
Package to consolidate common auth signal behavior
