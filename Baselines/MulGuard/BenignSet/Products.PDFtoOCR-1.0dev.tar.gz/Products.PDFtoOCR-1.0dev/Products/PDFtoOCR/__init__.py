from Products.Archetypes.atapi import *
from Products.CMFCore import utils as cmfutils

# Unleash the crazy monkeys!
import patches

def initialize(context):
    """Initializer called when used as a Zope 2 product."""

