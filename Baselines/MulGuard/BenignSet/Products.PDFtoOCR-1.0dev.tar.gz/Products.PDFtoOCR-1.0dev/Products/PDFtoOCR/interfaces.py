from zope.interface import Interface

class IIndex(Interface):
    """ Processes indexing PDF files using OCR
    """

