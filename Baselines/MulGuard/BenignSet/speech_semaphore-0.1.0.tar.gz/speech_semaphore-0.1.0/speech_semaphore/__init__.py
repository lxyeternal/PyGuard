from .sinthesis_with_pause import ClientTTS

__version__ = "0.1.0"
