from .core import Metadata
from .core import Config, Basic, ConfigException
# from .drive import DriveExplorer
# from .excel import Excel
# from .workbook import Workbook
# from .sharepoint import _SiteBasic, Site, List
__version__ = Metadata.PACKAGE_VERSION
#__all__ = ["files.Files", "client.Config"]

