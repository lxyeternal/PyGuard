### IMPORTS ###

# Python Standard Library
import os
import json

# 3rd party
# ...

#Local
# ...

### FUNCTIONS ###
    
def _xor(*args):
    return sum(bool(i) for i in args) == 1 





