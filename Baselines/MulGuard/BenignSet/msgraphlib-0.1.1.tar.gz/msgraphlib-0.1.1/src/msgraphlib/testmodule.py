### IMPORTS ###

# Python Standard Library
import os
import json

# 3rd party
# ...

#Local
# from graph.api import API
from graph.metadata import Metadata


### CLASSES ###
    
class TestClass():

    def __init__(self):
        ''

