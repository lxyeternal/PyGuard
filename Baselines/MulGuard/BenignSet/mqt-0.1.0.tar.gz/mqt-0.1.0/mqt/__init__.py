#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""

mqt
---

QA Tools for Odoo maintainers (MQT)

"""

from __future__ import absolute_import, division, print_function, \
    with_statement, unicode_literals

from .mqt import Mqt
