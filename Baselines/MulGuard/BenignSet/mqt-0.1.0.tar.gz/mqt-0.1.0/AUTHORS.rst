=======
Credits
=======

Development Lead
----------------

* Odoo Community Association <github@odoo-community.org>

Contributors
------------

None yet. Why not be the first?
