#!/usr/bin/env python
from setuptools import setup

required = [line for line in open('requirements/base.txt').read().split("\n")]

setup(
    name='pywithings',
    version='0.4.0',
    description="Library for the Withings API",
    author='ORCAS',
    author_email='developer@orcasinc.com',
    url="https://github.com/orcasgit/python-withings",
    license = "MIT License",
    packages = ['withings'],
    install_requires = required,
    test_suite='tests.all_tests',
    scripts=['bin/withings'],
    keywords="withings",
    zip_safe = True,
    classifiers=[
        "Development Status :: 3 - Alpha",
        "Intended Audience :: Developers",
        "Programming Language :: Python",
        "Programming Language :: Python :: 2",
        "Programming Language :: Python :: 2.7",
        "Programming Language :: Python :: 3",
        "Programming Language :: Python :: 3.3",
        "Programming Language :: Python :: 3.4",
        "Programming Language :: Python :: 3.5",
        "Programming Language :: Python :: 3.6",
        "Programming Language :: Python :: Implementation",
        "Programming Language :: Python :: Implementation :: CPython",
        "Programming Language :: Python :: Implementation :: PyPy",
    ]
)
