import geojson

def example_function(geojson:geojson):
    return 'this is an example tool'