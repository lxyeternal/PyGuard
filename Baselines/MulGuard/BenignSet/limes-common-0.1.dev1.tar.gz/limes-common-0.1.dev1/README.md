# limes-common
This is the shared methods between limes and limes-core, mostly networking code