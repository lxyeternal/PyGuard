#ifndef GLOBALS_H
#define GLOBALS_H

// danger zone
// usually commented out

// no derivative of the activation function
// #define NO_DERIV_ACTIVATION



#ifdef _WIN32
// that includes the standard M_PI etc stuff
#define _USE_MATH_DEFINES
#include <cmath>  

#endif



#endif
