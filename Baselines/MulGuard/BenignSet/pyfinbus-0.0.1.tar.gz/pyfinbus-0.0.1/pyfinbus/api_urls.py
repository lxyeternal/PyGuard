# stock
xueqiu_kline = "https://stock.xueqiu.com/v5/stock/chart/kline.json?symbol={}&begin={}&end={}&period={}&type={}&indicator=kline,pe,pb,ps,pcf,market_capital,agt,ggt,balance"
xueqiu_valuation = "https://stock.xueqiu.com/v5/stock/finance/valuation_data.json?is_latest=0&range=1y&symbol={}&type={}&version=1"