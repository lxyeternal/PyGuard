# S3TorchConnector

S3TorchConnector is a tool which allows Python code to interface with a performant S3 client.

This project is currently a placeholder.