def reverse_str(x: str):
    return x[::-1]
