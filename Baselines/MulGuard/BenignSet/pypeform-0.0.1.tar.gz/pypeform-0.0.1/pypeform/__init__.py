"""
This is the documentation for the package.
"""

__version__ = '0.0.1'
