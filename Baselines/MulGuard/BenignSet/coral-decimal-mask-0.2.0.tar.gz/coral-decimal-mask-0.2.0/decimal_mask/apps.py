from django.apps import AppConfig


class ProjectNameConfig(AppConfig):
    name = "decimal_mask"
