"""Flask-WebSub

This package consists of three (mostly independent) different components:

- flask_websub.hub
- flask_websub.publisher
- flask_websub.subscriber

"""
