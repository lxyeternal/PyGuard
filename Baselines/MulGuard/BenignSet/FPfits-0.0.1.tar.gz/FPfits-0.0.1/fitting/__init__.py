from plotting import fit
