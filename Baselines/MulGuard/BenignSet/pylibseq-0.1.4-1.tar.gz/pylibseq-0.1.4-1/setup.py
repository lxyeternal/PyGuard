#!/usr/bin/env python

# setup.py.in.distutils
#
# Copyright 2012, 2013 Brandon Invergo <brandon@invergo.net>
#
# Copying and distribution of this file, with or without modification,
# are permitted in any medium without royalty provided the copyright
# notice and this notice are preserved.  This file is offered as-is,
# without any warranty.

from __future__ import print_function
from distutils.core import setup,Extension
from Cython.Build import cythonize
import platform, glob, sys, subprocess

#Dependency checks

##Check for libsequence version
try:
    proc = subprocess.Popen(['libsequenceConfig','--version'],stdout=subprocess.PIPE)
    (out,err) = proc.communicate()
    version = str(out).rstrip()
    print ("libsequence version",version," found.")
    if version <= '1.8.7':
        raise RuntimeError("libsequence > ,'1.8.7' required, but ",version, "found.")
except:
    print("libsequenceConfig not found.  Please install fwdpp (http://github.com/molpopgen/libsequence)")


##Can we compile a program based on libsequence?
print("Attempting to compile and link a test program using libsequence...")
try:
    proc = subprocess.check_output(['make','-f','check_deps/Makefile','clean'])
    proc = subprocess.check_output(['make','-f','check_deps/Makefile'])
    proc = subprocess.check_output(['make','-f','check_deps/Makefile','clean'])
except subprocess.CalledProcessError as e:
    print (e.returncode)
print("done")

if platform.system() == 'Linux' or platform.system() == 'Darwin':
    doc_dir = '/usr/local/share/doc/pylibseq'
else:
    try:
        from win32com.shell import shellcon, shell
        homedir = shell.SHGetFolderPath(0, shellcon.CSIDL_APPDATA, 0, 0)
        appdir = 'pylibseq'
        doc_dir = os.path.join(homedir, appdir)
    except:
        pass

long_desc = \
"""
"""

extensions = []
pdata = {'libsequence':['*.pxd']}
provided = []
modules = ['polytable','summstats','windows','fst']
for i in modules:
    extensions.append(Extension("libsequence."+i,
                                sources=["libsequence/"+i+".cpp"],
                                language="c++",                  
                                extra_compile_args=["-std=c++11"],  
                                extra_link_args=["-std=c++11"],
                                libraries=["sequence"])
                                )
    provided.append('libsequence.'+i)
    pdata['libsequence.'+i]=['*.pxd']



setup(name='pylibseq',
      version='0.1.4-1',
      author='Kevin R. Thornton',
      author_email='krthornt@uci.edu',
      maintainer='Kevin R. Thornton',
      maintainer_email='krthornt@uci.edu',
      url='http://github.com/molpopgen/pylibseq',
      description="""""",
      long_description=long_desc,
      data_files=[(doc_dir, ['COPYING', 'README.rst'])],
      download_url='',
      classifiers=[],
      platforms=['Linux','OS X'],
      license='GPL >= 2',
      provides=provided,
      obsoletes=['none'],
      packages=['libsequence'],
      py_modules=[],
      scripts=[],
      package_data=pdata,
      ext_modules=extensions
)
     
