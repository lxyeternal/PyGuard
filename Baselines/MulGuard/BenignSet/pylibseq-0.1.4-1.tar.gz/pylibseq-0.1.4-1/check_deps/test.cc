#include <Sequence/SimData.hpp>
#include <Sequence/SummStats.hpp>

using namespace std;
using namespace Sequence;

int main(int argc, char ** argv)
{
  auto x = SimData();
}
