def pygman():
    print('pygman')
