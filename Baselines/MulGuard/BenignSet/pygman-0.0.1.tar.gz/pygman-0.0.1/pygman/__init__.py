from pygman.pygman import *

print("pygman")
