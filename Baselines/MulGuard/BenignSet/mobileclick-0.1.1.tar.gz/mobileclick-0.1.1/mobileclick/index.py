# -*- coding: utf-8 -*-

class Index(object):

    def __init__(self, qid, rank, filepath, title, url, body):
        self.qid = qid
        self.rank = rank
        self.filepath = filepath
        self.title = title
        self.url = url
        self.body = body
