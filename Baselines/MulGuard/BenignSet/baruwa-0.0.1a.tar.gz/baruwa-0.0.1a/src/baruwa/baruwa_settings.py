# Baruwa only setting
#

MS_CONFIG = '/etc/MailScanner/MailScanner.conf'
