Compute estimated stock coverage based on product sales over a date range.
