"""Top-level package for Agrotech Sensor Kit API."""

from agro_kit.agro_kit import AgroKit, Reading

__author__ = """Zidaan Habib, Fraser Montandon"""
__email__ = 'hbbzid001@myuct.ac.za'

__version__ = '1.0.0'
