
def main():
    print("This the Agro-Kit API. ")

if __name__ == "__main__":
    main()
