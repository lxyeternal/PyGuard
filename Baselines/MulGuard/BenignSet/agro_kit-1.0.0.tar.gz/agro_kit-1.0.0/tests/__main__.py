import os

def main():
    os.system("pytest test_agro_kit.py")

if __name__ == "__main__":
    main()
