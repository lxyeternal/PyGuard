from light_sensor.light_sensor import light_sensor

__version__ = "1.0.0"
