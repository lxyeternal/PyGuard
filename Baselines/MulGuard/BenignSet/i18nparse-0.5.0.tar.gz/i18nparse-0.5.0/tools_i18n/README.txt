This directory contains a copy of the msgfmt.py file from the cpython
distribution, because it is not always installed by default.
A copy of the orginal license file is also included here.
