__version__ = "0.5.0"
# this file must contain __version__ = version_string as its first line

# MIT License
# Copyright (c) 2018 s-ball
