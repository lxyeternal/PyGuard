#!/usr/bin/env python
# -*- coding: utf-8 -*-

__author__ = "R4SAS <r4sas@i2pmail.org>"
__version__ = "0.2.1"
__copyright__ = "Copyright (c) R4SAS"
__license__ = "MIT"
