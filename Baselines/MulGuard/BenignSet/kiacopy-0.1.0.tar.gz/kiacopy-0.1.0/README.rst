=======
kiacopy
=======


.. image:: https://img.shields.io/pypi/v/kiacopy.svg
        :target: https://pypi.python.org/pypi/kiacopy

.. image:: https://img.shields.io/travis/ganariya/kiacopy.svg
        :target: https://travis-ci.com/ganariya/kiacopy

.. image:: https://readthedocs.org/projects/kiacopy/badge/?version=latest
        :target: https://kiacopy.readthedocs.io/en/latest/?badge=latest
        :alt: Documentation Status




kiacopy can make k-independent traveling salesman problem


* Free software: MIT license
* Documentation: https://kiacopy.readthedocs.io.


Features
--------

* TODO

Credits
-------

This package was created with Cookiecutter_ and the `audreyr/cookiecutter-pypackage`_ project template.

.. _Cookiecutter: https://github.com/audreyr/cookiecutter
.. _`audreyr/cookiecutter-pypackage`: https://github.com/audreyr/cookiecutter-pypackage
