=====
Usage
=====

To use kiacopy in a project::

    import kiacopy
