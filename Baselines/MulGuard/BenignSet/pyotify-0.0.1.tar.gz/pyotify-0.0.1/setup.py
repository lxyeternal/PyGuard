import setuptools
import re


def read_file(filename):
    with open(filename) as file:
        return file.read()

setuptools.setup(
    name='pyotify',
    version='0.0.1',
    author='Bogdan Paunovic',
    long_description = read_file('README.md'),
    long_description_content_type='text/markdown',
    author_email='bogdanbokipaunovic@gmail.com',
    description='Fully-featured library to interact with the Spotify Web API',
    url='https://github.com/paunzz/pyotify',
    packages=setuptools.find_packages(exclude=['tests*']),
    install_requires=read_file('requirements.in'),
    extras_require={
        'tests': {
            'pytest',
        },
    },
    classifiers=[
        'Environment :: Console',
        'Intended Audience :: Developers',
        'Programming Language :: Python :: 3.4',
        'Programming Language :: Python :: 3.5',
        'Programming Language :: Python :: 3.6',
        'Programming Language :: Python :: 3.7',
        'Programming Language :: Python :: 3.8',
        'Programming Language :: Python :: Implementation :: CPython',
        'Programming Language :: Python :: Implementation :: PyPy',
        'License :: OSI Approved :: MIT License',
        'Operating System :: OS Independent',

    ],
) 