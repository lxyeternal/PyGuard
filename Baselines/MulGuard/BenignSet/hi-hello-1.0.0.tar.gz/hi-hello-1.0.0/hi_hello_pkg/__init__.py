def hello():
    print("==========================")
    print("Hello! You look nice today")
    print("==========================")