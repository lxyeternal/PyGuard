# ffwd-client-python

[FFWD](https://github.com/spotify/ffwd-java) client for Python.

See [examples](./examples) for usage examples.

## Installation

Install from PYPI:

```
$> pip install --user ffwd
```
