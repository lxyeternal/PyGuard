import setuptools

setuptools.setup(
    name="printername2",
    version="0.0.7",
    author="Yitian",
    author_email="123@456.com",
    url="https://dev.azure.com/yliu9yl/pypi-test",
    packages=[
        "test_folder1"
    ],
    python_requires='>=3.6',
)