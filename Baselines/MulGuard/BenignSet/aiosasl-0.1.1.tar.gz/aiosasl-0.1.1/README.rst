``aiosasl``, pure python generic asyncio SASL library
#####################################################

``aiosasl`` provides a generic, asyncio-based SASL library. It can be used with
any protocol, provided the neccessary interface code is provided by the
application or protocol implementation.

Dependencies
------------

* Python ≥ 3.4 (or Python = 3.3 with tulip)
