<h2>A computing library for engineers.</h2>


<p>Contains apps (literally they are wxPython apps) and the following:</p>
<ol>
	<li>Integration, fitting, root finding methods,</li>
	<li><b>eng:</b> Food, psychrometry, refrigerants,</li>
	<li><b>stats:</b> Follows R terminology and includes several methods,</li>
	<li><b>util:</b> Utility package,</li>
	<li><b>wxpy:</b> Utilities specific to wxPython.</li>
</ol>
