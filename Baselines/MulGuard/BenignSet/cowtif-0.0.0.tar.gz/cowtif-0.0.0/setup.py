# -*- coding: utf-8 -*-
# @author: Algorithm Team @ 杉数科技/Cardinal Operations
# @email: coalgo@shanshu.ai
# @date: 2023/06

from setuptools import setup, find_packages

setup(
    name="cowtif",
    version="0.0.0",
    description="联络：coalgo@shanshu.ai",
    author=["coalgo@shanshu.ai"],
    packages=find_packages(),
    include_package_data=True,
    install_requires=[
    ]
)
