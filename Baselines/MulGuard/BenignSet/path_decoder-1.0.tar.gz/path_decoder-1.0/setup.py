from setuptools import setup

setup(name="path_decoder",version="1.0",
description="This package will extract the json paths from a json file",
author="Chetan",
packages=['path_decoder'],
)