def p(a):
    print(a)

def fr_p(n, b):
    for i in range(int(n)):
        print(b)

def rpc(var, v1, v2):
    rpcv=var.replace(v1, v2)
    print(rpcv)

def vars(var):
    vars=var

def rvs(a):
    b=a[::-1]
    print(b)

def i_p(val):
    while True:
        print(val)

def if_else_p(a, b, c, d):
    if a == b:
        print(c)
    else:
        print(d)

def lwr(a):
    var=a.lower()
    print(var)

def if_elif_else(a, b, c, d, e, f):
    if a==b:
        print(c)
    elif a==d:
        print(e)
    else:
        print(f)

    


    