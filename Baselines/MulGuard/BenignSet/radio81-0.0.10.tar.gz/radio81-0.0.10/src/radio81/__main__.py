
from radio81.console import start

# Press the green button in the gutter to run the script.


if __name__ == '__main__':
    start()
