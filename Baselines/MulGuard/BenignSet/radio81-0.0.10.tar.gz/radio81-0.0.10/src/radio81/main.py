def main():
    start()