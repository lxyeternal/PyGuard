====================
imio.directory.policy
====================

User documentation
