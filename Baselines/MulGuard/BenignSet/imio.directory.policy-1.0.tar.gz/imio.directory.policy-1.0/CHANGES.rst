Changelog
=========


1.0 (2022-11-15)
----------------

- Add available languages to prepare for multilingual
  [laulaz]

- Update buildout to use Plone 6.0.0a3 packages versions
  [boulch]


1.0a1 (2022-01-25)
------------------

- Initial release.
  [laulaz]
