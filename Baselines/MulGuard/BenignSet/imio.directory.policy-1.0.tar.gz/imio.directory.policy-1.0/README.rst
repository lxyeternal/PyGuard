.. This README is meant for consumption by humans and pypi. Pypi can render rst files so please do not use Sphinx features.
   If you want to learn more about writing documentation, please check out: http://docs.plone.org/about/documentation_styleguide.html
   This text does not appear on pypi or github. It is a comment.

.. image:: https://travis-ci.org/imio/imio.directory.policy.svg?branch=master
    :target: https://travis-ci.org/imio/imio.directory.policy

.. image:: https://coveralls.io/repos/github/imio/imio.directory.policy/badge.svg?branch=master
    :target: https://coveralls.io/github/imio/imio.directory.policy?branch=master
    :alt: Coveralls

.. image:: https://img.shields.io/pypi/v/imio.directory.policy.svg
    :target: https://pypi.python.org/pypi/imio.directory.policy/
    :alt: Latest Version

.. image:: https://img.shields.io/pypi/status/imio.directory.policy.svg
    :target: https://pypi.python.org/pypi/imio.directory.policy
    :alt: Egg Status

.. image:: https://img.shields.io/pypi/pyversions/imio.directory.policy.svg?style=plastic   :alt: Supported - Python Versions

.. image:: https://img.shields.io/pypi/l/imio.directory.policy.svg
    :target: https://pypi.python.org/pypi/imio.directory.policy/
    :alt: License


=====================
imio.directory.policy
=====================

Policies to setup imio.directory

Features
--------

- TODO


Examples
--------

This add-on can be seen in action at the following sites:
- Is there a page on the internet where everybody can see the features?


Documentation
-------------

TODO


Translations
------------

This product has been translated into

- French


Installation
------------

Install imio.directory.policy by adding it to your buildout::

    [buildout]

    ...

    eggs =
        imio.directory.policy


and then running ``bin/buildout``


Contribute
----------

- Issue Tracker: https://github.com/imio/imio.directory.policy/issues
- Source Code: https://github.com/imio/imio.directory.policy


License
-------

The project is licensed under the GPLv2.
