# Ory Django

This package provides integration with Ory Cloud or Ory Kratos for your django application

## Installing

TBD

## Configuration

You need to add these variables to your settings

```
ORY_SDK_URL=https://projectId.projects.oryapis.com
LOGIN_URL=https://projectId.projects.oryapis.com/ui/login
LOGOUT_URL=https://projectId.projects.oryapis.com/logout
```
