This app was developed as part of the Pinax ecosystem but is just a Django app
and can be used independently of other Pinax apps. To learn more about Pinax,
see http://pinaxproject.com/

pinax-cms
=========

.. image:: https://img.shields.io/travis/pinax/pinax-cms.svg
    :target: https://travis-ci.org/pinax/pinax-cms

.. image:: https://img.shields.io/coveralls/pinax/pinax-cms.svg
    :target: https://coveralls.io/r/pinax/pinax-cms

.. image:: https://img.shields.io/pypi/dm/pinax-cms.svg
    :target:  https://pypi.python.org/pypi/pinax-cms/

.. image:: https://img.shields.io/pypi/v/pinax-cms.svg
    :target:  https://pypi.python.org/pypi/pinax-cms/

.. image:: https://img.shields.io/badge/license-MIT-blue.svg
    :target:  https://pypi.python.org/pypi/pinax-cms/


Welcome to the documentation for pinax-cms!


Running the Tests
------------------------------------

::

    $ pip install detox
    $ detox
