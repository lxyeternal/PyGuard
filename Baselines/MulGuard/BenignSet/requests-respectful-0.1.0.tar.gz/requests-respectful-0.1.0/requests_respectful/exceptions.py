
class RequestsRespectfulError(Exception):
    pass


class RequestsRespectfulRateLimitedError(Exception):
    pass


class RequestsRespectfulConfigError(Exception):
    pass


class RequestsRespectfulRedisError(Exception):
    pass
