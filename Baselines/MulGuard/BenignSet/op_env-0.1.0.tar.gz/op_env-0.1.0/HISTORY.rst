=======
History
=======

0.1.0 (2021-02-01)
------------------

* First release on PyPI.
