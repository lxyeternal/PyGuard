"""Top-level package for op-env."""

__author__ = """Vince Broz"""
__email__ = 'vince@broz.cc'
__version__ = '0.1.0'
