=====
Usage
=====

To use op-env in a project::

    import op_env
