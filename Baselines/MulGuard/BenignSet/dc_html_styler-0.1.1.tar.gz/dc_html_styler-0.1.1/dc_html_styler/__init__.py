"""Top-level package for dc_html_styler."""

__author__ = """Jakob Erik Jensen"""
__email__ = 'jej@danskecommodities.com'
__version__ = '0.1.1'
