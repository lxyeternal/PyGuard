#!/usr/bin/env python

"""Tests for `dc_html_styler` package."""


import unittest

from dc_html_styler import dc_html_styler


class TestDc_html_styler(unittest.TestCase):
    """Tests for `dc_html_styler` package."""

    def setUp(self):
        """Set up test fixtures, if any."""

    def tearDown(self):
        """Tear down test fixtures, if any."""

    def test_000_something(self):
        """Test something."""
