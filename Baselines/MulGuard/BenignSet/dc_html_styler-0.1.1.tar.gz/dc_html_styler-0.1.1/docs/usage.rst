=====
Usage
=====

To use dc_html_styler in a project::

    import dc_html_styler
