=======
History
=======

0.1.1 (2021-03-18)
------------------

* First release on PyPI.
