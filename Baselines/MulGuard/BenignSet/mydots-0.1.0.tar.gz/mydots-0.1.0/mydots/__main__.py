from mydots import cli


cli.main()
