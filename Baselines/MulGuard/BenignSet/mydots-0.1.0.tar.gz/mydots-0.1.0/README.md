mydots
======

A simple JSON parser.

