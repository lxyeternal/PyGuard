Api Wrapper for BlueAir API using async in python, this was inspired by [this guide](https://developers.home-assistant.io/docs/api_lib_index) to be a lightweight wrapper, with simple error handling.

a lot of this is based on [hass-blueair](https://github.com/aijayadams/hass-blueair).

