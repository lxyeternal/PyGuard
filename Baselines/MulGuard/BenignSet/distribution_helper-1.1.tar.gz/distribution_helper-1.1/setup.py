from setuptools import setup

setup(name='distribution_helper',
      version='1.1',
      description='Gaussian distributions',
      packages=['distribution_helper'],
      zip_safe=False)
