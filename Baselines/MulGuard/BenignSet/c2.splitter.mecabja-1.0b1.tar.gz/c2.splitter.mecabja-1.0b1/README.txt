Introduction
============

This package is Japanese language splitter for MeCab.

License
-----------

GNU General Public License (GPL)


Prerequisite
-----------------

This package should work with UNIX related systm, such as Linux, FreeBSD, MacOS X.

- Python2.4.3 or higher.
- MeCab 0.9 or higher, tested with MeCab 0.93.
- Dictionary-charset: UTF-8 and Site-charset: UTF-8


Require packeage
-------------------------

- mecab-python, it is auto included.


THANKS
----------

MJSplitter http://zope.org/Members/mojix/MJSplitter/ Michiharu 'Zope Junkie' Sakurai aka mojix


