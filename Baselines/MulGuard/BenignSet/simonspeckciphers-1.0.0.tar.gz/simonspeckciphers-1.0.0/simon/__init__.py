# -*- coding: utf-8 -*-

"""Top-level package for Simon"""
from .simon import SimonCipher
__author__ = """Michael Calvin McCoy"""
__email__ = 'calvin.mccoy@protonmail.com'
__version__ = '1.0.0'
