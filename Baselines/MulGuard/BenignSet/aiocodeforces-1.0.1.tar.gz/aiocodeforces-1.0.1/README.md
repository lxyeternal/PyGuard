# aiocodeforces

Async based API wrapper for CodeForces written in Python for Python.

Currently a work in progress. Documentation coming out soon hopefully.
