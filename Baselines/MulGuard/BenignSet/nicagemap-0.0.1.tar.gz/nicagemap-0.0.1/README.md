# nicagemap


[![image](https://img.shields.io/pypi/v/nicagemap.svg)](https://pypi.python.org/pypi/nicagemap)


**A python package for interactive mapping**


-   Free software: MIT license
-   Documentation: https://OscarVel21.github.io/nicagemap
    

## Features

-   TODO

## Credits

This package was created with [Cookiecutter](https://github.com/cookiecutter/cookiecutter) and the [giswqs/pypackage](https://github.com/giswqs/pypackage) project template.
