"""Top-level package for nicagemap."""

__author__ = """Oscar Santiago Velasquez Muñoz"""
__email__ = 'oscar_velasquez1995@hotmail.com'
__version__ = '0.0.1'
