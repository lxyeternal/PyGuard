# Auquan Asia DS Toolbox

This package is intended to be used for the Auquan's Asia Data Science challenge