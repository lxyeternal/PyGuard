"""
Tests for the dit.algorithms module.
"""
