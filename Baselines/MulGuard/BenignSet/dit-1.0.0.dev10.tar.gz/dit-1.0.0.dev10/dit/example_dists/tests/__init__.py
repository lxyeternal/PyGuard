"""
Tests for dit.example_dists.
"""
