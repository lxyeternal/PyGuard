"""
Tests for dit.other.
"""
