"""
Tests for dit.shannon.
"""
