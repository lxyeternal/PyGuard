"""
Tests for dit.multivariate.
"""
