"""
Tests for dit.divergences.
"""
