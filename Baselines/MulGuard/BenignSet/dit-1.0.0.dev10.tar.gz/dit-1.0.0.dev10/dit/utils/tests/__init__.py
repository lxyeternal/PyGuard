"""
Tests for dit.utils.
"""
