"""
Tests for basic dit functionality.
"""
