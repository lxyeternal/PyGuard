"""
Tests for dit.math.
"""
