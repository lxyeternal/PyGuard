def add_two_nums(num1,num2):
    return num1+num2
def substract_two_nums(num1,num2):
    return num1-num2
def multiple_two_nums(num1,num2):
    return num1*num2
def divide_two_nums(num1,num2):
    return num1/num2
