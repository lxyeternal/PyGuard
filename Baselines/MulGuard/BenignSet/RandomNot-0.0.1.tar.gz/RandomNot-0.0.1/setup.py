from setuptools import setup,find_packages
classfiries=[
    'development status::5-Production/Stable'
    'Intended Audince::Education'
    'Operating System::Micrsofot::Windows::Windows 11'
    'Programming Language::Python::3'
]
setup(
     name='RandomNot',
     version='0.0.1',
     description='calculator',
long_description_content_type="text/markdown",

    long_description=open('README.txt').read()+'\n\n'+open('CHANGELOG.txt').read(),
    url='',
    author='Giorgi Uertashvili',
    author_email='giouerta97@gmail.com',
    license='MIT',
    keywords='calculator',
    packages=find_packages(),
    install_requesres=['']




)