Fitting FTIR data with multi lorentzian / Gaussian functions. 

## Resources

1. [Rampy](https://github.com/charlesll/rampy)
2. [lmfit](https://lmfit.github.io/lmfit-py/fitting.html)
3. [PseudoVoigt](https://docs.mantidproject.org/nightly/fitting/fitfunctions/PseudoVoigt.html)
