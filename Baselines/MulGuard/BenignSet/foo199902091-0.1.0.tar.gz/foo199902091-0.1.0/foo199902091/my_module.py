# simple_module.py

def greet(name):
    return f"Hello, {name}!"
