# -*- coding: utf-8 -*-


class NoPrekeyRecordException(Exception):
    pass
