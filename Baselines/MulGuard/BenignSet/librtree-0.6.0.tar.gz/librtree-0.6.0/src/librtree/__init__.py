__version__ = '0.6.0'

from librtree.rtree import RTree
from librtree.style import RTreeStyle
