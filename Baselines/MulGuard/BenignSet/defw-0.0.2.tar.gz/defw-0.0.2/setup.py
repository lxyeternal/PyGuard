import setuptools
setuptools.setup(
    name="defw",
    version="0.0.2",
    python_requires='>=3.6',
)