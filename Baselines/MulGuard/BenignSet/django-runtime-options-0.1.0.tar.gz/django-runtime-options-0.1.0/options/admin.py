from django.contrib import admin

from options.models import Option


admin.site.register(Option)
