from django.apps import AppConfig


class OptionsConfig(AppConfig):
    name = "options"
