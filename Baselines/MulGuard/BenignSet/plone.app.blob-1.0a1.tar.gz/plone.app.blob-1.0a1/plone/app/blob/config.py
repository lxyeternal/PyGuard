
packageName = 'plone.app.blob'
packageGlobals = globals()

permissions = {
    'Blob': 'plone.app.blob: Add Blob',
}

