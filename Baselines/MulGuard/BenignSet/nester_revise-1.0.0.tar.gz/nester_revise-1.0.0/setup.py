#from distutils.core import setup
from setuptools import setup

setup (
        name='nester_revise',
        version='1.0.0',
        py_modules=['nest_revise'],
        author='jr',
        author_email='jr001@me.com',
        url='http://nanoalmighty.com',
        description='A simple printer of lists',
        )
