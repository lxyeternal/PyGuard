from ._core import Collection, local, task

__all__ = ["task", "Collection", "local"]
