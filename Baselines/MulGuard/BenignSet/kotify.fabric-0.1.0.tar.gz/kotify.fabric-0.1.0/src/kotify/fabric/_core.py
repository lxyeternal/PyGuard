from fabric import task  # noqa
from invoke import Collection  # noqa
from invoke import run as local  # noqa
