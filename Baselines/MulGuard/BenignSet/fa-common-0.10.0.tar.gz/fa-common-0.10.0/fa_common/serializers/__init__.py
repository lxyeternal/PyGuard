from .common import CamelModel, Serializer
from .openapi import patch
