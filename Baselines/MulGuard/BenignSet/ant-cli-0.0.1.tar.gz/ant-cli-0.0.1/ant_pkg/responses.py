CREATED_FILES = 'Created files:'
DIRECTORY_NOT_CREATED = 'Directory not found: %s.'
SCAFFOLD_NOT_FOUND = 'Scaffold not found.'
SUCCESSFUL_COMMAND = 'The command was executed correctly.'
HELP_DESCRIPTION = 'Tool for assembling scaffolding.'
SCAFFOLD_HAS_NOT_BASE = 'The file .scaffold does not have the section "base"'
TITTLE_BAR = '='*5 + '%s' + '='*5
END_BAR = '='*10
