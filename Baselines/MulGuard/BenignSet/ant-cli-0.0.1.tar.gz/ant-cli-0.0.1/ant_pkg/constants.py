import os

CONFIG_FOLDER = os.path.join(os.path.dirname(__file__), 'config.yaml')
COMMAND_FOLDER = os.path.join(os.path.dirname(__file__), 'commands')
SCAFFOLD_FILE_NAME = '.scaffold'
