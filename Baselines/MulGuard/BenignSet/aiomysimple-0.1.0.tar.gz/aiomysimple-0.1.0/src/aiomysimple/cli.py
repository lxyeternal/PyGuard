"""Console script for aiomysimple."""
import sys


def main():
    return 0


if __name__ == "__main__":
    sys.exit(main())  # pragma: no cover
