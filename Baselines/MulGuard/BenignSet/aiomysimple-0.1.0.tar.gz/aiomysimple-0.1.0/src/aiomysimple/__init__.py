"""Top-level package for aiomysimple."""

from .aiomysimple import *

__author__ = """Starwort"""
__email__ = "tcphone93@gmail.com"
__version__ = "0.1.0"
