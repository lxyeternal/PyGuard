from django.apps import AppConfig


class DjangoMCAppConfig(AppConfig):
    name = 'django_mc'
