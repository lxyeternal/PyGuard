def test_imports():
    import django_mc
    import django_mc.link
