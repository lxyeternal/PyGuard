Changelog
=========

0.1.0
-----

- Added ``django_mc.link`` sub-application.
- Added ``AddComponentTypeToRegions`` and ``RemoveComponentTypeFromRegions``
  to make it super easy to add and remove component types to and from the list of
  allowed components in a region.
- Initial release.
