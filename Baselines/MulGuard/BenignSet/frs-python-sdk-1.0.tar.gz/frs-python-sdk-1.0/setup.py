from setuptools import setup, find_packages

setup(
    name = 'frs-python-sdk',
    version = "1.0",
    description = "FRS",
    license = "MIT Licence",

    url = "https://github.com/huaweicloud/huaweicloud-sdk-python-frs",
    author = "sevanco",
    author_email = "zhangqi130@huawei.com",
)