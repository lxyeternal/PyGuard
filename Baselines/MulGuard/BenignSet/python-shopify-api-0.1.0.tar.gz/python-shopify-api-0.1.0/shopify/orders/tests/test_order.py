from unittest import TestCase


class TestOrder(TestCase):
    def test_email(self):
        self.fail()

    def test_closed_at(self):
        self.fail()

    def test_created_at(self):
        self.fail()

    def test_updated_at(self):
        self.fail()

    def test_number(self):
        self.fail()

    def test_note(self):
        self.fail()

    def test_token(self):
        self.fail()

    def test_gateway(self):
        self.fail()

    def test_test(self):
        self.fail()

    def test_total_price(self):
        self.fail()

    def test_subtotal_price(self):
        self.fail()

    def test_total_weight(self):
        self.fail()

    def test_total_tax(self):
        self.fail()

    def test_taxes_included(self):
        self.fail()

    def test_currency(self):
        self.fail()

    def test_financial_status(self):
        self.fail()

    def test_confirmed(self):
        self.fail()

    def test_total_discounts(self):
        self.fail()

    def test_total_line_items_price(self):
        self.fail()

    def test_cart_token(self):
        self.fail()

    def test_buyer_accepts_marketing(self):
        self.fail()

    def test_name(self):
        self.fail()

    def test_referring_site(self):
        self.fail()

    def test_landing_site(self):
        self.fail()

    def test_cancelled_at(self):
        self.fail()

    def test_cancel_reason(self):
        self.fail()

    def test_total_price_usd(self):
        self.fail()

    def test_checkout_token(self):
        self.fail()

    def test_reference(self):
        self.fail()

    def test_user_id(self):
        self.fail()

    def test_location_id(self):
        self.fail()

    def test_source_identifier(self):
        self.fail()

    def test_source_url(self):
        self.fail()

    def test_processed_at(self):
        self.fail()

    def test_device_id(self):
        self.fail()

    def test_browser_ip(self):
        self.fail()

    def test_landing_site_ref(self):
        self.fail()

    def test_order_number(self):
        self.fail()

    def test_discount_codes(self):
        self.fail()

    def test_note_attributes(self):
        self.fail()

    def test_payment_gateway_names(self):
        self.fail()

    def test_processing_method(self):
        self.fail()

    def test_checkout_id(self):
        self.fail()

    def test_source_name(self):
        self.fail()

    def test_fulfillment_status(self):
        self.fail()

    def test_tax_lines(self):
        self.fail()

    def test_tags(self):
        self.fail()
