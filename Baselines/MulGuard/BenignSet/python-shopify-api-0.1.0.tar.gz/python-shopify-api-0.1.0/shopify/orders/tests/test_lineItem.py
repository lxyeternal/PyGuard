from unittest import TestCase


class TestLineItem(TestCase):
    def test_variant_id(self):
        self.fail()

    def test_title(self):
        self.fail()

    def test_quantity(self):
        self.fail()

    def test_price(self):
        self.fail()

    def test_grams(self):
        self.fail()

    def test_sku(self):
        self.fail()

    def test_variant_title(self):
        self.fail()

    def test_vendor(self):
        self.fail()

    def test_fulfillment_service(self):
        self.fail()

    def test_product_id(self):
        self.fail()

    def test_requires_shipping(self):
        self.fail()

    def test_taxable(self):
        self.fail()

    def test_gift_card(self):
        self.fail()

    def test_name(self):
        self.fail()

    def test_variant_inventory_management(self):
        self.fail()

    def test_properties(self):
        self.fail()

    def test_product_exists(self):
        self.fail()

    def test_fulfillable_quantity(self):
        self.fail()

    def test_total_discount(self):
        self.fail()

    def test_fulfillment_status(self):
        self.fail()

    def test_tax_lines(self):
        self.fail()

    def test_origin_location(self):
        self.fail()

    def test_destination_location(self):
        self.fail()
