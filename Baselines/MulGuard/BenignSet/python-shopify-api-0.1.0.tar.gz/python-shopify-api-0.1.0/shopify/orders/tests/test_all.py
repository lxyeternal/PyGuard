import unittest

from test_address import TestAddress
from test_clientDetail import TestClientDetail
from test_customer import TestCustomer
# from test_lineItem import TestLineItem
# #from test_order import TestOrder
from test_paymentDetail import TestPaymentDetail
from test_shippingLine import TestShippingLine
from test_taxLine import TestTaxLine


if __name__ == '__main__':
    unittest.main()
