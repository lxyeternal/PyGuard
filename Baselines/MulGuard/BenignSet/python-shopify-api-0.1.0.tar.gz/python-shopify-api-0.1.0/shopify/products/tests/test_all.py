import unittest

from test_image import TestImage
from test_product import TestProduct
from test_variant import TestVariant
from test_option import TestOption


if __name__ == '__main__':
    unittest.main()
