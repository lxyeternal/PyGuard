def totext():
    print("to text")
