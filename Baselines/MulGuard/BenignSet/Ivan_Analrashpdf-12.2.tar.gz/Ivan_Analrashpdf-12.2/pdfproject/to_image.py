def toimg():
    print("to boobs")
