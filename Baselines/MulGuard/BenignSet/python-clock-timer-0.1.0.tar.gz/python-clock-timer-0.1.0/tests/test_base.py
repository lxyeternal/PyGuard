from clock_timer.base import NAME


def test_base():
    assert NAME == "clock_timer"
