"""Entry point for clock_timer."""

from .cli import main  # pragma: no cover

if __name__ == "__main__":  # pragma: no cover
    main()
