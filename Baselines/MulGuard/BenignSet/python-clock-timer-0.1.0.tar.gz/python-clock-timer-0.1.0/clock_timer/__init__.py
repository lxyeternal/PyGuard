from clock_timer.entities.clock_logger import ClockLogger
