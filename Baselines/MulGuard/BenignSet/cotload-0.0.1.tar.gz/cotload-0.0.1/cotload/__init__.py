from Unit import Unit

def create_unit(name):
    unit = Unit(name)
    return unit