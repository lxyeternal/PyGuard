#### pa_utils

A collection of utilities to do Price Action Analysis on Share Market data