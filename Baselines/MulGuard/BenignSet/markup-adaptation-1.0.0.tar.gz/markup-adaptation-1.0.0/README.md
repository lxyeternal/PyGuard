markup-adaptation
=================

A framework for annotating SVGs with an adaptation schema that can be used to define (graphical) templates. Please bear with us while we prepare more detailed documentation.

Installation
------------

1. Install using `pip`:
  ```shell
  pip install markup-adaptation
  ```
