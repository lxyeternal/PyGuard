from setuptools import setup
import os

setup(
    name="py_matching_pattern",
    version="0.0.1",
    packages=["py_matching_pattern"],
    url='https://github.com/diogok/py_matching_pattern',
)
