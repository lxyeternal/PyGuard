# pyebas
  python package for an easy-access to open-source air pollutant data from EBAS database via FTP links.
