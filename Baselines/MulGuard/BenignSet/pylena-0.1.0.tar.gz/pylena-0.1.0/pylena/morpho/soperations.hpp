#pragma once

#include <mln/core/image/ndimage.hpp>

#include <mln/morpho/erosion.hpp>

#include "se.hpp"

namespace pln::morpho
{
  void def_operations(pybind11::module& m);
} // namespace pln::morpho