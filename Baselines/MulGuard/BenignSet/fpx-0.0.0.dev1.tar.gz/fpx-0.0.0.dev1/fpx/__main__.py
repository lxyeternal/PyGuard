from fpx.app import run_app

run_app()
