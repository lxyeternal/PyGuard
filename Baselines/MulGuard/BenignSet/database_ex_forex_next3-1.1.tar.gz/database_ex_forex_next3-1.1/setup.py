from setuptools import setup

setup (name='database_ex_forex_next3' ,
       version = '1.1' ,
       description = 'database_ex_forex_next3' ,
       author = 'omid' ,
       packages =['database_ex_forex_next3'] ,
       zip_safe = False
       
       )