# DRAFT Usage
```
from hukudo.gitlab import gl
gl.registry.get_all_tags()
```


# Installation
```
pip install hukudo
```

DRAFT For Gitlab Tools
```
pip install hukudo[gitlab]
```


# Development
Create a virtualenv and install in dev mode
```
make initial
make docs
```
