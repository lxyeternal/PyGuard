SpEndPoint
##########

Installation
------------

.. code-block:: shell

   pip install spendpoint

or

.. code-block:: shell

   pip install --index-url https://pip:glpat-m8mNfhxZAUnWvy7rLS1x@git.rys.one/api/v4/projects/262/packages/pypi/simple --no-deps spendpoint
