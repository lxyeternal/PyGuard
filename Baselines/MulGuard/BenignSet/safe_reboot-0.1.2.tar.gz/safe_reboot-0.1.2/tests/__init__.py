"""Unit test package for safe_reboot."""
