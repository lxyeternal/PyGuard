=======
History
=======

0.1.0 (2020-03-03)
------------------

* First release on PyPI.
