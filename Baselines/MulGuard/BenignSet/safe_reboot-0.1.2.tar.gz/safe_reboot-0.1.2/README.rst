===========
safe-reboot
===========


.. image:: https://img.shields.io/pypi/v/safe_reboot.svg
        :target: https://pypi.python.org/pypi/safe_reboot

.. image:: https://img.shields.io/travis/swallat/safe_reboot.svg
        :target: https://travis-ci.com/swallat/safe_reboot

.. image:: https://readthedocs.org/projects/safe-reboot/badge/?version=latest
        :target: https://safe-reboot.readthedocs.io/en/latest/?badge=latest
        :alt: Documentation Status




Wrapper around reboot. Checks if other users are logged in or have active screen or tmux sessions.


* Free software: Apache Software License 2.0
* Documentation: https://safe-reboot.readthedocs.io.


Features
--------

* TODO

Credits
-------

This package was created with Cookiecutter_ and the `audreyr/cookiecutter-pypackage`_ project template.

.. _Cookiecutter: https://github.com/audreyr/cookiecutter
.. _`audreyr/cookiecutter-pypackage`: https://github.com/audreyr/cookiecutter-pypackage
