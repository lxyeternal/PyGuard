safe_reboot
===========

.. toctree::
   :maxdepth: 4

   safe_reboot
