safe\_reboot package
====================

Submodules
----------

safe\_reboot.safe\_reboot module
--------------------------------

.. automodule:: safe_reboot.safe_reboot
   :members:
   :undoc-members:
   :show-inheritance:


Module contents
---------------

.. automodule:: safe_reboot
   :members:
   :undoc-members:
   :show-inheritance:
