=====
Usage
=====

To use safe-reboot in a project::

    import safe_reboot
