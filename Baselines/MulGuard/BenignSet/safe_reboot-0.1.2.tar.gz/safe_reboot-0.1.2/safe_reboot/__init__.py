"""Top-level package for safe-reboot."""

__author__ = """Sebastian Wallat"""
__email__ = 'sebastian@wallat.io'
__version__ = '0.1.2'
