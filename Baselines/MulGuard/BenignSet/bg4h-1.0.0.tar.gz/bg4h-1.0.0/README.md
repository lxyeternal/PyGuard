# BG4h

bee gees for Humans Table Definitions

## ChangeLog
### v1.0.0 - 18.12.2023

- ts/net lib converted to python
- spellfix
- added todos for unknown / unclear values
