# markerbci-python
Handling marker devices for brain-computer interfaces.  

 - buttonbox module  
 This module was originally developed by Wilbert van Ham, Radboud University Nijmegen.
 You can find original source from [here](https://github.com/wilberth/RuSocSci)  
