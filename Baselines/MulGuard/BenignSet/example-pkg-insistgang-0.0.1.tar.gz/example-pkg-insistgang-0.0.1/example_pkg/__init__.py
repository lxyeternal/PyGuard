

def plus(a,b):
    return a+b



def mins(a,b):
    return a-b


