# Code samples for the Revit Batch Processor
This repository contains code samples for the [Revit Batch Processor](https://github.com/bvn-architecture/RevitBatchProcessor)

A more detailed description of the varies modules, can be found in the online [docs](https://jchristel.github.io/SampleCodeRevitBatchProcessor/) and in the [wiki](https://github.com/jchristel/SampleCodeRevitBatchProcessor/wiki).
