def printFromAPI():
    print('hello')