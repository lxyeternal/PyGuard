#Apkparser
#Author:
	leiserfg
#LIC: 
	DWRFYW
