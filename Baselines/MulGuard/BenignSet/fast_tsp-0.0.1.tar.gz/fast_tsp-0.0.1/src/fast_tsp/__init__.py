from ._core import __doc__, __version__, find_tour
