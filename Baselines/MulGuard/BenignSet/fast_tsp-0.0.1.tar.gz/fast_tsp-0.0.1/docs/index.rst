fast_tsp Documentation
============================

Contents:

.. toctree::
   :maxdepth: 2

   fast_tsp
