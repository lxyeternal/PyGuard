# Changelog

All notable changes to this project will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.0.0/).

## 1.0.3 (April 4th, 2021)

### Added
* Support for characters.

### Changed
* HTTP2 enabled (async mode only).

## 1.0.2 (March 8th, 2021)

### Added
* Support for mangas.

### Changed
* Some bug fixes.

## 1.0.1 (March 8th, 2021)

### Changed
* Bug fixes.

## 1.0.0 (March 8th, 2021)

* First release