def test():
	print("test")