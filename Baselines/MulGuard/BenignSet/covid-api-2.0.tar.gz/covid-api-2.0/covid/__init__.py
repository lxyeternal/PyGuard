from pycovid.Base import *

__version__ = "1.0.0"
__author__ = "@v1s1t0r999 [Idea: @Aashs]"