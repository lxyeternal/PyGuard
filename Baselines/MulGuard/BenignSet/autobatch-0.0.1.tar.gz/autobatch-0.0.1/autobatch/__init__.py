from .autobatch import AutoBatch

name = 'autobatch'
__version__ = '0.1.0' 