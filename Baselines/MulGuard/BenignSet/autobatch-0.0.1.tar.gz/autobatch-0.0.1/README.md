This is a simple tool to convert your synchronous call interface to a batch-handled asynchronous call, which is useful if you deploy a deep learning model and provide restful API.

这是一个简单的工具将你的同步调用接口转换为按批次处理的异步调用，这是有用的如果你部署了一个深度学习模型并提供了restful API。

