from pygrass.interval.base import IntervalBase
from pygrass.interval.formats import IntervalFormatBase, IntervalFile, BamFile