import setuptools

setuptools.setup(
    name="scrapzon",
    version="0.0.1",
    author="sachin Sankar",
    author_email="sachinpannadi@gmail.com",
    python_requires='>=3.6, <4',
    install_requires=['requests','lxml'],
)
