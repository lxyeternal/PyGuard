"""从python发布工具中导入setup函数"""
from distutils.core import setup

setup(
    name        ='ershixiongwhois',
    version     ='1.0.0',
    py_modules  =['ershixiongwhois'],
    author      ='hfpython',
    author_email='wqiq_77@163.com',
    url         ='http://www.baidu.com',
    description ='A simple printer of nested lists',
    )
