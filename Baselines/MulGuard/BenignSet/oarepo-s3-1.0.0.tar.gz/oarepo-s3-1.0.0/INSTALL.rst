Installation
============

oarepo-s3 is on PyPI so all you need is:

.. code-block:: console

   $ pip install oarepo-s3
