from .util import cmd_exists
from .examples import squareKnotPres
from .acme import makeACMEinput, runACMEinput
# import typing as T
# import typing_extensions as TE