

def encode():
    pass


def decode():
    pass
