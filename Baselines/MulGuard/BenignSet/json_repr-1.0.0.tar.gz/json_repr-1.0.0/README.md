# json-repr
 Pretty print JSON like data structures with a "repr(...)" fallback, e.g. for MongoDB types
