# AI-Maze

This program is for a school project in AI. The purpose is to have the agent traverse the left side of the maze until it finds the entrance. Once found, it will make a node and start its path inside the maze until it finds the exit. Once the exit is found, the path traveled is printed.

- Code written by Jody Bailey
