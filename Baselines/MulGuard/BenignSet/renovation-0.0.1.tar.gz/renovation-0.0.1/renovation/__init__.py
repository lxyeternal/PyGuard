"""
Draw floor plans needed to renovate an apartment.

Author: Nikolay Lysenko
"""

