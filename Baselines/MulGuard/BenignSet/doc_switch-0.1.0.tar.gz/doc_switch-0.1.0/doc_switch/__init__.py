"""Top-level package for DocSwitch."""

__author__ = """Cutewarriorlover"""
__email__ = 'cutewarriorlover@gmail.com'
__version__ = '0.1.0'
