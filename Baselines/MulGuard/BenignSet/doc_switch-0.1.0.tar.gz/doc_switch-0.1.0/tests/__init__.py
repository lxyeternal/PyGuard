"""Unit test package for doc_switch."""
