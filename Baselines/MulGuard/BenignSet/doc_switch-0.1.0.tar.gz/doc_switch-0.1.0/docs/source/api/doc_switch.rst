doc\_switch package
===================

Submodules
----------

doc\_switch.cli module
----------------------

.. automodule:: doc_switch.cli
   :members:
   :undoc-members:
   :show-inheritance:

doc\_switch.doc\_switch module
------------------------------

.. automodule:: doc_switch.doc_switch
   :members:
   :undoc-members:
   :show-inheritance:

Module contents
---------------

.. automodule:: doc_switch
   :members:
   :undoc-members:
   :show-inheritance:
