# DocSwitch

![PyPI Badge](https://img.shields.io/pypi/v/doc_switch.svg%0A%20%20%20%20%20:target:%20https://pypi.python.org/pypi/doc_switch)
![Travis CI Badge](https://img.shields.io/travis/cutewarriorlover/doc_switch.svg%0A%20%20%20%20%20:target:%20https://travis-ci.com/cutewarriorlover/doc_switch)
![ReadTheDocs Badge](https://readthedocs.org/projects/doc-switch/badge/?version=latest%0A%20%20%20%20%20:target:%20https://doc-switch.readthedocs.io/en/latest/?version=latest%0A%20%20%20%20%20:alt:%20Documentation%20Status)

![PyUp Badge](https://pyup.io/repos/github/cutewarriorlover/doc_switch/shield.svg%0A%20%20:target:%20https://pyup.io/repos/github/cutewarriorlover/doc_switch/%0A%20%20:alt:%20Updates)

DocSwitch gives you the freedom to write your Python documentation in any format you want, switching between them effortlessly.

-   Free software: MIT license
-   Documentation: <https://doc-switch.readthedocs.io>.
