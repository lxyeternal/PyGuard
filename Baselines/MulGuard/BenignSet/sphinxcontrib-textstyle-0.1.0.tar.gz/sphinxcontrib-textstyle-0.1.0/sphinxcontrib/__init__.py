# -*- coding: utf-8 -*-
"""
    sphinxcontrib-rubytag
    ~~~~~~~~~~~~~~~~~~~~~~~~~

    :copyright: Copyright 2013 by the WAKAYAMA Shirou
    :license: BSD, see LICENSE for details.
"""

__import__('pkg_resources').declare_namespace(__name__)
