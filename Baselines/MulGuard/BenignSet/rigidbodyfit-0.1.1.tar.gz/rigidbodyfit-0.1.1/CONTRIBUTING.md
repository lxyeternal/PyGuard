# Contributing

File an issue at https://gitlab.com/cblau/rigidbodyfit/-/issues
