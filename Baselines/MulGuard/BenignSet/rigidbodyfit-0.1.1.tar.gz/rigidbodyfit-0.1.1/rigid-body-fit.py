#!/usr/bin/python3
import rigidbodyfit.runner

rigidbodyfit.runner.run()
