"""Receive and/or send commands to radio controlled sockets (model GT-FSI-11) from brand 'Globaltronics'."""
from .gtsocket import *