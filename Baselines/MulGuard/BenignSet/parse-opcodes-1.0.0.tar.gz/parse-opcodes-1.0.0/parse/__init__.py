#__init__.py

#Version of the parse-opcodes package
__version__ = "1.0.0"