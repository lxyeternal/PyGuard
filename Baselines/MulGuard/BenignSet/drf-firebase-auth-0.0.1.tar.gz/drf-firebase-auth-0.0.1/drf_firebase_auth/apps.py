from django.apps import AppConfig


class CoreConfig(AppConfig):
    name = 'drf_firebase_auth'
