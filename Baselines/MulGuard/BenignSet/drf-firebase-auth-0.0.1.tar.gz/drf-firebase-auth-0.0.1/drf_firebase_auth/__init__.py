# -*- coding: utf-8 -*-

__title__ = 'drf-firebase-auth'
__version__ = '0.0.1'
__author__ = 'Gary Burgmann'
__license__ = 'MIT'
__copyright__ = 'Copyright 2019 Gary Burgmann'

# Version synonym
VERSION = __version__
