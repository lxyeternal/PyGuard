from Add3 import *	

adder = Add3(3, "add a little more")
print(adder)
