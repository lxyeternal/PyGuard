from .GaussionDistribution import Gaussian
from .BinomialDistribution import Binomial
