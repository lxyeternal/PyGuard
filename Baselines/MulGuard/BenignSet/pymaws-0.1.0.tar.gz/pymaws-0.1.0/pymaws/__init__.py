#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Thu Mar 14 17:01:44 2019

@author: shlomi
"""

name = "pymaws"