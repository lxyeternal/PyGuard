Utility library
