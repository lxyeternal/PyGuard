# parquetranger

[![Documentation Status](https://readthedocs.org/projects/parquetranger/badge/?version=latest)](https://parquetranger.readthedocs.io/en/latest)
[![codeclimate](https://img.shields.io/codeclimate/maintainability/endremborza/parquetranger.svg)](https://codeclimate.com/github/endremborza/parquetranger)
[![codecov](https://img.shields.io/codecov/c/github/endremborza/parquetranger)](https://codecov.io/gh/endremborza/parquetranger)
[![pypi](https://img.shields.io/pypi/v/parquetranger.svg)](https://pypi.org/project/parquetranger/)

add keywords to pyproject.toml
