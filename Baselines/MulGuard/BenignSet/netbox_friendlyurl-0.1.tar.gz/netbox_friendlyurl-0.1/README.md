# netbox_friendlyurl
Create user-friendly url's for standard netbox/model/type/pk/ format
