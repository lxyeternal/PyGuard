A long description and overview of your project. The contents of this file
will be added to the project's documentation.