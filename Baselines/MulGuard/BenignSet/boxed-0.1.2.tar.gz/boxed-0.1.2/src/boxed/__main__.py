import boxed.simplebox.__main__
