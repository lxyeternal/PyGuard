def resolveIt(votes):
    results = {
        'yes': 0,
        'no': 0,
        'abstain': 0,
        'liquid': 0
    }
    return results