# Yes, magic methods suck, but this makes it easier to use classes
def load_qtimer_plugin(url = None, token = None):
	return FreshBooksPlugin(url, token)

def FreshBooksPlugin(PluginPrototype):
	# TODO
	pass
