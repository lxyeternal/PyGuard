"""
CustomTkinter Spinbox
Author : Sheikh Rashdan
Version : 1.0
"""

__version__ : '1.0'

from .ctkspinbox import CTkSpinbox