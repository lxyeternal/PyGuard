class Error(Exception):
    pass


class RegistrationError(Error):
    pass
