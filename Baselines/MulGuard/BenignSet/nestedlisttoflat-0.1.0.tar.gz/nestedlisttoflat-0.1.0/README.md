**#Developer : Avik Das**

*## Convert nested list to one list* 
*Return the exception details as well *
