# SDVX Offical Ranking

[The official site](https://p.eagate.573.jp/game/sdvx/iv/p/ranking/index.html) of SDVX(Sound Voltex) provides first-100 scores of all tunes. A lot of statistics and analysis works can be done by those data. This project helps to crawl those data.

## Usage

```bash
pip install rasis
```
