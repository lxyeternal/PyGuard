printobject
===========

.. image:: https://badge.fury.io/py/printobject.png
        :target: https://badge.fury.io/py/printobject

.. image:: https://travis-ci.org/numerodix/printobject.png?branch=master
    :target: https://travis-ci.org/numerodix/printobject

.. image:: https://pypip.in/license/printobject/badge.png
        :target: https://pypi.python.org/pypi/printobject/


Python version support: CPython 2.6, 2.7, 3.2, 3.3 and PyPy.


Installation
------------

.. code:: bash

    $ pip install printobject
