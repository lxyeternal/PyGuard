from setuptools import setup

setup(name='dnms_probability',
      version='0.10',
      description='Gaussian and Binomial distributions',
      packages=['dnms_probability'],
      author='James Oyebade',
      author_email='jamesthepink@gmail.com',
      zip_safe=False)
