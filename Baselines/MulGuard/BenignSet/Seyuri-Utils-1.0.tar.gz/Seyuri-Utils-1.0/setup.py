from setuptools import setup

setup(
    name='Seyuri-Utils',
    version='1.0',
    description='This package contains some useful functions',
    packages=['seyuri_utils'],
    install_requires=[
        'colorama'
    ]
)