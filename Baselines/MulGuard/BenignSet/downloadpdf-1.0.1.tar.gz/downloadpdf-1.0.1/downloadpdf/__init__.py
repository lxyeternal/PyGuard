#!/usr/bin/env python3
from downloadpdf.scrap import scrapHREF
from downloadpdf.download import downloadPDF
