************************************
A tile that shows Gists from GitHub.
************************************

.. only:: html

  Contents
  ========

.. toctree::
   :maxdepth: 2

   configuration


.. only:: html

  Indices and tables
  ==================

  * :ref:`genindex`
  * :ref:`modindex`
  * :ref:`search`
