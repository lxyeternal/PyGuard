# -*- coding: utf-8 -*-
"""Configuration options for collective.tiles.githubgist."""

PROFILE_ID = u'profile-collective.tiles.githubgist'
INSTALL_PROFILE = '{0}:default'.format(PROFILE_ID)
UNINSTALL_PROFILE = '{0}:uninstall'.format(PROFILE_ID)
PROJECT_NAME = 'collective.tiles.githubgist'
