# -*- coding: utf-8 -*-
"""Module for collective.tiles.githubgist related tests."""
