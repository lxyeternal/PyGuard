# Fortinet API
A simple lib for handle API calls to Fortinet

## Install
```bash
pip install fortinetapi
```

## Usage
[Here](example) we have some examples of using API Token or User and Passowrd login 
