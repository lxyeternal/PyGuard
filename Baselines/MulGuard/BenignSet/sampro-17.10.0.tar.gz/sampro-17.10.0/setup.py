from distutils.core import setup

setup(name='sampro',
      version='17.10.0',
      description='sampling profiler',
      license="MIT",
      author='Kurt Rose',
      author_email='kurt@kurtrose.com',
      url='https://github.com/kurtbrose/sampro',
      packages=['sampro'],
     )
