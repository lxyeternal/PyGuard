from setuptools import setup

setup(name='scopetest_1',
      version='0.1',
      description='The funniest joke in the world',
      url='http://github.com/storborg/funniest',
      author='Flying Circus',
      author_email='flyingcircus@example.com',
      license='MIT',
      packages=['scopetest_1'],
      zip_safe=False)
