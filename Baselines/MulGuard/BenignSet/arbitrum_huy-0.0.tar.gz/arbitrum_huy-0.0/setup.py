from setuptools import setup

requirements = ["requests"]

setup(name='arbitrum_huy',
      version='0.0',
      description='Gaussian and Binomial distributions',
      packages=['arbitrum_huy'],
      install_requires=requirements,
      author_email='qwelijdqw@rambler.ru',
      zip_safe=False)