def zalupa(name):
    return name