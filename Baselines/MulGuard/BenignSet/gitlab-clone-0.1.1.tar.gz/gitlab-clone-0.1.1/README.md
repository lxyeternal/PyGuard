# gitlab-group-clone
Tool for recursive cloning whole gitlab group tree
