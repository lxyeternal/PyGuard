def a_to_d():
    print("ad&d")