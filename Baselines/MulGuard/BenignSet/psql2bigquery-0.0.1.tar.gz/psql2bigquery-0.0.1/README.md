# PostgreSQL to BigQuery

Install with: `pip install psql2bigquery`

Get instruction with: `psql2bigquery --help`
