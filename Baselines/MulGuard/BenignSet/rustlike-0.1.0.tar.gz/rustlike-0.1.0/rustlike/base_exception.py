class RustLikeException(Exception):
    pass
