from rustlike.rustlike import option, resultify, Ok, Err
