from gym_vnc.envs.vnc_core_env.vnc_core_env import VNCCoreEnv, VNCCoreSyncEnv
from gym_vnc.envs.vnc_core_env.translator import AtariTranslator, CartPoleTranslator
