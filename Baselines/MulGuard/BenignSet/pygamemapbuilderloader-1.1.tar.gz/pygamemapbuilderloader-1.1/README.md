Check out the github for anyting relating to the project

https://github.com/AustinRheyne/MapBuilder