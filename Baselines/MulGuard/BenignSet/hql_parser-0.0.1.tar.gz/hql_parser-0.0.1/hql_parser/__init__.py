name = "hql_parser"
__version__ = "0.0.1"

from .hql_parser import DDL_Handler
  
