"""
Alias for array type
====================
"""

import numpy.typing


ArrayLike = numpy.typing.ArrayLike
