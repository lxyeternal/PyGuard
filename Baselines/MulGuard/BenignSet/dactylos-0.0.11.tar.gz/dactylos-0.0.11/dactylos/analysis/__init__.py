"""
Analysis tools for data taken with dactylos.CaenN6725 digitizer software

"""


from .file_inspector import inspect_file
