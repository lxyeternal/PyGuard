from mynameiscandy.candy import Candylady
# หรืออาจ import * ก็ได้ ถ้าต้องการเรียกทุก class
