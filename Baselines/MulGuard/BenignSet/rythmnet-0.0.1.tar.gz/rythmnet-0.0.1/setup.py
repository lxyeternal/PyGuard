from setuptools import setup, find_packages

setup(
    name='rythmnet', # Replace with your package name
    version='0.0.1', # Replace with your package version
    description='Rythmnet_implementation',
    author='ErnisMeshi',
    author_email='ernis.meshi@student.uni-pr.edu',
    packages=find_packages(),
    install_requires=[
        # Add any dependencies that your package requires here
    ],
    classifiers=[
        'Programming Language :: Python :: 3.10',
    ],
)
