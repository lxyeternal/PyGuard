https://blog.csdn.net/weixin_44592427/article/details/115002569

python setup.py sdist bdist_wheel


twine upload dist/*