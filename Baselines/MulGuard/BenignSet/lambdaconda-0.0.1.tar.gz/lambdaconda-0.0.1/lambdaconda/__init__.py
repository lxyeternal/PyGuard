name = 'lambdaconda'

def call(event, context):
    return "Hello from lambdaconda"