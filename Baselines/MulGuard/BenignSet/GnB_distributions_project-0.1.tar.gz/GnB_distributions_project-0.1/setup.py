from setuptools import setup

setup(name='GnB_distributions_project',
      version='0.1',
      description='Gaussian and binomial distributions',
      packages=['GnB_distributions_project'],
      author = 'Desmond Webb',
      author_email = 'datasciencedjw@gmail.com',
      zip_safe=False)
