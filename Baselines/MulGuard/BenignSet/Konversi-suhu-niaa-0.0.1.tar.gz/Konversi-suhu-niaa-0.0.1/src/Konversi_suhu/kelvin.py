nilai_konversi=273
class Kelvin:
    def __init__ (self,derajat):
        print('Selamat Datang di konversi Kelvin')
        self.derajat = derajat

    def hitung_konv(self):
        return self.derajat+ 273
    
  
def menghitung_konversi_celcius_to_kelvin():
    return "ini fungsi menghitung konversi Celcius ke Kelvin"