class Fahrenheit:
    def __init__ (self,derajat):
        print('Selamat Datang di konversi Fahrenheit')
        self.derajat = derajat

    def hitung_konv(self):
        return (self.derajat *1.8)+32
    
  
def menghitung_konversi_celcius_to_fahrenheit():
    return "ini fungsi menghitung konversi Celcius ke Fahrenheit"