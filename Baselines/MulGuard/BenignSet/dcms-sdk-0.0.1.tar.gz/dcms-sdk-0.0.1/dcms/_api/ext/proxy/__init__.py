
from .proxy_pool_class import ProxyPool
from .scrapy_middlewares import ProxyPoolMiddleWare as ScrapyProxyPoolMiddleWare

proxy_pool = ProxyPool()

# __all__ = ['proxy_pool', 'ScrapyProxyPoolMiddleWare']
