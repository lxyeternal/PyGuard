
simple.py        Trivial Python module
test_simple.py   Test suite for trivial Python module

