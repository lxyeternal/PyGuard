"""Sancho: Yet another unit testing framework for Python.
"""

# Mark this directory as a package

# created 2002/01/29, AMK

__revision__ = "$Id: __init__.py 20227 2003-01-16 21:26:56Z akuchlin $"


