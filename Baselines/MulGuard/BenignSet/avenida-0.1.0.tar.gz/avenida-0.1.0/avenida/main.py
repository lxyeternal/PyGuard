hola


def main():

    print("Hola")


if __name__ == "__main__":
    main()
