# Not On PyPi

This is a reserved package name to prevent [dependency confusion / substitution attack](https://redhuntlabs.com/blog/dependency-confusion-attack-what-why-and-how.html). If installed, will immediately raise an error indicating that the wrong PyPi repository was used.

If someone would like to use this package name, I would be happy to discuss handoff. Please contact me through a Github issue on [KyleKing/not-on-pypi](https://github.com/KyleKing/not-on-pypi) or if I don't respond, you can try my `gmail` account `dev.act.kyle`
