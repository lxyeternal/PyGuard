"""Calculate static code quality metrics."""

from sourcery_analytics.analysis import analyze_methods, analyze
from sourcery_analytics.extractors import extract_methods, extract
