"""Elements of ``sourcery-analysis`` implemented as a CLI."""
