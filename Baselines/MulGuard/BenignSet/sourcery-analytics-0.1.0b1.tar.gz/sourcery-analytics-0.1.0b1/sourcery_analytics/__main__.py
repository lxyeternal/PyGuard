"""Main entrypoint for sourcery-analytics as a command line interface and module script."""
from sourcery_analytics.main import app

app(prog_name="sourcery-analytics")
