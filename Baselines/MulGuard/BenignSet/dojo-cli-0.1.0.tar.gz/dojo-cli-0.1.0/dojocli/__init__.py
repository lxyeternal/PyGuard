"""Top-level package for dojo-cli."""

__author__ = """Robnet Kerns"""
__email__ = "robnet@jataware.com"
__version__ = "0.1.0"
