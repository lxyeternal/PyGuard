# FaceAnalyzer
A python library for face detection and features extraction based on mediapipe library

## Introduction
FaceAnalyzer is a library based on mediapipe library and is provided under MIT Licence. It provides an object orientation tool to play around with faces.
It can be used to :
1 - Extract faces from an image
2 - Measure the face position and orientation
3 - Measure eyes openings
4 - Detect blinks
5 - Extract the face from an image (useful for face learning applications)
6 - Compute face triangulation (builds triangular surfaces that can be used to build 3D models of the face)
7 - Copy a face from an image to another.

## Requirements
This library requires :
1 - mediapipe (used for facial landmarks extraction)
2 - opencv used for drawing and image morphing
3 - scipy used for efficient delaulay triangulation
4 - numpy, as any thing that uses math


## How to install
Just install from pipy
```bash
pip install FaceAnalyzer
```

## How to use

```python
# Import the two main classes FaceAnalyzer and Face 
from FaceAnalyzer import FaceAnalyzer, Face

fa = FaceAnalyzer()
# ... Recover an image in RGB format as numpy array (you can use pillow opencv but if you use opencv make sure you change the color space from BGR to RGB)
# Now process the image
fa.process(image)

# Now you can find faces in fa.faces which is a list of instances of object Face
if fa.nb_faces>0:
    print(f"{fa.nb_faces} Faces found")
    # We can get the landmarks in numpy format NX3 where N is the number of the landmarks and 3 is x,y,z coordinates 
    print(fa.faces[0].npLandmarks)
```