"""Core package module.
"""


VERSION: tuple = (1, 0, 7)
__version__: str = ".".join(map(str, VERSION))
