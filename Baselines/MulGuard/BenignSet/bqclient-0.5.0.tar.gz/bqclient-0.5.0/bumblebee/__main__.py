from .app import main

main()
