#!/usr/bin/python
# -*- coding: utf-8 -*-

from . import structures

from .structures import Decimal
