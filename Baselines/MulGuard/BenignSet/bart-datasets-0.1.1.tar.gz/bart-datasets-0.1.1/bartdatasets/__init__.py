from bartdatasets.utils import logger

# SET LOGGER
logger.configure_logger()
