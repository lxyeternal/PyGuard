.. include:: ../README.rst

.. toctree::
   :maxdepth: 3
   :titlesonly:

   modules
