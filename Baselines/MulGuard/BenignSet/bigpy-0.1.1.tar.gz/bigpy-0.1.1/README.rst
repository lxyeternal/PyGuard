BIG Python Utilities
====================

A collection of various useful Python utilities.
