class BaseEvent:
    error_code=None