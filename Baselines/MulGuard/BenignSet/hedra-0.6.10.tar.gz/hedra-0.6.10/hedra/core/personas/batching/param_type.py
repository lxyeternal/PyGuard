from enum import Enum

class ParamType(Enum):
    FLOAT='FLOAT'
    INTEGER='INTEGER'