from enum import Enum


class PartitionMethod:
    JOB_PER_CORE='JOB_PER_CORE'
    BATCHES='BATCHES'