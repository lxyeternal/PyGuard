from .transitions import (
    setup_to_validate_transition,
    setup_to_optimize_transition,
    setup_to_execute_transition,
    setup_to_checkpoint_transition,
    setup_to_wait_transition
)