from .transitions import (
    submit_to_setup_transition,
    submit_to_optimize_transition,
    submit_to_execute_transition,
    submit_to_checkpoint_transition,
    submit_to_submit_transition,
    submit_to_complete_transition,
    submit_to_wait_transition
)