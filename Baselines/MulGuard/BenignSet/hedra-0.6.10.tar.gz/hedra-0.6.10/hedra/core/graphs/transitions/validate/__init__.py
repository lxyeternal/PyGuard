from .transitions import (
    validate_to_setup_transition,
    validate_to_wait_transition
)