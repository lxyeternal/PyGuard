class Plugin:
    
    def __init__(self, *args, **kwargs) -> None:
        pass