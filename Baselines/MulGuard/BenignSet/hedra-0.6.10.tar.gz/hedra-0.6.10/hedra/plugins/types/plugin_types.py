from enum import Enum


class PluginType(Enum):
    OPTIMIZER='OPTIMIZER'
    PERSONA='PERSONA'
    ENGINE='ENGINE'
    REPORTER='REPORTER'