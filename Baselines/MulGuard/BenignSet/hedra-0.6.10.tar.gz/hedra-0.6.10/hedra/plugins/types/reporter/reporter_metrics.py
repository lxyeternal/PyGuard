
from hedra.reporting.metric import MetricsSet


class Metrics(MetricsSet):
    pass