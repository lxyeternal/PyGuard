from hedra.core.graphs.stages import (
    Analyze
)


class AnalyzeStage(Analyze):
    pass