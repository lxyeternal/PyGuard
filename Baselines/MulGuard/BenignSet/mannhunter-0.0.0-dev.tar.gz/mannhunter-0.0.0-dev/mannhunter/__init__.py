"""A memory limiting tool for Supervisor"""

from __future__ import absolute_import, unicode_literals

__version__ = '0.0.0-dev'
__author__ = 'Sam Clements <sam.clements@datasift.com>'
