=======
History
=======

0.1.0 (2019-08-24)
------------------

* First release on PyPI.
