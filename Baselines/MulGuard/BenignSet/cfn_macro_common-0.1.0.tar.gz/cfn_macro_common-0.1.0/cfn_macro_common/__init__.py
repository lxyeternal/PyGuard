# -*- coding: utf-8 -*-

"""Top-level package for CFN Macro Common."""

__author__ = """John Mille"""
__email__ = 'JohnPreston@users.noreply.github.com'
__version__ = '0.1.0'
