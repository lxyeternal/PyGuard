=====
Usage
=====

To use CFN Macro Common in a project::

    import cfn_macro_common
