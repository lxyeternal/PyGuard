def hello() -> str:
    return "Hello, world!"
