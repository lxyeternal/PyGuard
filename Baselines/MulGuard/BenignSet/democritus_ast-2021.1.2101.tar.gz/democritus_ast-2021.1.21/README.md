# Democritus Ast

[![PyPI](https://img.shields.io/pypi/v/democritus-ast.svg)](https://pypi.python.org/pypi/democritus-ast)
[![Build Status](https://travis-ci.com/democritus-project/democritus-ast.svg?branch=master)](https://travis-ci.com/democritus-project/democritus-ast)
[![codecov](https://codecov.io/gh/democritus-project/democritus-ast/branch/master/graph/badge.svg?token=V0WOIXRGMM)](https://codecov.io/gh/democritus-project/democritus-ast)

Democritus functions<sup>[1]</sup> for working with Python ASTs.

[1] Democritus functions are <i>simple, effective, modular, well-tested, and well-documented</i> Python functions.

## Usage

Coming soon...

## Credits

This package was created with [Cookiecutter](https://github.com/audreyr/cookiecutter) and Floyd Hightower's [Python project template](https://github.com/fhightower-templates/python-project-template).
