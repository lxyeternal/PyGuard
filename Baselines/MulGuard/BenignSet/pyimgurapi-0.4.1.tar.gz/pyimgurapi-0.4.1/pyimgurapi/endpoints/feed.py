from .base_endpoint import BaseEndpoint


class Feed(BaseEndpoint):
    pass
