from .base_endpoint import BaseEndpoint


class Gallery(BaseEndpoint):
    pass
