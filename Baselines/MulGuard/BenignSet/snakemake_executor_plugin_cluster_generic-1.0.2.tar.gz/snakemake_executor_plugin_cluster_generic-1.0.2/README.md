# snakemake-executor-plugin-cluster-generic

A generic Snakemake executor plugin for submission of jobs to cluster systems that provide a submission command that accepts the path to a job script (like PBS, LSF, SGE, ...).