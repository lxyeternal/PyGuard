******
hidabc
******

Collection of abstract protocols to interact with HID devices.
