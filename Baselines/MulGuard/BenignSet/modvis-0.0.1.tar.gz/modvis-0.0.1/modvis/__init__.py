"""Top-level package for ModVis."""

__author__ = """Pin Shuai"""
__email__ = 'pinshuai.phd@gmail.com'
__version__ = '0.0.1'
