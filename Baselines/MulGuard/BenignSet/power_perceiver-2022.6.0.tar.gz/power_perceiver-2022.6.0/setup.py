"""The bulk of the config is in pyproject.toml"""

from setuptools import setup

setup()
