from power_perceiver.production.model import FullModel


def test_initialize_model():
    FullModel()


# Test passing batch through model
def test_pass_batch_through_model():
    FullModel()


# Test getting a point prediction out of the model
def test_get_point_prediction():
    FullModel()
