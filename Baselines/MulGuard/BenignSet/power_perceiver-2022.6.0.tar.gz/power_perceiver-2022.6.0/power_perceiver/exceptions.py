class NoPVSystemsInSlice(Exception):
    pass
