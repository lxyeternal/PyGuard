__name__ = "chanim"


## Importing all of manim so that you only worry about chanimlib.
from manim import *

## chanimlib modules.
from .chem_objects import *
from .compounds import *
