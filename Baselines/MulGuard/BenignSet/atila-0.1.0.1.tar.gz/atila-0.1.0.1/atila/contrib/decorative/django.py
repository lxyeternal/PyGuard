#-----------------------------------------------------------
# This module directory is deprecated 
# USE atila.contrib.services
#-----------------------------------------------------------

from ..services.django import auth
