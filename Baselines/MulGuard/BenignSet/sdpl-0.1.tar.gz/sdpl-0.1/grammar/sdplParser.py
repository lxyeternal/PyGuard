# Generated from sdpl.g4 by ANTLR 4.5.1
# encoding: utf-8
from antlr4 import *
from io import StringIO

def serializedATN():
    with StringIO() as buf:
        buf.write("\3\u0430\ud6d1\u8206\uad2d\u4417\uaef1\u8d80\uaadd\3\62")
        buf.write("\u0117\4\2\t\2\4\3\t\3\4\4\t\4\4\5\t\5\4\6\t\6\4\7\t\7")
        buf.write("\4\b\t\b\4\t\t\t\4\n\t\n\4\13\t\13\4\f\t\f\4\r\t\r\4\16")
        buf.write("\t\16\4\17\t\17\4\20\t\20\4\21\t\21\4\22\t\22\4\23\t\23")
        buf.write("\4\24\t\24\4\25\t\25\4\26\t\26\4\27\t\27\3\2\3\2\3\2\3")
        buf.write("\2\3\2\3\2\3\2\3\2\3\2\3\2\3\2\6\2:\n\2\r\2\16\2;\3\3")
        buf.write("\3\3\3\3\3\3\5\3B\n\3\3\3\3\3\3\4\3\4\3\4\3\4\3\4\3\4")
        buf.write("\3\4\3\4\3\4\3\4\3\4\3\4\3\4\3\4\3\4\3\4\3\4\3\4\3\4\3")
        buf.write("\4\3\4\3\4\3\4\5\4]\n\4\3\5\3\5\3\5\3\5\3\5\3\5\3\5\3")
        buf.write("\5\3\5\3\6\3\6\3\6\7\6k\n\6\f\6\16\6n\13\6\3\7\5\7q\n")
        buf.write("\7\3\7\3\7\3\7\3\7\3\7\5\7x\n\7\3\b\3\b\3\b\3\b\3\b\3")
        buf.write("\t\3\t\3\t\3\t\3\t\3\t\3\t\3\t\3\t\3\n\3\n\3\n\3\n\3\n")
        buf.write("\3\n\3\n\3\13\3\13\3\13\3\13\3\13\3\13\6\13\u0095\n\13")
        buf.write("\r\13\16\13\u0096\3\13\3\13\3\13\3\13\3\13\3\13\3\13\3")
        buf.write("\13\3\f\3\f\3\f\3\f\3\r\3\r\3\r\3\r\7\r\u00a9\n\r\f\r")
        buf.write("\16\r\u00ac\13\r\3\r\3\r\3\16\3\16\3\16\3\16\3\17\3\17")
        buf.write("\3\17\3\17\3\17\3\17\3\17\3\17\3\20\3\20\3\20\3\20\3\20")
        buf.write("\3\20\5\20\u00c2\n\20\3\20\3\20\3\20\3\20\3\20\3\20\7")
        buf.write("\20\u00ca\n\20\f\20\16\20\u00cd\13\20\3\21\3\21\3\21\3")
        buf.write("\21\3\21\3\21\3\21\3\21\5\21\u00d7\n\21\3\22\3\22\3\22")
        buf.write("\5\22\u00dc\n\22\3\22\3\22\5\22\u00e0\n\22\3\22\5\22\u00e3")
        buf.write("\n\22\3\23\3\23\3\23\3\23\3\23\3\23\3\23\3\23\7\23\u00ed")
        buf.write("\n\23\f\23\16\23\u00f0\13\23\3\23\3\23\3\24\3\24\3\24")
        buf.write("\3\24\3\24\3\24\3\24\3\24\7\24\u00fc\n\24\f\24\16\24\u00ff")
        buf.write("\13\24\3\24\3\24\3\25\3\25\7\25\u0105\n\25\f\25\16\25")
        buf.write("\u0108\13\25\3\25\3\25\3\26\3\26\7\26\u010e\n\26\f\26")
        buf.write("\16\26\u0111\13\26\3\26\3\26\3\27\3\27\3\27\3\u010f\3")
        buf.write("\36\30\2\4\6\b\n\f\16\20\22\24\26\30\32\34\36 \"$&(*,")
        buf.write("\2\5\4\2\23\23..\5\2\22\22\35$..\3\2%*\u011f\29\3\2\2")
        buf.write("\2\4=\3\2\2\2\6\\\3\2\2\2\b^\3\2\2\2\ng\3\2\2\2\fp\3\2")
        buf.write("\2\2\16y\3\2\2\2\20~\3\2\2\2\22\u0087\3\2\2\2\24\u008e")
        buf.write("\3\2\2\2\26\u00a0\3\2\2\2\30\u00a4\3\2\2\2\32\u00af\3")
        buf.write("\2\2\2\34\u00b3\3\2\2\2\36\u00c1\3\2\2\2 \u00d6\3\2\2")
        buf.write("\2\"\u00e2\3\2\2\2$\u00e4\3\2\2\2&\u00f3\3\2\2\2(\u0102")
        buf.write("\3\2\2\2*\u010b\3\2\2\2,\u0114\3\2\2\2.:\5\4\3\2/:\5\6")
        buf.write("\4\2\60:\5\b\5\2\61:\5*\26\2\62:\5\16\b\2\63:\5\20\t\2")
        buf.write("\64:\5\22\n\2\65:\5\24\13\2\66:\5\34\17\2\67:\5$\23\2")
        buf.write("8:\5&\24\29.\3\2\2\29/\3\2\2\29\60\3\2\2\29\61\3\2\2\2")
        buf.write("9\62\3\2\2\29\63\3\2\2\29\64\3\2\2\29\65\3\2\2\29\66\3")
        buf.write("\2\2\29\67\3\2\2\298\3\2\2\2:;\3\2\2\2;9\3\2\2\2;<\3\2")
        buf.write("\2\2<\3\3\2\2\2=>\7\3\2\2>A\5(\25\2?@\7\4\2\2@B\7.\2\2")
        buf.write("A?\3\2\2\2AB\3\2\2\2BC\3\2\2\2CD\7\5\2\2D\5\3\2\2\2EF")
        buf.write("\7.\2\2FG\7\6\2\2GH\7\7\2\2HI\7\b\2\2IJ\5(\25\2JK\7\t")
        buf.write("\2\2KL\7\60\2\2LM\7\5\2\2M]\3\2\2\2NO\7.\2\2OP\7\6\2\2")
        buf.write("PQ\7\7\2\2QR\7\n\2\2RS\5(\25\2ST\7\13\2\2TU\5(\25\2UV")
        buf.write("\7\f\2\2VW\7\b\2\2WX\5(\25\2XY\7\t\2\2YZ\7\60\2\2Z[\7")
        buf.write("\5\2\2[]\3\2\2\2\\E\3\2\2\2\\N\3\2\2\2]\7\3\2\2\2^_\7")
        buf.write(".\2\2_`\7\6\2\2`a\7\b\2\2ab\7\r\2\2bc\7\16\2\2cd\5\n\6")
        buf.write("\2de\7\17\2\2ef\7\5\2\2f\t\3\2\2\2gl\5\f\7\2hi\7\20\2")
        buf.write("\2ik\5\f\7\2jh\3\2\2\2kn\3\2\2\2lj\3\2\2\2lm\3\2\2\2m")
        buf.write("\13\3\2\2\2nl\3\2\2\2oq\7\21\2\2po\3\2\2\2pq\3\2\2\2q")
        buf.write("r\3\2\2\2rs\7.\2\2st\7\22\2\2tw\t\2\2\2uv\7\4\2\2vx\7")
        buf.write(".\2\2wu\3\2\2\2wx\3\2\2\2x\r\3\2\2\2yz\7\24\2\2z{\7\b")
        buf.write("\2\2{|\7.\2\2|}\7\5\2\2}\17\3\2\2\2~\177\7\25\2\2\177")
        buf.write("\u0080\7.\2\2\u0080\u0081\7\26\2\2\u0081\u0082\7\n\2\2")
        buf.write("\u0082\u0083\5(\25\2\u0083\u0084\7\13\2\2\u0084\u0085")
        buf.write("\5(\25\2\u0085\u0086\7\5\2\2\u0086\21\3\2\2\2\u0087\u0088")
        buf.write("\7\25\2\2\u0088\u0089\7\b\2\2\u0089\u008a\7.\2\2\u008a")
        buf.write("\u008b\7\26\2\2\u008b\u008c\5(\25\2\u008c\u008d\7\5\2")
        buf.write("\2\u008d\23\3\2\2\2\u008e\u008f\7.\2\2\u008f\u0090\7\6")
        buf.write("\2\2\u0090\u0091\7\27\2\2\u0091\u0094\5\26\f\2\u0092\u0093")
        buf.write("\7\20\2\2\u0093\u0095\5\26\f\2\u0094\u0092\3\2\2\2\u0095")
        buf.write("\u0096\3\2\2\2\u0096\u0094\3\2\2\2\u0096\u0097\3\2\2\2")
        buf.write("\u0097\u0098\3\2\2\2\u0098\u0099\7\f\2\2\u0099\u009a\7")
        buf.write("\b\2\2\u009a\u009b\7\r\2\2\u009b\u009c\7\16\2\2\u009c")
        buf.write("\u009d\5\n\6\2\u009d\u009e\7\17\2\2\u009e\u009f\7\5\2")
        buf.write("\2\u009f\25\3\2\2\2\u00a0\u00a1\7.\2\2\u00a1\u00a2\7\30")
        buf.write("\2\2\u00a2\u00a3\5\30\r\2\u00a3\27\3\2\2\2\u00a4\u00a5")
        buf.write("\7\16\2\2\u00a5\u00aa\5\32\16\2\u00a6\u00a7\7\20\2\2\u00a7")
        buf.write("\u00a9\5\32\16\2\u00a8\u00a6\3\2\2\2\u00a9\u00ac\3\2\2")
        buf.write("\2\u00aa\u00a8\3\2\2\2\u00aa\u00ab\3\2\2\2\u00ab\u00ad")
        buf.write("\3\2\2\2\u00ac\u00aa\3\2\2\2\u00ad\u00ae\7\17\2\2\u00ae")
        buf.write("\31\3\2\2\2\u00af\u00b0\7.\2\2\u00b0\u00b1\7\22\2\2\u00b1")
        buf.write("\u00b2\7.\2\2\u00b2\33\3\2\2\2\u00b3\u00b4\7.\2\2\u00b4")
        buf.write("\u00b5\7\6\2\2\u00b5\u00b6\7\31\2\2\u00b6\u00b7\7.\2\2")
        buf.write("\u00b7\u00b8\7\30\2\2\u00b8\u00b9\5\36\20\2\u00b9\u00ba")
        buf.write("\7\5\2\2\u00ba\35\3\2\2\2\u00bb\u00bc\b\20\1\2\u00bc\u00c2")
        buf.write("\5 \21\2\u00bd\u00be\7\16\2\2\u00be\u00bf\5\36\20\2\u00bf")
        buf.write("\u00c0\7\17\2\2\u00c0\u00c2\3\2\2\2\u00c1\u00bb\3\2\2")
        buf.write("\2\u00c1\u00bd\3\2\2\2\u00c2\u00cb\3\2\2\2\u00c3\u00c4")
        buf.write("\f\6\2\2\u00c4\u00c5\7+\2\2\u00c5\u00ca\5\36\20\7\u00c6")
        buf.write("\u00c7\f\5\2\2\u00c7\u00c8\7,\2\2\u00c8\u00ca\5\36\20")
        buf.write("\6\u00c9\u00c3\3\2\2\2\u00c9\u00c6\3\2\2\2\u00ca\u00cd")
        buf.write("\3\2\2\2\u00cb\u00c9\3\2\2\2\u00cb\u00cc\3\2\2\2\u00cc")
        buf.write("\37\3\2\2\2\u00cd\u00cb\3\2\2\2\u00ce\u00cf\5\"\22\2\u00cf")
        buf.write("\u00d0\5,\27\2\u00d0\u00d1\5\"\22\2\u00d1\u00d7\3\2\2")
        buf.write("\2\u00d2\u00d3\7\16\2\2\u00d3\u00d4\5 \21\2\u00d4\u00d5")
        buf.write("\7\17\2\2\u00d5\u00d7\3\2\2\2\u00d6\u00ce\3\2\2\2\u00d6")
        buf.write("\u00d2\3\2\2\2\u00d7!\3\2\2\2\u00d8\u00e3\5(\25\2\u00d9")
        buf.write("\u00e3\5\32\16\2\u00da\u00dc\7\21\2\2\u00db\u00da\3\2")
        buf.write("\2\2\u00db\u00dc\3\2\2\2\u00dc\u00dd\3\2\2\2\u00dd\u00e3")
        buf.write("\7/\2\2\u00de\u00e0\7\21\2\2\u00df\u00de\3\2\2\2\u00df")
        buf.write("\u00e0\3\2\2\2\u00e0\u00e1\3\2\2\2\u00e1\u00e3\7\60\2")
        buf.write("\2\u00e2\u00d8\3\2\2\2\u00e2\u00d9\3\2\2\2\u00e2\u00db")
        buf.write("\3\2\2\2\u00e2\u00df\3\2\2\2\u00e3#\3\2\2\2\u00e4\u00e5")
        buf.write("\7.\2\2\u00e5\u00e6\7\6\2\2\u00e6\u00e7\7\32\2\2\u00e7")
        buf.write("\u00e8\7.\2\2\u00e8\u00e9\7\30\2\2\u00e9\u00ee\5\32\16")
        buf.write("\2\u00ea\u00eb\7\20\2\2\u00eb\u00ed\5\32\16\2\u00ec\u00ea")
        buf.write("\3\2\2\2\u00ed\u00f0\3\2\2\2\u00ee\u00ec\3\2\2\2\u00ee")
        buf.write("\u00ef\3\2\2\2\u00ef\u00f1\3\2\2\2\u00f0\u00ee\3\2\2\2")
        buf.write("\u00f1\u00f2\7\5\2\2\u00f2%\3\2\2\2\u00f3\u00f4\7.\2\2")
        buf.write("\u00f4\u00f5\7\6\2\2\u00f5\u00f6\7\33\2\2\u00f6\u00f7")
        buf.write("\7.\2\2\u00f7\u00f8\7\30\2\2\u00f8\u00fd\5\32\16\2\u00f9")
        buf.write("\u00fa\7\20\2\2\u00fa\u00fc\5\32\16\2\u00fb\u00f9\3\2")
        buf.write("\2\2\u00fc\u00ff\3\2\2\2\u00fd\u00fb\3\2\2\2\u00fd\u00fe")
        buf.write("\3\2\2\2\u00fe\u0100\3\2\2\2\u00ff\u00fd\3\2\2\2\u0100")
        buf.write("\u0101\7\5\2\2\u0101\'\3\2\2\2\u0102\u0106\7\34\2\2\u0103")
        buf.write("\u0105\t\3\2\2\u0104\u0103\3\2\2\2\u0105\u0108\3\2\2\2")
        buf.write("\u0106\u0104\3\2\2\2\u0106\u0107\3\2\2\2\u0107\u0109\3")
        buf.write("\2\2\2\u0108\u0106\3\2\2\2\u0109\u010a\7\34\2\2\u010a")
        buf.write(")\3\2\2\2\u010b\u010f\7-\2\2\u010c\u010e\13\2\2\2\u010d")
        buf.write("\u010c\3\2\2\2\u010e\u0111\3\2\2\2\u010f\u0110\3\2\2\2")
        buf.write("\u010f\u010d\3\2\2\2\u0110\u0112\3\2\2\2\u0111\u010f\3")
        buf.write("\2\2\2\u0112\u0113\7-\2\2\u0113+\3\2\2\2\u0114\u0115\t")
        buf.write("\4\2\2\u0115-\3\2\2\2\269;A\\lpw\u0096\u00aa\u00c1\u00c9")
        buf.write("\u00cb\u00d6\u00db\u00df\u00e2\u00ee\u00fd\u0106\u010f")
        return buf.getvalue()


class sdplParser ( Parser ):

    grammarFileName = "sdpl.g4"

    atn = ATNDeserializer().deserialize(serializedATN())

    decisionsToDFA = [ DFA(ds, i) for i, ds in enumerate(atn.decisionToState) ]

    sharedContextCache = PredictionContextCache()

    literalNames = [ "<INVALID>", "'REGISTER'", "'AS'", "';'", "'='", "'LOAD'", 
                     "'SCHEMA'", "'VERSION'", "'TABLE'", "'FROM'", "'WITH'", 
                     "'PROJECTION'", "'('", "')'", "','", "'-'", "'.'", 
                     "'*'", "'EXPAND'", "'STORE'", "'INTO'", "'JOIN'", "'BY'", 
                     "'FILTER'", "'ORDER'", "'GROUP'", "'''", "':'", "'/'", 
                     "'$'", "'{'", "'}'", "'@'", "'%'", "'?'", "'!='", "'=='", 
                     "'<='", "'<'", "'>='", "'>'", "'AND'", "'OR'", "'```'" ]

    symbolicNames = [ "<INVALID>", "<INVALID>", "<INVALID>", "<INVALID>", 
                      "<INVALID>", "<INVALID>", "<INVALID>", "<INVALID>", 
                      "<INVALID>", "<INVALID>", "<INVALID>", "<INVALID>", 
                      "<INVALID>", "<INVALID>", "<INVALID>", "<INVALID>", 
                      "<INVALID>", "<INVALID>", "<INVALID>", "<INVALID>", 
                      "<INVALID>", "<INVALID>", "<INVALID>", "<INVALID>", 
                      "<INVALID>", "<INVALID>", "<INVALID>", "<INVALID>", 
                      "<INVALID>", "<INVALID>", "<INVALID>", "<INVALID>", 
                      "<INVALID>", "<INVALID>", "<INVALID>", "CO_NE", "CO_EQ", 
                      "CO_LE", "CO_LT", "CO_GE", "CO_GT", "AND", "OR", "QUOTE_DELIM", 
                      "ID", "DECIMAL", "INTEGER", "WS", "SL_COMMENT" ]

    RULE_startrule = 0
    RULE_libDecl = 1
    RULE_relationDecl = 2
    RULE_projectionDecl = 3
    RULE_schemaFields = 4
    RULE_schemaField = 5
    RULE_expandSchema = 6
    RULE_storeDecl = 7
    RULE_storeSchemaDecl = 8
    RULE_joinDecl = 9
    RULE_joinElement = 10
    RULE_relationColumns = 11
    RULE_relationColumn = 12
    RULE_filterDecl = 13
    RULE_filterExpression = 14
    RULE_filterOperation = 15
    RULE_filterOperand = 16
    RULE_orderByDecl = 17
    RULE_groupByDecl = 18
    RULE_quotedString = 19
    RULE_quotedCode = 20
    RULE_compOperator = 21

    ruleNames =  [ "startrule", "libDecl", "relationDecl", "projectionDecl", 
                   "schemaFields", "schemaField", "expandSchema", "storeDecl", 
                   "storeSchemaDecl", "joinDecl", "joinElement", "relationColumns", 
                   "relationColumn", "filterDecl", "filterExpression", "filterOperation", 
                   "filterOperand", "orderByDecl", "groupByDecl", "quotedString", 
                   "quotedCode", "compOperator" ]

    EOF = Token.EOF
    T__0=1
    T__1=2
    T__2=3
    T__3=4
    T__4=5
    T__5=6
    T__6=7
    T__7=8
    T__8=9
    T__9=10
    T__10=11
    T__11=12
    T__12=13
    T__13=14
    T__14=15
    T__15=16
    T__16=17
    T__17=18
    T__18=19
    T__19=20
    T__20=21
    T__21=22
    T__22=23
    T__23=24
    T__24=25
    T__25=26
    T__26=27
    T__27=28
    T__28=29
    T__29=30
    T__30=31
    T__31=32
    T__32=33
    T__33=34
    CO_NE=35
    CO_EQ=36
    CO_LE=37
    CO_LT=38
    CO_GE=39
    CO_GT=40
    AND=41
    OR=42
    QUOTE_DELIM=43
    ID=44
    DECIMAL=45
    INTEGER=46
    WS=47
    SL_COMMENT=48

    def __init__(self, input:TokenStream):
        super().__init__(input)
        self.checkVersion("4.5.1")
        self._interp = ParserATNSimulator(self, self.atn, self.decisionsToDFA, self.sharedContextCache)
        self._predicates = None



    class StartruleContext(ParserRuleContext):

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def libDecl(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(sdplParser.LibDeclContext)
            else:
                return self.getTypedRuleContext(sdplParser.LibDeclContext,i)


        def relationDecl(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(sdplParser.RelationDeclContext)
            else:
                return self.getTypedRuleContext(sdplParser.RelationDeclContext,i)


        def projectionDecl(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(sdplParser.ProjectionDeclContext)
            else:
                return self.getTypedRuleContext(sdplParser.ProjectionDeclContext,i)


        def quotedCode(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(sdplParser.QuotedCodeContext)
            else:
                return self.getTypedRuleContext(sdplParser.QuotedCodeContext,i)


        def expandSchema(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(sdplParser.ExpandSchemaContext)
            else:
                return self.getTypedRuleContext(sdplParser.ExpandSchemaContext,i)


        def storeDecl(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(sdplParser.StoreDeclContext)
            else:
                return self.getTypedRuleContext(sdplParser.StoreDeclContext,i)


        def storeSchemaDecl(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(sdplParser.StoreSchemaDeclContext)
            else:
                return self.getTypedRuleContext(sdplParser.StoreSchemaDeclContext,i)


        def joinDecl(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(sdplParser.JoinDeclContext)
            else:
                return self.getTypedRuleContext(sdplParser.JoinDeclContext,i)


        def filterDecl(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(sdplParser.FilterDeclContext)
            else:
                return self.getTypedRuleContext(sdplParser.FilterDeclContext,i)


        def orderByDecl(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(sdplParser.OrderByDeclContext)
            else:
                return self.getTypedRuleContext(sdplParser.OrderByDeclContext,i)


        def groupByDecl(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(sdplParser.GroupByDeclContext)
            else:
                return self.getTypedRuleContext(sdplParser.GroupByDeclContext,i)


        def getRuleIndex(self):
            return sdplParser.RULE_startrule

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterStartrule" ):
                listener.enterStartrule(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitStartrule" ):
                listener.exitStartrule(self)




    def startrule(self):

        localctx = sdplParser.StartruleContext(self, self._ctx, self.state)
        self.enterRule(localctx, 0, self.RULE_startrule)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 55 
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            while True:
                self.state = 55
                la_ = self._interp.adaptivePredict(self._input,0,self._ctx)
                if la_ == 1:
                    self.state = 44
                    self.libDecl()
                    pass

                elif la_ == 2:
                    self.state = 45
                    self.relationDecl()
                    pass

                elif la_ == 3:
                    self.state = 46
                    self.projectionDecl()
                    pass

                elif la_ == 4:
                    self.state = 47
                    self.quotedCode()
                    pass

                elif la_ == 5:
                    self.state = 48
                    self.expandSchema()
                    pass

                elif la_ == 6:
                    self.state = 49
                    self.storeDecl()
                    pass

                elif la_ == 7:
                    self.state = 50
                    self.storeSchemaDecl()
                    pass

                elif la_ == 8:
                    self.state = 51
                    self.joinDecl()
                    pass

                elif la_ == 9:
                    self.state = 52
                    self.filterDecl()
                    pass

                elif la_ == 10:
                    self.state = 53
                    self.orderByDecl()
                    pass

                elif la_ == 11:
                    self.state = 54
                    self.groupByDecl()
                    pass


                self.state = 57 
                self._errHandler.sync(self)
                _la = self._input.LA(1)
                if not ((((_la) & ~0x3f) == 0 and ((1 << _la) & ((1 << sdplParser.T__0) | (1 << sdplParser.T__17) | (1 << sdplParser.T__18) | (1 << sdplParser.QUOTE_DELIM) | (1 << sdplParser.ID))) != 0)):
                    break

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx

    class LibDeclContext(ParserRuleContext):

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def quotedString(self):
            return self.getTypedRuleContext(sdplParser.QuotedStringContext,0)


        def ID(self):
            return self.getToken(sdplParser.ID, 0)

        def getRuleIndex(self):
            return sdplParser.RULE_libDecl

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterLibDecl" ):
                listener.enterLibDecl(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitLibDecl" ):
                listener.exitLibDecl(self)




    def libDecl(self):

        localctx = sdplParser.LibDeclContext(self, self._ctx, self.state)
        self.enterRule(localctx, 2, self.RULE_libDecl)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 59
            self.match(sdplParser.T__0)
            self.state = 60
            self.quotedString()
            self.state = 63
            _la = self._input.LA(1)
            if _la==sdplParser.T__1:
                self.state = 61
                self.match(sdplParser.T__1)
                self.state = 62
                self.match(sdplParser.ID)


            self.state = 65
            self.match(sdplParser.T__2)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx

    class RelationDeclContext(ParserRuleContext):

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def ID(self):
            return self.getToken(sdplParser.ID, 0)

        def quotedString(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(sdplParser.QuotedStringContext)
            else:
                return self.getTypedRuleContext(sdplParser.QuotedStringContext,i)


        def INTEGER(self):
            return self.getToken(sdplParser.INTEGER, 0)

        def getRuleIndex(self):
            return sdplParser.RULE_relationDecl

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterRelationDecl" ):
                listener.enterRelationDecl(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitRelationDecl" ):
                listener.exitRelationDecl(self)




    def relationDecl(self):

        localctx = sdplParser.RelationDeclContext(self, self._ctx, self.state)
        self.enterRule(localctx, 4, self.RULE_relationDecl)
        try:
            self.state = 90
            la_ = self._interp.adaptivePredict(self._input,3,self._ctx)
            if la_ == 1:
                self.enterOuterAlt(localctx, 1)
                self.state = 67
                self.match(sdplParser.ID)
                self.state = 68
                self.match(sdplParser.T__3)
                self.state = 69
                self.match(sdplParser.T__4)
                self.state = 70
                self.match(sdplParser.T__5)
                self.state = 71
                self.quotedString()
                self.state = 72
                self.match(sdplParser.T__6)
                self.state = 73
                self.match(sdplParser.INTEGER)
                self.state = 74
                self.match(sdplParser.T__2)
                pass

            elif la_ == 2:
                self.enterOuterAlt(localctx, 2)
                self.state = 76
                self.match(sdplParser.ID)
                self.state = 77
                self.match(sdplParser.T__3)
                self.state = 78
                self.match(sdplParser.T__4)
                self.state = 79
                self.match(sdplParser.T__7)
                self.state = 80
                self.quotedString()
                self.state = 81
                self.match(sdplParser.T__8)
                self.state = 82
                self.quotedString()
                self.state = 83
                self.match(sdplParser.T__9)
                self.state = 84
                self.match(sdplParser.T__5)
                self.state = 85
                self.quotedString()
                self.state = 86
                self.match(sdplParser.T__6)
                self.state = 87
                self.match(sdplParser.INTEGER)
                self.state = 88
                self.match(sdplParser.T__2)
                pass


        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx

    class ProjectionDeclContext(ParserRuleContext):

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def ID(self):
            return self.getToken(sdplParser.ID, 0)

        def schemaFields(self):
            return self.getTypedRuleContext(sdplParser.SchemaFieldsContext,0)


        def getRuleIndex(self):
            return sdplParser.RULE_projectionDecl

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterProjectionDecl" ):
                listener.enterProjectionDecl(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitProjectionDecl" ):
                listener.exitProjectionDecl(self)




    def projectionDecl(self):

        localctx = sdplParser.ProjectionDeclContext(self, self._ctx, self.state)
        self.enterRule(localctx, 6, self.RULE_projectionDecl)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 92
            self.match(sdplParser.ID)
            self.state = 93
            self.match(sdplParser.T__3)
            self.state = 94
            self.match(sdplParser.T__5)
            self.state = 95
            self.match(sdplParser.T__10)
            self.state = 96
            self.match(sdplParser.T__11)
            self.state = 97
            self.schemaFields()
            self.state = 98
            self.match(sdplParser.T__12)
            self.state = 99
            self.match(sdplParser.T__2)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx

    class SchemaFieldsContext(ParserRuleContext):

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def schemaField(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(sdplParser.SchemaFieldContext)
            else:
                return self.getTypedRuleContext(sdplParser.SchemaFieldContext,i)


        def getRuleIndex(self):
            return sdplParser.RULE_schemaFields

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterSchemaFields" ):
                listener.enterSchemaFields(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitSchemaFields" ):
                listener.exitSchemaFields(self)




    def schemaFields(self):

        localctx = sdplParser.SchemaFieldsContext(self, self._ctx, self.state)
        self.enterRule(localctx, 8, self.RULE_schemaFields)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 101
            self.schemaField()
            self.state = 106
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            while _la==sdplParser.T__13:
                self.state = 102
                self.match(sdplParser.T__13)
                self.state = 103
                self.schemaField()
                self.state = 108
                self._errHandler.sync(self)
                _la = self._input.LA(1)

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx

    class SchemaFieldContext(ParserRuleContext):

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def ID(self, i:int=None):
            if i is None:
                return self.getTokens(sdplParser.ID)
            else:
                return self.getToken(sdplParser.ID, i)

        def getRuleIndex(self):
            return sdplParser.RULE_schemaField

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterSchemaField" ):
                listener.enterSchemaField(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitSchemaField" ):
                listener.exitSchemaField(self)




    def schemaField(self):

        localctx = sdplParser.SchemaFieldContext(self, self._ctx, self.state)
        self.enterRule(localctx, 10, self.RULE_schemaField)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 110
            _la = self._input.LA(1)
            if _la==sdplParser.T__14:
                self.state = 109
                self.match(sdplParser.T__14)


            self.state = 112
            self.match(sdplParser.ID)
            self.state = 113
            self.match(sdplParser.T__15)
            self.state = 114
            _la = self._input.LA(1)
            if not(_la==sdplParser.T__16 or _la==sdplParser.ID):
                self._errHandler.recoverInline(self)
            else:
                self.consume()
            self.state = 117
            _la = self._input.LA(1)
            if _la==sdplParser.T__1:
                self.state = 115
                self.match(sdplParser.T__1)
                self.state = 116
                self.match(sdplParser.ID)


        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx

    class ExpandSchemaContext(ParserRuleContext):

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def ID(self):
            return self.getToken(sdplParser.ID, 0)

        def getRuleIndex(self):
            return sdplParser.RULE_expandSchema

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterExpandSchema" ):
                listener.enterExpandSchema(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitExpandSchema" ):
                listener.exitExpandSchema(self)




    def expandSchema(self):

        localctx = sdplParser.ExpandSchemaContext(self, self._ctx, self.state)
        self.enterRule(localctx, 12, self.RULE_expandSchema)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 119
            self.match(sdplParser.T__17)
            self.state = 120
            self.match(sdplParser.T__5)
            self.state = 121
            self.match(sdplParser.ID)
            self.state = 122
            self.match(sdplParser.T__2)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx

    class StoreDeclContext(ParserRuleContext):

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def ID(self):
            return self.getToken(sdplParser.ID, 0)

        def quotedString(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(sdplParser.QuotedStringContext)
            else:
                return self.getTypedRuleContext(sdplParser.QuotedStringContext,i)


        def getRuleIndex(self):
            return sdplParser.RULE_storeDecl

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterStoreDecl" ):
                listener.enterStoreDecl(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitStoreDecl" ):
                listener.exitStoreDecl(self)




    def storeDecl(self):

        localctx = sdplParser.StoreDeclContext(self, self._ctx, self.state)
        self.enterRule(localctx, 14, self.RULE_storeDecl)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 124
            self.match(sdplParser.T__18)
            self.state = 125
            self.match(sdplParser.ID)
            self.state = 126
            self.match(sdplParser.T__19)
            self.state = 127
            self.match(sdplParser.T__7)
            self.state = 128
            self.quotedString()
            self.state = 129
            self.match(sdplParser.T__8)
            self.state = 130
            self.quotedString()
            self.state = 131
            self.match(sdplParser.T__2)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx

    class StoreSchemaDeclContext(ParserRuleContext):

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def ID(self):
            return self.getToken(sdplParser.ID, 0)

        def quotedString(self):
            return self.getTypedRuleContext(sdplParser.QuotedStringContext,0)


        def getRuleIndex(self):
            return sdplParser.RULE_storeSchemaDecl

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterStoreSchemaDecl" ):
                listener.enterStoreSchemaDecl(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitStoreSchemaDecl" ):
                listener.exitStoreSchemaDecl(self)




    def storeSchemaDecl(self):

        localctx = sdplParser.StoreSchemaDeclContext(self, self._ctx, self.state)
        self.enterRule(localctx, 16, self.RULE_storeSchemaDecl)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 133
            self.match(sdplParser.T__18)
            self.state = 134
            self.match(sdplParser.T__5)
            self.state = 135
            self.match(sdplParser.ID)
            self.state = 136
            self.match(sdplParser.T__19)
            self.state = 137
            self.quotedString()
            self.state = 138
            self.match(sdplParser.T__2)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx

    class JoinDeclContext(ParserRuleContext):

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def ID(self):
            return self.getToken(sdplParser.ID, 0)

        def joinElement(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(sdplParser.JoinElementContext)
            else:
                return self.getTypedRuleContext(sdplParser.JoinElementContext,i)


        def schemaFields(self):
            return self.getTypedRuleContext(sdplParser.SchemaFieldsContext,0)


        def getRuleIndex(self):
            return sdplParser.RULE_joinDecl

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterJoinDecl" ):
                listener.enterJoinDecl(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitJoinDecl" ):
                listener.exitJoinDecl(self)




    def joinDecl(self):

        localctx = sdplParser.JoinDeclContext(self, self._ctx, self.state)
        self.enterRule(localctx, 18, self.RULE_joinDecl)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 140
            self.match(sdplParser.ID)
            self.state = 141
            self.match(sdplParser.T__3)
            self.state = 142
            self.match(sdplParser.T__20)
            self.state = 143
            self.joinElement()
            self.state = 146 
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            while True:
                self.state = 144
                self.match(sdplParser.T__13)
                self.state = 145
                self.joinElement()
                self.state = 148 
                self._errHandler.sync(self)
                _la = self._input.LA(1)
                if not (_la==sdplParser.T__13):
                    break

            self.state = 150
            self.match(sdplParser.T__9)
            self.state = 151
            self.match(sdplParser.T__5)
            self.state = 152
            self.match(sdplParser.T__10)
            self.state = 153
            self.match(sdplParser.T__11)
            self.state = 154
            self.schemaFields()
            self.state = 155
            self.match(sdplParser.T__12)
            self.state = 156
            self.match(sdplParser.T__2)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx

    class JoinElementContext(ParserRuleContext):

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def ID(self):
            return self.getToken(sdplParser.ID, 0)

        def relationColumns(self):
            return self.getTypedRuleContext(sdplParser.RelationColumnsContext,0)


        def getRuleIndex(self):
            return sdplParser.RULE_joinElement

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterJoinElement" ):
                listener.enterJoinElement(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitJoinElement" ):
                listener.exitJoinElement(self)




    def joinElement(self):

        localctx = sdplParser.JoinElementContext(self, self._ctx, self.state)
        self.enterRule(localctx, 20, self.RULE_joinElement)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 158
            self.match(sdplParser.ID)
            self.state = 159
            self.match(sdplParser.T__21)
            self.state = 160
            self.relationColumns()
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx

    class RelationColumnsContext(ParserRuleContext):

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def relationColumn(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(sdplParser.RelationColumnContext)
            else:
                return self.getTypedRuleContext(sdplParser.RelationColumnContext,i)


        def getRuleIndex(self):
            return sdplParser.RULE_relationColumns

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterRelationColumns" ):
                listener.enterRelationColumns(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitRelationColumns" ):
                listener.exitRelationColumns(self)




    def relationColumns(self):

        localctx = sdplParser.RelationColumnsContext(self, self._ctx, self.state)
        self.enterRule(localctx, 22, self.RULE_relationColumns)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 162
            self.match(sdplParser.T__11)
            self.state = 163
            self.relationColumn()
            self.state = 168
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            while _la==sdplParser.T__13:
                self.state = 164
                self.match(sdplParser.T__13)
                self.state = 165
                self.relationColumn()
                self.state = 170
                self._errHandler.sync(self)
                _la = self._input.LA(1)

            self.state = 171
            self.match(sdplParser.T__12)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx

    class RelationColumnContext(ParserRuleContext):

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def ID(self, i:int=None):
            if i is None:
                return self.getTokens(sdplParser.ID)
            else:
                return self.getToken(sdplParser.ID, i)

        def getRuleIndex(self):
            return sdplParser.RULE_relationColumn

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterRelationColumn" ):
                listener.enterRelationColumn(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitRelationColumn" ):
                listener.exitRelationColumn(self)




    def relationColumn(self):

        localctx = sdplParser.RelationColumnContext(self, self._ctx, self.state)
        self.enterRule(localctx, 24, self.RULE_relationColumn)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 173
            self.match(sdplParser.ID)
            self.state = 174
            self.match(sdplParser.T__15)
            self.state = 175
            self.match(sdplParser.ID)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx

    class FilterDeclContext(ParserRuleContext):

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def ID(self, i:int=None):
            if i is None:
                return self.getTokens(sdplParser.ID)
            else:
                return self.getToken(sdplParser.ID, i)

        def filterExpression(self):
            return self.getTypedRuleContext(sdplParser.FilterExpressionContext,0)


        def getRuleIndex(self):
            return sdplParser.RULE_filterDecl

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterFilterDecl" ):
                listener.enterFilterDecl(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitFilterDecl" ):
                listener.exitFilterDecl(self)




    def filterDecl(self):

        localctx = sdplParser.FilterDeclContext(self, self._ctx, self.state)
        self.enterRule(localctx, 26, self.RULE_filterDecl)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 177
            self.match(sdplParser.ID)
            self.state = 178
            self.match(sdplParser.T__3)
            self.state = 179
            self.match(sdplParser.T__22)
            self.state = 180
            self.match(sdplParser.ID)
            self.state = 181
            self.match(sdplParser.T__21)
            self.state = 182
            self.filterExpression(0)
            self.state = 183
            self.match(sdplParser.T__2)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx

    class FilterExpressionContext(ParserRuleContext):

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def filterOperation(self):
            return self.getTypedRuleContext(sdplParser.FilterOperationContext,0)


        def filterExpression(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(sdplParser.FilterExpressionContext)
            else:
                return self.getTypedRuleContext(sdplParser.FilterExpressionContext,i)


        def AND(self):
            return self.getToken(sdplParser.AND, 0)

        def OR(self):
            return self.getToken(sdplParser.OR, 0)

        def getRuleIndex(self):
            return sdplParser.RULE_filterExpression

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterFilterExpression" ):
                listener.enterFilterExpression(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitFilterExpression" ):
                listener.exitFilterExpression(self)



    def filterExpression(self, _p:int=0):
        _parentctx = self._ctx
        _parentState = self.state
        localctx = sdplParser.FilterExpressionContext(self, self._ctx, _parentState)
        _prevctx = localctx
        _startState = 28
        self.enterRecursionRule(localctx, 28, self.RULE_filterExpression, _p)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 191
            la_ = self._interp.adaptivePredict(self._input,9,self._ctx)
            if la_ == 1:
                self.state = 186
                self.filterOperation()
                pass

            elif la_ == 2:
                self.state = 187
                self.match(sdplParser.T__11)
                self.state = 188
                self.filterExpression(0)
                self.state = 189
                self.match(sdplParser.T__12)
                pass


            self._ctx.stop = self._input.LT(-1)
            self.state = 201
            self._errHandler.sync(self)
            _alt = self._interp.adaptivePredict(self._input,11,self._ctx)
            while _alt!=2 and _alt!=ATN.INVALID_ALT_NUMBER:
                if _alt==1:
                    if self._parseListeners is not None:
                        self.triggerExitRuleEvent()
                    _prevctx = localctx
                    self.state = 199
                    la_ = self._interp.adaptivePredict(self._input,10,self._ctx)
                    if la_ == 1:
                        localctx = sdplParser.FilterExpressionContext(self, _parentctx, _parentState)
                        self.pushNewRecursionContext(localctx, _startState, self.RULE_filterExpression)
                        self.state = 193
                        if not self.precpred(self._ctx, 4):
                            from antlr4.error.Errors import FailedPredicateException
                            raise FailedPredicateException(self, "self.precpred(self._ctx, 4)")
                        self.state = 194
                        self.match(sdplParser.AND)
                        self.state = 195
                        self.filterExpression(5)
                        pass

                    elif la_ == 2:
                        localctx = sdplParser.FilterExpressionContext(self, _parentctx, _parentState)
                        self.pushNewRecursionContext(localctx, _startState, self.RULE_filterExpression)
                        self.state = 196
                        if not self.precpred(self._ctx, 3):
                            from antlr4.error.Errors import FailedPredicateException
                            raise FailedPredicateException(self, "self.precpred(self._ctx, 3)")
                        self.state = 197
                        self.match(sdplParser.OR)
                        self.state = 198
                        self.filterExpression(4)
                        pass

             
                self.state = 203
                self._errHandler.sync(self)
                _alt = self._interp.adaptivePredict(self._input,11,self._ctx)

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.unrollRecursionContexts(_parentctx)
        return localctx

    class FilterOperationContext(ParserRuleContext):

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def filterOperand(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(sdplParser.FilterOperandContext)
            else:
                return self.getTypedRuleContext(sdplParser.FilterOperandContext,i)


        def compOperator(self):
            return self.getTypedRuleContext(sdplParser.CompOperatorContext,0)


        def filterOperation(self):
            return self.getTypedRuleContext(sdplParser.FilterOperationContext,0)


        def getRuleIndex(self):
            return sdplParser.RULE_filterOperation

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterFilterOperation" ):
                listener.enterFilterOperation(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitFilterOperation" ):
                listener.exitFilterOperation(self)




    def filterOperation(self):

        localctx = sdplParser.FilterOperationContext(self, self._ctx, self.state)
        self.enterRule(localctx, 30, self.RULE_filterOperation)
        try:
            self.state = 212
            token = self._input.LA(1)
            if token in [sdplParser.T__14, sdplParser.T__25, sdplParser.ID, sdplParser.DECIMAL, sdplParser.INTEGER]:
                self.enterOuterAlt(localctx, 1)
                self.state = 204
                self.filterOperand()
                self.state = 205
                self.compOperator()
                self.state = 206
                self.filterOperand()

            elif token in [sdplParser.T__11]:
                self.enterOuterAlt(localctx, 2)
                self.state = 208
                self.match(sdplParser.T__11)
                self.state = 209
                self.filterOperation()
                self.state = 210
                self.match(sdplParser.T__12)

            else:
                raise NoViableAltException(self)

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx

    class FilterOperandContext(ParserRuleContext):

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def quotedString(self):
            return self.getTypedRuleContext(sdplParser.QuotedStringContext,0)


        def relationColumn(self):
            return self.getTypedRuleContext(sdplParser.RelationColumnContext,0)


        def DECIMAL(self):
            return self.getToken(sdplParser.DECIMAL, 0)

        def INTEGER(self):
            return self.getToken(sdplParser.INTEGER, 0)

        def getRuleIndex(self):
            return sdplParser.RULE_filterOperand

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterFilterOperand" ):
                listener.enterFilterOperand(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitFilterOperand" ):
                listener.exitFilterOperand(self)




    def filterOperand(self):

        localctx = sdplParser.FilterOperandContext(self, self._ctx, self.state)
        self.enterRule(localctx, 32, self.RULE_filterOperand)
        self._la = 0 # Token type
        try:
            self.state = 224
            la_ = self._interp.adaptivePredict(self._input,15,self._ctx)
            if la_ == 1:
                self.enterOuterAlt(localctx, 1)
                self.state = 214
                self.quotedString()
                pass

            elif la_ == 2:
                self.enterOuterAlt(localctx, 2)
                self.state = 215
                self.relationColumn()
                pass

            elif la_ == 3:
                self.enterOuterAlt(localctx, 3)
                self.state = 217
                _la = self._input.LA(1)
                if _la==sdplParser.T__14:
                    self.state = 216
                    self.match(sdplParser.T__14)


                self.state = 219
                self.match(sdplParser.DECIMAL)
                pass

            elif la_ == 4:
                self.enterOuterAlt(localctx, 4)
                self.state = 221
                _la = self._input.LA(1)
                if _la==sdplParser.T__14:
                    self.state = 220
                    self.match(sdplParser.T__14)


                self.state = 223
                self.match(sdplParser.INTEGER)
                pass


        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx

    class OrderByDeclContext(ParserRuleContext):

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def ID(self, i:int=None):
            if i is None:
                return self.getTokens(sdplParser.ID)
            else:
                return self.getToken(sdplParser.ID, i)

        def relationColumn(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(sdplParser.RelationColumnContext)
            else:
                return self.getTypedRuleContext(sdplParser.RelationColumnContext,i)


        def getRuleIndex(self):
            return sdplParser.RULE_orderByDecl

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterOrderByDecl" ):
                listener.enterOrderByDecl(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitOrderByDecl" ):
                listener.exitOrderByDecl(self)




    def orderByDecl(self):

        localctx = sdplParser.OrderByDeclContext(self, self._ctx, self.state)
        self.enterRule(localctx, 34, self.RULE_orderByDecl)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 226
            self.match(sdplParser.ID)
            self.state = 227
            self.match(sdplParser.T__3)
            self.state = 228
            self.match(sdplParser.T__23)
            self.state = 229
            self.match(sdplParser.ID)
            self.state = 230
            self.match(sdplParser.T__21)
            self.state = 231
            self.relationColumn()
            self.state = 236
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            while _la==sdplParser.T__13:
                self.state = 232
                self.match(sdplParser.T__13)
                self.state = 233
                self.relationColumn()
                self.state = 238
                self._errHandler.sync(self)
                _la = self._input.LA(1)

            self.state = 239
            self.match(sdplParser.T__2)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx

    class GroupByDeclContext(ParserRuleContext):

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def ID(self, i:int=None):
            if i is None:
                return self.getTokens(sdplParser.ID)
            else:
                return self.getToken(sdplParser.ID, i)

        def relationColumn(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(sdplParser.RelationColumnContext)
            else:
                return self.getTypedRuleContext(sdplParser.RelationColumnContext,i)


        def getRuleIndex(self):
            return sdplParser.RULE_groupByDecl

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterGroupByDecl" ):
                listener.enterGroupByDecl(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitGroupByDecl" ):
                listener.exitGroupByDecl(self)




    def groupByDecl(self):

        localctx = sdplParser.GroupByDeclContext(self, self._ctx, self.state)
        self.enterRule(localctx, 36, self.RULE_groupByDecl)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 241
            self.match(sdplParser.ID)
            self.state = 242
            self.match(sdplParser.T__3)
            self.state = 243
            self.match(sdplParser.T__24)
            self.state = 244
            self.match(sdplParser.ID)
            self.state = 245
            self.match(sdplParser.T__21)
            self.state = 246
            self.relationColumn()
            self.state = 251
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            while _la==sdplParser.T__13:
                self.state = 247
                self.match(sdplParser.T__13)
                self.state = 248
                self.relationColumn()
                self.state = 253
                self._errHandler.sync(self)
                _la = self._input.LA(1)

            self.state = 254
            self.match(sdplParser.T__2)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx

    class QuotedStringContext(ParserRuleContext):

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def ID(self, i:int=None):
            if i is None:
                return self.getTokens(sdplParser.ID)
            else:
                return self.getToken(sdplParser.ID, i)

        def getRuleIndex(self):
            return sdplParser.RULE_quotedString

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterQuotedString" ):
                listener.enterQuotedString(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitQuotedString" ):
                listener.exitQuotedString(self)




    def quotedString(self):

        localctx = sdplParser.QuotedStringContext(self, self._ctx, self.state)
        self.enterRule(localctx, 38, self.RULE_quotedString)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 256
            self.match(sdplParser.T__25)
            self.state = 260
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            while (((_la) & ~0x3f) == 0 and ((1 << _la) & ((1 << sdplParser.T__15) | (1 << sdplParser.T__26) | (1 << sdplParser.T__27) | (1 << sdplParser.T__28) | (1 << sdplParser.T__29) | (1 << sdplParser.T__30) | (1 << sdplParser.T__31) | (1 << sdplParser.T__32) | (1 << sdplParser.T__33) | (1 << sdplParser.ID))) != 0):
                self.state = 257
                _la = self._input.LA(1)
                if not((((_la) & ~0x3f) == 0 and ((1 << _la) & ((1 << sdplParser.T__15) | (1 << sdplParser.T__26) | (1 << sdplParser.T__27) | (1 << sdplParser.T__28) | (1 << sdplParser.T__29) | (1 << sdplParser.T__30) | (1 << sdplParser.T__31) | (1 << sdplParser.T__32) | (1 << sdplParser.T__33) | (1 << sdplParser.ID))) != 0)):
                    self._errHandler.recoverInline(self)
                else:
                    self.consume()
                self.state = 262
                self._errHandler.sync(self)
                _la = self._input.LA(1)

            self.state = 263
            self.match(sdplParser.T__25)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx

    class QuotedCodeContext(ParserRuleContext):

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def QUOTE_DELIM(self, i:int=None):
            if i is None:
                return self.getTokens(sdplParser.QUOTE_DELIM)
            else:
                return self.getToken(sdplParser.QUOTE_DELIM, i)

        def getRuleIndex(self):
            return sdplParser.RULE_quotedCode

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterQuotedCode" ):
                listener.enterQuotedCode(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitQuotedCode" ):
                listener.exitQuotedCode(self)




    def quotedCode(self):

        localctx = sdplParser.QuotedCodeContext(self, self._ctx, self.state)
        self.enterRule(localctx, 40, self.RULE_quotedCode)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 265
            self.match(sdplParser.QUOTE_DELIM)
            self.state = 269
            self._errHandler.sync(self)
            _alt = self._interp.adaptivePredict(self._input,19,self._ctx)
            while _alt!=1 and _alt!=ATN.INVALID_ALT_NUMBER:
                if _alt==1+1:
                    self.state = 266
                    self.matchWildcard() 
                self.state = 271
                self._errHandler.sync(self)
                _alt = self._interp.adaptivePredict(self._input,19,self._ctx)

            self.state = 272
            self.match(sdplParser.QUOTE_DELIM)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx

    class CompOperatorContext(ParserRuleContext):

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def CO_NE(self):
            return self.getToken(sdplParser.CO_NE, 0)

        def CO_EQ(self):
            return self.getToken(sdplParser.CO_EQ, 0)

        def CO_LE(self):
            return self.getToken(sdplParser.CO_LE, 0)

        def CO_LT(self):
            return self.getToken(sdplParser.CO_LT, 0)

        def CO_GE(self):
            return self.getToken(sdplParser.CO_GE, 0)

        def CO_GT(self):
            return self.getToken(sdplParser.CO_GT, 0)

        def getRuleIndex(self):
            return sdplParser.RULE_compOperator

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterCompOperator" ):
                listener.enterCompOperator(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitCompOperator" ):
                listener.exitCompOperator(self)




    def compOperator(self):

        localctx = sdplParser.CompOperatorContext(self, self._ctx, self.state)
        self.enterRule(localctx, 42, self.RULE_compOperator)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 274
            _la = self._input.LA(1)
            if not((((_la) & ~0x3f) == 0 and ((1 << _la) & ((1 << sdplParser.CO_NE) | (1 << sdplParser.CO_EQ) | (1 << sdplParser.CO_LE) | (1 << sdplParser.CO_LT) | (1 << sdplParser.CO_GE) | (1 << sdplParser.CO_GT))) != 0)):
                self._errHandler.recoverInline(self)
            else:
                self.consume()
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx



    def sempred(self, localctx:RuleContext, ruleIndex:int, predIndex:int):
        if self._predicates == None:
            self._predicates = dict()
        self._predicates[14] = self.filterExpression_sempred
        pred = self._predicates.get(ruleIndex, None)
        if pred is None:
            raise Exception("No predicate with index:" + str(ruleIndex))
        else:
            return pred(localctx, predIndex)

    def filterExpression_sempred(self, localctx:FilterExpressionContext, predIndex:int):
            if predIndex == 0:
                return self.precpred(self._ctx, 4)
         

            if predIndex == 1:
                return self.precpred(self._ctx, 3)
         




