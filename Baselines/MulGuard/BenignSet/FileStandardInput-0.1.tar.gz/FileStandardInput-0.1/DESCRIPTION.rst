File Standard Input Reader
==========================

A Python Standard File Input Reader to Read standard input from file instead of console.
The project can be found on github.
github link : www.github.com/ashik94vc/FileStandardInput

 USAGE
---------

To use this simply import file input like
*from FileStandardInput import FileInput*

Then initiate input class with the file path like

*input = FileInput.input('filepath')*

then substitute *input.file_input()* instead of standard input.

author : "Ashik Vetrivelu <vcashik@gmail.com>"
