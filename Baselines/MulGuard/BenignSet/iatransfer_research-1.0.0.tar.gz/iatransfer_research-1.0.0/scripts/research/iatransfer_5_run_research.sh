#!/bin/bash

#vm
iatransfer_pretrain