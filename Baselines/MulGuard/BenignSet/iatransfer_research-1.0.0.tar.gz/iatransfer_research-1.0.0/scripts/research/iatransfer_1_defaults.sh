#!/bin/bash

#cloudshell
# export MACHINE_TYPE=e2-standard-16
export MACHINE_TYPE=e2-highcpu-16
export ZONE=us-central1-f
export VM=vm
export TPU_INSTANCE_NAME=tpu
