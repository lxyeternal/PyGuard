#!/bin/bash

python3 -m iatransfer.research.paper.stats table -s config/transfer/methods/models-small-append.json -i config/transfer/methods/methods.json 