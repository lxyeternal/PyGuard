"""
Convert magnet links to .torrent files

Visit <https://github.com/jwodder/demagnetize> for more information.
"""

__version__ = "0.1.0"
__author__ = "John Thorvald Wodder II"
__author_email__ = "demagnetize@varonathe.org"
__license__ = "MIT"
__url__ = "https://github.com/jwodder/demagnetize"
