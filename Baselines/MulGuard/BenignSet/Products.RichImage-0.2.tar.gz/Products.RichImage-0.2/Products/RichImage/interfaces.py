from zope.interface import Interface


class IRichImage(Interface):
    """Image with crop functionalities"""
