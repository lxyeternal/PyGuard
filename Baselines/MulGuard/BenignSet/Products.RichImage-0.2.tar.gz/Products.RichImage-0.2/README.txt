Introduction
============

Image with scaling and manual crop functionalities.
