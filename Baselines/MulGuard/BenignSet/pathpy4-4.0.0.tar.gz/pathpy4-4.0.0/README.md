# pathpy4
[![PyPI Latest Release](https://img.shields.io/pypi/v/pathpy.svg)](https://pypi.org/project/pathpy/)
![test](https://github.com/pathpy/pathpy4/actions/workflows/test.yml/badge.svg)
[![codecov](https://codecov.io/gh/pathpy/pathpy4/branch/main/graph/badge.svg?token=FCC1VLST13)](https://codecov.io/gh/pathpy/pathpy4)
[![Code style: black](https://img.shields.io/badge/code%20style-black-000000.svg)](https://github.com/psf/black)
[![Imports: isort](https://img.shields.io/badge/%20imports-isort-%231674b1?style=flat&labelColor=ef8336)](https://pycqa.github.io/isort/)
[![License](https://img.shields.io/badge/licence-%20AGPL--3.0-blue.svg)](https://github.com/pathpy/pathpy4/blob/main/LICENSE.txt)
