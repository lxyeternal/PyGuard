"""Pathpy Module."""

# flake8: noqa
# pylint: disable=unused-import

from . import _version

__version__ = _version.get_versions()["version"]
