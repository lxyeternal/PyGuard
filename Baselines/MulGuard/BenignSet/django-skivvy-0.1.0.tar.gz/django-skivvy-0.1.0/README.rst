django-skivvy
-------------

django-skivvy helps you write better and more readable tests for Django views.

Requirements
~~~~~~~~~~~~
- Python 3.5
- Django 1.9


Installation
~~~~~~~~~~~~

.. code-block::

    pip install django-skivvy

Usage
~~~~~
Refer to the `documentation <https://cadasta.github.io/django-skivvy/#django-skivvy>`_ for further details.
