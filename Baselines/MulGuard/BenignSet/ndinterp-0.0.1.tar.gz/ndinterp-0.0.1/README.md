# ndinterp

N-dimensional interpolation, python package.
