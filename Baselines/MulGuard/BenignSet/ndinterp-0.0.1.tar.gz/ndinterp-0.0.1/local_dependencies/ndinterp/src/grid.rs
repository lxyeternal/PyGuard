//! Interpolation algorithms for gridded base points.

pub mod spline;
