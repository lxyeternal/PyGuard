//! Spline based interpolation.
