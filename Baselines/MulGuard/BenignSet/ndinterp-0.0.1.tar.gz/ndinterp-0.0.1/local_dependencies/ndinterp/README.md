# ndinterp

N-dimensional interpolation library.
