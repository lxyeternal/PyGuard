import os
import pathlib

test_path = pathlib.Path(os.path.abspath(os.path.dirname(__file__)))
