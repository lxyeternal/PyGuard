"""Top-level SeqLike API."""

from .SeqLike import SeqLike, ntSeqLike, aaSeqLike, SeqLikeType
from .SeqLikeAccessor import SeqLikeAccessor

__version__ = "1.1.2"
