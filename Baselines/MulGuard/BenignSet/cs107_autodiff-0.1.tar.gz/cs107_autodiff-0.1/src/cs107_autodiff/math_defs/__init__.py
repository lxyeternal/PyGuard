from .dual import Dual

__all__ = [
    'Dual'
]
