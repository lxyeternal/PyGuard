default_app_config = "simple_redirects.apps.SimpleRedirectsConfig"

VERSION = (2, 0, 0)
__version__ = ".".join(map(str, VERSION))
