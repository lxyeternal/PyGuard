Files below this directory are re-packaged in part from for convenience:
    https://github.com/chriseppstein/compass

The LICENSE for the files is found in LICENSE.markdown in this directory.
