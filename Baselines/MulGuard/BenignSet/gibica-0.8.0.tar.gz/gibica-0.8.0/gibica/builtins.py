"""Built-in functions module."""


def _print(*args):
    """Print an object in the stdout."""
    return print(*args)
