==================
Gibica
==================

Gibica is an interpreter developped in Python 3 (v3.6+).

The aim of this project is to better understand how a basic interpreter works by implementing a simple language.

.. toctree::
   :maxdepth: 2

   quickstart
   basics
   advanced
