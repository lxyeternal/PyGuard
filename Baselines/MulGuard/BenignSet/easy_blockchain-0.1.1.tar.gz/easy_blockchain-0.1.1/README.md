# py-blockchain
A blockchain for human

## Getting Started

Create your first wallet:
```
from easy_blockchain.wallet import Wallet
from easy_blockchain.blockchain import Block, BlockChain


```


