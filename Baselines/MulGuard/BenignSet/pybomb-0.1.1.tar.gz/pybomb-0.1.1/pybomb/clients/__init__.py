"""
Clients for the main resources of the GiantBomb API
http://www.giantbomb.com/api/documentation#toc-0-1
"""
