"""
A library of clients for the main resources of the GiantBomb API
http://www.giantbomb.com/api/documentation#toc-0-1
"""
from pybomb.clients.games_client import GamesClient

# Platform ID's
PS3 = 35
