import sys

import square.main

if __name__ == '__main__':
    sys.exit(square.main.main())
