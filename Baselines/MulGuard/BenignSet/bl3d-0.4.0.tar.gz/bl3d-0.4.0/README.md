# bl3d – A Domain Driven Design library

Bioneland's Domain Driven Design library (bl3d, pronounced */'bled/*) is a collection
of classes to write domain driven designed software.
