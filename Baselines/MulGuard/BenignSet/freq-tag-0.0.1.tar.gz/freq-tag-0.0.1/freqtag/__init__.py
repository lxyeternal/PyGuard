from ._version import __version__
from ._template import foo, Bar

__all__ = ['__version__', 'foo', 'Bar']
