.. -*- mode: rst -*-

|GHActions|_ |Codecov|_ |CircleCI|_

.. |GHActions| image:: https://github.com/Frequency-Tagging/freq-tag/workflows/build/badge.svg
.. _GHActions: https://github.com/Frequency-Tagging/freq-tag/actions

.. |Codecov| image:: https://codecov.io/gh/Frequency-Tagging/freq-tag/branch/master/graph/badge.svg
.. _Codecov: https://codecov.io/gh/Frequency-Tagging/freq-tag

.. |CircleCI| image:: https://circleci.com/gh/Frequency-Tagging/freq-tag.svg?style=svg
.. _CircleCI: https://circleci.com/gh/Frequency-Tagging/freq-tag/tree/master

freq-tag - A Python package facilitating the analysis of frequency-tagging data
===============================================================================

.. _documentation: https://frequency-tagging.github.io/freq-tag/

Refer to the documentation_ for examples.
