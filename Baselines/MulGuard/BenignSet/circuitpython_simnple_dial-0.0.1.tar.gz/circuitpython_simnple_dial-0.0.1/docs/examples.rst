Simple test
------------

Ensure your device works with this simple test.

.. literalinclude:: ../examples/simple_dial_test.py
    :caption: examples/simple_dial_test.py
    :linenos:
