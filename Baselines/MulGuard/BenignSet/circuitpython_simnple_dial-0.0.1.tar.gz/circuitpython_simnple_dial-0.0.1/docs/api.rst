
.. automodule:: simple_dial
    :members:
    :member-order: bysource
