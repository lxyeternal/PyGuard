# DNN Convert Tool

Convert caffemodel to [DNNLibrary](https://github.com/daquexian/DNNLibrary)'s format(I named this format "daq" for my ID "daquexian").

## Usage

Install caffe and pycaffe first.

```
python3 caffe2daq.py [prototxt] [caffemodel]
```

It is WIP from some aspects -- not all layers and properties are support. But I might not have much time to continue working on it. So any PR is welcome.
