DEBUG_ENVIRON_KEY = "DEBUG"

LAMBDA_EVENT_KEY = "lambda_event"
LAMBDA_CONTEXT_KEY = "lambda_context"
LAMBDA_RETURN_KEY = "lambda_return"
