# pygltfio

python glTF IO.

## >=python-3.10

* match statement used


## parser


### extensions

* [ ] mikktspace
* [ ] draco
* [ ] ktx2

## writer

TODO:
