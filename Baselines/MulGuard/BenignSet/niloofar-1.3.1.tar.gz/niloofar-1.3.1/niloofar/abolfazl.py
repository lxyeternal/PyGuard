class Nil(object):
    def __init__(self, *args):
        super(Nil, self).__init__(*args)
        print("god is great like god")

    def abolfazl(self,a):
        if a>0:
             return True
        else:
            return False





