from django.apps import AppConfig


class ReadLogConfig(AppConfig):
    name = 'read_log'
