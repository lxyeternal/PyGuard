lsst-sphinx-bootstrap-theme Changelog
=====================================

0.1 (2016-12-14)
----------------

- Forked from  `astropy-helpers theme <https://github.com/astropy/astropy-helpers>`_ and refactored into a sphinx theme-only package.
- Added LSST branding and colors.
- Using FF Meta and Hack from typekit.com.
