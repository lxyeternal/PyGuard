###########################
lsst-sphinx-bootstrap-theme
###########################

This is a prototype Sphinx theme for LSST Stack documentation, based on the Astropy Sphinx theme.
