# TODO

- implement basic DNS client functionality into dnstraceroute to eliminate need
  of modified dnspython module
- add support for python 2.x for the conservatives and faint-hearted ;-)
- dnsfingerprint.py tool to fingerprint DNS servers
