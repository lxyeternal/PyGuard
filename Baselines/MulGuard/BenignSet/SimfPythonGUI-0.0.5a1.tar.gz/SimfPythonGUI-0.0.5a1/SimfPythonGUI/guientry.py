#!/usr/bin/env python
import SimfPythonGUI


def main():
    SimfPythonGUI.main.main()


if __name__ == '__main__':
    main()
