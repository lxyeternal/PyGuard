_na = 'name'
_tp = 'type'
_opt = 'optional'
_nu = 'nullable'
_cp = 'is_compound'
_srl = 'compound_serialize-mcrr'
_sch = 'compound_schema'
_def = 'default'

_spbtps = (int, float, bool, str)

_empt = (None, "", (), [], {})
