def list_elements():
    return ['TextInput', 'NumberInput', 'Button', 'DropDown']