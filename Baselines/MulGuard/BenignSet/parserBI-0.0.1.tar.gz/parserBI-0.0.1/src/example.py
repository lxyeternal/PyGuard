# Code file

def ajoute_deux(var: int) -> int:
    return var + 2
