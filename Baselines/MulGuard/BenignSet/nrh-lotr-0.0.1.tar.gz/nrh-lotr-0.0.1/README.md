# Lord of the Rings SDK

Author: Nathanial Hapeman

## Installation

pip install nrh-lotr

## Usage

TODO

## Developing from source? Install like:

```sh
python3 -m venv lotr
source ./lotr/bin/activate
python -m pip install -e .
```

## Prompt

Create these endpoints:

- /movie
- /movie/{id}
- /movie/{id}/{quote}
- /quote
- /quote/{id}

Deploy to package manager like: npm, pip, maven, etc...

Fill out design.md
