from .lotr import LOTR, Movie, Quote
