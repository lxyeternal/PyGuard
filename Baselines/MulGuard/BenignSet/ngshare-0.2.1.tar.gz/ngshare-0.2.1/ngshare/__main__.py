from .ngshare import main

main()
