from je_auto_control.utils.exception.exceptions import AutoControlException

raise AutoControlException()
