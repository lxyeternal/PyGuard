from je_auto_control.utils.exception.exceptions import ImageNotFoundException

raise ImageNotFoundException("test.png")
