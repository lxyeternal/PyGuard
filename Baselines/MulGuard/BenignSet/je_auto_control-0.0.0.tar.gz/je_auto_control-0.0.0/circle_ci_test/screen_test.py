from je_auto_control import size

print(size())
