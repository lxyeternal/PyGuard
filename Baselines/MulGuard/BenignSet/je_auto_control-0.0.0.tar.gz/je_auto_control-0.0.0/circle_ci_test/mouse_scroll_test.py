from je_auto_control import scroll

scroll(100)
