from je_auto_control.linux_with_x11.mouse import *
