from je_auto_control.osx.core import osx_vk

