#!/usr/bin/env python3

marathon_config = {}
