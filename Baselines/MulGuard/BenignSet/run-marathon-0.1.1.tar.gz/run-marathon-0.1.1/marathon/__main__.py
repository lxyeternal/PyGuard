#!/usr/bin/env python3

from marathon import cli

cli.main()
