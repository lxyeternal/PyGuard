class Foo(object):

    def __init__(self):
        self.name = "foo"

    def print(self):
        print("I am foo")