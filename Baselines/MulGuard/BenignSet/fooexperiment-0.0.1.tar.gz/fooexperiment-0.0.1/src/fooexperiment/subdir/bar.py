class Bar(object):

    def __init__(self):
        self.name = "bar"

    def print(self):
        print("I am bar")