class SQLLineageException(Exception):
    """Base Exception for SQLLineage"""
