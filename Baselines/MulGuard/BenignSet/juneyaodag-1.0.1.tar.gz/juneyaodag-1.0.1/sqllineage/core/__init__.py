# For backward compatibility, so people can still do `from sqllineage.core import LineageAnalyzer`
from sqllineage.core.analyzer import LineageAnalyzer  # noqa
