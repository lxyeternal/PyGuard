mds-account-invoice-confirmpost
===============================
Queries a confirmation if you post an invoice.

Install
=======

pip install mds-account-invoice-confirmpost

Requires
========
- Tryton 4.6

Changes
=======
*4.6.0 - 22.03.2019*

- first public version
