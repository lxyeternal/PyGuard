To use (with caution), simply do::

>>> from cvgtracker import Tracker

To visualize the live-updating plot while the tracker runs, one need to install bokeh by

>>> easy_install bokeh

and use "bokeh serve" option

There is a file called "trial.py" for test. Please do the following 

>>> bokeh serve
>>> python trial.py

Your webbrower will open a new window or tab to illustrate the tracker
