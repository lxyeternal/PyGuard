The data in this directory is pulled from [moses](https://github.com/molecularsets/moses) and is available under the MIT License.

The three data sets included here represent the span of the data included in the MOSES benchmark (i.e., Combinatorial and HMM are the most dissimilar and VAE is in between the two).

The dataset titled with a DOI is retrieved from the paper at the DOI, with SMILES string encoded by @JacksonBurns.