
import setuptools

setuptools.setup(
    name="smart-fairness-via-contrastive-estimation",
    version="1.0",
    packages=setuptools.find_packages(),
    install_requires=['torch>=1.5.1', 'numpy>=1.18.5', 'scipy>=1.4.1', 'Pillow>=7.2.0', 'dill>=0.3.2', 'pandas>=1.0.1', 'torchvision>=0.6.1', 'scikit-learn>=0.23.1', 'fairlearn>=0.4.6', 'cvxpy>=1.1.5', 'wandb>=0.9.2', 'latextable>=0.1.1', 'matplotlib>=3.2.2', 'texttable>=1.6.2', 'checksumdir>=1.2.0', 'python-box>=4.2.3', 'tensorboard>=2.4.1'],
)
