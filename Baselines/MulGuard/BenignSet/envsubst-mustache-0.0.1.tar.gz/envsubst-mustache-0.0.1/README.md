envsubst-mustache
=================
GNU envsubst-like tool with a [mustache templating](https://mustache.github.io/) system.


### Simple Example
```
envsubst-mustache < etc/template-example.txt
```
