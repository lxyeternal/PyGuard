x=5
y=6
print(x+y)