# sentry-sprintly
A plugin for [Sentry](https://www.getsentry.com/) that creates [Sprint.ly](https://sprint.ly) defects out of exceptions.

## Installation
`$ pip install sentry-sprintly`

Sentry will automagically detect that it has been installed.

![](http://i.imgur.com/xkUsi.png)