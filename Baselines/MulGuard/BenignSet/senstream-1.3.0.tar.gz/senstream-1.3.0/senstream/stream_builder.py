# 1. User can define custom scripts and operations on given senspot timestreams
# 2. Ability to set alert thresholds for user defined senstreams
# 3. Connects to the resensys alert_manager to trigger on given condition
# 4. Ability to add the series to resensys.net as a custom timestream