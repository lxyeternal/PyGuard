# sdepend
Local dependency manager for SCons scripts
