from setuptools import setup

setup(name='AutomaticGraphs',
      version='0.1.1',
      description='Plot graphs faster with seaborn',
      packages=['AutomaticGraphs'],
      zip_safe=False)