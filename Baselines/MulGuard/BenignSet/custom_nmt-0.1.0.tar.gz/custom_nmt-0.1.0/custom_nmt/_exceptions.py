class InvalidGraphError(Exception):
    pass

class InvalidDatasetError(Exception):
    pass
