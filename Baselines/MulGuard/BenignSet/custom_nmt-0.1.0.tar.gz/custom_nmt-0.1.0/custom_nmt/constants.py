# Activation functions
LINEAR = 'linear'
SOFTMAX = 'softmax'

# Special tokens
START_TOKEN = '<start>'
END_TOKEN = '<end>'
OOV_TOKEN = '<unk>'
