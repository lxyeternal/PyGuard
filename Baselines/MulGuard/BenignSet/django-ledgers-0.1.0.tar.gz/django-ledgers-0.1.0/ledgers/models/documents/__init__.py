from .iterator import DocumentIterator
from .document import Document
