DISCORD_CDN = 'https://cdn.discordapp.com'
DISCORD_API_URL = 'https://discordapp.com/api/v6'
