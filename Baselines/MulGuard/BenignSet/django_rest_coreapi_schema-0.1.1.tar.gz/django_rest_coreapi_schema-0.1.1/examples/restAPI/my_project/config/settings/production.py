from .base import *

print("Settings: PRODUCTION")

DEBUG = False