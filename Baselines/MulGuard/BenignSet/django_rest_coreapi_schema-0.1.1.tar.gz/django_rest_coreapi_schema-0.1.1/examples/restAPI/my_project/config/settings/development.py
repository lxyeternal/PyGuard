from .base import *

print("Settings: DEVELOPMENT")
