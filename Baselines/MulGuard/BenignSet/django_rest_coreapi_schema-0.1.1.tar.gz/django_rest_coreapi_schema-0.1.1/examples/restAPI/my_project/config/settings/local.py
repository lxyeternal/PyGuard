from .base import *

print("Settings: LOCAL")
