from .base import *

print("Settings: TEST")
