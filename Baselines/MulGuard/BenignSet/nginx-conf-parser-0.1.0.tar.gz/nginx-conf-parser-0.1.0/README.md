# Nginx Configuration parser for python
[![Build Status](https://travis-ci.org/Querdos/nginx-conf-parser.svg?branch=master)](https://travis-ci.org/Querdos/nginx-conf-parser)
