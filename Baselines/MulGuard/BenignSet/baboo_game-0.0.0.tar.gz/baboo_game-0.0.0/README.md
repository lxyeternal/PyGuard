# Baboo Dice Game

[![made-with-python](https://img.shields.io/badge/Made%20with-Python-1f425f.svg)](https://www.python.org/)
![Release](https://img.shields.io/github/v/release/vitaliisili/dice_game_python)
![Watchers](https://img.shields.io/github/watchers/vitaliisili/dice_game_python?style=social)
[![PyPI version](https://badge.fury.io/py/pypi.svg)](https://pypi.org/project/smart-nine/)

![baboo](https://lh3.googleusercontent.com/pw/AJFCJaWOlNjWnEZ6Lcp7Z8AE3YGCv1CaVTXDX-9VXJxfnNVw_Qljmyfhx-khr0Shs1wI2oESp3tbQ8dmKpcmOHViL-OoKLZE10lQ1qUbnz7cikdgstf7bFq7fds7V1WK7DTMOjJejmubcV0MMieJMfxASOtl=w577-h433-s-no)