# iacchus-table-language

This project aims to develop a simple, concise and robust language for making
bi-dimensional data tables

[https://github.com.iacchus/iacchus-table-language](https://github.com.iacchus/iacchus-table-language)
