.. todo::
    Extend REGEXP and executor to validate arguments

.. todo::
    Add support for multiple databases

.. todo::
    Add support for serverside cursors