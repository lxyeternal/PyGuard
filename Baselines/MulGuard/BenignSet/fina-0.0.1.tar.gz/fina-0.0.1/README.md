# fina
Python package to build financial data
