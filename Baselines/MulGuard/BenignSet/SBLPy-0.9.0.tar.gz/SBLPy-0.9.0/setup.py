from setuptools import setup

setup(
    name='SBLPy',
    version='0.9.0',
    packages=['sblpy'],
    url='',
    license='MIT',
    author='EEKIM10',
    author_email='eek@clicksminuteper.net',
    description='SBLP\'s HTTP system, wrapped into python'
)
