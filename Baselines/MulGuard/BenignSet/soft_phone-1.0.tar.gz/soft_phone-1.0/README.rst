soft_phone
**********
Python library for automated phone call testing using PJSIP/PJSUA