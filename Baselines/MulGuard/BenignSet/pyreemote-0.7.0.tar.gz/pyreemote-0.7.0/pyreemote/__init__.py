# coding=utf-8
__LIBRARY_VERSION__ = '0.7.0'
