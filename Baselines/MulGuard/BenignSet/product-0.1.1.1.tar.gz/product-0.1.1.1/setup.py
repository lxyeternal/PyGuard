from setuptools import setup

setup(
    name='product',      # name of PyPI package
    version='0.1.1.1',   # version number, update with new releases
    packages=['product'] # name of script
)

