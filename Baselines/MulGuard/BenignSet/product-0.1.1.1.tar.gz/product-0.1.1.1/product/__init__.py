# coding: utf-8
def prod(x):
    p = 1
    for i in x:
        p *= i
    return p
