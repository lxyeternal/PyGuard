"""Speed Test Runner init"""
from speed_test import main
