from .cli import innate


if __name__ == "__main__":
    innate.cli()
