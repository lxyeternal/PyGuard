from django.apps import AppConfig


class CharletteConfig(AppConfig):
    name = "charlette"
