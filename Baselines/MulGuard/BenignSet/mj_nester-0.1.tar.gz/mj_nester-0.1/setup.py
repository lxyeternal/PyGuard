from distutils.core import setup

setup(
        name = 'mj_nester',
        version = '0.1',
        py_modules = ['mj_nester'],
        author = 'MJ',
        author_email = 'mj@kicknturf.com',
        url = 'http://www.kicknturf.com',
        description = 'Printing items in the nested list'
    )
