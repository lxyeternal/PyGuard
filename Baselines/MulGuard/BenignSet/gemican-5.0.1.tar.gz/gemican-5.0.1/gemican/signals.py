raise ImportError(
    'Importing from `gemican.signals` is deprecated. '
    'Use `from gemican import signals` or `import gemican.plugins.signals` instead.'
)
