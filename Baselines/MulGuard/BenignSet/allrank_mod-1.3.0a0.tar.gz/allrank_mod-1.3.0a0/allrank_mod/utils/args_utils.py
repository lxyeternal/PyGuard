def split_as_strings(splits):
    return [str(x).strip() for x in splits.split(",")]
