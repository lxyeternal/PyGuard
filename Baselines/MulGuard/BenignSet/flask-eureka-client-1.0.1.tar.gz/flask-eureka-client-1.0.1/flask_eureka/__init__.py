# coding: utf-8

from flask_eureka.eureka import Eureka, eureka_bp
