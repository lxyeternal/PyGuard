from kaa.request import Request


class Resources():

    def __init__(self, request: Request):
        self.request = request
