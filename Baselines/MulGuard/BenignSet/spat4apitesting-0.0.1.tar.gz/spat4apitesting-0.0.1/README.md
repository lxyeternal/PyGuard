# spat
Simple Python API Testing

## Installation

There is no installation app/process at this time.  Just copy the code folder and use

## Usage

Coming Soon

## Contributing

This project is not seeking contributors currently.  But you are welcome to submit a pull request for any bugs found.   For any improvements, please open an issue first to discuss what you would like to change.

## License

[GNU General Public License v3.0](https://www.gnu.org/licenses/gpl-3.0.en.html)
