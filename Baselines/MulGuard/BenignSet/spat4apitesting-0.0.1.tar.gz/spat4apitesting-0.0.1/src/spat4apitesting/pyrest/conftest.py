#! /usr/bin/env python
########################################################################################################################
# Description:  This is the py.test configuration file                                                                 #
# Author: Jasmine-Arabella Post                                                                                        #
########################################################################################################################

########################################
#         Some Setup Stuff             #
########################################
# import pytest
# import os
# import sys



"""
NOTE:  This file currently does nothing.  It was originally setup to do the work the test runner is now doing.
It may be used in the future for py.test fixture or other py.test things, so it is being kept for now.
"""


# End of File
# ==============================================================================