"""
Import lazy_* functions to the main package.
"""

from .laa import lazy_all, lazy_any
