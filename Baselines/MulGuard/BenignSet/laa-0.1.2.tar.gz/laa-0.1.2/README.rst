Lazy «any» and «all»
====================

Sometimes, one would like to use the Python built-ins «any» and «all», but combined with the advantages of Short Circuit
Evaluation.

The package `laa` provides two methods: `lazy_any` and `lazy_all`.

Detailed description of the basic idea (german): `https://juergen.rocks/art/python-any-all-lazy-short-circuit-evaluation.html <https://juergen.rocks/art/python-any-all-lazy-short-circuit-evaluation.html>`__
