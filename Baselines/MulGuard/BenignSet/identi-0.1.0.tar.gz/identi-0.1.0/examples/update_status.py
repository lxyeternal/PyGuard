#!/usr/bin/python

from identi import Identica

identica = Identica()

# OAuth Handshaking

identica.updateStatus("Test message #test")

