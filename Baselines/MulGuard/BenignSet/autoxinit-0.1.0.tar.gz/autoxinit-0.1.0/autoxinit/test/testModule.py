# -*- coding: utf-8 -*-
class testModuleClass:
	
	def __init__(self):
		pass




def testModuleFunction():
	pass