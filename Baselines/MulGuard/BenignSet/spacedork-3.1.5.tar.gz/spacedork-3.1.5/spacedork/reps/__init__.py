from spacedork.reps.zoomeye import ZoomEye

repo = {
    'zoomeye':ZoomEye
}