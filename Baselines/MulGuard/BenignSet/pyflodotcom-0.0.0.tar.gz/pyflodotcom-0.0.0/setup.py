from setuptools import setup, find_packages

setup(
    name="pyflodotcom",
    packages=find_packages(),
    install_requires=[],
    classifiers=[
        "Programming Language :: Python :: 3.10",
    ],
)
