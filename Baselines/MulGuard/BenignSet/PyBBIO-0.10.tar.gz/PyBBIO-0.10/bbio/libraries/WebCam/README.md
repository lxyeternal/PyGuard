WebCam - v0.1
Copyright 2014 Rekha Seethamraju  
rekha.kmit@gmail.com  
  
WebCam is a library for streaming video and taking a picture from a webcam   
connected to the beaglebone black.  
  
See documentation here:   
  https://github.com/alexanderhiam/PyBBIO/wiki/WebCam  
As well as the included example programs:   
  PyBBIO/examples/webcam_test.py  
  PyBBIO/examples/webcam_bbioserver_test.py  
  
WebCam is released as part of PyBBIO under its MIT license. See PyBBIO/LICENSE.txt
