MMA7660 - v0.1

Copyright 2014 Rekha Seethamraju rekha.kmit@gmail.com

Library for controlling accelerometer MMA7660 with the Beaglebone Black's I2C's
pins.

See documentation here:
https://github.com/alexanderhiam/PyBBIO/wiki/MMA7660
As well as the included example programs:
PyBBIO/examples/mma7660_test.py

MMA7660 is released as part of PyBBIO under its MIT license. See PyBBIO/LICENSE.txt