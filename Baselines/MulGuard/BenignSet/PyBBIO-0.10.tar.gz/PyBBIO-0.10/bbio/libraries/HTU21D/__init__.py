# __init__.py file for PyBBIO's HTU21D library
from HTU21D import HTU21D