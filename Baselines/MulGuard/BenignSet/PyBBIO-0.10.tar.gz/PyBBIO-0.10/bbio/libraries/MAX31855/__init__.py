# __init__.py file for PyBBIO's MAX31855 library

from max31855 import MAX31855
