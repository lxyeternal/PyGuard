# This is just an example to demonstrate libraries directory
# scheme for PyBBIO. 
# To test:
#   run PyBBIO/tests/library_test.py


def foo():
  print "Hello, world!"


