# Copyright holders

- 2015 Eugen Salzmann
- 2015 Oliver Sander
- 2016 Xinyun Li
- 2021-2022 Alexander Müller
- 2023 Henrik Jakob

All licenses reside at the folder LICENSES.
Each source file here has the corresponding header for license information
