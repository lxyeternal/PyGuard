// SPDX-FileCopyrightText: 2023 The dune-iga developers mueller@ibb.uni-stuttgart.de
// SPDX-License-Identifier: LGPL-3.0-or-later

#pragma once
namespace Dune::Python::IGA {
  enum class Reader { json };

}  // namespace Dune::Python::IGA
