=====
Usage
=====

To use fabfiles in a project::

    import fabfiles
