"""Top-level package for fabfiles."""

__author__ = """Ivan Savov"""
__email__ = 'ivan@minireference.com'
__version__ = '0.1.0'
