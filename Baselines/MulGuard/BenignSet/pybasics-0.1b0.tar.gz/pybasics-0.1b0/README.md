# pybasics - 0.1

Basic utils in Python.

## Install

```python
pip3 install pybasics
```

## Examples

```python
from pybasics.main import read_file
from pybasics.main import read_pickle
from pybasics.main import write_file
from pybasics.main import write_pickle
```
