# MT-Scrapper
The api-wrapper for the MT informations reading
## Install
To install clone the repo and install the required values `pip3 install requirements.txt`
## Use it

