=======
History
=======

0.1
---

* Initial release with GenomicsDataFrame + AnnotatedMatrix classes.
