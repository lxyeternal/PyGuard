class Ariane():
    def __init__(self):
        self.saludo = "Hola Ariane"
        
    def show(self):
        print(self.saludo)
        
    