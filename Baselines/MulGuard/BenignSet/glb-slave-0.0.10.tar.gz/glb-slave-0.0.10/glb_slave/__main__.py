# -*- coding: utf-8 -*-
from .command import process

process()
