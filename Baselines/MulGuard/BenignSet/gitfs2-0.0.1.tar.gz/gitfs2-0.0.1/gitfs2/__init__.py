# flake8: noqa
from gitfs2.opener import GitFSOpener
from gitfs2._version import __author__, __version__
