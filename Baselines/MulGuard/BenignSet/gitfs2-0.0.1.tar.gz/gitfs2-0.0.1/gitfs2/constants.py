PROGRAM_NAME = "gitfs2"
REPOS_DIR_NAME = "repos"

MESSAGE_INVALID_GIT_URL = 'An invalid git url: "%s" in mobanfile'
DEFAULT_CLONE_DEPTH = 2
