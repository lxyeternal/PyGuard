====================
django-oscar-zarrinpal-gateway v0.1
====================

Payment gateway integration for `Zarinpal Payments <https://www.zarinpal.com>`_ in django-oscar_.
Zarinpal Payments is a large payment gateway based in The I.R. Iran .



License
-------

This package is release under the BSD license.


Installation
------------

`Detailed documentation`_


.. _django-oscar: https://github.com/django-oscar/django-oscar
.. _Detailed documentation: https://github.com/mojtabaakbari221b/django-oscar-zarinpal-gateway/blob/main/README.rst