default_app_config = 'django_oscar_zarinpal_gateway.checkout.apps.CheckoutConfig'
