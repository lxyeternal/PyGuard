# readme

Simulator(based tk) for dotPack ( Eliteu Programable led matrix pack ).

# Install

```bash
# Python >= 3.6
pip install https://github.com/wwj718/dotpack_pyclient_tk/archive/refs/heads/main.zip
```

# Usage

```python
from dotpack import DotPack
pack = DotPack()
pack.set_pixel(0, 0, 'red')
```
