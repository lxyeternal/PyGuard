def sayhello():
    print("hello Moshe Rosenblum have a great day !!!  ( :cd .."
          "")


def saybay():
    print("bay-bay moshe")

def helloeliran():
    print("ELIRAN you are amazing, really you are unbelievable !!!")