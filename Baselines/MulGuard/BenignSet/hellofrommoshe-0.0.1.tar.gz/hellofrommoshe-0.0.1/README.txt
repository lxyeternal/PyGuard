This is a very simple say hallo .
