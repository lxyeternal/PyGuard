.. contents::

Introduction
============

Workflow package for cpskin


Tests
=====

This package is tested using Travis CI. The current status is:

.. image:: https://travis-ci.org/IMIO/cpskin.workflow.png
    :target: http://travis-ci.org/IMIO/cpskin.workflow

.. image:: https://coveralls.io/repos/github/IMIO/cpskin.workflow/badge.svg?branch=master
    :target: https://coveralls.io/github/IMIO/cpskin.workflow?branch=master
