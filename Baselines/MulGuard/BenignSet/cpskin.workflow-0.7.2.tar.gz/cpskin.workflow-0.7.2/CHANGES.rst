Changelog
=========

0.7.2 (2020-10-27)
------------------

- Upload to pypi.org.
  [bsuttor]


0.7.1 (2019-03-13)
------------------

- Update View private content permission, adding "List folder contents" and
  "Access contents information": WEBNAM-69.
  [bsuttor]


0.7.0 (2019-03-01)
------------------

- Add View private content permission : WEBNAM-69.
  [bsuttor]


0.6.4 (2017-10-04)
------------------

- Add 'Private' state in cpskin_moderation_workflow : #18850
  [laulaz]


0.6.3 (2017-01-31)
------------------

- Add usable upgrade step for adding collective.contact workflow.
  [bsuttor]


0.6.2 (2016-10-02)
------------------

- Add missing i18n attributes for workflows state ids
  [mpeeters]


0.6.1 (2016-08-19)
------------------

- Fix collective.contact features by keeping states ids in workflow
  [laulaz]


0.6 (2016-08-18)
----------------

- Add workflow for collective.contact contents with created / published states
  to allow anonymous user to view published contents (#14368)
  [laulaz]

- Add Dexterity tests.
  [bsuttor]


0.5 (2016-07-27)
----------------

- Add new Private state for cpskin_workflow (#14475)
  [laulaz]

- Fix tests
  [laulaz]


0.4 (2016-05-10)
----------------

- Remove old AT references into members-policy.
  [bsuttor]

- Add event on dexterity content for setting exclude_from_nav.
  [bsuttor]


0.3 (2016-02-12)
----------------

- Add dexterity support.
  [bsuttor]


0.2 (2016-01-19)
----------------

- Add dependency workflow to import_step.xml.
  [bsuttor]


0.1 (2014-07-02)
----------------

- Initial release
