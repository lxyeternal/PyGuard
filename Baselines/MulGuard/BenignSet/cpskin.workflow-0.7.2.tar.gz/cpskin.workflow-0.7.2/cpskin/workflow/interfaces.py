from zope.interface import Interface


class ICPSkinWorkflowLayer(Interface):
    """
    Marker interface that defines a ZTK browser layer.
    """


class ICPSkinWorkflowWithMembersLayer(Interface):
    """
    Marker interface that defines a ZTK browser layer.
    """
