- Laurent Lasudry, Original Author [Affinitic]
- Jean-François Roche, Original Author [Affinitic]
- Benoît Suttor, Original Author [iMio]

