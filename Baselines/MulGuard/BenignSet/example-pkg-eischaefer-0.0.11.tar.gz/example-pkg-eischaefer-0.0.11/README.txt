# Example Package

*Note: This file is best viewed with support for the Markdown markup language.*

This is a simple package. I can use **bold**, *italics*, and <u>underscore</u>.

1. Abc
2. def
   1. ghi
   2. jkl

