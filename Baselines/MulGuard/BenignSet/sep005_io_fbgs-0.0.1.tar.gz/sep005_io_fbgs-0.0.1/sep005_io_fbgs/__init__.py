"""
A project template for the sdPy effort..
"""

__version__ = "0.0.1"

from .fbgs import read_fbgs
