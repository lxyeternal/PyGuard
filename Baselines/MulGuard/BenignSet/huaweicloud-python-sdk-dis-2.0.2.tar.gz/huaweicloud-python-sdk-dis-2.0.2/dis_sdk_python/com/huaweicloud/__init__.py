#-*-coding:utf-8-*-
_all_ = ['dis']