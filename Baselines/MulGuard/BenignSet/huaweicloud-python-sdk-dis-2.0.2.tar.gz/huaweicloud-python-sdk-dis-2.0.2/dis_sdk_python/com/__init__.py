#-*-coding:utf-8-*-
_all_ = ['huaweicloud']