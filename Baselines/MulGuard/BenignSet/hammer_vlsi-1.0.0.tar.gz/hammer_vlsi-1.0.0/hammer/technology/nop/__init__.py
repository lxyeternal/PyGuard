from hammer.tech import HammerTechnology


class NopTechnology(HammerTechnology):
    pass


tech = NopTechnology()
