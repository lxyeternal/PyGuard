Nangate45 Technology Library
============================
This is a PDK that comes packaged with [OpenROAD-flow](https://github.com/The-OpenROAD-Project/OpenROAD-flow). Right now, it is only validated against the OpenROAD-flow backend of hammer. 

Dummy SRAMs
-----------
The Nangate45 plugin comes with fake SRAMs without behavioral models or GDS files. 
They only have timing libs for the TT corner (same as the pdk's stcell lib).

Supported Tools
---------------
Only the OpenROAD-flow tools are suported, but compatibility between the two plugins is no longer maintained.
