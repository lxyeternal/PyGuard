#!/bin/bash
# sample vivado setup script.

# setup license server
source /tools/flexlm/flexlm.sh
# setup vivado environment variables
source /tools/xilinx/Vivado/2018.1/settings64.sh
