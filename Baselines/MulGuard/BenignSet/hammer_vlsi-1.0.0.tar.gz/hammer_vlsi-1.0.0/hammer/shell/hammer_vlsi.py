#  hammer-vlsi
#  CLI script - by default, it just uses the default CLIDriver.
#
#  See LICENSE for licence details.

from hammer.vlsi import CLIDriver

def main():
    CLIDriver().main()
