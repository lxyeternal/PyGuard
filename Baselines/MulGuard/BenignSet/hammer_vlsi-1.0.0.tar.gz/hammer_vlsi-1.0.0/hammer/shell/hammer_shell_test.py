# Simple script which tests if hammer-shell is correctly installed into the path.

def main():
    print("hammer-shell appears to be on the path")
