# See LICENSE for licence details.

class HammerConfigError(Exception):
    pass
