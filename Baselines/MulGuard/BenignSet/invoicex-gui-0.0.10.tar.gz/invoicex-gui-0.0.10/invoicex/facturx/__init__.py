# -*- coding: utf-8 -*-

from ._version import __version__
from .facturx import FacturX