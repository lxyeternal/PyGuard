# literary-build-hatch

`pyproject.toml`:
```toml
[tool.hatch.build.targets.wheel.hooks.literary]
dependencies = ["literary-build-hatch"]
```
