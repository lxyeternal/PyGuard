from cloeepy_rabbitmq.cloeepy_rabbitmq import CloeePyRabbitMQ

def get_plugin_class():
    return CloeePyRabbitMQ
