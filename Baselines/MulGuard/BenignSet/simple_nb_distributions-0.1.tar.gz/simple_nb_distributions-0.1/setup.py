from setuptools import setup

setup(name='simple_nb_distributions',
      version='0.1',
      description='Gaussian and Binomial distributions',
      packages=['distributions'],
      zip_safe=False)
