basebot
========

*Not a baseball bot.

basebot is a foundation on which you can build your IRC bots. Look at `core.py` as an example of how to write plugins for it.


Installation
------------

.. code:: shell

    $ git clone https://github.com/clearskies/basebot.git
    $ pip install -r requirements.txt
    $ mkdir ~/.basebot
    $ cp -r sample/* ~/.basebot/
    $ python setup.py install
    $ basebot


Plugins
-------

Look in https://github.com/clearskies/basebot/tree/master/sample/ for sample plugins
