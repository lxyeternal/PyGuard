def sub(x,y):
    return (x-y)