# Djangoroku


[![Build Status](https://travis-ci.org/joemccann/dillinger.svg?branch=master)](https://github.com/ioi2908/djangoroku)

Djangoroku is the package that helps to deploy django application to heroku without worry of creating files required or installing third-party packages. The tool will all do for you! 

  - It setup the `settings.py` file for deployment
  - It install all the necessary packages in your project
  - Deploy the application while coding
  - It setup the default database, `sqlite` in heroku 

### Tech

Djangoroku involves these tech:

* [Django](https://docs.djangoproject.com/en/3.1/) - Python backend framework
* [Heroku](https://dashboard.heroku.com/apps) - PaaS for build and deploy apps
* [Python](https://www.python.org/) - Server side language

### Installation and Uses

To install and use `djangoroku` run these commands. Make sure you're at the root directory of your project.
```sh
$ pip install djangoroku
$ echo "from djangoroku import *" > deploy.py
$ python3 deploy.py
```

The script will start running and do it for you. You'll only needed to provide:
 - Your project name
 - Choose the app name (which will be the heroku domain name)
 - Needed to be logged in your heroku account (emphasized)

Make sure your project runs with no errors in `localhost`, while developing. Note that, the package only helps to deploy and not debug your coding errors.


### Todos

 - Display and interprete heroku logs for debugging during deployment.
 - Setting up all types of databases.
 

License
----

MIT




