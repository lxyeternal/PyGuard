# Consul DNS SRV

envs

```
NAMESERVER
```

or

```
NAMESERVER_HOST
NAMESERVER_PORT
```

## Usage

```


```