from django.apps import AppConfig


class StdnumfieldConfig(AppConfig):
    name = 'stdnumfield'
