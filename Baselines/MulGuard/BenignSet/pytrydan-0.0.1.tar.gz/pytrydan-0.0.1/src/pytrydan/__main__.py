"""Make the CLI runnable using python -m pytrydan."""
from .cli import app

app(prog_name="pytrydan")
