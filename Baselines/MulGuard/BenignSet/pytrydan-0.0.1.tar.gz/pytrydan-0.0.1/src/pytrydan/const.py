KEYWORDS = {
    "ChargeState",
    "ChargePower",
    "ChargeEnergy",
    "SlaveError",
    "ChargeTime",
    "HousePower",
    "FVPower",
    "Paused",
    "Locked",
    "Timer",
    "Intensity",
    "Dynamic",
    "MinIntensity",
    "MaxIntensity",
    "PauseDynamic",
    "DynamicPowerMode",
    "ContractedPower",
}

API_TIMEOUT = 10
