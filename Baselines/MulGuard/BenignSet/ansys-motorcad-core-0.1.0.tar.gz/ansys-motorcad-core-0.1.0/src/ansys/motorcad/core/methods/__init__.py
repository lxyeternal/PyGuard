"""motorcad.core.methods."""
