# -*- coding: utf-8 -*-
from __future__ import (
    division, absolute_import, print_function, unicode_literals,
)


NAME = 'cpl'
VERSION = '0.1.0'
AUTHORS = [
    'huntzhan',
]
EMAILS = [
    'programmer.zhx@gmail.com',
]
LICENSE = ''
URL = ''
DESCRIPTION = 'cpl stands for "copy-paste loop".'
