Init:

1. `./bash-scripts/pip-install-pkgs-of-requirements.sh`
2. `python setup.py develop`

Cleanup:

1. `python setup.py develop --uninstall`
