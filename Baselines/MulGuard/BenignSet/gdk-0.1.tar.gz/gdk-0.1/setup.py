from setuptools import setup

setup(name='gdk',
      version='0.1',
      description='Gaussian distributions',
      packages=['gdk'],
      author = 'Dinesh Kumar Gnanasekaran',
      author_email = 'dinesh.gna111@gmail.com',
      zip_safe=False)
