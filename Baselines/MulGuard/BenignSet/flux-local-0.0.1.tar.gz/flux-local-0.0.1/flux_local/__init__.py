"""
.. include:: ../README.md
"""

__all__ = [
    "manifest",
    "helm",
    "kustomize",
    "repo",
]
