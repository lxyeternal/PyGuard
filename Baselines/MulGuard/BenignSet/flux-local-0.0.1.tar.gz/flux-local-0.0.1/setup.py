"""Minimal setup for the project, see setup.cfg"""
from setuptools import setup

setup()
