# Changelog

## Version 1.0.0 (development)
- Add tools to upload studies into the EUCAN-Connect Catalogue from the external catalogues:
  - BirthCohorts
  - Data Catalogue
  - Catalogues using the Mica software application

## Version 0.1
- Project started from template repository molgenis/molgenis-template-py
- Project files adapted to molgenis-py-eucan-connect repo
