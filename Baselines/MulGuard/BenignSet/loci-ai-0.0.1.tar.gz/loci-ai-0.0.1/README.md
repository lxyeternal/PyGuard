# loci

## What is loci?

loci is a python cli application for competing chess evaluation functions.
