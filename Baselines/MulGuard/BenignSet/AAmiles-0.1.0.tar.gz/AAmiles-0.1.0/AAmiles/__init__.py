# Version of the AAmiles package
__version__ = "0.1.0"