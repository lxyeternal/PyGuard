from .getDataAA import get

# Version of the getDataAA subpackage
__version__ = "0.1.0"