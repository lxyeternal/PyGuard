from django.apps import AppConfig


class DurationwidgetConfig(AppConfig):
    name = 'django_validators'
