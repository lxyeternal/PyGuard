ralph_beast
===========

Beast is convenient Ralph API commandline client. 

It can be used as generic Tastypie commandline client for querying, manipulating
REST resources from the shell.

Docs
----

- `how to install`_

.. _how to install: https://github.com/allegro/ralph_beast/blob/master/doc/install.rst

- howto_

.. _howto: https://github.com/allegro/ralph_beast/blob/master/doc/howto.rst
