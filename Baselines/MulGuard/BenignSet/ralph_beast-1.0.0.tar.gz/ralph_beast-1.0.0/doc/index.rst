.. Beast - Ralph API Client documentation master file, created by Wojciech Matyskiewicz
   sphinx-quickstart on Tue Mar 26 12:38:59 2013.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

Welcome to Beast - Ralph API Client's documentation!
====================================================

Contents:

.. toctree::
   :maxdepth: 2

   install.rst
   howto.rst



Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`

