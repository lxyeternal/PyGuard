=======
PRIMAP2
=======


.. image:: https://img.shields.io/pypi/v/primap2.svg
        :target: https://pypi.python.org/pypi/primap2

.. image:: https://readthedocs.org/projects/primap2/badge/?version=latest
        :target: https://primap2.readthedocs.io/en/latest/?badge=latest
        :alt: Documentation Status




The next generation of the PRIMAP climate policy analysis suite.


* Free software: Apache Software License 2.0
* Documentation: https://primap2.readthedocs.io.


Features
--------

* TODO

Credits
-------

This package was created with Cookiecutter_ and the `audreyr/cookiecutter-pypackage`_ project template.

.. _Cookiecutter: https://github.com/audreyr/cookiecutter
.. _`audreyr/cookiecutter-pypackage`: https://github.com/audreyr/cookiecutter-pypackage
