"""Top-level package for PRIMAP2."""

__author__ = """Mika Pflüger"""
__email__ = 'mika.pflueger@pik-potsdam.de'
__version__ = '0.1.0'
