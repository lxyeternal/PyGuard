=====
Usage
=====

To use PRIMAP2 in a project::

    import primap2
