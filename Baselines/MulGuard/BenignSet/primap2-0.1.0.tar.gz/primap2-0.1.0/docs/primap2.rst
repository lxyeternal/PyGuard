primap2 package
===============

Submodules
----------

primap2.primap2 module
----------------------

.. automodule:: primap2.primap2
   :members:
   :undoc-members:
   :show-inheritance:

Module contents
---------------

.. automodule:: primap2
   :members:
   :undoc-members:
   :show-inheritance:
