def print_test():
    return print('Hello World')
    
