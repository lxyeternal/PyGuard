"""
init for package
"""
from .quick_netmiko import QuickNetmiko
