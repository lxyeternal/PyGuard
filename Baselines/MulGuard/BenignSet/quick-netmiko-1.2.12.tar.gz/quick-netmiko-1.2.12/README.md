[![Unit-Testing, Coverage, Linting](https://github.com/btr1975/quick_netmiko/actions/workflows/test-coverage-lint.yml/badge.svg)](https://github.com/btr1975/quick_netmiko/actions/workflows/test-coverage-lint.yml)

# quick_netmiko
Just a quick way to use Netmiko to get command output from devices
