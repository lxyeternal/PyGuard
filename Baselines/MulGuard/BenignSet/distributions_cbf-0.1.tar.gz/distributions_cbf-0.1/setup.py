from setuptools import setup

setup(name='distributions_cbf',
      version='0.1',
      description='Gaussian distributions',
      packages=['distributions_cbf'],
      author= 'Cesar Blanco',
      author_email= 'cblanco@learning.eoi.es',
      zip_safe=False)
