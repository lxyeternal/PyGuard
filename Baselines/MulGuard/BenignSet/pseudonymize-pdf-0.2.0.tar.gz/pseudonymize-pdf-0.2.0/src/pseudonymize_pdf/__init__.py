"""
A convenience library to read and alter PDFs to remove
personally identifying data.
"""
__version__ = '0.2.0'
