
tool to develop python packages



dist
----

Use `dv dist` to move dist subdirectories ( ``~/.config/develop/develop.pon`` 
has the distbase if not specified with --distbase commandline option)

