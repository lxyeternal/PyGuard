import megacom
megacom.main()
