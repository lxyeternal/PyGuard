[![Contributor Covenant](https://img.shields.io/badge/Contributor%20Covenant-2.1-4baaaa.svg)](CODE_OF_CONDUCT.md)
[![PyPI badge](http://img.shields.io/pypi/v/notevennexus.svg)](https://pypi.python.org/pypi/notevennexus)
[![Anaconda-Server Badge](https://anaconda.org/scipp/notevennexus/badges/version.svg)](https://anaconda.org/scipp/notevennexus)
[![License: BSD 3-Clause](https://img.shields.io/badge/License-BSD%203--Clause-blue.svg)](LICENSE)

# notevennexus

## About

Validate NeXus files

## Installation

```sh
python -m pip install notevennexus
```
