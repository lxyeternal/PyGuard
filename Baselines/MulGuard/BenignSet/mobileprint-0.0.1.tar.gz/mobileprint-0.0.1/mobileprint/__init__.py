from .human_benchmark import HumanPlay

def run():
	game_instance = HumanPlay()
	game_instance.mainloop()