# -*- coding: utf-8 -*-

"""Top-level package for OpenTISim."""

__author__ = """Mark van Koningsveld"""
__email__ = 'm.vankoningsveld@tudelft.nl'
__version__ = 'v.4.0'

