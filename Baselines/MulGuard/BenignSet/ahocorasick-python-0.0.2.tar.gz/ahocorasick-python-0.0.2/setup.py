# coding:utf-8
__author__ = 'zhoukunpeng'
# --------------------------------
# Created by zhoukunpeng  on 2015/8/15.
# ---------------------------------
from setuptools import setup, find_packages

setup(
        name="ahocorasick-python",
        packages=["ahocorasick"],
        version='0.0.2'
)
