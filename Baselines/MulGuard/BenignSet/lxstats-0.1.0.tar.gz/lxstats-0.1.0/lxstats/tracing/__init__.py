"""Interface to Linux kernel tracing facility."""
