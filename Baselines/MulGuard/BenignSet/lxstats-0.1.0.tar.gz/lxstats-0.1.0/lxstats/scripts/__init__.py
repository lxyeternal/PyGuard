"""CLI scripts."""
