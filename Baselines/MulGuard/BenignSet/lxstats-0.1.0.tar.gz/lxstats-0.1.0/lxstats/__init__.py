"""Library to interact with files under /proc and /sys on Linux."""


__version__ = '0.1.0'
