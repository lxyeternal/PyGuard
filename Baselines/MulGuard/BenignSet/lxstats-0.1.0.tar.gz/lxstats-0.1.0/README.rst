=======
LxStats
=======

.. image:: https://travis-ci.org/albertodonato/lxstats.svg?branch=master
   :target: https://travis-ci.org/albertodonato/lxstats
   :alt: Build Status

.. image:: https://codecov.io/gh/albertodonato/lxstats/branch/master/graph/badge.svg
   :target: https://codecov.io/gh/albertodonato/lxstats
   :alt: Coverage Status

LxStats is a library to access system and process statistics and metrics on
Linux systems.

It provides easy parsing of information from various files under the ``/proc``
and ``/sys`` filesystems.
