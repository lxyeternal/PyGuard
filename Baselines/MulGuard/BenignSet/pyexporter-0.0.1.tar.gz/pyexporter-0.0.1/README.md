# PyExporter

The framework for exporting data

Functional сapabilities:
1. Get data from .xlsx files

## Install

```
pip3 install pyexporter
```

## Upgrade

```
pip3 install --upgrade pyexporter
```

# How it works 

## Settings of exporting

