firstdown_cloud
---------------

Python library for processing mission ops data for mobile push notifications and status apps.
