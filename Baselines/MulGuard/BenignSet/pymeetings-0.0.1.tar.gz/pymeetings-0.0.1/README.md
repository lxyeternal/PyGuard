
# Pymeetings

This is a simple library that allows to compute the different hours in different
spots of the world with respect to the GMT.

# Installation


```Bash
pip install pymeetings

```

# Examples

Here is a simple example:

```Python
from pymeetings.pymeet import GetMeetingHour(['Chicago', 'Paris'], '2020/11/23')

df = getmet.ConstructTable()
print(df)
```

There are several examples that are present in the directory **examples**.

# Still ToDo


