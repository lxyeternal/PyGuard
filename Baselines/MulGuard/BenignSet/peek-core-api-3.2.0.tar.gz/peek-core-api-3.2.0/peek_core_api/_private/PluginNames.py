apiFilt = {"plugin": "peek_core_api"}
apiTuplePrefix = "peek_core_api."
apiObservableName = "peek_core_api"
apiActionProcessorName = "peek_core_api"
apiTupleOfflineServiceName = "peek_core_api"
