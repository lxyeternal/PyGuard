"""Upload file to IBM Cloud Object Storage."""

from .cos import CloudObjectStorageUpload
