from __future__ import absolute_import
from __future__ import division
from __future__ import print_function
from __future__ import unicode_literals

######################################################################
# cgkitinfo
#
# Copyright (C) 2004, Matthias Baas (baas@ira.uka.de)
#
# http://cgkit.sourceforge.net
#
# You may distribute under the terms of the BSD license, as
# specified in the file license.txt.
####################################################################

version_info = (1,2,1,"final") # also update setup.py

# The following line is replaced by the setup script
version = "1.2.1"
