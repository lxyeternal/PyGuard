"""
This is demonistrate the basic calculator functionality like add, subtract, multiply and divide two numbers.
"""

def add_numbers(number1, number2):
    return number1 + number2

def subtract_numbers(number1, number2):
    return number1 - number2

def multiply_numbers(number1, number2):
    return number1 * number2

def divide_numbers(number1, number2):
    return number1 / number2


print(add_numbers(10,5))