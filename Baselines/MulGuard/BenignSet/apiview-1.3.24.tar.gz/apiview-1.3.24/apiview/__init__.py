# encoding: utf-8
from __future__ import absolute_import, unicode_literals

__version__ = '1.3.24'
__author__ = '007gzs'

default_app_config = 'apiview.apps.ApiViewConfig'
