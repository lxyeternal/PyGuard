# *****************************************************************************
# precompressed/__init__.py
# *****************************************************************************

"""
precompressed is a pluggable application for Django developers who want
to serve precompressed (gzipped) static files.

"""

__version__ = (0, 0, 1)
