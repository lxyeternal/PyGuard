# *****************************************************************************
# precompressed/models.py
# *****************************************************************************

"""
Exists for django to recognize precompressed as an app,
so that its template tags can be resolved.

"""
