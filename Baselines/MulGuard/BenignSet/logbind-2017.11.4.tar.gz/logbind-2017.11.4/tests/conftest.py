import sys
import logging

logging.basicConfig(level='DEBUG', stream=sys.stdout)