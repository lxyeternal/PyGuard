.. image:: https://travis-ci.org/cjrh/logbind.svg?branch=master
    :target: https://travis-ci.org/cjrh/logbind

.. image:: https://coveralls.io/repos/github/cjrh/logbind/badge.svg?branch=master
    :target: https://coveralls.io/github/cjrh/logbind?branch=master

.. image:: https://img.shields.io/pypi/pyversions/logbind.svg
    :target: https://pypi.python.org/pypi/logbind

.. image:: https://img.shields.io/github/tag/cjrh/logbind.svg
    :target: https://img.shields.io/github/tag/cjrh/logbind.svg

.. image:: https://img.shields.io/badge/install-pip%20install%20logbind-ff69b4.svg
    :target: https://img.shields.io/badge/install-pip%20install%20logbind-ff69b4.svg

.. image:: https://img.shields.io/pypi/v/logbind.svg
    :target: https://img.shields.io/pypi/v/logbind.svg

.. image:: https://img.shields.io/badge/calver-YYYY.MM.MINOR-22bfda.svg
    :target: http://calver.org/

**ALPHA**

logbind
======================

<Text goes here.>