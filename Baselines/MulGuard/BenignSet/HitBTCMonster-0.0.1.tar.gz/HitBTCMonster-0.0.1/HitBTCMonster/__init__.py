__name__ = 'HitBTCMonster'
__version__ = '0.0.1'
__license__ = 'MIT'
__description__ = 'A library for better communication with HitBTC Exchange API'
__repository__ = 'https://github.com/prscodx/HitBTCMonster'
__author__ = {
    'name': 'prscodx',
    'email': 'prscodx@gmail.com',
}
