# CLIdle
This is a Wordle clone for the terminal. There are no
dependencies, except for Windows where you may need
to install windows-curses. As well as this, there
is a built-in hard mode that prevents you from
typing in the wrong letters.

## Screenshot
![Screenshot](./img/screenshot.png)
