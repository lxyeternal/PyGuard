from distutils.core import setup
setup(name='dbadmin',
      version='1.0',
      description = 'just a python wrapper for doing most DB admin functions',
      author = 'Anand Jeyahar',
      author_email = 'anand.jeyahar@gmail.com',
      url = 'git@github.com:anandjeyahar/python-DbAdmin.git',
      packages= ['dbadmin'],
      )
