import os

BASE_URL = os.getenv('BASE_URL', 'https://the-one-api.dev/v2/')
API_KEY = os.getenv('API_KEY')