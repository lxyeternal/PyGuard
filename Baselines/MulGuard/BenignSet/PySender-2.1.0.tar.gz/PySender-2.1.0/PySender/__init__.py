from PySender.__main__ import main
from PySender.__version__ import __version__
