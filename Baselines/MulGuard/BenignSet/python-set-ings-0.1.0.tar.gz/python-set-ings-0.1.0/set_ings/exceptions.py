
class SettingsError(Exception):
    pass
