# -*- coding: utf-8 -*-

__version__ = '0.0.1'
__author__ = 'matteo vezzola <matteo@studioripiu.it>'

default_app_config = 'ripiu.cmsplugin_lasagna.apps.LasagnaConfig'
