from quickvec.embedding import SqliteWordEmbedding, WordEmbedding
