from os import path, pardir

PROJECTROOT = path.abspath(path.join(path.dirname(__file__), pardir, pardir, pardir))
DATA_DIR = path.join(PROJECTROOT, 'data')

# TODO documentation
# TODO scripts module need tests

