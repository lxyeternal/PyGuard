# polygon_crop

This package allows you to crop the image interactively with mouse.

```python
img_crop(img_array)
```
