from setuptools import setup, find_packages
import sys, os

import mailtools

def read(*path):
    """
    Read and return content from ``path``
    """
    f = open(
        os.path.join(
            os.path.dirname(__file__),
            *path
        ),
        'r'
    )
    try:
        return f.read().decode('UTF-8')
    finally:
        f.close()


setup(
    name='mailtools',
    version=mailtools.__version__,
    description="Tools for constructing and sending emails",
    long_description='''
mailtools
----------

Writing a web application? Want to send some emails from it? Mailtools can
help!

 - Simple API for sending plain text messages, HTML and messages with
   attachments.

 - ``ThreadedMailer`` sends emails in the background and returns control
   to your application immediately, even when talking to slow remote servers.

 - Temporary sending failures are automatically retried.

 - Running your application in test mode? The ``RedirectMessages`` wrapper
   routes emails to a test address and not to live email addresses.

Usage
------

Creating a simple SMTP mailer::


	from mailtools import SMTPMailer
        mailer = SMTPMailer('127.0.0.1')

This mailer will block until messages are sent and won't retry failures. Use
``ThreadedMailer`` to fix this::

        mailer = ThreadedMailer(SMTPMailer('127.0.0.1'))

Sending a plain text message::

        message = u'This is a plain text message'
        mailer.send_plain(
                u'sender@example.com',
                [u'recipient@example.com'],
                u'hi',
                message
        )

Sending an HTML message::

        message = u'<html><body>Look! HTML!</body></html>'
        mailer.send_html(
                u'sender@example.com',
                [u'recipient@example.com'],
                u'hi',
                message
        )

Adding attachments::

        message = u'index.rst is attached to this message'
        mailer.send_plain(
                u'sender@example.com',
                [u'recipient@example.com'],
                u'hi',
                message,
                attachments=['index.rst']
        )
''',

    classifiers=[
        'Development Status :: 3 - Alpha',
        'Topic :: Communications :: Email',
        'Environment :: Web Environment',
        'License :: OSI Approved :: BSD License',
        'Programming Language :: Python',
    ],

    keywords='',
    author='Oliver Cope',
    author_email='oliver@redgecko.org',
    url='',
    license='BSD',
    packages=find_packages(exclude=['ez_setup', 'examples', 'tests']),
    include_package_data=True,
    zip_safe=False,
    install_requires=[
        # -*- Extra requirements: -*-
    ],
    test_suite='nose.collector',
    tests_require=['nose'],
    entry_points="""
    # -*- Entry points: -*-
    """,
)
