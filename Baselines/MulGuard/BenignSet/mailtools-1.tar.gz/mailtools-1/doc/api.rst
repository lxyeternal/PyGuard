
Module API documentation
=========================

mailtools.mailer
----------------


.. automodule:: mailtools.mailer
        :members:

mailtools.utils
----------------

.. automodule:: mailtools.utils
        :members:


