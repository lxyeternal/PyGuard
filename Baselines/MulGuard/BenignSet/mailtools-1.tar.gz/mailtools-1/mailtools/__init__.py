"""
mailtools package.

Exports all symbols from ``mailtools.mailer``.
"""
__version__ = "1"

from mailtools.mailer import *
