# Various command line utils

## Installation

`$ pip install folkol-utils`
