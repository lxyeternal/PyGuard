Class = pricePerformance:

Evaluate the performance of single models.

- Append key performance statistics: Error, AbsError
- Append key performance and confidence semgmentations: Performance Bands, Confidence Bands
- Produce key statistics: performance and confidence band frequencies, confidence by condidence bands (# & &)

Class = comparePrice:

Compare the performance of models against each other.

- Supply a list of model 'pricePerformance' classes.
- Compare all combinations of models to show which perform stronger and weaker.