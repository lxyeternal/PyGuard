Ninja Printer is used to retrieve mails from a mailbox and print pdf attachments to the default printer.
A confirmation of print status is sent to each sender of an email that includes an attachment.
The default printer can be set on the CUPS host.