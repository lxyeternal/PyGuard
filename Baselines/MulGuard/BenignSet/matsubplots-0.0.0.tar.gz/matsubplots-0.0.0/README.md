# matsubplots

Better subplots for [matplotlib](https://matplotlib.org).

[![license](https://img.shields.io/github/license/auneri/matsubplots)](https://github.com/auneri/matsubplots/blob/main/LICENSE.md)
[![build](https://img.shields.io/github/actions/workflow/status/auneri/matsubplots/main.yml)](https://github.com/auneri/matsubplots/actions)

## Getting started

```shell
pip install git+https://github.com/auneri/matsubplots.git
```
