from distutils.core import setup
setup(
        name = "list_nester",
        version = "1.0.0",
        py_modules = ["list_nester"],
        author = "Saurabh Sharma",
        author_email = "crack2open@gmail.com",
        url = "headfirstlabs.com",
        description = "A simple printer of nested list"
        )


