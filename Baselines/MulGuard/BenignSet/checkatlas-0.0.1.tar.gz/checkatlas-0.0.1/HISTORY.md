Changelog
=========


(unreleased)
------------
- Release: version  🚀 [drbecavin]
- Release: version  🚀 [drbecavin]
- Release: version  🚀 [drbecavin]
- Release: version  🚀 [drbecavin]
- Release: version  🚀 [drbecavin]
- Clean project before release. [drbecavin]
- Release: version  🚀 [drbecavin]
- Add corrupted h5ad management with AnnDataReadError. [drbecavin]
- Add corrupted h5ad management with AnnDataReadError. [drbecavin]
- Add resume capacity in checkatlas.py. [drbecavin]
- Fix obs_beys selection. [drbecavin]
- Add list_atlases.csv. [drbecavin]
- Fix list files. [drbecavin]
- Add HLCA index names. [drbecavin]
- Release: version  🚀 [drbecavin]
- Clean project. [drbecavin]
- Clean files. [drbecavin]
- Remove rds from type of file. [christophe Becavin]
- Prepare checkatlas for discovair. [christophe Becavin]
- Clean all codes. make fmt, make lint, and make docs. [christophe
  Becavin]
- Make fmt. [christophe Becavin]
- Add read the docs conf. [christophe Becavin]
- Add read the docs conf. [christophe Becavin]
- Add read the docs conf. [christophe Becavin]
- Add read the docs conf. [christophe Becavin]
- Add read the docs conf. [christophe Becavin]
- Add all examples. [christophe Becavin]
- Add all examples. [christophe Becavin]
- Update README.md. [drbecavin]
- Update README.md. [drbecavin]
- Add example 2 and 3. [christophe Becavin]
- Add html examples. [christophe Becavin]
- Merge branch 'main' of github.com:becavin-lab/checkatlas. [christophe
  Becavin]
- Update README.md. [drbecavin]
- Add html examples. [christophe Becavin]
- Add Example 1 and 2. [christophe Becavin]
- Add examples to checkatlas. [christophe Becavin]
- Update README.md. [drbecavin]
- Reformat code. [christophe Becavin]
- #18 Add os.sep in filename, Put multihread=False by default.
  [christophe Becavin]
- Close #18, add folders.py to save all files in checkatlas_files/
  folder. [christophe Becavin]
- Merge branch 'main' of github.com:becavin-lab/checkatlas. [christophe
  Becavin]
- Update README.md. [drbecavin]

  Add summary
- Add pycharm run configuration. [christophe Becavin]
- First big update : Labmeeting presentation. Prototyp is ready.
  [christophe Becavin]
- Add Antoine metrics, add Dask. [christophe Becavin]
- Release: version  🚀 [christophe Becavin]
- Reformat and lint corrected. [christophe Becavin]
- Modifi atlas.py return statement. [christophe Becavin]
- Merge branch 'main' of github.com:becavin-lab/checkatlas. [christophe
  Becavin]
- Update README.md. [drbecavin]
- Add files for github workflow and template. [christophe Becavin]
- Clean project files. [christophe Becavin]
- Remove github templates from project creation. [christophe Becavin]
- Add git ignore. [christophe Becavin]
- Add git ignore. [christophe Becavin]
- ✅ Ready to clone and code. [drbecavin]
- First commit with many changes. [christophe Becavin]
- Initial commit. [drbecavin]


