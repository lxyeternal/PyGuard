def clust_analysis_external(adata, partition_key):
    """

    Parameters
    ----------
    adata
    partition_key

    Returns
    -------

    """


def clust_analysis_internal(adata, partition_key):
    """

    Parameters
    ----------
    adata
    partition_key

    Returns
    -------

    """
