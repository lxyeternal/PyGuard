# psdm-analysis

The psdm-analysis tool is meant to parse the [Power System Data Model (PSDM)](https://github.com/ie3-institute/PowerSystemDataModel) as well as provide calculation and plotting utilities to analyze the respective data.

It is currently under development and therefore highly unstable. So if you want to use it, expect it to change quite frequently for now.