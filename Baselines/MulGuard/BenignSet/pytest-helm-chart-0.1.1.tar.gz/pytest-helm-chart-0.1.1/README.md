# pytest-kube-provider

A plugin to provide different types and configs of Kubernetes clusters that can be used for testing.

---



## Features

* TODO


## Requirements

* TODO


## Installation

You can install "pytest-kube-provider" via `pip` from `PyPI`:

```
$ pip install pytest-kube-provider
```


## Usage

* TODO

## Contributing

Contributions are very welcome. Tests can be run with `tox`_, please ensure
the coverage at least stays the same before you submit a pull request.

## License

See [LICENSE](LICENSE).

## Issues

If you encounter any problems, please [file an issue](https://github.com/piontec/pytest-kube-provider/issues) along with a detailed description.

