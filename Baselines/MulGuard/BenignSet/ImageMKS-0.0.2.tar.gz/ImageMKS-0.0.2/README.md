ImageMKS is a package for sharing segmentation frameworks.
