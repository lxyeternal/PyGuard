from setuptools import setup, find_packages
import sys
sys.path[0:0] = ['src/gscrud']


setup(
    name='lkinterface',
    version='0.1',
    description='LavKode interfaces',
    long_description='LavKode interfaces',
    author='muthugit',
    author_email='base.muthupandian@gmail.com',
    url='https://muthupandian.in',
    packages=['lkinterface'],
)