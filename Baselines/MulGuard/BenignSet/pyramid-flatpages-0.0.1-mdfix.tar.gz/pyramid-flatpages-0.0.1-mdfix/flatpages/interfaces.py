from zope.interface import Interface

class IFlatPagesRoot(Interface):
    """ Any class that implements this interface will be respected as the root
    of our flatpages URI.

    """

    pass
