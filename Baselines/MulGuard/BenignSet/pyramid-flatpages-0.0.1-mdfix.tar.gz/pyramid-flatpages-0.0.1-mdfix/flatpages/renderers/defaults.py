renderers = {
    'flatpages.renderers.markdown.MarkdownRendererFactory': [
        'md',
        'markdown'
    ],
}
