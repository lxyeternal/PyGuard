def add_one(number):
    return number + 1

print('#'*20)
print(' NETWORK TOOLS - v0.0.1')
