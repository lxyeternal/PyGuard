def vprint(variables, sep ='\n'):
    vars = variables.split(',')
    for var in vars:
      print(var.strip(), '=', repr(eval(var)), end = sep)