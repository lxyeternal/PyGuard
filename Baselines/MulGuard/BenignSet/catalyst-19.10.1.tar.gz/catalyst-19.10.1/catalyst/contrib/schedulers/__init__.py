# flake8: noqa
from torch.optim.lr_scheduler import *
from .base import BaseScheduler, BatchScheduler
from .onecycle import OneCycleLR
