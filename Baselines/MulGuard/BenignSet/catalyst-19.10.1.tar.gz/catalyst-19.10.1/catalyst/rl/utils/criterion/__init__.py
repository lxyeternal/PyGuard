# flake8: noqa

from .categorical import categorical_loss
from .quantile import quantile_loss
