def foo(a, b):
    return dict(a=a, b=b)


def bar():
    pass


__all__ = ["foo"]
