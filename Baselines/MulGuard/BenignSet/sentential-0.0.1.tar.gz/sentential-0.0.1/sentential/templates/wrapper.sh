#!/bin/bash

chamber exec $PREFIX -- $@