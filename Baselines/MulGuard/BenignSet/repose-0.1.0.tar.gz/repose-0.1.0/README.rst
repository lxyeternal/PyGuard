Repose - Python API client framework
====================================

.. image:: https://img.shields.io/pypi/v/repose.svg
    :target: https://badge.fury.io/py/repose

.. image:: https://img.shields.io/pypi/dm/repose.svg
    :target: https://pypi.python.org/pypi/repose

.. image:: https://img.shields.io/github/license/adamcharnock/repose.svg
    :target: https://pypi.python.org/pypi/repose/

.. image:: https://img.shields.io/travis/adamcharnock/repose.svg
    :target: https://travis-ci.org/adamcharnock/repose/

.. image:: https://coveralls.io/repos/adamcharnock/repose/badge.svg
    :target: https://coveralls.io/r/adamcharnock/repose/

Tested on Python 2.7, 3.2, 3.3, 3.4, 3.5

Installation
------------

Installation using pip::

    pip install repose

Usage
-----

*Usage instructions here*

Credits
-------

Developed by `Adam Charnock`_, contributions very welcome!

repose is packaged using repose_.

.. _repose: https://github.com/adamcharnock/repose/
.. _Adam Charnock: https://adamcharnock.com

