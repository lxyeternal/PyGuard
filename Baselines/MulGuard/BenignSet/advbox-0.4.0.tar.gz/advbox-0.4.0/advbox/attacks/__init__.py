"""
Attack methods __init__.py
"""
