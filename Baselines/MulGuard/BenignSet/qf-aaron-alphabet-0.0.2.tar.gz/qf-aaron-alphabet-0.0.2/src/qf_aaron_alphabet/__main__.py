from qf_aaron_alphabet import main

main()

