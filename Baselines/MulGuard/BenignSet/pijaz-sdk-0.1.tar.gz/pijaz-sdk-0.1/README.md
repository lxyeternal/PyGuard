Pijaz Python SDK
=================

Pijaz SDK for [Python](https://www.python.org)


### Initial platform setup

See [Initial platform setup](https://github.com/pijaz/pijaz-sdk#initial-platform-setup) in the main README for the SDK.


### API

The main API documentation resides in the [README](https://github.com/pijaz/pijaz-sdk#api) for the SDK.

