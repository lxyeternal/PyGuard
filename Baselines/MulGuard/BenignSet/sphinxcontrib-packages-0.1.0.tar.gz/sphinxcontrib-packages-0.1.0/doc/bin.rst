Installed binaries
==================

This information is provided by the directive::

  .. packages:bin::

It iterates over directories of the ``PATH`` environment variable, and list
binaries available in those.

.. packages:bin::
