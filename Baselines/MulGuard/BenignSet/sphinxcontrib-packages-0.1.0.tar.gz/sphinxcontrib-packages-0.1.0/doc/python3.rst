Installed python3 packages
==========================

This information is provided by the directive::

  .. packages:python3::

It lists available python2 packgaes. Note that system packages may not be
displayed if run in a `virtualenv`.

.. packages:python3::
