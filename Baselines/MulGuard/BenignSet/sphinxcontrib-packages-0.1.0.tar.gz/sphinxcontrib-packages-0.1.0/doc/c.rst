Installed C libraries
=====================

This information is provided by the directive::

  .. packages:c::

List available C libraries. This is done using the ``ldconfig`` command. An
alternative way to get this information is to look at the ``*-dev`` deb
packages (if current system is or inherits from Debian).

.. packages:c::
