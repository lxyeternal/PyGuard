Installed python2 packages
==========================

This information is provided by the directive::

  .. packages:python2::

It lists available python2 packgaes. Note that system packages may not be
displayed if run in a `virtualenv`.

.. packages:python2::
