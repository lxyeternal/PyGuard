Installed LaTeX packages
========================

This information is provided by the directive::

  .. packages:latex::

It lists installed LaTeX packages. It uses the `kpsepath` binary.

.. packages:latex::
