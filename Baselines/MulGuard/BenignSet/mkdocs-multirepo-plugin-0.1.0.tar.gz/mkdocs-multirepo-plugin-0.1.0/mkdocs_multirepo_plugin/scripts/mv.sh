#!/bin/bash

mv "$1"/* .
rm -rf $1
