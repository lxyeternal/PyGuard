class IvenResponse:
    def __init__(self):
        self.iven_code = 0
        self.description = None
        self.message = None
        self.task = 0
        self.need_conf_update = False
        self.need_firm_update = False
        self.api_key = None
        self.device_uid = None
        self.status = 0
