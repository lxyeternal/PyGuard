class SnapshotError(Exception):
    pass
