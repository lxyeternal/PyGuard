====================================
Pegasus for Single Cell Analysis
====================================

Pegasus is a tool for analyzing transcriptomes of millions of single cells. It is a command line tool, a python package and a base for Cloud-based analysis workflows.

`Read documentation <http://sccloudpy.readthedocs.io>`__
