from .data_structure import Array2D, MemData
from .io import infer_file_format, read_input, write_output
