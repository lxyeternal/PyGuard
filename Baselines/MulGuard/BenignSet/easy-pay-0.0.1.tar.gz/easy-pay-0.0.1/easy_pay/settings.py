time_zone = "Asia/Shanghai"
order_time_expire = 60 * 10 + 60 * 2
wechat_domain = "https://api.mch.weixin.qq.com"

