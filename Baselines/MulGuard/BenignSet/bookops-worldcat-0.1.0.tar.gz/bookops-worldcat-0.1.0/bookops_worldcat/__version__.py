__title__ = "bookops-worldcat"
__version__ = "0.1.0"
__author__ = "Tomasz Kalata"
__author_email__ = "klingaroo@gmail.com"
