Sir-bot-a-lot
=============

The good Sir Bot-a-lot. An asynchronous python bot framework.
