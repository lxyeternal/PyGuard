from .plugin import SlackPlugin  # noQa: F401
