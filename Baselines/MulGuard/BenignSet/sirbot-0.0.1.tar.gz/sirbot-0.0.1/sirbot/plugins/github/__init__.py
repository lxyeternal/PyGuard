from .plugin import GithubPlugin  # noQa: F401
