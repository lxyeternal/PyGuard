Hypatia
=======

A Python indexing and searching system.

See http://github.com/Pylons/hypatia for more information while this package
is in alpha development.
