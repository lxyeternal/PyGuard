:mod:`hypatia` Change History
=============================

.. literalinclude:: ../CHANGES.txt
