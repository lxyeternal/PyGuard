Simple test
------------

Ensure your device works with this simple test.

.. literalinclude:: ../examples/customvision_simpletest.py
    :caption: examples/customvision_simpletest.py
    :linenos:
