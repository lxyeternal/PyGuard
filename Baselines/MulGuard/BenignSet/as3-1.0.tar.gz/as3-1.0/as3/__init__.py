__version__ = '1.0'
from as3 import as3
