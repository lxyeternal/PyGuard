from .deepspeech2_v1 import get_deepspeech2_v1
from .deepspeech2_v2 import get_deepspeech2_v2
from .deepasrnetwork1 import get_deepasrnetwork1
