from setuptools import setup

setup(name='gaussion_and_binomial_distributions',
      version='0.1',
      description='Gaussian distributions',
      packages=['gaussion_and_binomial_distributions'],
      zip_safe=False)
