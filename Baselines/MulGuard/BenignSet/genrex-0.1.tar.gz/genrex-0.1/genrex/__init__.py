
from typing import Generator
from genrex.pattern import parse