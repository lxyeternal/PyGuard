from basic_sdk import application

if __name__ == "__main__":
    application()
