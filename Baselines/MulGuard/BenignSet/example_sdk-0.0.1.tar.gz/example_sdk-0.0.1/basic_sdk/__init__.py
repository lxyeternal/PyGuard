from basic_sdk.cli.application import app as application

__all__ = ("application",)
