class Platform:
    def __init__(self, *args, **kwargs):
        super(Platform, self).__init__(*args, **kwargs)
