https://yandex.ru/support/market-distr/product-feed.html

https://dev.vk.com/method/market
https://ads.vk.com/help/articles/ecomm_catalog

https://docs.google.com/document/d/1_zBRRCNoM7uxe6xPHn5ztTFi55ANqjKKDA3XM1MvLEc/edit

https://partner-api.youla.io/swagger/rapi#overview
https://partner-api.youla.io/swagger/ui

https://www.avito.ru/autoload/documentation/templates/1196267