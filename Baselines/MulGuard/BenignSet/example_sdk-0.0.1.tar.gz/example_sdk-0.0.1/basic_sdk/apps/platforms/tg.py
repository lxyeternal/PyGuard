from gdshoplib.apps.platforms.base import Platform


class TgManager(Platform):
    KEY = "TG"
