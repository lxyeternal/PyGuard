from gdshoplib.apps.platforms.base import Platform


class OkManager(Platform):
    KEY = "OK"
