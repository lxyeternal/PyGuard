from gdshoplib.apps.platforms.base import Platform


class InstagramManager(Platform):
    DESCRIPTION_TEMPLATE = "instagram.txt"
    KEY = "INSTAGRAM"
