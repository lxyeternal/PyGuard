from .modelwrapper import ModelWrapper
from .utils.log_configuration import set_logger_config

set_logger_config()
