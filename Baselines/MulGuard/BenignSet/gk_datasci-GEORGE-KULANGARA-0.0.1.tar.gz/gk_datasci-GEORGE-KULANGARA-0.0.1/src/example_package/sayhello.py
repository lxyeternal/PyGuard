def hi(name):
    print("hello " + str(name) + ", how are you today?")


