def add_five(number):
    return number + 5