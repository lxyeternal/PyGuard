__title__ = 'ohashi'
__author__ = 'Bryan Veloso'
__version__ = '0.0.10'
__license__ = 'BSD'
