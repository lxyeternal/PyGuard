from django.apps import AppConfig


class TopicsConfig(AppConfig):
    name = 'oldp.apps.topics'
