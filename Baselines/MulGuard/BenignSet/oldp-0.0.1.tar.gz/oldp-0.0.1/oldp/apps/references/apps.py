from django.apps import AppConfig


class ReferencesConfig(AppConfig):
    name = 'oldp.apps.references'
