from oldp.apps.backend.processing.processing_steps import BaseProcessingStep


class PostProcessingStep(BaseProcessingStep):
    def process(self, content):
        pass
