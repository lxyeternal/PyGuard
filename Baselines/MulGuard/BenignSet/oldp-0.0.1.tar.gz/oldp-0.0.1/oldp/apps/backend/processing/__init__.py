

class ProcessingError(ValueError):
    pass


class AmbiguousReferenceError(ProcessingError):
    pass


