
from django.apps import AppConfig


class BackendConfig(AppConfig):
    name = 'oldp.apps.backend'
