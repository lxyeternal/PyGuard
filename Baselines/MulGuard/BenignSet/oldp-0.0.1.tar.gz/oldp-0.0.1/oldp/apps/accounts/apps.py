from django.apps import AppConfig


class AccountsConfig(AppConfig):
    """This app is only an extension to the account management from django-allauth."""
    name = 'oldp.apps.accounts'
