from activity_stream.models import * 
from django.contrib import admin

admin.site.register(ActivityFollower)
admin.site.register(ActivityTypes)
admin.site.register(ActivityStreamItem)
