"""Mel cepstral distortion (MCD) computations in python."""

# Copyright 2014 Matt Shannon

# This file is part of mcd.
# See `License` for details of license and warranty.


__version__ = '0.1'
