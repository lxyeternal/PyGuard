=======
colonel
=======

.. image:: https://travis-ci.org/nlpodyssey/colonel.svg?branch=master
    :target: https://travis-ci.org/nlpodyssey/colonel

.. image:: https://codecov.io/gh/nlpodyssey/colonel/branch/master/graph/badge.svg
  :target: https://codecov.io/gh/nlpodyssey/colonel

.. image:: https://coveralls.io/repos/github/nlpodyssey/colonel/badge.svg?branch=master
  :target: https://coveralls.io/github/nlpodyssey/colonel?branch=master

.. image:: https://readthedocs.org/projects/colonel/badge/?version=latest
  :target: http://colonel.readthedocs.io/en/latest/?badge=latest
  :alt: Documentation Status

**Colonel** is a *Python 3* library for handling *CoNLL* data formats.
