===================
iw.releaser package
===================

You may find documentation in:

- Global README.txt: iw/releaser/docs/README.txt
- General: iw/releaser/docs
- Technical: iw/releaser/doctest

This package is created and maintained by Ingeniweb_.

.. _Ingeniweb: http://www.ingeniweb.com

