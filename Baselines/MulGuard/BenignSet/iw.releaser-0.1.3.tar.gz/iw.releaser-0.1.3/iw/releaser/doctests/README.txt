========
Doctests
========

This folder contains doctests for iw.releaser package.

