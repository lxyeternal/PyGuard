see docs/README.txt

