================
my.package package
================

.. contents::

What is my.package ?
==================

Explain here what is the purpose of my.package.

How to use my.package ?
=====================

Explain here how the package is used. Points to doctests here !




