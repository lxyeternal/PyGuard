==================
my.package package
==================

You may find documentation in:

- Global README.txt: my/package/docs/README.txt
- General: my/package/docs
- Technical: my/package/doctest

This package is created and maintained by Ingeniweb_.

.. _Ingeniweb: http://www.ingeniweb.com

