""" 
lipidoz/__init__.py

Joon-Yong Lee (junyoni@gmail.com)
Dylan Ross (dylan.ross@pnnl.gov)

    LipidOZ
    
"""


# release.major_version.minor_version
__version__ = '0.9.4'
