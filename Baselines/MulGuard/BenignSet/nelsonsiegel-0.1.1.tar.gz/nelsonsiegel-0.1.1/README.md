# nelsonsiegel
Suites for Nelson-Siegel style curve modeling in Python
