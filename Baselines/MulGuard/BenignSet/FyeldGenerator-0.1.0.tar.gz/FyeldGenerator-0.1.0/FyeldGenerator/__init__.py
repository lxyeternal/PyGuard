# -*- coding: utf-8 -*-

from .core import generate_field

