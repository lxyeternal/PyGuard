#!/usr/bin/python
# Filename: hello.py

def world():
  print 'Hello World!'
  return "Hello from Py-Sample"

version = '0.1'

# End of hello.py