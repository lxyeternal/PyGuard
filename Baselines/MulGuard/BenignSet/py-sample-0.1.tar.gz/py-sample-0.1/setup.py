#!/usr/bin/env python

from distutils.core import setup

setup(
    name='py-sample',
    version='0.1',
    description='Sample package for Gemfury',
    author='Michael Rykov',
    author_email='michael@gemfury.com',
    url='http://www.gemfury.com',
    packages=['py_sample'])