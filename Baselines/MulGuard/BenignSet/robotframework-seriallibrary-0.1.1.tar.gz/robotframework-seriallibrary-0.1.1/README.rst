====================================
SerialLibrary for Robot Framework
====================================

This is a serial port test library for Robot Framework.

