from prometheus_mysql_exporter import main

if __name__ == '__main__':
    main()
