"""
Datatypes for brewing. 
"""

