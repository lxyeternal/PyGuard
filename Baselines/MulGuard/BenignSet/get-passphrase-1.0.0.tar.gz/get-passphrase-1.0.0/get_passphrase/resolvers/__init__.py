from .standard_resolvers import *
