# Upload API

Simple file uploading handler.

## Installation

```sh
pip install px-django-upload
```

In `settings.py`:

```python
INSTALLED_APPS += [
  'pxd_upload',
]
```
