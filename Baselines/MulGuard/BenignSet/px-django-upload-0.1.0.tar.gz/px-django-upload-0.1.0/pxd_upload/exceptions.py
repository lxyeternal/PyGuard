class UploadException(Exception):
    pass
