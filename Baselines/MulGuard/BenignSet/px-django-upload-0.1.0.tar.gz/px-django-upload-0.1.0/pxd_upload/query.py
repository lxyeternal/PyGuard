from django.db import models


__all__ = 'UploadQuerySet',


class UploadQuerySet(models.QuerySet):
    pass
