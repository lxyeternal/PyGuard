__all__ = 'autodiscover',


def autodiscover():
    pass
