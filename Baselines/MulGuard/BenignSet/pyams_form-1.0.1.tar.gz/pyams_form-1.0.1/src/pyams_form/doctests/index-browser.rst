Browser support documentation
=============================

Contents:

.. toctree::
   :maxdepth: 2

   browser
   widget-button
   widget-checkbox
   widget-file
   widget-file-testing
   widget-image
   widget-multi
   widget-object
   widget-objectmulti
   widget-orderedselect
   widget-password
   widget-radio
   widget-select
   widget-select-source
   widget-submit
   widget-text
   widget-textarea
   widget-textlines


Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`
