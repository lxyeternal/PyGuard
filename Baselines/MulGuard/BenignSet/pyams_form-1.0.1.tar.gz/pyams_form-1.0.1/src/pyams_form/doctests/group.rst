===========
Group Forms
===========

Group forms allow you to split up a form into several logical units without
much overhead. To the parent form, groups should be only dealt with during
coding and be transparent on the data extraction level.

For the examples to work, we have to bring up most of the form framework:

  >>> from pyramid.testing import setUp, tearDown
  >>> config = setUp()

  >>> from pyams_utils import includeme as include_utils
  >>> include_utils(config)
  >>> from pyams_site import includeme as include_site
  >>> include_site(config)
  >>> from pyams_i18n import includeme as include_i18n
  >>> include_i18n(config)
  >>> from pyams_form import includeme as include_form
  >>> include_form(config)

  >>> from pyams_form import interfaces, util, testing
  >>> testing.setup_form_defaults(config.registry)

So let's first define a complex content component that warrants setting up
multiple groups:

  >>> import zope.interface
  >>> import zope.schema

  >>> class IVehicleRegistration(zope.interface.Interface):
  ...     firstName = zope.schema.TextLine(title='First Name')
  ...     lastName = zope.schema.TextLine(title='Last Name')
  ...
  ...     license = zope.schema.TextLine(title='License')
  ...     address = zope.schema.TextLine(title='Address')
  ...
  ...     model = zope.schema.TextLine(title='Model')
  ...     make = zope.schema.TextLine(title='Make')
  ...     year = zope.schema.TextLine(title='Year')

  >>> @zope.interface.implementer(IVehicleRegistration)
  ... class VehicleRegistration(object):
  ...
  ...     def __init__(self, **kw):
  ...         for name, value in kw.items():
  ...             setattr(self, name, value)

The schema above can be separated into basic, license, and car information,
where the latter two will be placed into groups. First we create the two
groups:

  >>> from pyams_form import field, group

  >>> class LicenseGroup(group.Group):
  ...     label = 'License'
  ...     fields = field.Fields(IVehicleRegistration).select(
  ...         'license', 'address')

  >>> class CarGroup(group.Group):
  ...     label = 'Car'
  ...     fields = field.Fields(IVehicleRegistration).select(
  ...         'model', 'make', 'year')

Most of the group is setup like any other (sub)form. Additionally, you can
specify a label, which is a human-readable string that can be used for layout
purposes.

Let's now create an add form for the entire vehicle registration. In
comparison to a regular add form, you only need to add the ``GroupForm`` as
one of the base classes. The groups are specified in a simple tuple:

  >>> import os
  >>> from pyams_form import form, tests

  >>> class RegistrationAddForm(group.GroupForm, form.AddForm):
  ...     fields = field.Fields(IVehicleRegistration).select(
  ...         'firstName', 'lastName')
  ...     groups = (LicenseGroup, CarGroup)
  ...
  ...     def create(self, data):
  ...         return VehicleRegistration(**data)
  ...
  ...     def add(self, object):
  ...         self.get_content()['obj1'] = object
  ...         return object

  >>> from pyams_template.interfaces import IContentTemplate
  >>> from pyams_template.template import TemplateFactory
  >>> from pyams_layer.interfaces import IFormLayer
  >>> factory = TemplateFactory(os.path.join(os.path.dirname(tests.__file__),
  ...                           'templates', 'simple-groupedit.pt'), 'text/html')
  >>> config.registry.registerAdapter(factory, (None, IFormLayer, RegistrationAddForm), IContentTemplate)

Note: The order of the base classes is very important here. The ``GroupForm``
class must be left of the ``AddForm`` class, because the ``GroupForm`` class
overrides some methods of the ``AddForm`` class.

Now we can instantiate the form:

  >>> request = testing.TestRequest()

  >>> add = RegistrationAddForm(None, request)
  >>> add.update()

After the form is updated the tuple of group classes is converted to group
instances:

  >>> add.groups
  (<....LicenseGroup object at ...>, <....CarGroup object at ...>)

If we happen to update the add form again, the groups that have
already been converted to instances ares skipped.

  >>> add.update()
  >>> add.groups
  (<....LicenseGroup object at ...>, <....CarGroup object at ...>)

We can now render the form:

  >>> from pyams_utils.testing import format_html, render_xpath
  >>> print(format_html(add.render()))
    <form action=".">
        <div class="row">
          <label for="form-widgets-firstName">First Name</label>
          <input type="text"
           id="form-widgets-firstName"
           name="form.widgets.firstName"
           class="text-widget required textline-field"
           value="" />
        </div>
        <div class="row">
          <label for="form-widgets-lastName">Last Name</label>
          <input type="text"
           id="form-widgets-lastName"
           name="form.widgets.lastName"
           class="text-widget required textline-field"
           value="" />
        </div>
      <fieldset>
        <legend>License</legend>
        <div class="row">
          <label for="form-widgets-license">License</label>
          <input type="text"
           id="form-widgets-license"
           name="form.widgets.license"
           class="text-widget required textline-field"
           value="" />
        </div>
        <div class="row">
          <label for="form-widgets-address">Address</label>
          <input type="text"
           id="form-widgets-address"
           name="form.widgets.address"
           class="text-widget required textline-field"
           value="" />
        </div>
      </fieldset>
      <fieldset>
        <legend>Car</legend>
        <div class="row">
          <label for="form-widgets-model">Model</label>
          <input type="text"
           id="form-widgets-model"
           name="form.widgets.model"
           class="text-widget required textline-field"
           value="" />
        </div>
        <div class="row">
          <label for="form-widgets-make">Make</label>
          <input type="text"
           id="form-widgets-make"
           name="form.widgets.make"
           class="text-widget required textline-field"
           value="" />
        </div>
        <div class="row">
          <label for="form-widgets-year">Year</label>
          <input type="text"
           id="form-widgets-year"
           name="form.widgets.year"
           class="text-widget required textline-field"
           value="" />
        </div>
      </fieldset>
      <div class="action">
          <input type="submit"
           id="form-buttons-add"
           name="form.buttons.add"
           class="submit-widget"
           value="Add" />
      </div>
    </form>


Registering a custom event handler for the DataExtractedEvent
--------------------------------------------------------------

  >>> data_extracted_eventlog = []
  >>> def data_extracted_logger(event):
  ...     data_extracted_eventlog.append(event)
  >>> _ = config.add_subscriber(data_extracted_logger, interfaces.form.IDataExtractedEvent)


Let's now submit the form, but forgetting to enter the address:

  >>> request = testing.TestRequest(params={
  ...     'form.widgets.firstName': 'Stephan',
  ...     'form.widgets.lastName': 'Richter',
  ...     'form.widgets.license': 'MA 40387',
  ...     'form.widgets.model': 'BMW',
  ...     'form.widgets.make': '325',
  ...     'form.widgets.year': '2005',
  ...     'form.buttons.add': 'Add'
  ...     })

  >>> add = RegistrationAddForm(None, request)
  >>> add.update()
  >>> print(render_xpath(add, './/i'))
  <i>There were some errors.</i>

  >>> print(render_xpath(add, './/fieldset[1]/ul'))
  <ul>
    <li>
      Address: <div class="error">Required input is missing.</div>
    </li>
  </ul>

As you can see, the template is clever enough to just report the errors at the
top of the form, but still report the actual problem within the group.


Check, if DataExtractedEvent was thrown:

  >>> len(data_extracted_eventlog) > 0
  True


So what happens, if errors happen inside and outside a group?

  >>> request = testing.TestRequest(params={
  ...     'form.widgets.firstName': 'Stephan',
  ...     'form.widgets.license': 'MA 40387',
  ...     'form.widgets.model': 'BMW',
  ...     'form.widgets.make': '325',
  ...     'form.widgets.year': '2005',
  ...     'form.buttons.add': 'Add'
  ...     })

  >>> add = RegistrationAddForm(None, request)
  >>> add.update()

  >>> print(render_xpath(add, './/i'))
  <i>There were some errors.</i>

  >>> print(render_xpath(add, './/ul'))
  <ul>
    <li>
    Last Name:
      <div class="error">Required input is missing.</div>
    </li>
  </ul>
  <ul>
    <li>
    Address:
      <div class="error">Required input is missing.</div>
    </li>
  </ul>

  >>> print(render_xpath(add, './/fieldset[1]/ul'))
  <ul>
    <li>
      Address: <div class="error">Required input is missing.</div>
    </li>
  </ul>

Let's now successfully complete the add form.

  >>> from zope.container import btree
  >>> context = btree.BTreeContainer()

  >>> request = testing.TestRequest(params={
  ...     'form.widgets.firstName': 'Stephan',
  ...     'form.widgets.lastName': 'Richter',
  ...     'form.widgets.license': 'MA 40387',
  ...     'form.widgets.address': '10 Main St, Maynard, MA',
  ...     'form.widgets.model': 'BMW',
  ...     'form.widgets.make': '325',
  ...     'form.widgets.year': '2005',
  ...     'form.buttons.add': 'Add'
  ...     })

  >>> add = RegistrationAddForm(context, request)
  >>> add.update()

The object is now added to the container and all attributes should be set:

  >>> reg = context['obj1']
  >>> reg.firstName
  'Stephan'
  >>> reg.lastName
  'Richter'
  >>> reg.license
  'MA 40387'
  >>> reg.address
  '10 Main St, Maynard, MA'
  >>> reg.model
  'BMW'
  >>> reg.make
  '325'
  >>> reg.year
  '2005'

Let's now have a look at an edit form for the vehicle registration:

  >>> class RegistrationEditForm(group.GroupForm, form.EditForm):
  ...     fields = field.Fields(IVehicleRegistration).select(
  ...         'firstName', 'lastName')
  ...     groups = (LicenseGroup, CarGroup)

  >>> config.registry.registerAdapter(factory, (None, IFormLayer, RegistrationEditForm), IContentTemplate)

  >>> request = testing.TestRequest()

  >>> edit = RegistrationEditForm(reg, request)
  >>> edit.update()

After updating the form, we can render the HTML:

  >>> print(format_html(edit.render()))
  <form action=".">
      <div class="row">
        <label for="form-widgets-firstName">First Name</label>
        <input type="text"
         id="form-widgets-firstName"
         name="form.widgets.firstName"
         class="text-widget required textline-field"
         value="Stephan" />
      </div>
      <div class="row">
        <label for="form-widgets-lastName">Last Name</label>
        <input type="text"
         id="form-widgets-lastName"
         name="form.widgets.lastName"
         class="text-widget required textline-field"
         value="Richter" />
      </div>
    <fieldset>
      <legend>License</legend>
      <div class="row">
        <label for="form-widgets-license">License</label>
        <input type="text"
         id="form-widgets-license"
         name="form.widgets.license"
         class="text-widget required textline-field"
         value="MA 40387" />
      </div>
      <div class="row">
        <label for="form-widgets-address">Address</label>
        <input type="text"
         id="form-widgets-address"
         name="form.widgets.address"
         class="text-widget required textline-field"
         value="10 Main St, Maynard, MA" />
      </div>
    </fieldset>
    <fieldset>
      <legend>Car</legend>
      <div class="row">
        <label for="form-widgets-model">Model</label>
        <input type="text"
         id="form-widgets-model"
         name="form.widgets.model"
         class="text-widget required textline-field"
         value="BMW" />
      </div>
      <div class="row">
        <label for="form-widgets-make">Make</label>
        <input type="text"
         id="form-widgets-make"
         name="form.widgets.make"
         class="text-widget required textline-field"
         value="325" />
      </div>
      <div class="row">
        <label for="form-widgets-year">Year</label>
        <input type="text"
         id="form-widgets-year"
         name="form.widgets.year"
         class="text-widget required textline-field"
         value="2005" />
      </div>
    </fieldset>
    <div class="action">
        <input type="submit"
         id="form-buttons-apply"
         name="form.buttons.apply"
         class="submit-widget"
         value="Apply" />
    </div>
  </form>

The behavior when an error occurs is identical to that of the add form:

  >>> request = testing.TestRequest(params={
  ...     'form.widgets.firstName': 'Stephan',
  ...     'form.widgets.lastName': 'Richter',
  ...     'form.widgets.license': 'MA 40387',
  ...     'form.widgets.model': 'BMW',
  ...     'form.widgets.make': '325',
  ...     'form.widgets.year': '2005',
  ...     'form.buttons.apply': 'Apply'
  ...     })

  >>> edit = RegistrationEditForm(reg, request)
  >>> edit.update()
  >>> print(render_xpath(edit, './/i'))
  <i>There were some errors.</i>

  >>> print(render_xpath(edit, './/ul'))
  <ul>
    <li>
    Address:
      <div class="error">Required input is missing.</div>
    </li>
  </ul>

  >>> print(render_xpath(edit, './/fieldset/ul'))
  <ul>
    <li>
      Address: <div class="error">Required input is missing.</div>
    </li>
  </ul>

When an edit form with groups is successfully committed, a detailed
object-modified event is sent out telling the system about the changes.
To see the error, let's create an event subscriber for object-modified events:

  >>> eventlog = []
  >>> import zope.lifecycleevent
  >>> def logEvent(event):
  ...     eventlog.append(event)
  >>> _ = config.add_subscriber(logEvent, zope.lifecycleevent.interfaces.IObjectModifiedEvent)


Let's now complete the form successfully:

  >>> request = testing.TestRequest(params={
  ...     'form.widgets.firstName': 'Stephan',
  ...     'form.widgets.lastName': 'Richter',
  ...     'form.widgets.license': 'MA 4038765',
  ...     'form.widgets.address': '11 Main St, Maynard, MA',
  ...     'form.widgets.model': 'Ford',
  ...     'form.widgets.make': 'F150',
  ...     'form.widgets.year': '2006',
  ...     'form.buttons.apply': 'Apply'
  ...     })

  >>> edit = RegistrationEditForm(reg, request)
  >>> edit.update()

The success message will be shown on the form, ...

  >>> print(render_xpath(edit, './/i'))
  <i>Data successfully updated.</i>

and the data are correctly updated:

  >>> reg.firstName
  'Stephan'
  >>> reg.lastName
  'Richter'
  >>> reg.license
  'MA 4038765'
  >>> reg.address
  '11 Main St, Maynard, MA'
  >>> reg.model
  'Ford'
  >>> reg.make
  'F150'
  >>> reg.year
  '2006'

Let's look at the event:

  >>> event = eventlog[-1]
  >>> event
  <zope...ObjectModifiedEvent object at ...>

The event's description contains the changed Interface and the names of
all changed fields, even if they where in different groups:

  >>> attrs = event.descriptions[0]
  >>> attrs.interface
  <InterfaceClass ....IVehicleRegistration>
  >>> attrs.attributes
  ('license', 'address', 'model', 'make', 'year')


Group form as instance
----------------------

It is also possible to use group instances in forms. Let's setup our previous
form and assing a group instance:

  >>> class RegistrationEditForm(group.GroupForm, form.EditForm):
  ...     fields = field.Fields(IVehicleRegistration).select(
  ...         'firstName', 'lastName')

  >>> config.registry.registerAdapter(factory, (None, IFormLayer, RegistrationEditForm), IContentTemplate)
  >>> request = testing.TestRequest()

  >>> edit = RegistrationEditForm(reg, request)

Instanciate the form and use a group class and a group instance:

  >>> carGroupInstance = CarGroup(edit.context, request, edit)
  >>> edit.groups = (LicenseGroup, carGroupInstance)
  >>> edit.update()
  >>> print(format_html(edit.render()))
  <form action=".">
      <div class="row">
        <label for="form-widgets-firstName">First Name</label>
        <input type="text"
         id="form-widgets-firstName"
         name="form.widgets.firstName"
         class="text-widget required textline-field"
         value="Stephan" />
      </div>
      <div class="row">
        <label for="form-widgets-lastName">Last Name</label>
        <input type="text"
         id="form-widgets-lastName"
         name="form.widgets.lastName"
         class="text-widget required textline-field"
         value="Richter" />
      </div>
    <fieldset>
      <legend>License</legend>
      <div class="row">
        <label for="form-widgets-license">License</label>
        <input type="text"
         id="form-widgets-license"
         name="form.widgets.license"
         class="text-widget required textline-field"
         value="MA 4038765" />
      </div>
      <div class="row">
        <label for="form-widgets-address">Address</label>
        <input type="text"
         id="form-widgets-address"
         name="form.widgets.address"
         class="text-widget required textline-field"
         value="11 Main St, Maynard, MA" />
      </div>
    </fieldset>
    <fieldset>
      <legend>Car</legend>
      <div class="row">
        <label for="form-widgets-model">Model</label>
        <input type="text"
         id="form-widgets-model"
         name="form.widgets.model"
         class="text-widget required textline-field"
         value="Ford" />
      </div>
      <div class="row">
        <label for="form-widgets-make">Make</label>
        <input type="text"
         id="form-widgets-make"
         name="form.widgets.make"
         class="text-widget required textline-field"
         value="F150" />
      </div>
      <div class="row">
        <label for="form-widgets-year">Year</label>
        <input type="text"
         id="form-widgets-year"
         name="form.widgets.year"
         class="text-widget required textline-field"
         value="2006" />
      </div>
    </fieldset>
    <div class="action">
        <input type="submit"
         id="form-buttons-apply"
         name="form.buttons.apply"
         class="submit-widget"
         value="Apply" />
    </div>
  </form>

Groups with Different Content
-----------------------------

You can customize the content for a group by overriding a group's
``get_content`` method.  This is a very easy way to get around not
having object widgets.  For example, suppose we want to maintain the
vehicle owner's information in a separate class than the vehicle.  We
might have an ``IVehicleOwner`` interface like so.

  >>> class IVehicleOwner(zope.interface.Interface):
  ...     firstName = zope.schema.TextLine(title='First Name')
  ...     lastName = zope.schema.TextLine(title='Last Name')

Then out ``IVehicleRegistration`` interface would include an object
field for the owner instead of the ``firstName`` and ``lastName``
fields.

  >>> class IVehicleRegistration(zope.interface.Interface):
  ...     owner = zope.schema.Object(title='Owner', schema=IVehicleOwner)
  ...
  ...     license = zope.schema.TextLine(title='License')
  ...     address = zope.schema.TextLine(title='Address')
  ...
  ...     model = zope.schema.TextLine(title='Model')
  ...     make = zope.schema.TextLine(title='Make')
  ...     year = zope.schema.TextLine(title='Year')

Now let's create simple implementations of these two interfaces.

  >>> @zope.interface.implementer(IVehicleOwner)
  ... class VehicleOwner(object):
  ...
  ...     def __init__(self, **kw):
  ...         for name, value in kw.items():
  ...             setattr(self, name, value)

  >>> @zope.interface.implementer(IVehicleRegistration)
  ... class VehicleRegistration(object):
  ...
  ...     def __init__(self, **kw):
  ...         for name, value in kw.items():
  ...             setattr(self, name, value)

Now we can create a group just for the owner with its own
``get_content`` method that simply returns the ``owner`` object field
of the ``VehicleRegistration`` instance.

  >>> class OwnerGroup(group.Group):
  ...     label = 'Owner'
  ...     fields = field.Fields(IVehicleOwner, prefix='owner')
  ...
  ...     def get_content(self):
  ...         return self.context.owner

When we create an Edit form for example, we should omit the ``owner``
field which is taken care of with the group.

  >>> class RegistrationEditForm(group.GroupForm, form.EditForm):
  ...     fields = field.Fields(IVehicleRegistration).omit(
  ...         'owner')
  ...     groups = (OwnerGroup,)

  >>> config.registry.registerAdapter(factory, (None, IFormLayer, RegistrationEditForm), IContentTemplate)

  >>> reg = VehicleRegistration(
  ...               license='MA 40387',
  ...               address='10 Main St, Maynard, MA',
  ...               model='BMW',
  ...               make='325',
  ...               year='2005',
  ...               owner=VehicleOwner(firstName='Stephan',
  ...                                  lastName='Richter'))
  >>> request = testing.TestRequest()

  >>> edit = RegistrationEditForm(reg, request)
  >>> edit.update()

When we render the form, the group appears as we would expect but with
the ``owner`` prefix for the fields.

  >>> print(format_html(edit.render()))
  <form action=".">
      <div class="row">
        <label for="form-widgets-license">License</label>
        <input type="text"
         id="form-widgets-license"
         name="form.widgets.license"
         class="text-widget required textline-field"
         value="MA 40387" />
      </div>
      <div class="row">
        <label for="form-widgets-address">Address</label>
        <input type="text"
         id="form-widgets-address"
         name="form.widgets.address"
         class="text-widget required textline-field"
         value="10 Main St, Maynard, MA" />
      </div>
      <div class="row">
        <label for="form-widgets-model">Model</label>
        <input type="text"
         id="form-widgets-model"
         name="form.widgets.model"
         class="text-widget required textline-field"
         value="BMW" />
      </div>
      <div class="row">
        <label for="form-widgets-make">Make</label>
        <input type="text"
         id="form-widgets-make"
         name="form.widgets.make"
         class="text-widget required textline-field"
         value="325" />
      </div>
      <div class="row">
        <label for="form-widgets-year">Year</label>
        <input type="text"
         id="form-widgets-year"
         name="form.widgets.year"
         class="text-widget required textline-field"
         value="2005" />
      </div>
    <fieldset>
      <legend>Owner</legend>
      <div class="row">
        <label for="form-widgets-owner-firstName">First Name</label>
        <input type="text"
         id="form-widgets-owner-firstName"
         name="form.widgets.owner.firstName"
         class="text-widget required textline-field"
         value="Stephan" />
      </div>
      <div class="row">
        <label for="form-widgets-owner-lastName">Last Name</label>
        <input type="text"
         id="form-widgets-owner-lastName"
         name="form.widgets.owner.lastName"
         class="text-widget required textline-field"
         value="Richter" />
      </div>
    </fieldset>
    <div class="action">
        <input type="submit"
         id="form-buttons-apply"
         name="form.buttons.apply"
         class="submit-widget"
         value="Apply" />
    </div>
  </form>

Now let's try and edit the owner.  For example, suppose that Stephan
Richter gave his BMW to Paul Carduner because he is such a nice guy.

  >>> request = testing.TestRequest(params={
  ...     'form.widgets.owner.firstName': 'Paul',
  ...     'form.widgets.owner.lastName': 'Carduner',
  ...     'form.widgets.license': 'MA 4038765',
  ...     'form.widgets.address': 'Berkeley',
  ...     'form.widgets.model': 'BMW',
  ...     'form.widgets.make': '325',
  ...     'form.widgets.year': '2005',
  ...     'form.buttons.apply': 'Apply'
  ...     })
  >>> edit = RegistrationEditForm(reg, request)
  >>> edit.update()

We'll see if everything worked on the form side.

  >>> print(render_xpath(edit, './/i'))
  <i>Data successfully updated.</i>

Now the owner object should have updated fields.

  >>> reg.owner.firstName
  'Paul'
  >>> reg.owner.lastName
  'Carduner'
  >>> reg.license
  'MA 4038765'
  >>> reg.address
  'Berkeley'
  >>> reg.model
  'BMW'
  >>> reg.make
  '325'
  >>> reg.year
  '2005'


Nested Groups
-------------

The group can contains groups. Let's adapt the previous RegistrationEditForm:

  >>> class OwnerGroup(group.Group):
  ...     label = 'Owner'
  ...     fields = field.Fields(IVehicleOwner, prefix='owner')
  ...
  ...     def get_content(self):
  ...         return self.context.owner

  >>> class VehicleRegistrationGroup(group.Group):
  ...     label = 'Registration'
  ...     fields = field.Fields(IVehicleRegistration).omit(
  ...         'owner')
  ...     groups = (OwnerGroup,)

  >>> config.registry.registerAdapter(factory, (None, IFormLayer, VehicleRegistrationGroup), IContentTemplate)

  >>> class RegistrationEditForm(group.GroupForm, form.EditForm):
  ...     groups = (VehicleRegistrationGroup,)

  >>> factory = TemplateFactory(os.path.join(os.path.dirname(tests.__file__),
  ...                           'templates', 'simple-nested-groupedit.pt'), 'text/html')
  >>> config.registry.registerAdapter(factory, (None, IFormLayer, RegistrationEditForm), IContentTemplate)

  >>> reg = VehicleRegistration(
  ...               license='MA 40387',
  ...               address='10 Main St, Maynard, MA',
  ...               model='BMW',
  ...               make='325',
  ...               year='2005',
  ...               owner=VehicleOwner(firstName='Stephan',
  ...                                  lastName='Richter'))
  >>> request = testing.TestRequest()

  >>> edit = RegistrationEditForm(reg, request)
  >>> edit.update()

Now let's try and edit the owner.  For example, suppose that Stephan
Richter gave his BMW to Paul Carduner because he is such a nice guy.

  >>> request = testing.TestRequest(params={
  ...     'form.widgets.owner.firstName': 'Paul',
  ...     'form.widgets.owner.lastName': 'Carduner',
  ...     'form.widgets.license': 'MA 4038765',
  ...     'form.widgets.address': 'Berkeley',
  ...     'form.widgets.model': 'BMW',
  ...     'form.widgets.make': '325',
  ...     'form.widgets.year': '2005',
  ...     'form.buttons.apply': 'Apply'
  ...     })
  >>> edit = RegistrationEditForm(reg, request)
  >>> edit.update()

We'll see if everything worked on the form side.

  >>> print(render_xpath(edit, './/i'))
  <i>Data successfully updated.</i>

Now the owner object should have updated fields.

  >>> reg.owner.firstName
  'Paul'
  >>> reg.owner.lastName
  'Carduner'
  >>> reg.license
  'MA 4038765'
  >>> reg.address
  'Berkeley'
  >>> reg.model
  'BMW'
  >>> reg.make
  '325'
  >>> reg.year
  '2005'

So what happens, if errors happen inside a nested group? Let's use an empty
invalid object for the test missing input errors:

  >>> reg = VehicleRegistration(owner=VehicleOwner())

  >>> request = testing.TestRequest(params={
  ...     'form.widgets.owner.firstName': '',
  ...     'form.widgets.owner.lastName': '',
  ...     'form.widgets.license': '',
  ...     'form.widgets.address': '',
  ...     'form.widgets.model': '',
  ...     'form.widgets.make': '',
  ...     'form.widgets.year': '',
  ...     'form.buttons.apply': 'Apply'
  ...     })

  >>> edit = RegistrationEditForm(reg, request)
  >>> edit.update()
  >>> data, errors = edit.extract_data()
  >>> print(render_xpath(edit, './/i'))
  <i>There were some errors.</i>

  >>> print(render_xpath(edit, './/fieldset/ul'))
  <ul>
    <li>
    License:
      <div class="error">Required input is missing.</div>
    </li>
    <li>
    Address:
      <div class="error">Required input is missing.</div>
    </li>
    <li>
    Model:
      <div class="error">Required input is missing.</div>
    </li>
    <li>
    Make:
      <div class="error">Required input is missing.</div>
    </li>
    <li>
    Year:
      <div class="error">Required input is missing.</div>
    </li>
  </ul>
  <ul>
    <li>
    First Name:
      <div class="error">Required input is missing.</div>
    </li>
    <li>
    Last Name:
      <div class="error">Required input is missing.</div>
    </li>
  </ul>


Group instance in nested group
------------------------------

Let's also test if the Group class can handle group objects as instances:

  >>> reg = VehicleRegistration(
  ...               license='MA 40387',
  ...               address='10 Main St, Maynard, MA',
  ...               model='BMW',
  ...               make='325',
  ...               year='2005',
  ...               owner=VehicleOwner(firstName='Stephan',
  ...                                  lastName='Richter'))
  >>> request = testing.TestRequest()

  >>> edit = RegistrationEditForm(reg, request)
  >>> vrg = VehicleRegistrationGroup(edit.context, request, edit)
  >>> ownerGroup = OwnerGroup(edit.context, request, edit)

Now build the group instance object chain:

  >>> vrg.groups = (ownerGroup,)
  >>> edit.groups = (vrg,)

Also use refreshActions which is not needed but will make coverage this
additional line of code in the update method:

  >>> edit.refreshActions = True

Update and render:

  >>> edit.update()
  >>> print(format_html(edit.render()))
  <form action=".">
    <fieldset>
      <legend>Registration</legend>
      <div class="row">
        <label for="form-widgets-license">License</label>
        <input type="text"
         id="form-widgets-license"
         name="form.widgets.license"
         class="text-widget required textline-field"
         value="MA 40387" />
      </div>
      <div class="row">
        <label for="form-widgets-address">Address</label>
        <input type="text"
         id="form-widgets-address"
         name="form.widgets.address"
         class="text-widget required textline-field"
         value="10 Main St, Maynard, MA" />
      </div>
      <div class="row">
        <label for="form-widgets-model">Model</label>
        <input type="text"
         id="form-widgets-model"
         name="form.widgets.model"
         class="text-widget required textline-field"
         value="BMW" />
      </div>
      <div class="row">
        <label for="form-widgets-make">Make</label>
        <input type="text"
         id="form-widgets-make"
         name="form.widgets.make"
         class="text-widget required textline-field"
         value="325" />
      </div>
      <div class="row">
        <label for="form-widgets-year">Year</label>
        <input type="text"
         id="form-widgets-year"
         name="form.widgets.year"
         class="text-widget required textline-field"
         value="2005" />
      </div>
      <fieldset>
        <legend>Owner</legend>
      <div class="row">
        <label for="form-widgets-owner-firstName">First Name</label>
        <input type="text"
         id="form-widgets-owner-firstName"
         name="form.widgets.owner.firstName"
         class="text-widget required textline-field"
         value="Stephan" />
      </div>
      <div class="row">
        <label for="form-widgets-owner-lastName">Last Name</label>
        <input type="text"
         id="form-widgets-owner-lastName"
         name="form.widgets.owner.lastName"
         class="text-widget required textline-field"
         value="Richter" />
      </div>
      </fieldset>
    </fieldset>
    <div class="action">
      <input type="submit"
         id="form-buttons-apply"
         name="form.buttons.apply"
         class="submit-widget"
         value="Apply" />
    </div>
  </form>


Now test the error handling if just one missing value is given in a group:

  >>> request = testing.TestRequest(params={
  ...     'form.widgets.owner.firstName': 'Paul',
  ...     'form.widgets.owner.lastName': '',
  ...     'form.widgets.license': 'MA 4038765',
  ...     'form.widgets.address': 'Berkeley',
  ...     'form.widgets.model': 'BMW',
  ...     'form.widgets.make': '325',
  ...     'form.widgets.year': '2005',
  ...     'form.buttons.apply': 'Apply'
  ...     })

  >>> edit = RegistrationEditForm(reg, request)
  >>> vrg = VehicleRegistrationGroup(edit.context, request, edit)
  >>> ownerGroup = OwnerGroup(edit.context, request, edit)
  >>> vrg.groups = (ownerGroup,)
  >>> edit.groups = (vrg,)

  >>> edit.update()
  >>> data, errors = edit.extract_data()
  >>> print(render_xpath(edit, './/i'))
  <i>There were some errors.</i>

  >>> print(render_xpath(edit, './/fieldset/ul'))
  <ul>
    <li>
    Last Name:
      <div class="error">Required input is missing.</div>
    </li>
  </ul>


Tests cleanup:

  >>> tearDown()
