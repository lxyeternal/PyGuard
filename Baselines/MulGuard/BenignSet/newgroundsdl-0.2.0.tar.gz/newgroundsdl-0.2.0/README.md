# newgroundsdl
Downloads all of the songs on a Newgrounds audio page.

Usage: newgroundsdl **AUDIO_PAGE_URL**
