## Environment Variables Table

| Environment Variabel       | Flag            | Default Value  |
|----------------------------|-----------------|----------------|
| CGE_KMA                    | kmaPathWrong    | kma            |
