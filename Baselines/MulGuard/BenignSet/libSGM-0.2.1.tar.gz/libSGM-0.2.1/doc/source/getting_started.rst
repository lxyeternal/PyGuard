Getting started
===============

.. toctree::
    getting_started/quick_overview.rst
    getting_started/installation.rst
    getting_started/example.rst


