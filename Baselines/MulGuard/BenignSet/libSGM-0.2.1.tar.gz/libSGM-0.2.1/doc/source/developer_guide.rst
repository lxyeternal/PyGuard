Developer guide
===============

.. toctree::
    developer_guide/memory_optimization.rst
    developer_guide/before_coding.rst

