.. _readme:

Introduction of scIBD
===============

scIBD is a doublet detection tool for single-cell chromatin accessibility sequencing (scCAS) data

scIBD can be seamlessly integrated into existing scCAS analysis workflows using python.