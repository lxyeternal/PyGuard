LCA Metrics
===========

Validation metrics for hierarchical label by Lowest Common Ancestor.

Original paper is (Kosmopoulos, 2015)
