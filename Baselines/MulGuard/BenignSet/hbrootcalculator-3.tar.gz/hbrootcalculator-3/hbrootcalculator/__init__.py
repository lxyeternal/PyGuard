def squareroot (number,root):
    print("HLO")
    return number ** (1/root)