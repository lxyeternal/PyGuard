## HB ROOT CALCULATOR 

## THIS IS A SIMPLE ROOT CALCULTOR MODULE YOU CAN EASILY USE IT


## Installation

```
pip install hbrootcalculator
```

## Usage

```py
import hbrootcalculator
number=int(input("HLO ENTER ANY NUMBER: "))
root=int(input("CUBE OR SQUARE ROOT : "))

if root=="2":
    result=(number**(1/2))
else:
    result=(number**(root))

print("RESULT =",result )

```

