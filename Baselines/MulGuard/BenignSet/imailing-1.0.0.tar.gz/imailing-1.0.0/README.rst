========
IMailing
========


.. image:: https://img.shields.io/pypi/v/imailing.svg
        :target: https://pypi.python.org/pypi/imailing

.. image:: https://img.shields.io/travis/RignonNoel/imailing.svg
        :target: https://travis-ci.org/RignonNoel/imailing

.. image:: https://readthedocs.org/projects/imailing/badge/?version=latest
        :target: https://imailing.readthedocs.io/en/latest/?badge=latest
        :alt: Documentation Status


.. image:: https://pyup.io/repos/github/RignonNoel/imailing/shield.svg
     :target: https://pyup.io/repos/github/RignonNoel/imailing/
     :alt: Updates



Interface to send transactionnal email with differents services 


* Free software: MIT license
* Documentation: https://imailing.readthedocs.io.


Features
--------

* TODO

Credits
-------

This package was created with Cookiecutter_ and the `audreyr/cookiecutter-pypackage`_ project template.

.. _Cookiecutter: https://github.com/audreyr/cookiecutter
.. _`audreyr/cookiecutter-pypackage`: https://github.com/audreyr/cookiecutter-pypackage
