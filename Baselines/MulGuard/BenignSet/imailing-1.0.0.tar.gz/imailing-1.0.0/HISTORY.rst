=======
History
=======

1.0.0 (2018-02-07)
------------------

* First release on PyPI.
