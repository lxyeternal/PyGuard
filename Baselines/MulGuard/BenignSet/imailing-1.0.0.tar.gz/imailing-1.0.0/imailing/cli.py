# -*- coding: utf-8 -*-

"""Console script for imailing."""

import click


@click.command()
def main(args=None):
    """Console script for imailing."""
    click.echo("Replace this message by putting your code into "
               "imailing.cli.main")
    click.echo("See click documentation at http://click.pocoo.org/")


if __name__ == "__main__":
    main()
