# -*- coding: utf-8 -*-

"""Top-level package for IMailing."""

__author__ = """Noël Rignon"""
__email__ = 'rignon.noel@gmail.com'
__version__ = '1.0.0'
