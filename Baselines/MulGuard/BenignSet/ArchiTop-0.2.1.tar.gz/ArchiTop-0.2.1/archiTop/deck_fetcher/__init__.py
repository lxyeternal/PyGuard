from .archidekt import ArchidektFetcher
