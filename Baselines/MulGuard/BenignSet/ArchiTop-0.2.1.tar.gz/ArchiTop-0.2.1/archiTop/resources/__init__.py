from .templates import (card_asset_template,
                        card_deck_template,
                        card_template,
                        final_deck_template)
