# Apollo

Checker complete with diff, token, and epsilon checking.
