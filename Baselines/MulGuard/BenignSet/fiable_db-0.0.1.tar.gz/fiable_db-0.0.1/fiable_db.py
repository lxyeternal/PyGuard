FILE = "fiabledb.json"

def start(file=False):
  file_name = file if file else FILE
