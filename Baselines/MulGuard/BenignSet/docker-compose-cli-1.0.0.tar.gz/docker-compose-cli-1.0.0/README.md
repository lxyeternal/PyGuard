# Docker compose CLI

To generate basic python docker-compose setup run:
```
docker-compose-cli [<project_name>]
```

Where <project_name> - name of your application.