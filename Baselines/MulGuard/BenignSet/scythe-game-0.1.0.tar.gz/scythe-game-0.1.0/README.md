# Scythe

[![Build Status](https://img.shields.io/travis/chucksmash/scythe.game.svg)](https://travis-ci.org/chucksmash/scythe-game)
[![Coverage](https://img.shields.io/coveralls/chucksmash/scythe-game.svg)](https://coveralls.io/r/chucksmash/scythe-game)
[![PyPi Version](https://img.shields.io/pypi/v/scythe-game.svg)](https://pypi.python.org/pypi/scythe-game)
[![Python Versions](https://img.shields.io/pypi/pyversions/scythe-game.svg)](https://pypi.python.org/pypi/scythe-game/)
[![Daily Downloads](https://img.shields.io/pypi/dd/scythe-game.svg)](https://pypi.python.org/pypi/scythe-game/)

Modeling the board game `Scythe` and creating agents to play it.
