#PyRho Package 

This is a PyRho package. 
- Control Earth Resistivity monitoring system
- Display Data
- Sending Data to Server
