"""
Copyright (c) 2017, Richard Campen
All rights reserved.

Licensed under the Modified BSD License.
For full license terms see LICENSE.txt

"""

# mothur_py v0.2.0

from .core import Mothur, MothurCommand
