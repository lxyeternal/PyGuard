"""Top-level package for dingtalk."""

__author__ = 'dingtalk2'
__email__ = 'ibopo@126.com'
__version__ = '0.1.0'
