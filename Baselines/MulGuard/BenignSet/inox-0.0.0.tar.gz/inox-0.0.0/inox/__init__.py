r"""Stainless neural networks in JAX"""

__version__ = '0.0.0'

from . import nn
from . import tree_util
