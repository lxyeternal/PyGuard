# Stainless neural networks in JAX
