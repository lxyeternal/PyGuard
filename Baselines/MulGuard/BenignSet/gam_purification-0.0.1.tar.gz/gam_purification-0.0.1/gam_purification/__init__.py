"""
GAM_Purification
Utilities for puriifying generalized additive models.
See http://proceedings.mlr.press/v108/lengerich20a.html
for more details on the theory behind purification.
"""

import gam_purification.models