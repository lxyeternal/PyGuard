from django.urls import path
from hydrothings import SensorThingsAPI


hydrothings_api = SensorThingsAPI()

urlpatterns = [
    path('', hydrothings_api.urls)
]
