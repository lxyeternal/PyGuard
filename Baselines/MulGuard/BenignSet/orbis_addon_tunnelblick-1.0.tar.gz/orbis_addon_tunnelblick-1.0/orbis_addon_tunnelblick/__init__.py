from .main import Tunnelblick as Main
name = "orbis_addon_tunnelblick"
