import numpy as np

def exp(t, a, b, c):
    return a * np.exp(-b * t) + c
