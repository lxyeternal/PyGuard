HAFFET (Hybrid Analytic Flux FittEr for Transients):
codes to play with SN alike LCs and spectra
==============

<a href="https://github.com/saberyoung/HAFFET/" rel="some text">![Foo](https://img.shields.io/badge/GitHub-saberyoung%2FHAFFET-blue.svg?style=flat)</a>
<a href="https://arxiv.org/abs/2107.13439" rel="some text">![Foo](https://img.shields.io/badge/arXiv-2107.13439-orange.svg?style=flat)</a>
<a href="https://github.com/saberyoung/HAFFET/blob/master/LICENSE" rel="license">![Foo](https://img.shields.io/github/license/saberyoung/haffet)</a>
<a href="http://haffet.readthedocs.io/en/latest/" rel="license">![Foo](https://readthedocs.org/projects/haffet/badge/?version=latest)</a>
<a href="https://github.com/saberyoung/HAFFET/issues" rel="license">![alt tag](https://img.shields.io/github/issues/saberyoung/haffet)</a>
![alt tag](https://img.shields.io/github/forks/saberyoung/haffet)
![alt tag](https://img.shields.io/github/stars/saberyoung/haffet)

Documentation
=============
Read the docs at https://haffet.readthedocs.io/en/latest/

A quick example showing how the GUI works
=============
![alt tag](docs/static/demo1.gif)

Q & A
=============
Let me (saberyoung@gmail.com) know if you had any questions.
