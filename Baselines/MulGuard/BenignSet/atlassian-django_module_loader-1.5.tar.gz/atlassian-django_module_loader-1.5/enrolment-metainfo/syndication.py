def do_enrol():
    return "Not Implemented"