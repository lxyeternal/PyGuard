# pyecotrend-ista

[![PyPI version](https://badge.fury.io/py/pyecotrend-ista.svg)](https://badge.fury.io/py/pyecotrend-ista)
[![GitHub issues](https://img.shields.io/github/issues/Ludy87/pyecotrend-ista)](https://github.com/Ludy87/pyecotrend-ista/issues)
[![GitHub forks](https://img.shields.io/github/forks/Ludy87/pyecotrend-ista)](https://github.com/Ludy87/pyecotrend-ista)
[![GitHub stars](https://img.shields.io/github/stars/Ludy87/pyecotrend-ista)](https://github.com/Ludy87/pyecotrend-ista)
[![GitHub license](https://img.shields.io/github/license/Ludy87/pyecotrend-ista)](https://github.com/Ludy87/pyecotrend-ista/blob/main/LICENSE)

Unofficial python library for the pyecotrend-ista API
