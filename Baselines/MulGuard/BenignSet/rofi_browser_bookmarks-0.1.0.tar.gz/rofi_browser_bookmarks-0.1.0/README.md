# rofi-browser-bookmarks

Provides a list of browser bookmarks to choose from in rofi.

## Installation

Installation is done via pip

```bash
pip3 install rofi_browser_bookmarks
```

## Usage

```bash
rofi-browser-bookmarks BROWSER [folder]
```

Currently only `google-chrome` is a supported browser.
