class BrowserNotFoundException(Exception):
    pass
