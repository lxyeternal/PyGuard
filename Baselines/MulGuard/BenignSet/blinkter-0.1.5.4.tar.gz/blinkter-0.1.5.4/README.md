# README
[![Documentation Status](https://readthedocs.org/projects/blinkter/badge/?version=latest)](https://blinkter.readthedocs.io/en/latest/?badge=latest)
[![GitHub license](https://img.shields.io/github/license/speratus/Blinkter.svg)](https://github.com/speratus/Blinkter/blob/master/LICENSE)
[![GitHub issues](https://img.shields.io/github/issues/speratus/Blinkter.svg)](https://github.com/speratus/Blinkter/issues)
[![GitHub forks](https://img.shields.io/github/forks/speratus/Blinkter.svg)](https://github.com/speratus/Blinkter/network)
![GitHub release](https://img.shields.io/github/release/speratus/Blinkter.svg)

Blinkter makes using the [Pimoroni Blinkt!](https://shop.pimoroni.com/products/blinkt) even  easier by making the library object oriented and 
adding several convenience methods. The intuitive objects that Blinkter layers on top of the [Blinkt!](https://github.com/pimoroni/blinkt)
python library greatly improve ease of use and reduce development times.
# Installation

## Easy Way
```
pip install blinkter
```
## Harder way
If you want to play around with the Blinkter code, the following steps will guide you through getting the repository
and installing the library from your code.

1. Make sure that `setuptools` is installed.
```
pip install setuptools
```
2. Next, clone this repository with
```
git clone https://github.com/speratus/Blinkter.git
```

3. Once the repository is downloaded, install it using this command:
```
python setup.py install
```
That's all there is to it. You should be ready to go in no time at all.

## Installing into a virtual environment.
Installing Blinkter into a virtual environment is not much harder than a regular installation of Blinkter.
Follow steps 1 and 2 as you normally would, but before executing step 3, make sure that your virtual environment is activated.
### Windows
On windows this is achieved using the command:
```
<ENVIRONMENT_NAME>\Scripts\activate
```
### Linux
In linux, the command is,
```
source <ENVIRONMENT_NAME>/bin/activate
```

Doing this will ensure that Blinkter is installed into the appropriate environment.

# Usage
```python
import blinkter

board = blinkter.BlinktBoard()
pixel = board.get_pixel(0)  #Or whatever pixel you want to manipulate
pixel.red() #Or pixel.blue(), or whatever else you want.
```
# Links
* [Pimoroni Blinkt! product page](https://shop.pimoroni.com/products/blinkt)
* [Blinkt library](https://github.com/pimoroni/blinkt)
* [Documentation](https://blinkter.readthedocs.io/)