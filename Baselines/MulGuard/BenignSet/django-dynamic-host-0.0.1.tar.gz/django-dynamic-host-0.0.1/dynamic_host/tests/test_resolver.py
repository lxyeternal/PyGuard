def resolver_func(host, request, **kwargs):
    return host == "example.com"
