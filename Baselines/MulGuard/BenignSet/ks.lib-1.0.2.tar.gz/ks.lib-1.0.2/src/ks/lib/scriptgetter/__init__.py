### -*- coding: utf-8 -*- #############################################
# Разработано компанией Ключевые Решения (http://keysolutions.ru/)
# Все права защищены, 2006-2007
#
# Developed by Key Solutions (http://keysolutions.ru/)
# All right reserved, 2006-2007
#######################################################################
# $Id: __init__.py 1254 2007-08-16 07:19:50Z anatoly $
#######################################################################

# Make it a Python package

from scriptgetter import *
