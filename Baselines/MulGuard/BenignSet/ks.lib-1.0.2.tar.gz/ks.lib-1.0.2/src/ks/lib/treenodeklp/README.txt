$Id: README.txt 1188 2007-07-11 23:48:37Z anatoly $

Как использовать продукт treenodeklp:

    Модуль treenodeklp.treenodeklp содержит класс TreeNodeKLP