### -*- coding: utf-8 -*- #############################################
# Разработано компанией Ключевые Решения (http://keysolutions.ru/)
# Все права защищены, 2006-2007
#
# Developed by Key Solutions (http://keysolutions.ru/)
# All right reserved, 2006-2007                                                                 #
#######################################################################

# Make it a Python package
from logging import getLogger, basicConfig, DEBUG

logger = getLogger('ks.lib.treenodeklp')

from treenodeklp import *