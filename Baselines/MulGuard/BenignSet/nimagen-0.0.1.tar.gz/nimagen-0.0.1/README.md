<img src="misc/Nigen_logo_banner.png" alt="drawing" width="300"/>

# Statistical and Visualisation tool for NeuroImaging GENetics studies

See the online documentation

## Quick install

1. `pip install lehai-ml/nigen`
2. `conda install lehai-ml/nigen`
