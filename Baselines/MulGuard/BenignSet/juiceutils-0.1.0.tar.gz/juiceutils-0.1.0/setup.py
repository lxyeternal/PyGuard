from setuptools import setup

setup(name='juiceutils', version='0.1.0', author_email='pannet.sec@gmail.com')
