from .anime_info import Ui_AnimeInfo
from .app import Ui_AnimeApp
from .settings import Ui_Settings
