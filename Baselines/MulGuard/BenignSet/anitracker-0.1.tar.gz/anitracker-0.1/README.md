# AniTracker

This tool is designed to help watch, sync, and manage animes with tools such as anilist. As of now this is a VERY early MVP, and it only works on linux and only works if you have mpv installed. In future updates this will be expanded more