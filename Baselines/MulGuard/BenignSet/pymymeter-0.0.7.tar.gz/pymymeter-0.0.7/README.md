# MyMeter

## Testing

Use the `demo.py` file.

Ex: `demo.py --username "your_username" --password "your_password"`

The username and password should be the ones you use to login to [https://mymeter.lge-ku.com/](https://mymeter.lge-ku.com/)
