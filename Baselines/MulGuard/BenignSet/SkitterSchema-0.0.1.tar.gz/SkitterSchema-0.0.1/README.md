# SkitterSchema
Classes representing users, tweets and entities on Twitter that can be mapped into a SQL-like database through SQLAlchemy.

TODO:
- foreign key constraints: how to deal with?
- get user mentions from description
- add place
- add weight to edges
