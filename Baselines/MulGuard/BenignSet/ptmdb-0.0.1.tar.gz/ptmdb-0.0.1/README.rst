PTMDB Library
=======================

A small library to allow a pandas data frame to be saved to a MongoDB repository

*Dependancies*::
	import pandas as pd
	import pymongo as py

*Usage*::
	import PTMDB as pmdb
	