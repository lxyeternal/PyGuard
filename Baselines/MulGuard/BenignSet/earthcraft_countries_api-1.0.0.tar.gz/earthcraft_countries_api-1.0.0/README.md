# EarthCraft Countries API
 
## Created for the EarthCraft bot