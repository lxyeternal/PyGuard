# __main__.py

from configparser import ConfigParser
from importlib import resources  # Python 3.7+
import sys

from earthcraft_countries_api import earthcraft_countries_api


def main():
    print("Hi")


if __name__ == "__main__":
    main()
