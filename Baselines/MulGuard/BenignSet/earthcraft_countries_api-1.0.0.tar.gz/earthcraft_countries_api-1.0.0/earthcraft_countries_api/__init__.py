# __init__.py

# Version of the earthcraft_countries-api
__version__ = "1.0.0"
