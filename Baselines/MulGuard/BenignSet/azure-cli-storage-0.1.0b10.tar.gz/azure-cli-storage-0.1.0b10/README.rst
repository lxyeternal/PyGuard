Microsoft Azure CLI 'storage' Command Module
==================================

This package is for the 'storage' module.
i.e. 'az storage'


