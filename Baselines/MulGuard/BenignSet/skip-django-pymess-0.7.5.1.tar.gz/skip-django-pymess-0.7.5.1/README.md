Documentation you can find [here](http://django-pymess.readthedocs.org/)


