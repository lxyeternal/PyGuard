VERSION = (0, 7, 5, 1)


def get_version():
    return '.'.join(map(str, VERSION))
