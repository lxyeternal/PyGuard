"""properties.py module"""

DEFAULT_CHARS = "abcdefghijklmnopqrstuvwxyz0123456789!@#$%^&*(-_=+)"
DEFAULT_FILE_NAME = ".secret.txt"
DEFAULT_LENGTH_OF_SECRET_KEY = 50
