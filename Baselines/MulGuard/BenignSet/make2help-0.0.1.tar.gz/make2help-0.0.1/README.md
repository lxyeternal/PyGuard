[![Build Status](https://travis-ci.org/515hikaru/make2help.svg?branch=master)](https://travis-ci.org/515hikaru/make2help)

# make2help
This is inspired by https://marmelab.com/blog/2016/02/29/auto-documented-makefile.html

**Testing Only Python 3.5 and later so on**.

# Install

Run following command to install:

```
 $ pip install git+https://github.com/515hikaru/make2help
```

# License

MIT License

# Author

Takahiro Kojima (@515hikaru)
