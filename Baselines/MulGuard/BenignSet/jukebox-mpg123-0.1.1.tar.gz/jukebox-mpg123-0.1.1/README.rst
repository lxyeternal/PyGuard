Jukebox mpg123 playback module
================================

jukebox_mpg123 simply plays the music on your local machine using the cli tool `mpg123 <http://mpg123.de/>`_

Startup
=========

::

    bin/jukebox jukebox_mpg123 --start

Shutdown
==========

::

    bin/jukebox jukebox_mpg123 --stop

