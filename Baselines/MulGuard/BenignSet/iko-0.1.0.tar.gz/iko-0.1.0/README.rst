iko
==========

Iko is an asynchronous micro-framework for
converting data into different structures.
