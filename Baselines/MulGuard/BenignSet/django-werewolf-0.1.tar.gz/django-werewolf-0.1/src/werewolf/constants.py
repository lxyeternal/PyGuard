# Don't touch this!
CHANGE_STATUS_TO = 'change_status_to'
CAN_VIEW_STATUS = 'can_view_status'