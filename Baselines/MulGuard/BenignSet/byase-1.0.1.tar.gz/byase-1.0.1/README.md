# BYASE

A library that uses Bayesian inference to identify gene-level 
and isoform-level ASE (Allele-specific expression) in polyploid 
(diploid or higher) organisms from single-end or 
paired-end RNA-seq data.