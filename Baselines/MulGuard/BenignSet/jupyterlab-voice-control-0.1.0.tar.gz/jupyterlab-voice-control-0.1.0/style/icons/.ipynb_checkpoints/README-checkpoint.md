# Licences

The icons were downloaded from materialdesignicons.com
and adapted for use with JupyterLab icon system.

## Apache 2.0

Icons distributed under [Apache 2.0](https://www.apache.org/licenses/LICENSE-2.0) licence terms are listed below
together with the respective creator/copyright holder:

- `microphone.svg` - Google
- `microphone-off.svg` - Google
