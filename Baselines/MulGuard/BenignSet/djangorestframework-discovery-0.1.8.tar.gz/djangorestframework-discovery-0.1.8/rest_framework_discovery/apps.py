from django.apps import AppConfig


class DiscoveryConfig(AppConfig):
    name = "rest_framework_discovery"
