# {number}. {title}

Date: {date}

## Status

{status}

## Context

## Decision

## Consequences

## Tags
- foo.bar
