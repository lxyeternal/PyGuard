# Adre - ADR Extended

## Usage

```bash
pip install adre

adre init
adre new "Babby's first ADR"
adre serve
```
