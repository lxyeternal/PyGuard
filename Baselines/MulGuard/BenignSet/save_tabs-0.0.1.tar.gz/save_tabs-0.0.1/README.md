# save-tabs

## Overview


## Usage


## Installation

The easiest way to install this program is using pip.

### Windows

In the console, type `py -m pip install save-tabs`

### macOS

In the console, type `python3 -m pip install save-tabs`

### Linux

This program is untested on Linux but I believe it should work.
