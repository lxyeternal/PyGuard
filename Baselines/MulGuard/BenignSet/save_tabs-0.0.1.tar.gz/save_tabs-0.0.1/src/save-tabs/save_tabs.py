"""Run this from the command line to use the program."""
import main


main.main()
