# __init__.py
from inferless.api import call, async_call


__version__ = "0.0.1"
__all__ = ["call", "async_call"]
