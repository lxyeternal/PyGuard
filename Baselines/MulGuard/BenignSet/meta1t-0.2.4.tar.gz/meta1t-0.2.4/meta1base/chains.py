# -*- coding: utf-8 -*-
known_chains = {
    "META1": {
        "chain_id": "3dbdca4078e2988c2a31202e2aa3cbeae7a8aa755a31e0f49d6f4b2a262e9c3e",
        "core_symbol": "META1",
        "prefix": "META1",
    },
    "CTS": {
        "chain_id": "53952fc10d52a3af6d572a298e8f99a0a2e7afd0f7dbad354d8d65e8c36c962d",
        "core_symbol": "CTS",
        "prefix": "CTS",
    },
    "TEST1": {
        "chain_id": "1be5237d42eab03f22f9bbeae7be85742e906f6426cbde1d8bd748787b893a99",
        "core_symbol": "TEST1",
        "prefix": "TEST1",
    },
}
