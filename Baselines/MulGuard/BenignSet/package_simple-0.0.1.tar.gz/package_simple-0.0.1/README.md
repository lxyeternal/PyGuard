# Package_simple

<b/>Description: The package package_simple is used to an example of package creation.<b/>

## Installation

Use the package manager [pip](https://pip.pypa.io/en/stable/) to install package_simple

```bash
pip install package_simple
```

## Usage

```python
from package_simple import file1_name

file1_name.my_function()
```

## Author
Carla Edila

## License
[MIT](https://choosealicense.com/licenses/mit/)