msSysCtl
In this pakage used to get system informations and control your system volume and sound
how to use? (answer)

just install and import the pakage and use functions to get your system informations and controll your brightness and volume
Install comment - pip install msSysCtl
import comment import msSysCtl

functions

sys_info()
boot_time()
cpu_info()
memmory_info()
disk_info()
network_info()
brightness_ctl(int)
volume_ctl(int)
