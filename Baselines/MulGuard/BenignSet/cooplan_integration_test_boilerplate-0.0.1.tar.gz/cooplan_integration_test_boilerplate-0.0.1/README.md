# cooplan-integration-test-boilerplate
Boilerplate code for integration tests
