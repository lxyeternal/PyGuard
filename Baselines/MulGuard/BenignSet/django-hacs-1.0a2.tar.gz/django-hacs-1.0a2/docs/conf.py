# -*- coding: utf-8 -*-
# ++ This file `conf.py` is generated at 5/10/16 7:24 PM ++

__author__ = "Md Nazrul Islam<connect2nazrul@gmail.com>"
