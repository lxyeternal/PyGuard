# preloop
This is a placeholder package that is used to reserve the "preloop" name on PyPI, and additionally test a PyPI publishing workflow.
