PC23
====


**pc32** is a simple Python compatibility library used by Python applications
and packages which about to support both 2.x and 3.x versions.
