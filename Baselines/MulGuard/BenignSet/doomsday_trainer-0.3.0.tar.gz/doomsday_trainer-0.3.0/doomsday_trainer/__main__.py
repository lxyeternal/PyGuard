"""Main module."""
from doomsday_trainer import trainer

trainer.main()
