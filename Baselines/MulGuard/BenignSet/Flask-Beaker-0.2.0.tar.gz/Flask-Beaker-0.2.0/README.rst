============
Flask-Beaker
============

Beaker session interface for Flask.


INSTALLATION
============

First, you must do::

    pip install Flask-Beaker

Or::

    python setup.py install


Usage
=====

For using Beaker session magnament in Flask you only have to add this into your app::

  from flask_beaker import BeakerSession
  BeakerSession(app)

TODOs and BUGS
==============
See: http://github.com/syrusakbary/flask-beaker/issues