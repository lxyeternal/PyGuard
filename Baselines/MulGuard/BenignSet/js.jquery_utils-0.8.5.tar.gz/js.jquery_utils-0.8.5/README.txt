js.jquery_utils
***************

Introduction
============

This library packages `jQuery Utils`_ for `fanstatic`_.

.. _`fanstatic`: http://fanstatic.org
.. _`jQuery Utils`: http://code.google.com/p/jquery-utils/

This requires integration between your web framework and ``fanstatic``,
and making sure that the original resources (shipped in the ``resources``
directory in ``js.jquery_utils``) are published to some URL.

