class ConfigError(Exception):
    pass