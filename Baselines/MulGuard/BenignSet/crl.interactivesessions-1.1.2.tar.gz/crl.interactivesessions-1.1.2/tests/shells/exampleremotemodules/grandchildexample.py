"""Example module grandchild
"""

__copyright__ = 'Copyright (C) 2019, Nokia'


def grandchild_func():
    return 'grandchild'
