__copyright__ = 'Copyright (C) 2019, Nokia'


def test_get_status_code(statuscodeverifier):
    statuscodeverifier.verify()
