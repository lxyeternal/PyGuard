__import__('pkg_resources').declare_namespace(__name__)

__copyright__ = 'Copyright (C) 2019, Nokia'
