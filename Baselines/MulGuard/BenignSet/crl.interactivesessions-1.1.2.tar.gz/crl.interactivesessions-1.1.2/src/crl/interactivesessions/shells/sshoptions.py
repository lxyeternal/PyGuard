__copyright__ = 'Copyright (C) 2019, Nokia'

sshoptions = (" -o 'UserKnownHostsFile=/dev/null'"
              " -o 'ServerAliveInterval=15'"
              " -o 'StrictHostKeyChecking=no'"
              " -o 'PreferredAuthentications=password'"
              " -o 'PubkeyAuthentication=no'"
              " -o ConnectTimeout=30")

scpoptions = (" -o 'UserKnownHostsFile=/dev/null'"
              " -o 'ServerAliveInterval=15'"
              " -o 'StrictHostKeyChecking=no'"
              " -o 'PreferredAuthentications=password'"
              " -o 'PubkeyAuthentication=no'"
              " -o ConnectTimeout=30")
