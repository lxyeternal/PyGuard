__copyright__ = 'Copyright (C) 2019, Nokia'
