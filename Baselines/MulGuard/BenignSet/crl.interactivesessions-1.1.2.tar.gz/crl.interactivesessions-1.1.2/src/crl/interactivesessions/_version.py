__copyright__ = 'Copyright (C) 2019, Nokia'

VERSION = '1.1.2'
GITHASH = ''


def get_version():
    return VERSION


def get_githash():
    return GITHASH
