__copyright__ = 'Copyright (C) 2019, Nokia'


try:
    comprange = xrange  # pylint: disable=invalid-name
except NameError:
    comprange = range
