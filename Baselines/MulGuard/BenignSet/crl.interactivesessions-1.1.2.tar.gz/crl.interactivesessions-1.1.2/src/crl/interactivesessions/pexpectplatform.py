import sys


__copyright__ = 'Copyright (C) 2019, Nokia'


def is_windows():
    return sys.platform == 'win32'
