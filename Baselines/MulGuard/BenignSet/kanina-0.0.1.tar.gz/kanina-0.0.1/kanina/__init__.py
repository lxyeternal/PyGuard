"""An simple calculator package"""
__version__ = '0.0.1'

import kanina.calculator

# __all__ = [
#         'calculator'
#         ]