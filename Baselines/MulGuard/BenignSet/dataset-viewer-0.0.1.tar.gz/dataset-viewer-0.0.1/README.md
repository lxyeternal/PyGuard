# Dataset Viewer

Allow to view a dataset image by image and edit their labels using napari
