========
Usage
========

To use Dad in a project::

    import dad