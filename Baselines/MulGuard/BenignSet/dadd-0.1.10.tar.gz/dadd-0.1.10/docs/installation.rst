============
Installation
============

At the command line::

    $ easy_install dad

Or, if you have virtualenvwrapper installed::

    $ mkvirtualenv dad
    $ pip install dad