
import os

DIR_PATH = os.path.dirname(os.path.realpath(__file__))

PARENT_DIR_PATH = os.path.abspath(os.path.join(DIR_PATH, ".."))