============
Installation
============

At the command line::

    $ easy_install dbus2any

Or, if you have virtualenvwrapper installed::

    $ mkvirtualenv dbus2any
    $ pip install dbus2any
