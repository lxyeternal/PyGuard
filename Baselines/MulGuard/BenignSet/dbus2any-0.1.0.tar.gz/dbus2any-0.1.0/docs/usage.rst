========
Usage
========

To use dbus2any in a project::

    import dbus2any
