class ResponseError(Exception):
    """
    当 BaseResponse 的返回值不为 0 时抛出的异常
    """
    pass
