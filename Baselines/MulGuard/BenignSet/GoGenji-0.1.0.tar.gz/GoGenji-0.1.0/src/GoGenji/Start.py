#!/usr/bin/env python3
# coding: utf-8
from .GoGenji import *
def start():
    exec(open("GoGenji.py").read(), globals())
