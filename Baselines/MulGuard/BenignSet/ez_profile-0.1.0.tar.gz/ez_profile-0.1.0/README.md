A simple library for a one-liner performance profile using `cProfile`!

If `snakeviz` is installed in your current environment, then the snakeviz
output will be shown in your default browser. Otherwise, your performance
profile will be printed to the console.

Usage:

```
import ez_profile # this is all you need

<all of your other code>
```
