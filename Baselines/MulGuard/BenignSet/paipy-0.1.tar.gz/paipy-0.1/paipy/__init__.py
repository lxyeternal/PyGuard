from .linear_regression import LinearRegression
from .NN import NN
