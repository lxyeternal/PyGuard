class LibVersionIdentifier(str):
    """Representation of a specific library version"""

    pass


class Secret(str):
    pass
