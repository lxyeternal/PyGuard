from .hc_installer import HcLibResolver
from .nlp_installer import NlpLibResolver
from .ocr_installer import OcrLibResolver
