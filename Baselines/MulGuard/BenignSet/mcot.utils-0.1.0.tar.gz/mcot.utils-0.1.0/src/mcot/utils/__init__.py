from .build import load_info
__doc__, __version__ = load_info(__name__) 
del load_info