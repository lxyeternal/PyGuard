Script interface for all mcot submodules

Defines the mcot command line tool
