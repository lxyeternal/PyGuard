from .plugin import FlashMessagePlugin

__all__ = ['FlashMessagePlugin']
