Installation
============

oarepo-references-draft is on PyPI so all you need is:

.. code-block:: console

   $ pip install oarepo-references-draft
