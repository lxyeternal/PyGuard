..
    Copyright (C) 2019 Mirek Simek, VSCHT Praha.

    oarepo-references-draft is free software; you can redistribute it and/or
    modify it under the terms of the MIT License; see LICENSE file for more
    details.

=========================
 oarepo-references-draft
=========================

.. image:: https://img.shields.io/travis/oarepo/oarepo-references-draft.svg
        :target: https://travis-ci.org/oarepo/oarepo-references-draft

.. image:: https://img.shields.io/coveralls/oarepo/oarepo-references-draft.svg
        :target: https://coveralls.io/r/oarepo/oarepo-references-draft

.. image:: https://img.shields.io/github/tag/oarepo/oarepo-references-draft.svg
        :target: https://github.com/oarepo/oarepo-references-draft/releases

.. image:: https://img.shields.io/pypi/dm/oarepo-references-draft.svg
        :target: https://pypi.python.org/pypi/oarepo-references-draft

.. image:: https://img.shields.io/github/license/oarepo/oarepo-references-draft.svg
        :target: https://github.com/oarepo/oarepo-references-draft/blob/master/LICENSE

## Alpha version, do not use yet

An extension of oarepo-references to work together with invenio-records-draft

Further documentation is available on
https://oarepo-references-draft.readthedocs.io/
