"""Gaia class file."""


class Gaia:
    """Gaia class."""

    def __init__(self):
        """Initialize a new Gaia class."""
        print('hello world')
