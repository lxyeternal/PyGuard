Simple test
------------

Ensure your device works with this simple test.

.. literalinclude:: ../examples/vl53l4cd_simpletest.py
    :caption: examples/vl53l4cd_simpletest.py
    :linenos:
