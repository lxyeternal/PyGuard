from pirebok.fuzzers.fuzzer import Fuzzer


class SqlFuzzer(Fuzzer):
    pass
