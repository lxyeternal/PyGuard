from pirebok.fuzzers.fuzzer import Fuzzer


class GenericFuzzer(Fuzzer):
    pass
