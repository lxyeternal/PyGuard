from pirebok.transformers.transformer import Transformer


class GenericTransformer(Transformer):
    pass
