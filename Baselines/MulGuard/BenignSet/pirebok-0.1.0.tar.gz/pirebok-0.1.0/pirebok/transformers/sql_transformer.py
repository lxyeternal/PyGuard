from pirebok.transformers.transformer import Transformer


class SqlTransformer(Transformer):
    pass
