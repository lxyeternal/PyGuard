__author__ = """Doğan Can Bakır"""
__email__ = 'dogancanbakir@protonmail.com'
__version__ = '0.1.0'
