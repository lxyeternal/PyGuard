from license_lister import run


def main():
    run()


if __name__ == "__main__":
    main()
