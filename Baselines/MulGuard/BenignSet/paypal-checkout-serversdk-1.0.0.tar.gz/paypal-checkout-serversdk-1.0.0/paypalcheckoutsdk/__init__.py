name = "paypalcheckoutsdk"
from paypalcheckoutsdk.config import *

