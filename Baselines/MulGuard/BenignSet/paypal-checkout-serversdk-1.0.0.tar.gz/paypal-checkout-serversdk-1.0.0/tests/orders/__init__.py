from tests.orders.orders_authorize_test import *
from tests.orders.orders_capture_test import *
from tests.orders.orders_create_test import *
from tests.orders.orders_get_test import *
from tests.orders.orders_patch_test import *
from tests.orders.orders_validate_test import *
