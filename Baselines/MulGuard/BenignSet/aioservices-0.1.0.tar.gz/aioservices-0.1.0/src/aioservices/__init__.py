"""Aioservices - Python 3 asyncio microservices framework."""

__version__ = '0.1.0'
"""Version number that follows semantic versioning.

:type: str
"""
