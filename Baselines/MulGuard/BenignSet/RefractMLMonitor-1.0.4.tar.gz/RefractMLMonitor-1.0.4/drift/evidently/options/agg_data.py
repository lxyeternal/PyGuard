from evidently.options.option import Option


class RenderOptions(Option):
    raw_data: bool = False
