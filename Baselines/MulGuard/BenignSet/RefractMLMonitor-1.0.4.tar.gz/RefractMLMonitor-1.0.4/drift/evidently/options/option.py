from evidently.pydantic_utils import FrozenBaseModel


class Option(FrozenBaseModel):
    pass
