Version 0.7.1 released 2011-11-17
    
    * Changing directory structure of dare to utils and runtime
    * updating the examples for bfast, bwa, bowtie, chipseq, postprocess, namd
