mrcfile
-------

A pure Python implementation of the `MRC2014 file format`__, which exposes the
file's header and data as numpy arrays.

.. _MRC2014: http://www.ccpem.ac.uk/mrc_format/mrc2014.php

__ MRC2014_
