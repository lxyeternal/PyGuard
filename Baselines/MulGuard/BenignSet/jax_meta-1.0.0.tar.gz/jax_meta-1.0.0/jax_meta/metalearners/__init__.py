from jax_meta.metalearners.anil import ANIL
from jax_meta.metalearners.base import MetaLearner
from jax_meta.metalearners.imaml import iMAML
from jax_meta.metalearners.lrd2 import LRD2Binary, LRD2OneVsRest
from jax_meta.metalearners.maml import MAML
from jax_meta.metalearners.meta_sgd import MetaSGD
from jax_meta.metalearners.r2d2 import R2D2