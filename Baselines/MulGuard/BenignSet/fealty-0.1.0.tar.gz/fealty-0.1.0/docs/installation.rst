============
Installation
============

At the command line::

    $ easy_install fealty

Or, if you have virtualenvwrapper installed::

    $ mkvirtualenv fealty
    $ pip install fealty
