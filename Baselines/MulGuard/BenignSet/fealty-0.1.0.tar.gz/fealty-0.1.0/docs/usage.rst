========
Usage
========

To use fealty in a project::

    import fealty
