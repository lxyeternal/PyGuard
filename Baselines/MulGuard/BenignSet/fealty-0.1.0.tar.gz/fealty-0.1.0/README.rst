===============================
fealty
===============================

.. image:: https://img.shields.io/travis/eddiejessup/fealty.svg
        :target: https://travis-ci.org/eddiejessup/fealty

.. image:: https://img.shields.io/pypi/v/fealty.svg
        :target: https://pypi.python.org/pypi/fealty


Discretised field utilities

* Free software: BSD license
* Documentation: https://fealty.readthedocs.org.

Features
--------

* TODO
