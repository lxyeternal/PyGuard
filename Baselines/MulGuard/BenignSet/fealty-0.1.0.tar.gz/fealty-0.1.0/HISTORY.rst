.. :changelog:

History
-------

0.1.0 (2015-01-11)
---------------------

* First release on PyPI.
