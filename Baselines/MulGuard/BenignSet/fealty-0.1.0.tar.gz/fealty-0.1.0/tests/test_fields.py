#!/usr/bin/env python
# -*- coding: utf-8 -*-

import unittest
from fealty import fields


class TestFealty(unittest.TestCase):

    def test_fields(self):
        pass


if __name__ == '__main__':
    unittest.main()
