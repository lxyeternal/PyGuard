# -*- coding: utf-8 -*-

__author__ = 'Elliot Marsden'
__email__ = 'elliot.marsden@gmail.com'
__version__ = '0.1.0'
