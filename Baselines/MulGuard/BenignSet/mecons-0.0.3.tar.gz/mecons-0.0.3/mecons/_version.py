"""The version number."""
# Authors: Christian Ferreyra, chrisferreyra13@gmail.com
# License: BSD-3-Clause

__version__ = '0.0.3'
