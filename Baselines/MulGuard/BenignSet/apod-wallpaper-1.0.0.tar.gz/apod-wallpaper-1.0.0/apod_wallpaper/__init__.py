#  __   ____   __  ____       _  _   __   __    __    ____   __   ____  ____  ____ 
# / _\ (  _ \ /  \(    \ ___ / )( \ / _\ (  )  (  )  (  _ \ / _\ (  _ \(  __)(  _ \
#/    \ ) __/(  O )) D ((___)\ /\ //    \/ (_/\/ (_/\ ) __//    \ ) __/ ) _)  )   /
#\_/\_/(__)   \__/(____/     (_/\_)\_/\_/\____/\____/(__)  \_/\_/(__)  (____)(__\_)
"""
NASA APOD wallpaper image download
~~~~~~~~~~~~~~~~~~~~~
TODO: Docs

"""
__title__ = 'apod-wallpaper'
__version__ = '1.0.0'
__author__ = 'Jason Harmon'
__license__ = 'Apache 2.0'
__copyright__ = 'Copyright 2015 Jason Harmon'

#from date_utils import format_date, date_range, random_date
#from apod import download_single, download_random, download_all
#from watermark import watermark
