"Module to compute the square of a number"

def quadrato(a):
    return a**2