
from distutils.core import setup

setup(
        name = 'ConvertString',
        packages = ['ConvertString'],
        version = '1.2',
        description = 'convert string to other factor',
        author = 'nonellldd',
        url = 'https://github.com/dung-dd/convertstring',
        download_url = 'https://github.com/dung-dd/convertstring.',
        author_email = 'btdungbk@gmail.com',
        keywords = ['convert string to', 'other factor', 'string to binary', 'binaary to string'],
        classifiers = []
        
)
