github: https://github.com/hiikion/bin-parcer
docs: https://github.com/hiikion/bin-parcer/blob/main/DOCS.md