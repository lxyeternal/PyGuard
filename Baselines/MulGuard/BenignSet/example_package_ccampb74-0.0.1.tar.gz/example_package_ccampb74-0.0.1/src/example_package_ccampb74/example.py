def add_nums(x,y):
    return x + y