"""Django Rest Framework Project Info View"""

__version__ = "0.0.1"
