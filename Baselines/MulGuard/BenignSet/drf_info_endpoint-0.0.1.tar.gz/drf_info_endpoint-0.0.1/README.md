# drf_info_endpoint
[![PyPI Version][pypi-image]][pypi-url]

[pypi-image]: https://img.shields.io/pypi/v/drf_info_endpoint
[pypi-url]: https://pypi.org/project/drf_info_endpoint/

# Installation

Using pip

`pip install drf_info_endpoint`

Using pipenv

`pipenv install drf_info_endpoint`

# Quick start
In your project’s `settings.py`.

```
DRF_INFO_ENDPOINT_PROJECT_NAME = "My Project"
DRF_INFO_ENDPOINT_VERSION = "v1.0"
```