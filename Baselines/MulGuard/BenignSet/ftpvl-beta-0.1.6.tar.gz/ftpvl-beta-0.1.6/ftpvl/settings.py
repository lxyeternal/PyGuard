default_hydra_clock_names = ["clk", "sys_clk", "clk_i"]
