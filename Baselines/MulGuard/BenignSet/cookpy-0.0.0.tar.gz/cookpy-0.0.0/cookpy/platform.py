# -*- coding: utf-8 -*-

import platform as p

linux = p.system() == 'Linux'
windows = p.system() == 'Windows'
