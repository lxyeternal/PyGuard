.. image:: static/logo.png

**Cookpy** is a cross-platform, free and open-source build system.


Overview
========

|license| |travisci| |coverage| |pypi|

...


About
=====

...


Documentation
=============

...


.. |license| image:: https://img.shields.io/github/license/cookpy/
                     cookpy.svg?style=flat-square
    :target: https://github.com/cookpy/cookpy/blob/master/LICENSE.rst

.. |travisci| image:: https://img.shields.io/travis/cookpy/
                      cookpy.svg?style=flat-square
    :target: https://travis-ci.org/cookpy/cookpy

.. |coverage| image:: https://img.shields.io/coveralls/cookpy/
                      cookpy.svg?style=flat-square
    :target: https://coveralls.io/r/cookpy/cookpy

.. |pypi| image:: https://img.shields.io/pypi/v/
                  cookpy.svg?style=flat-square&label=latest%20version
    :target: https://pypi.python.org/pypi/cookpy
