from setuptools import setup

setup(name='hungdq97_distributions',
      version='0.1',
      description='Gaussian distributions',
      packages=['hungdinh97_distributions'],
      author_email='hungdinhquang97@gmail.com',
      zip_safe=False)
