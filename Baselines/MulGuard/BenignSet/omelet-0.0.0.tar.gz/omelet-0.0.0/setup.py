from distutils.core import setup

setup(
    name = 'omelet',
    packages = ['omelet'],
    version = '0.0.0',
    description = 'pre-release',
    author = 'Eunjong Kim',
    author_email = 'eunjong@live.com',
    url = 'https://github.com/yoonslab/omelet',
    download_url = 'https://github.com/yoonslab/omelet/archive/0.0.0.tar.gz',
    keywords = ['machine learning', 'auto ml', 'xai'],
    classifiers = [],
)
