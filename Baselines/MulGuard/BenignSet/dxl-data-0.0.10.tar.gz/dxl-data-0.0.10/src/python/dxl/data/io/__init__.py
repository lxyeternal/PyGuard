from ._numpy import load_npz
from ._h5 import h5_add_dataset
from ._bin import load_bin