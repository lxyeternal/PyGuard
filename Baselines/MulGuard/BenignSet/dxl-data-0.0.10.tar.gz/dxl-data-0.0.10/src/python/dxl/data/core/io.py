from dxl.fs import Path
import numpy as np


def load_mat(path: Path):
    pass
