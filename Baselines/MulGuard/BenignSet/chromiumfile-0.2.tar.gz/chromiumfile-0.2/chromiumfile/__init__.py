from ._core import (
    chromium_dir, bootstrap_file,
    win_chromium_dir, win_bootstrap_file,
    mac_chromium_dir, mac_bootstrap_file,
    linux_chromium_dir, linux_bootstrap_file
)