from chromiumfile import (
    chromium_dir,  # chromium 文件夹路径
    bootstrap_file  # 浏览器启动文件路径, 即 chrome.exe 的路径
)

# 记录测试结果
name = 'me/chromiumfile'
print(f'[测试通过] {name}')