

def arvind():
	print ("ok ok ok ")
