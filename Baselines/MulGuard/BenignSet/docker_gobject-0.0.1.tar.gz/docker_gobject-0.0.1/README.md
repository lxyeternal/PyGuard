# docker_gobject

## Installation
```bash
pip install docker_gobject
```
