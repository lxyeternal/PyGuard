|Build Status| |Documentation Status|

The diapason Python module can be used to generate note sounds.


.. |Build Status| image:: https://api.travis-ci.org/Soundphy/diapason.svg?branch=master
   :target: https://travis-ci.org/Soundphy/diapason
.. |Documentation Status| image:: https://readthedocs.org/projects/diapason/badge/
   :target: http://diapason.readthedocs.io/
