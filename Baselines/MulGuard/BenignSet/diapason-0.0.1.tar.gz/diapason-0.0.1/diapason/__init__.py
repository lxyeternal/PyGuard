__version__ = '0.0.1'

from .core import note_frequency
from .core import generate_wav
