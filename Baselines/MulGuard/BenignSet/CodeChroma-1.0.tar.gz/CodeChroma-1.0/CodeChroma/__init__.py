from CodeChroma.terminalColors import TerminalColors
from CodeChroma.colors import Colors