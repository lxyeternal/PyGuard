"""Module for IQ Option API http resources."""
