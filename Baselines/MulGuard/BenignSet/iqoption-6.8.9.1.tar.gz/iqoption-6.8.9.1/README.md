# Iqoption API

great robot
https://npt-life.com/iq-option-robot

Stop sell private version now

## Document

### New document

https://lu-yi-hsun.github.io/iqoptionapi/
 
### Old document

old document not support anymore:
https://github.com/Lu-Yi-Hsun/iqoptionapi_private/blob/master/old_document.md
