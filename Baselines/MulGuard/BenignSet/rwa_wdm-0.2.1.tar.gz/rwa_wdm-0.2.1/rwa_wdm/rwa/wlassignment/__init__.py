from .vcolor import vertex_coloring
from .ff import first_fit
