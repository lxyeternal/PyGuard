from .rwa import (
    dijkstra_vertex_coloring,
    dijkstra_first_fit,
    yen_vertex_coloring,
    yen_first_fit,
    genetic_algorithm
)
