#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""building-web-apps-with-go
https://github.com/apachecn/building-web-apps-with-go"""

__author__ = "ApacheCN"
__email__ = "apachecn@163.com"
__license__ = "CC BY-NC-SA 4.0"
__version__ = "2024.3.1.0"