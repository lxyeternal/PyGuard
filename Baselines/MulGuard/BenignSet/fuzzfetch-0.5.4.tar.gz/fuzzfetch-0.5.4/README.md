[![Build Status](https://api.travis-ci.org/MozillaSecurity/fuzzfetch.svg?branch=master)](https://travis-ci.org/MozillaSecurity/fuzzfetch)
[![Build Status](https://ci.appveyor.com/api/projects/status/okgquor0hp2rsy6d/branch/master?svg=true)](https://ci.appveyor.com/project/MozillaSecurity/fuzzfetch/branch/master)
[![codecov](https://codecov.io/gh/MozillaSecurity/fuzzfetch/branch/master/graph/badge.svg)](https://codecov.io/gh/MozillaSecurity/fuzzfetch)
