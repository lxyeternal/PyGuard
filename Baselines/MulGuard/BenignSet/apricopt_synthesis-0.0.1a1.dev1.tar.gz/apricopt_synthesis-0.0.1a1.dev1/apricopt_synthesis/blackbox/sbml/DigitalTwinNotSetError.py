class DigitalTwinNotSetError(RuntimeError):
    pass
