=====
Usage
=====

To use Move Symlink in a project::

    import movesymlink
