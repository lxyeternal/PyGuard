from project.settings import *

DEBUG = True

DATABASES['default']['HOST'] = '127.0.0.1'
