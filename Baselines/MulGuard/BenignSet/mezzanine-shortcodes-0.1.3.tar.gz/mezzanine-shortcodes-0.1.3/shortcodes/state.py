SHORTCODES = {}  # {name: <Shortcode>, ...}
TOOLBAR = []  # [<Button>, <Menu>, ...]

DEBUG_DISPLAYNAMES = set()  # ['displayname', ...]
