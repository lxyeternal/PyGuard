__version__ = '0.1.3'

from .render import richtext_filters
from .register_api import button, Menu, menubutton, GenericButton, GenericMenubutton

default_app_config = 'shortcodes.apps.ShortcodesConfig'
