"""
A tensor is just a n-dimensional arrya
"""
from numpy import ndarray as Tensor
