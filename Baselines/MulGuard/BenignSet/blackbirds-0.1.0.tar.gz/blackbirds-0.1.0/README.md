![](docs/_static/banner.svg)

[![Build and test package](https://github.com/arnauqb/birds/actions/workflows/ci.yml/badge.svg)](https://github.com/arnauqb/birds/actions/workflows/ci.yml)
[![codecov](https://codecov.io/gh/arnauqb/birds/branch/main/graph/badge.svg?token=HvwGGjA7qr)](https://codecov.io/gh/arnauqb/birds)

# 1. Installation

The easiest way to install Birds is to install it from the PyPI repository

```
pip install birds
```
