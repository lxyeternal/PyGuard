def test__simple():
    assert 1 == 1
