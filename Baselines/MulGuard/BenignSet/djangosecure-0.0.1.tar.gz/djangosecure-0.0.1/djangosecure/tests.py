from django.test import TestCase

# TODO: Create tests

# class TestImportTestCase(TestCase):
#     def test_imports(self):
#         try:
#             import djangosecure
#         except ImportError:
#             self.fail("Could not import djangosecure")
