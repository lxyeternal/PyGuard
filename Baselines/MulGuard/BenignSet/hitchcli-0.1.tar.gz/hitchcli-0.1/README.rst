HitchCLI
========

HitchCLI is a plugin for the Hitch test framework that lets you test
command line applications. It includes a wrapper around pexpect to
let you write steps to interact with interactive command line
applications.


Documentation
=============

See:

* https://hitchtest.readthedocs.org/en/latest/services/cli.html
