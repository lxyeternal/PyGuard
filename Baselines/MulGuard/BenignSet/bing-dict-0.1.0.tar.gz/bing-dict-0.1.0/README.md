# bing-dict
A utility for English-to-Chinese translation from bing dictionary.
