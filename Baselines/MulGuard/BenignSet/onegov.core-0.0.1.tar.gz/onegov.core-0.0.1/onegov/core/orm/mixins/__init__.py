from onegov.core.orm.mixins.timestamp import TimestampMixin

__all__ = ['TimestampMixin']
