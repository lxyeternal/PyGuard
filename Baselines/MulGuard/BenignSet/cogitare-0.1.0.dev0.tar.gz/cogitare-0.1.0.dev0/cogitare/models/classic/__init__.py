from cogitare.models.classic.logistic import LogisticRegression
from cogitare.models.classic.feedforward import FeedForward


__all__ = ['LogisticRegression', 'FeedForward']
