"""Timekit.io REST API Python Client"""
from __future__ import absolute_import, unicode_literals

from timekit.client import TimekitAPI

__all__ = ["TimekitAPI"]
__version__ = "0.0.7"