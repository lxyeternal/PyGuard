def nothing():
    print("nothing")
