__title__ = "leafbot"
__author__ = "mudkipdev"
__license__ = "MIT"
__version__ = "0.0.0"

from .bot import *
