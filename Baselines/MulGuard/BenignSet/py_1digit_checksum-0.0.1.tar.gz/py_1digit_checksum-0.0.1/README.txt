This package implements various 1-digit checksums used for e.g. credit
card numbers and more.

These checksums are not ment for security but for catching type errors.

License: Gnu Lesser General Public License
