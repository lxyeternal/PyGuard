""" Base clases for DecimalString type """

version = ('0', '0', '1', None)

