### Original Authors
* [Hany Moussa](https://github.com/hanymoussa)
* [Ramez Moussa](https://github.com/ramezmoussa)

### Major Contributors
* [Tristan Gingold](https://github.com/tgingold)