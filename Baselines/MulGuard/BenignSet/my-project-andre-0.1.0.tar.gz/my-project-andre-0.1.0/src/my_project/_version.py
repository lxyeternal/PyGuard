"""File to keep the package version in one place"""
__version__ = "0.1.0"
__version_info__ = tuple(__version__.split("."))
