from ._version import __version__, __version_info__         # noqa
from .something import foo                                  # noqa
