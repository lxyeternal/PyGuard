"""Integration tests configuration file."""

from NiaPy.tests.conftest import pytest_configure  # pylint: disable=unused-import
