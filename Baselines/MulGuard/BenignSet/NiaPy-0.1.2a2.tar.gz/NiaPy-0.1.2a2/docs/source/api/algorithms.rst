:mod:`NiaPy.algorithms`
============================

:mod:`NiaPy.algorithms.basic`
----------------------------------
.. automodule:: NiaPy.algorithms.basic
    :members:
    :undoc-members:
    :show-inheritance:

:mod:`NiaPy.algorithms.modified`
-----------------------------------
.. automodule:: NiaPy.algorithms.modified
    :members:
    :undoc-members:
    :show-inheritance:
