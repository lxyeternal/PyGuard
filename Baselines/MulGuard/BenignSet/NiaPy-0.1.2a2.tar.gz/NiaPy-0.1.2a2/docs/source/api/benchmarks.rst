:mod:`NiaPy.benchmarks`
============================
.. automodule:: NiaPy.benchmarks
    :members:
    :undoc-members:
    :show-inheritance: