Guides
======

Here are gethered together user guides.

.. toctree::

    git_begginers
    mingw_installation