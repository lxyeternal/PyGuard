"""Current version of package prefix_codes"""
__version__ = "1.0.0"