def edinbruh():
    print(f"https://gist.github.com/IAmThe2ndHuman/"
          f"{37743616 >> 10}f8c641c0acf2a84bb533baad5ea")