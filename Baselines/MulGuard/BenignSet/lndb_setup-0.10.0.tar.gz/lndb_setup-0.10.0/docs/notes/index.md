# Notes

These are any notes on design decisions, prototypes, background that don't make it into the package.

```{toctree}
:maxdepth: 1
:glob:
:reversed:

*
```
