# lndb-setup: Setup & configure LaminDB

Read the [docs](https://lamin.ai/docs/lndb-setup).
