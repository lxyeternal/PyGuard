"""THIS FILE IS GENERATED FROM beem SETUP.PY."""
version = '0.1.0'
