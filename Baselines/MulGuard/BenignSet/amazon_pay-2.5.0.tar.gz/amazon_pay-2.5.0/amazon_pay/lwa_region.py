regions = {'jp': 'amazon.co.jp',
           'uk': 'amazon.co.uk',
           'de': 'amazon.de',
           'eu': 'amazon.co.uk',
           'us': 'amazon.com',
           'na': 'amazon.com'}
