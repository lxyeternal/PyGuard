import pytest

import amazon_pay_sdk_python


@pytest.mark.xfail
def test_that_you_wrote_tests():
    assert False, "No, you have not written tests yet"
