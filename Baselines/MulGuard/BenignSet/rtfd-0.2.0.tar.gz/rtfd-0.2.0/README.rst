rtfd
====

Build, read your exclusive and fuck docs.

Installation
------------

- Production Version

    `$ pip install -U rtfd`

- Development Version

    `$ pip install -U git+https://github.com/staugur/rtfd.git@master`

Quickstart
----------

1. rtfd init -b xx --other-options

2. rtfd project -a create --other-options your-docs-project

3. rtfd build your-docs-project

More options with ``--help / -h`` option.
