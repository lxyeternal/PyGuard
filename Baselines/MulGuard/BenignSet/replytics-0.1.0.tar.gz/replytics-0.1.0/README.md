Easily track your Repl.it statistics with Repl-Analytics! Simply put this at the beginning of your code and Replytics is active.
```py
import replytics;replytics.init('https://repl.it/YOUR REPL LINK HERE')
```
Don't forget to replace the url to the url of your own Repl.
Run `replytics.get_views()` to get the amount of views your Repl has. Dashboard coming soon.