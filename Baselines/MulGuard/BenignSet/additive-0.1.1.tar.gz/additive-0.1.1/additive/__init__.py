"""Gives users direct access to classes and functions."""
from additive.additive import share, shares
