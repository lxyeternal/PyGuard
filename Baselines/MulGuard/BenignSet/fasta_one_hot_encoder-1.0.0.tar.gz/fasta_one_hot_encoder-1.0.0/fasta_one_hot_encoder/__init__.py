from .fasta_one_hot_encoder import FastaOneHotEncoder

__all__ = ["FastaOneHotEncoder"]
