try:
    from cStringIO import StringIO
except ImportError:
    from io import StringIO
