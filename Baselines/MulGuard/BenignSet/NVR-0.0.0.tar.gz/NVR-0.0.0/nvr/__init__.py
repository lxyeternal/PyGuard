from NVR import *

__version__ = "0.0.0"
