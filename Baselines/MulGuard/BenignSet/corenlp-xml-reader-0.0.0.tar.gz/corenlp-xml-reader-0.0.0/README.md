# corenlp-xml-reader
A utility for easily working with CoreNLP-annotated text in Python.

## About this package
Other than reading the xml file into a python representation, this utility
does some necessary "fixing up" of the data in CoreNLP.
[to be described]

## Quickstart

### Install
Install from the Python Package Index:
```bash
pip install corenlp-xml-reader
```

Alternatively, install a version you can hack on:
```bash
git clone https://github.com/enewe101/corenlp-xml-reader.git
cd corenlp-xml-reader
python setup.py develop
```

### Use

[Add basic usage examples.]
