from setuptools import setup

setup(
    name='binhoshell',
    version='0.2.1',
    description='A shell in python (???)',
    url='https://bitbucket.org/paikka/shellpy/src',
    author='Fábio',
    author_email='fabio@paikka.me',
    license='MIT',
    packages=['shellpy'],
    zip_safe=False
)