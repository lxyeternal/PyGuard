__version__ = '1.0.1'

from assignhooks.patch import *
from assignhooks.transformer import *
from assignhooks.instrument import *
