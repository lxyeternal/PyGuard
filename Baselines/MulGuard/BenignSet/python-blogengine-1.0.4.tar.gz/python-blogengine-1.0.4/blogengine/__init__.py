import logging


def getLogger():
    return logging.getLogger('blogengine')


from blogengine import BlogEngine

