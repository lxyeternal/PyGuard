class BaseEntity(object):
    type = 'post'


from site import Site
from post import Post
from page import Page
