from . import Post

class Page(Post):
    type = 'page'