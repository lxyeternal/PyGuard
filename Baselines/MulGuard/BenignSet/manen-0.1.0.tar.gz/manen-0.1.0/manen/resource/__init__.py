"""
manen.resource
==============
"""
