def sumsquare(x1,x2):
    return (x1**2+x2**2)

def add(x1,x2):
    return (x1+x2)
