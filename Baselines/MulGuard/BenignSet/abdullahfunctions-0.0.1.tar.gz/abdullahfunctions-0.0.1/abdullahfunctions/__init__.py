from abdullahfunctions import sumsquare
from abdullahfunctions import add
