# -*- coding: utf-8 -*-

from . import intranet_partner
