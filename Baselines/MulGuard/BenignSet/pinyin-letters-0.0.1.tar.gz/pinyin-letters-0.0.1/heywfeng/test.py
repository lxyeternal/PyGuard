from service.test_service import add_no


def add():
    res = add_no(1, 2)
    print(res)
