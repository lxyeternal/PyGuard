# -*- coding:utf-8 -*-

#############################################
# File Name: setup.py
# Author: hey
# Mail: 1957875073@qq.com
# Created Time:  2022-1-5 10:17:34
#############################################

from setuptools import setup

setup()
