def add_no(a, b):
    return a + b
