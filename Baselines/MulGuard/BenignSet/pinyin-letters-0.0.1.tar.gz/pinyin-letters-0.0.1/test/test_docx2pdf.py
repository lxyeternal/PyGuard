from heyWFeng import docx
path = '.'
docx.docx2pdf(path=path)

