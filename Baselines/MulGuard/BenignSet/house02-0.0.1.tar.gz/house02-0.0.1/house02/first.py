def dayin1():
    print('Hello Nikki First!')