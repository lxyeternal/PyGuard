def dayin2():
    print('Hello Nikki Second!')