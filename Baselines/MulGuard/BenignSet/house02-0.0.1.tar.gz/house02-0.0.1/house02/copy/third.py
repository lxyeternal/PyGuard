def dayin3():
    print('Hello Nikki Third!')