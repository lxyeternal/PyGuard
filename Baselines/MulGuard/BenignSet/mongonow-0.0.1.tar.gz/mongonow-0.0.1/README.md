### Did you ever wonder if there was a quick way to get a dummy MongoDB instance up and running?

With MongoNow, your problem has finally found a solution: 
``pip install mongonow``
#### Done! Your Mongo-like database is ready in less than 10 seconds.

