
 ## pyparallelizer
 This is the starter text for a python package.
