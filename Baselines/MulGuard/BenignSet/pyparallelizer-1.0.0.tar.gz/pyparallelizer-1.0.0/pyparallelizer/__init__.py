
name="pyparallelizer/pyparallelizer"
__version__ = "1.0.0"

from pyparallelizer import Pyparallelizer
