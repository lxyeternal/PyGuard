# Democritus Random

[![PyPI](https://img.shields.io/pypi/v/d8s-random.svg)](https://pypi.python.org/pypi/d8s-random)
[![Build Status](https://travis-ci.com/democritus-project/d8s-random.svg?branch=main)](https://travis-ci.com/democritus-project/d8s-random)
[![codecov](https://codecov.io/gh/democritus-project/d8s-random/branch/main/graph/badge.svg?token=V0WOIXRGMM)](https://codecov.io/gh/democritus-project/d8s-random)

Democritus functions<sup>[1]</sup> for working with random.

[1] Democritus functions are <i>simple, effective, modular, well-tested, and well-documented</i> Python functions.

## Usage

Coming soon...

## Credits

This package was created with [Cookiecutter](https://github.com/audreyr/cookiecutter) and Floyd Hightower's [Python project template](https://github.com/fhightower-templates/python-project-template).
