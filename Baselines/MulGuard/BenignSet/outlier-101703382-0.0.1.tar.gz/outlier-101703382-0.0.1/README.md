# Removal of Outliers from csv file

```
Class project-2 for DATA ANALYSIS AND VISUALISATION 2020 - UCS633 Thapar University, Patiala
Submitted by: Paras Arora
101703382 (COE 18)

```
THis package take 2 inputs filename of input csv file and file name of output csv file. 
It gives an output of number of the rows removed from dataset. And final file saved in output csv file.

## Installation
`pip install outlier-101703382`

## Use via command line
`outlier-101703382_cli in.csv out.csv`

## Use in .py script
```
from outlier-101703382 import remove_outliers
remove_outliers('input.csv', 'output.csv')
```

