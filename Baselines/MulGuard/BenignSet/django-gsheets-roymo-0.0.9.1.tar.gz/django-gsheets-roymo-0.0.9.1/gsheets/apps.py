from django.apps import AppConfig


class GsheetsConfig(AppConfig):
    name = 'gsheets'
