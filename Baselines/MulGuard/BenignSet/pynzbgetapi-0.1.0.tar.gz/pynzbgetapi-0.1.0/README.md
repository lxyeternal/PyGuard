pynzbgetapi
=====
A simple Python library for using the NZBGetAPI.

Installation
------------
You can get the code from `https://github.com/holiestofhandgrenades/pynzbgetapi`

Example
-------
    import pynzbgetapi

    ng_api = pynzbgetapi.NZBGetAPI("192.168.0.x", "username", "password")
    ng_api.status()

License
-------
This code is released under the Apache license.
