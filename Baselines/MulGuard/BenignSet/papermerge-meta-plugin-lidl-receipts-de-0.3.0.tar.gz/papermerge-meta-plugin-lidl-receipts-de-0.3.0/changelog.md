# Changelog

## [0.1.0] - 13 June 2020

### very first papermerge metadata plugin

