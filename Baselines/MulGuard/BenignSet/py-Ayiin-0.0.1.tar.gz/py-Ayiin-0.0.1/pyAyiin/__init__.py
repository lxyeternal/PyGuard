from pyAyiin.pyrogram.ayiin import *


DEVS = [1905050903, 1965424892]
