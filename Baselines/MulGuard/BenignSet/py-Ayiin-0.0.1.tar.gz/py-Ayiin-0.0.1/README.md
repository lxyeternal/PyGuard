# AyiinXd Library

Core library of [The AyiinXd](https://AyiinXd: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@github.com/AyiinXd/AyiinXd), a python based telegram userbot.


[![PyPI - Version](https://img.shields.io/pypi/v/AyiinXd?style=round)](https://pypi.org/project/AyiinXd)    
[![PyPI - Downloads](https://img.shields.io/pypi/dm/AyiinXd?label=DOWNLOADS&style=round)](https://pypi.org/project/AyiinXd)    
[![Maintenance](https://img.shields.io/badge/Maintained%3F-yes-green.svg)](https://github.com/AyiinXd/AyiinXd/graphs/commit-activity)
[![Open Source Love svg2](https://badges.frapsoft.com/os/v2/open-source.svg?v=103)](https://github.com/AyiinXd/AyiinXd)
[![PRs Welcome](https://img.shields.io/badge/PRs-welcome-brightgreen.svg?style=flat-square)](https://makeapullrequest.com)

# Installation
```bash
pip3 install -U AyiinXd
```

# Documentation 
[![Documentation](https://img.shields.io/badge/Documentation-AyiinXd-blue)](http://ultroid.tech/)


See more working plugins on [the offical repository](https://github.com/AyiinXd/AyiinXd)!

> Made with 💕 by [@AyiinXd](https://t.me/AyiinXd).    


# License
[![License](https://www.gnu.org/graphics/agplv3-155x51.png)](LICENSE)   
AyiinXd is licensed under [GNU Affero General Public License](https://www.gnu.org/licenses/agpl-3.0.en.html) v3 or later.

# Credits
* [![AyiinXd](https://img.shields.io/static/v1?label=AyiinXd&message=devs&color=critical)](https://t.me/AyiinXd)
* [Dan](https://github.com/delivrance) for [Pyrogram](https://github.com/pyrogram/pyrogram)
