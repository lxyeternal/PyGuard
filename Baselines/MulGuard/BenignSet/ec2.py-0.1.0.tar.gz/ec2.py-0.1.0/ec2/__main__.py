#!/usr/bin/env python

from .main import *

main()
