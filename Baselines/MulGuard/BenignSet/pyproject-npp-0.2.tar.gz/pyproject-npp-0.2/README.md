# pyproject
## Informació
- Per executar el programa s'ha de tenir instalat el python versio 3 o mes.
- Requeriments a requirements.txt.
- El fitxer compilar.bat transforma el .py en .pyc que es mes eficient i rapid.
- Executar amb opcio -h per veure mes opcions i funcionalitats.
## Instal·lació
- Utilitzant `pip`
```
pip install pyproject
```
## Ús
- Executar el fitxer `pyproject.py` o `pyproject.cpython-39.pyc`