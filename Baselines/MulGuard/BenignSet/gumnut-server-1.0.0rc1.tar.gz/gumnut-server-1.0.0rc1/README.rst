gumnut server
#############



Documentation
*************

Please refer to https://gumnut-server.readthedocs.org



Changelog
*********

1.0.0
=====

Added
-----

-  Documentation (still in progress, though)
-  Introduced ``tox`` for handling testing, build, and publishing tasks
-  Introduced Github Actions for automated testing