# RAMSLIBS 
## Useful tools for working with RAMS data

[![Documentation Status](https://readthedocs.org/projects/ramslibs/badge/?version=latest)](https://ramslibs.readthedocs.io/en/latest/?badge=latest)

Install with:
```
git clone git@github.com:lsterzinger/ramslibs.git
cd ramslibs
pip install .
``` 
