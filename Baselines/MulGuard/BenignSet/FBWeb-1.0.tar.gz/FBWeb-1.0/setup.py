from setuptools import setup

deps = []

setup(
    name="FBWeb",
    description="Simplicity-focused Flask website builder",
    version="v1.0",
    author="Albert Szadziński",
    author_email="albert.szadzinski@smcebi.edu.pl",
    license="GPL-3.0",
    #install_requires=deps,
    packages=['FBWeb'],
    #entry_points={
     #   'console_scripts': ['xmppy = xmppy.Messenger:main']
    #}
)
