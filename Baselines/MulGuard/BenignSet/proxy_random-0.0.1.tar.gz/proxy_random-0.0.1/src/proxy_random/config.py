# Built-in providers
HTTP_PROXY_URL = "https://free-proxy-list.net/"
HTTPS_PROXY_URL = "https://www.sslproxies.org/"

TEST_URL = "https://httpbin.org/ip"
