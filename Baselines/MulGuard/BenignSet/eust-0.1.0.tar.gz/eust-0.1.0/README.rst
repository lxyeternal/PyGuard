==============
Eurostat tools
==============


.. image:: https://img.shields.io/pypi/v/eust.svg
        :target: https://pypi.python.org/pypi/eust

.. image:: https://img.shields.io/travis/rasmuse/eust.svg
        :target: https://travis-ci.org/rasmuse/eust

.. image:: https://readthedocs.org/projects/eust/badge/?version=latest
        :target: https://eust.readthedocs.io/en/latest/?badge=latest
        :alt: Documentation Status




A set of tools to download, archive, and read Eurostat data


* Free software: MIT license
* Documentation: https://eust.readthedocs.io.


Features
--------

* TODO

Credits
-------

This package was created with Cookiecutter_ and the `audreyr/cookiecutter-pypackage`_ project template.

.. _Cookiecutter: https://github.com/audreyr/cookiecutter
.. _`audreyr/cookiecutter-pypackage`: https://github.com/audreyr/cookiecutter-pypackage
