=====
Usage
=====

To use Eurostat tools in a project::

    import eust
