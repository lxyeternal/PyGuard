#!/usr/bin/env python3
# encoding: utf-8

from .main import main
from .version import VERSION as __version__
