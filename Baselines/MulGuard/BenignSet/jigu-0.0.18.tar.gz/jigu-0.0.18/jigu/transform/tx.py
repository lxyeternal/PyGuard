# TODO: Refactor merge-logging into TxInfoTransformer
