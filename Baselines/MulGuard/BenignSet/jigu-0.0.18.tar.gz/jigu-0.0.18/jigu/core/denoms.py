MicroLunaDenom = "uluna"
MicroUSDDenom = "uusd"
MicroKRWDenom = "ukrw"
MicroSDRDenom = "usdr"
MicroCNYDenom = "ucny"
MicroJPYDenom = "ujpy"
MicroEURDenom = "ueur"
MicroGBPDenom = "ugbp"
MicroMNTDenom = "umnt"

uLuna = MicroLunaDenom
uUSD = MicroUSDDenom
uKRW = MicroKRWDenom
uSDR = MicroSDRDenom
uCNY = MicroCNYDenom
uJPY = MicroJPYDenom
uEUR = MicroEURDenom
uGBP = MicroGBPDenom
uMNT = MicroMNTDenom

STAKING = uLuna
STANDARD = uSDR
