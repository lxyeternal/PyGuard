================================
深信服SSLVPN api接口sdk(python)
================================
基于M7.6.8 R2版本开发，如不适用你的版本，请提issuse

--------
安装说明
--------
1.pip安装requests

2.修改config.py里面参数配置

------
注意！
------

如果SSLVPN没有单独配置证书,用默认自带的证书，config里SSL_ENABLE设置为false

有问题可以提issuse