from .content import SinglePost
from .page import Page, MainPage
