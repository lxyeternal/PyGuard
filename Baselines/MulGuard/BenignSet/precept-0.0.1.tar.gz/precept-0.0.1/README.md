# precept

Toolbox to create async command line application.
