from .xgboost_regressor import XGBoostRegressor
from .linear_regressor import LinearRegressor
from .neural_network import MLPRegressor
from .neighbors import KNeighborsRegressor
