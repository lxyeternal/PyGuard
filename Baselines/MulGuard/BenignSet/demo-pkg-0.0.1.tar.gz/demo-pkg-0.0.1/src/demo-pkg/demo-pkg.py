def demo-pkg():
 print("hello")
