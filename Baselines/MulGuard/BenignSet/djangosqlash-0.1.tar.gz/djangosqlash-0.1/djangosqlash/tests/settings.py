# -*- coding:utf-8 -*-
SECRET_KEY = '@^jwb0=!d03l8x!4hba!oj=#87-f57-oyq%mup^n#x#az_llmq'
DATABASES = {
    'default': {
        'ENGINE': 'django.db.backends.sqlite3',
        'NAME': ":memory:",
    }
}
INSTALLED_APPS = ["djangosqlash"]
