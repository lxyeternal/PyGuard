djangosqlash
========================================

django version of https://github.com/podhmo/sqlash

