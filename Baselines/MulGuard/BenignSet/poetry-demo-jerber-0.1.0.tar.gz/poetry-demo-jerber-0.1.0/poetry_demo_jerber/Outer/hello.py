print("HIII")
