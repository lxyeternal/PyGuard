#!/usr/bin/env python
# -*- coding: utf-8 -*-

class Delta:

    def __init__(self):
        pass

    def diff(self, pk, old_data, new_data, *args, **kwargs):
        raise NotImplemented()
