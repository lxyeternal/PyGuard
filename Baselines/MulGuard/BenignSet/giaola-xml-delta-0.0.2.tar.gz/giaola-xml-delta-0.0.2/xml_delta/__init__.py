# -*- coding: utf-8 -*-

"""Top-level package for delta 11888."""

__author__ = """Dimitris Klouvas"""
__email__ = 'dimitris@giaola.com'
__version__ = '0.1.0'

from .delta_task import DeltaTask
