#!/usr/bin/env python
# -*- coding: utf-8 -*-
from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker

from .base import Storage
from models import Base, Listing


class SqlAlchemyStorage(Storage):

    def fetch_listings(self, ids):
        results = self.session.query(Listing).filter(Listing.dasUniqueId.in_(ids),
                                                     Listing.type == self.type).all()
        return [result.to_dict() for result in results]

    def bulk_create(self, data, network_errors={}):
        db_objects = []

        for key, value in data.iteritems():
            db_objects.append(Listing(dasUniqueId=key,
                                      type=self.type,
                                      data=value,
                                      sent=not (network_errors and
                                                network_errors.has_key(key))))
        self.session.bulk_save_objects(db_objects)
        self.session.commit()

    def bulk_update(self, data, network_errors={}):

        for key, value in data.iteritems():
            model = Listing(dasUniqueId=key,
                            type=self.type,
                            data=value,
                            sent=not (network_errors and
                                      network_errors.has_key(key)))
            self.session.merge(model)

        self.session.commit()

    # def read(self, data, *args, **kwargs):
    #     if not self.enabled:
    #         self.fire(Storage.EVENT_READ, data=data, query_data=[])
    #         return
    #
    #     ids = [d[self.pk_key] for d in data]
    #
    #     results = self.session.query(Listing).filter(Listing.dasUniqueId.in_(ids),
    #                                                  Listing.type == self.type).all()
    #     results = [model.to_dict() for model in results]
    #
    #     self.fire(Storage.EVENT_READ, data=data, query_data=results)
    #
    # def update(self, data, *args, **kwargs):
    #     if not self.enabled:
    #         return
    #
    #     sent = kwargs.get('sent', False)
    #
    #     for changed_data in data:
    #         dasUniqueId = changed_data.pop(self.pk_key, None)
    #         model = Listing(dasUniqueId=dasUniqueId, type=self.type, data=changed_data, sent=sent)
    #         self.session.merge(model)
    #
    #     self.session.commit()

    def _connect(self):
        # engine = create_engine(self.connection_string, echo=True, client_encoding='utf8')
        engine = create_engine(self.connection_string, client_encoding='utf8')
        Base.metadata.create_all(engine)
        Session = sessionmaker(bind=engine)

        self.session = Session()
