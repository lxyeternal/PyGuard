=====
Usage
=====

To use delta 11888 in a project::

    import giaola_xml_delta
