# lsmPy


[![image](https://img.shields.io/pypi/v/lsmpy.svg)](https://pypi.python.org/pypi/lsmpy)


**A demo python package**


-   Free software: MIT license
-   Documentation: https://SASM235.github.io/lsmpy
    

## Features

-   TODO

## Credits

This package was created with [Cookiecutter](https://github.com/cookiecutter/cookiecutter) and the [giswqs/pypackage](https://github.com/giswqs/pypackage) project template.
