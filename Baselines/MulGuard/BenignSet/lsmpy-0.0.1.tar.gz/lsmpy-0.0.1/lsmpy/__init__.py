"""Top-level package for lsmPy."""

__author__ = """Shruti Anna Samuel"""
__email__ = 'annasam13@gmail.com'
__version__ = '0.0.1'
