CONFIG_FILE = '.manageacloud'

MAC_FILE = '.manageacloud'
AUTH_SECTION = 'auth'
USER_OPTION = 'user'
APIKEY_OPTION = 'apikey'
AUTH_ERROR = 'auth_error'
NO_ERROR = 'no_error'

AUTH_ERROR_EXIT_CODE = 2
EXCEPTION_EXIT_CODE = 3