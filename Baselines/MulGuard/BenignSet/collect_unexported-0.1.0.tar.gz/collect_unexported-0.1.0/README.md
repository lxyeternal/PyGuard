<!--
SPDX-FileCopyrightText: Peter Pentchev <roam@ringlet.net>
SPDX-License-Identifier: BSD-2-Clause
-->

# Collect files omitted from the release tarballs

Some projects explicitly exclude some development files from
their release tarballs. Sometimes, when packaging those projects,
it may be useful to have these files around, e.g. for running tests.
