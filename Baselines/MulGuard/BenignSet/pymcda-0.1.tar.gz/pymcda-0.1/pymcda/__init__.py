import iomcda
import weightedsum
import topsis
import concordance
import fuzzy
import promethee

try:
	import numpy as np
except ImportError:
    print "numpy missing!"
#try:
	#import pandas as pd
#except ImportError:
    #print "pandas missing!"
__version__ = '0.1'

