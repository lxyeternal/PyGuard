from setuptools import setup

setup(name='pymcda',
      version='0.1',
      description='',
      url='https://github.com/gmassei/pymcda',
      author='gianluca massei',
      author_email='g_massa@libero.it',
      license='GPL',
      packages=['pymcda'],
      install_requires=['numpy','pandas'],
      zip_safe=False)
##TODO: pandas packages
##http://www.scotttorborg.com/python-packaging/minimal.html
##python setup.py install
