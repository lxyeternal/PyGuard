#:
SECONDS_IN_DAY: float = 86400

#:
HOURS_IN_DAY: float = 24

#:
MINUTES_IN_DAY: float = 1440

#:
MINUTES_IN_HOUR: float = 60

#:
SECONDS_IN_HOUR: float = 3600

#:
SECONDS_IN_MINUTE: float = 60

#:
DEGREES_IN_HOUR: float = 15
