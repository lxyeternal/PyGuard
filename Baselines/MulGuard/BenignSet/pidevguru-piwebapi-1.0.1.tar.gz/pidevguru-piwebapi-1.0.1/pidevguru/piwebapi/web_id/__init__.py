# coding: utf-8

from pidevguru.piwebapi.web_id.web_id_generator import WebIdGenerator
