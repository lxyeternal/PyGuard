# coding: utf-8
from enum import Enum


class WebIdStringType(Enum):
    OneGuid = 1
    TwoGuids = 2
    ThreeGuids = 3
