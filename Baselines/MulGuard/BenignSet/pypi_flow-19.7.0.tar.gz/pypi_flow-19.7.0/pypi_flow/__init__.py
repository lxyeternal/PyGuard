def packageDirectory(package):
    pass