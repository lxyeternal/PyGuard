from __future__ import absolute_import

from tagtools.tagcloud import *
from tagtools.settings import *

from tagging.views import tagged_object_list
