from kontagent import Kontagent, KontagentError

def __exported_functionality__():
    """
    Dummy function to placate PyFlakes.
    """
    return [Kontagent, KontagentError]