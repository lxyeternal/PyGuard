from goodwiki.client import GoodwikiClient
from goodwiki.errors import *
