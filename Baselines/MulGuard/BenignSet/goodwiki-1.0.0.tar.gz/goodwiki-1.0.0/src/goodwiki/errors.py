class CorruptWikitextError(Exception):
    pass
