==========
EDGE OF PY
==========

Package for assessing the distance to criticality in brain dynamics.

Features
--------
Coming soon.

Installation
------------
Install edgeofpy by running:

    pip3 install edgeofpy

Documentation
-------------
Coming soon.

Change Log
----------
Coming soon.

Requirements
------------
- Python 3.7 or later
- numpy
- scipy
- matplotlib
- powerlaw
- neurokit2

License
-------
The project is licensed under the Apache 2.0 license.
