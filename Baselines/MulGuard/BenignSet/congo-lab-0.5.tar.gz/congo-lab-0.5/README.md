# ConGo Lab

A fork of the Octopus project [LINK](https://github.com/richardingham/octopus) stripped down to only the octopus python library.

## Documentation

[Legacy documentation](doc/Octopus%20Documentation.md)
