class Error (Exception):
    pass


class InvalidType (Error):
    pass


class Immutable (Error):
    pass


class InvalidValue (Error):
    pass


class ValueTooSmall (Error):
    pass


class ValueTooLarge (Error):
    pass
