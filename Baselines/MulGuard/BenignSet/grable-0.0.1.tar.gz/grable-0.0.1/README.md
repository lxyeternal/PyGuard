# grable
A simple tabular language for making rule-based linguistic parser/generators
