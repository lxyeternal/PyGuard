"""__init__ module for dictstore package."""

from .interface import *
__all__ = ['DictStore']
