"""
setup.py for dictstore
refer setup.cfg for more information
"""

from setuptools import setup

if __name__ == '__main__':
    setup()
