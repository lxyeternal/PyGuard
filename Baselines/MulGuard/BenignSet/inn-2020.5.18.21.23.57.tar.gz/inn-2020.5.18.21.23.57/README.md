<h1 align = "center">:rocket: inn :facepunch:</h1>

[![Downloads](http://pepy.tech/badge/inn)](http://pepy.tech/project/inn)
[![Downloads](https://pepy.tech/badge/inn/month)](https://pepy.tech/project/inn/month)
[![Downloads](https://pepy.tech/badge/inn/week)](https://pepy.tech/project/inn/week)
[![PyPI release](https://img.shields.io/pypi/v/inn.svg)](https://pypi.python.org/pypi/inn)
[![PyPI version](https://img.shields.io/pypi/pyversions/inn.svg)](https://pypi.python.org/pypi/inn)
---

# Install
```sh
pip install inn
```