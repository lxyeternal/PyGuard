#!/usr/bin/env python
# -*- coding: utf-8 -*-
# @Project      : DeepNN.
# @File         : FFM
# @Time         : 2020/4/21 1:28 下午
# @Author       : yuanjie
# @Email        : yuanjie@xiaomi.com
# @Software     : PyCharm
# @Description  : https://mp.weixin.qq.com/s/XtgdQlpcXz-WjyEKSQfemg
# https://github.com/Hourout/CTR-keras/blob/master/CTR/FFM.py


