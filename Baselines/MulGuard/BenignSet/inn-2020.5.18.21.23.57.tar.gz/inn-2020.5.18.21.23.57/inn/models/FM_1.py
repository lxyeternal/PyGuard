#!/usr/bin/env python
# -*- coding: utf-8 -*-
# @Project      : DeepNN.
# @File         : FM_1
# @Time         : 2020/4/21 11:35 上午
# @Author       : yuanjie
# @Email        : yuanjie@xiaomi.com
# @Software     : PyCharm
# @Description  : /Users/yuanjie/Desktop/Projects/Python/Awesome-RecSystem-Models/Model/FM_TensorFlow.py


