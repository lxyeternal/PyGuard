#!/usr/bin/env python
# -*- coding: utf-8 -*-
# @Project      : Python.
# @File         : fc
# @Time         : 2020-03-11 16:46
# @Author       : yuanjie
# @Email        : yuanjie@xiaomi.com
# @Software     : PyCharm
# @Description  : 


import tensorflow as tf
from tensorflow.python.keras.layers import \
    Dense, Conv1D, GlobalMaxPooling1D, Concatenate, Dropout
