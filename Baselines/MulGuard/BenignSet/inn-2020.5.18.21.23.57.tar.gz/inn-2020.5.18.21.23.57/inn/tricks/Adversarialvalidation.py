#!/usr/bin/env python
# -*- coding: utf-8 -*-
# @Project      : DeepTricks.
# @File         : Adversarialvalidation
# @Time         : 2019-09-22 21:49
# @Author       : yuanjie
# @Email        : yuanjie@xiaomi.com
# @Software     : PyCharm
# @Description  : 


"""
对抗性验证
https://www.kaggle.com/kevinbonnes/adversarial-validation
"""