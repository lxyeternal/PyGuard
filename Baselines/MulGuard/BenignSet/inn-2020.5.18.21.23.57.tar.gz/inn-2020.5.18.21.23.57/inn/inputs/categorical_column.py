#!/usr/bin/env python
# -*- coding: utf-8 -*-
# @Project      : DeepNN.
# @File         : categorical_column
# @Time         : 2020/4/13 4:53 下午
# @Author       : yuanjie
# @Email        : yuanjie@xiaomi.com
# @Software     : PyCharm
# @Description  : wrap a categorical column with an embedding_column or indicator_column

import tensorflow as tf

"""wrap



"""
