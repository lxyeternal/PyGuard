__version__ = '0.1.0'
__author__ = 'Paul Wolf'
__license__ = 'MIT'

from . query import DjangoQuery
from . result import DQResult

