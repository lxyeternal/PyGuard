# Contributing

Welcome! As a [Jupyter](https://jupyter.org) project, we follow the [Jupyter contributor guide](https://jupyter.readthedocs.io/en/latest/contributor/content-contributor.html).

Please make sure to follow the Jupyter [code of conduct](https://github.com/jupyter/governance/blob/master/conduct/code_of_conduct.md).
