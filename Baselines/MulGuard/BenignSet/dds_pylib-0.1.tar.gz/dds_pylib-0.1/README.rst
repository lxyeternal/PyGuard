dds_pylib
=========

**Diversified Data Python Helper Library**

List of available utilities:

1. dates
    1. classes
        1. Gregorian()
    1. functions
        1. todays_julian()
        1.  gregorian2julian()
        1.  julian2gregorian()

