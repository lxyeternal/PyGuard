#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
    __init__.py
    ~~~~~~~~~~~

    Diversified Data Python Utilies Library

    :copyright: (c) 2017 by Stephen Funkhouser.
    :license: see LICENSE for more details.
"""
__title__ = 'dds_pylib'
__version__ = '0.1'
__author__ = 'Stephen Funkhouser'
