#!/usr/bin/python
from distutils.core import setup
setup (
	name="meatmachine",
	version="1.0",
	description="A Kingdom of Loathing bot",
	author="Matt Chaney",
	author_email="chaney.mathew@gmail.com",
	url="http://www.github.com/mattchaney/meatmachine",
	py_modules= ["meatmachine"]
)
