"""Entry point for openlicense."""

from openlicense.cli import main  # pragma: no cover

if __name__ == "__main__":  # pragma: no cover
    main()
