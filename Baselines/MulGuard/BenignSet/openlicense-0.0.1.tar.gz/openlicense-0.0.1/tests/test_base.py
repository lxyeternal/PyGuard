from openlicense.base import NAME


def test_base():
    assert NAME == "openlicense"
