mayor_version = 0
sub_version = 0
revision = 1
release = ''
release_num = ''
version = f'{mayor_version}.{sub_version}.{revision}{release}{release_num}'