from django.apps import AppConfig


class StateMachineAppConfig(AppConfig):
    name = 'state_machine'
