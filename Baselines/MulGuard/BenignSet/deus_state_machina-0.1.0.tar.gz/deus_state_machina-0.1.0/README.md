Deus State Machina
==================

Deus State Machina is a state machine for django that makes sure that you're
not accidentally shooting yourself in the foot when doing things concurrently.

