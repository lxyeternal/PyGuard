#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""Version info"""

short_version = '0.1'
version = '0.1.0'
