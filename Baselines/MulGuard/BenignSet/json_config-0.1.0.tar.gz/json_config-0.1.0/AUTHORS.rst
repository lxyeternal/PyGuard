=======
Credits
=======

Development Lead
----------------

* Manu Phatak <bionikspoon@gmail.com>

Contributors
------------

None yet. Why not be the first?