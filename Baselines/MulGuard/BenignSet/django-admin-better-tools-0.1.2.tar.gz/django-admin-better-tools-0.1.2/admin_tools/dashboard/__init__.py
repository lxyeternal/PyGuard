from admin_tools.dashboard.dashboards import *  # noqa
from admin_tools.dashboard.registry import *  # noqa
