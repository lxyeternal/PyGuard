"""
  A Harness for creating and using various kinds of GPs.
  -- kandasamy@cs.cmu.edu
"""

