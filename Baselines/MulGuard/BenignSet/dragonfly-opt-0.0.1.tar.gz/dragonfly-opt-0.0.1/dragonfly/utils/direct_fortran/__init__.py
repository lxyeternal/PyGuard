"""
  Python wrapper for fortran direct library.
"""
