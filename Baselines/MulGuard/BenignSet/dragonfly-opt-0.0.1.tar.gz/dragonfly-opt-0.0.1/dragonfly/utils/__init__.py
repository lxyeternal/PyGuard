"""
  Some general utility functions we will need.
  -- kandasamy@cs.cmu.edu
"""
