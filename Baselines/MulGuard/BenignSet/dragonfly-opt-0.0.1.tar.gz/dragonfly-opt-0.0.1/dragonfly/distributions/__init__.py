"""
  Classes for various probability distributions
  -- kvysyara@andrew.cmu.edu
"""
