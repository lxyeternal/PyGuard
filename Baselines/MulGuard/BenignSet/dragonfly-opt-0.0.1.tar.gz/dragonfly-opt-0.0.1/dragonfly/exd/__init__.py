"""
  Implements core functionality for Design of Experiments.
  -- kandasamy@cs.cmu.edu
"""
