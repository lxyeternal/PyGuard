"""
  Harness for creating and editing Neural network architectures and defining
  distances/kernels between them.
  -- kandasamy@cs.cmu.edu
"""
