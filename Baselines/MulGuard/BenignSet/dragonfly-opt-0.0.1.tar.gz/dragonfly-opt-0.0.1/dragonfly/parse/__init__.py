"""
  Parser for json and protocol buffer config files. 
  -- kvysyara@andrew.cmu.edu
"""
