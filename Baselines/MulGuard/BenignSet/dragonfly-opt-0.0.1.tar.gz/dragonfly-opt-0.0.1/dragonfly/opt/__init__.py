"""
  Implements all optimisation routines here.
  -- kandasamy@cs.cmu.edu
"""
