"""
  Library for Multi-fidelity Gaussian Process Bandit Optimisation.
  -- kandasamy@cs.cmu.edu
"""
