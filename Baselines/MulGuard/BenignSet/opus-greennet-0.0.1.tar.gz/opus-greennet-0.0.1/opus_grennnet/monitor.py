# from .auth import Auth

# class SmokeDetector: