complete -W "--completions -h --help -l --list -r --remove -u --update $(dotedit --list)" dotedit
