# pyportall

Python SDK to Portall's data and services.

Please take a look at the [documentation](https://inspide.github.io/pyportall/) to get set up.
