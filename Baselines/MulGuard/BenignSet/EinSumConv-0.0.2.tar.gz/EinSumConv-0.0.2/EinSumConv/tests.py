import unittest
from tensor import TestTensor
from findIndex import TestFindIndex
from delta import TestDelta
from eps import TestEps
from renameIndex import TestRenameIndex


# import pdb; pdb.set_trace()

if __name__ == '__main__':
    unittest.main()
