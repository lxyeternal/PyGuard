# -*- coding: utf-8 -*-

import click


@click.command()
def main(args=None):
    """Console script for distill"""
    click.echo("Hello World")


if __name__ == "__main__":
    main()
