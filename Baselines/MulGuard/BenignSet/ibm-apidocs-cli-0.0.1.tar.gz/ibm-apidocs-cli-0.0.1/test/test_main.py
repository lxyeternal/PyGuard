# coding=utf-8

import os
import json
import re
from ibm_apidocs_cli.main import get_basename, get_frontmatter_cli, get_sdk_generator_cli, get_latest_sdk_version, create_frontmatter_config_file, create_frontmatter_md_file, create_language_specific_files, rename_language_specific_files, get_argument_parser, process_args

def test_get_basename_from_file():
    assert 'assistant-v1' == get_basename('/home/geman/public/assistant-v1.json')
    assert 'assistant-v1' == get_basename('/assistant-v1.json')
    assert 'assistant-v1' == get_basename('assistant-v1.json')
    assert 'assistant-v1' == get_basename('/assistant-v1.txt')
    try:
      name = get_basename('')
      assert '%s should be None' % name
    except ValueError as identifier:
      pass

def test_get_basename_from_url():
    assert 'assistant-v1' == get_basename('https://raw.github.ibm.com/Watson/developer-cloud--api-definitions/master/apis-public/assistant-v1.json')
    assert 'assistant-v1' == get_basename('https://ibm.com/assistant-v1.json')

def test_get_frontmatter_cli():
  cli = get_frontmatter_cli('./test/resources/frontmatter/app.js')
  assert cli is not None
  assert cli.endswith('/test/resources/frontmatter/app.js')

def test_get_sdk_generator_cli():
  cli = get_sdk_generator_cli('./test/resources/sdk-generator/run.jar')
  assert cli is not None
  assert cli.endswith('/test/resources/sdk-generator/run.jar')

def test_get_latest_sdk_version():
  languages = ['java', 'node', 'python', 'ruby', 'go', 'swift']
  for l in languages:
    sdk_ver = get_latest_sdk_version(l)
    assert re.match(r"[\d]+[\d.\.]*[\d]$", sdk_ver)

def test_create_frontmatter_config_file():
  languages = ['java', 'node', 'python', 'ruby', 'go', 'swift']
  create_frontmatter_config_file('./test/resources/apidocs/assistant-v1.json', './test/resources/apidocs/assistant-v1-config.json', languages, './test/target/assistant-v1-config.json')
  with open('./test/target/assistant-v1-config.json') as f:
    test_config = json.load(f)
  expected = ['publicUrls',
              'gatewayUrls',
              'serviceMajorVersion',
              'serviceName',
              'sdkName',
              'javaSdkVersion',
              'pythonSdkVersion',
              'swiftSdkVersion']
  assert set(expected).issubset(test_config.keys())

def test_create_frontmatter_md_file():
  create_frontmatter_md_file('./test/resources/frontmatter/app.js', './test/resources/apidocs/assistant-v1.json',
    './test/target/assistant-v1-config.json', './test/target/assistant-v1.md')

def test_create_language_specific_files():
  languages = ['java', 'node', 'python', 'ruby', 'go', 'swift']
  create_language_specific_files('./test/resources/sdk-generator/run.jar', languages, './test/resources/apidocs/assistant-openapi3-v1.json', './test/target')

def test_rename_language_specific_files():
  openapi_file = './test/resources/apidocs/assistant-v1.json'
  languages = ['java', 'node', 'python', 'ruby', 'go', 'swift']
  apidocs = './test/resources/apidocs'
  output_folder = './test/target/'
  for lang in languages:
    if not os.path.isfile(output_folder+lang+'-apiref.json'):
      open(output_folder+lang+'-apiref.json', 'w').close()
  rename_language_specific_files(openapi_file, languages, apidocs, output_folder)
  with open('./test/resources/apidocs/apiref-index.json') as f:
    expected = json.load(f)[os.path.basename(openapi_file)].values()
  actual = os.listdir(output_folder)
  assert set(expected).issubset(actual)

def test_main():
  result = os.system('ibm-apidocs-cli --openapi ./test/resources/apidocs/assistant-openapi3-v1.json \
                                      --apidocs ./test/resources/apidocs \
                                      --config assistant-v1-config.json \
                                      --output_folder ./test/target \
                                      --frontmatter ./test/resources/frontmatter \
                                      --sdk_generator ./test/resources/sdk-generator')
  assert result == 0
