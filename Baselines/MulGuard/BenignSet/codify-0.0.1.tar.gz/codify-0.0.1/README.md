
# codify
Generate codes


To install:	```pip install codify```
