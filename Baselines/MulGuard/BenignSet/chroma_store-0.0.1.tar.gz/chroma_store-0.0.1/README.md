# example_store

[![PyPI - Version](https://img.shields.io/pypi/v/example-store.svg)](https://pypi.org/project/example-store)
[![PyPI - Python Version](https://img.shields.io/pypi/pyversions/example-store.svg)](https://pypi.org/project/example-store)

-----

**Table of Contents**

- [example\_store](#example_store)
  - [Installation](#installation)
  - [License](#license)

## Installation

```console
pip install example-store
```

## License

`example-store` is distributed under the terms of the [Apache-2.0](https://spdx.org/licenses/Apache-2.0.html) license.
