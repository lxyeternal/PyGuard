# artellapipe-libs-drive
============================================================

Library to handle Artella Project production tracking using Google Drive Sheets

.. image:: https://travis-ci.com/ArtellaPipe/artellapipe-libs-drive.svg?branch=master&kill_cache=1
    :target: https://travis-ci.com/ArtellaPipe/artellapipe-libs-drive

.. image:: https://coveralls.io/repos/github/ArtellaPipe/artellapipe-libs-drive/badge.svg?branch=master&kill_cache=1
    :target: https://coveralls.io/github/ArtellaPipe/artellapipe-libs-drive?branch=master

.. image:: https://img.shields.io/badge/docs-sphinx-orange
    :target: https://artellapipe.github.io/artellapipe-libs-drive/

.. image:: https://img.shields.io/github/license/ArtellaPipe/artellapipe-libs-drive
    :target: https://github.com/ArtellaPipe/artellapipe-libs-drive/blob/master/LICENSE

.. image:: https://img.shields.io/pypi/v/artellapipe-libs-drive?branch=master&kill_cache=1
    :target: https://pypi.org/project/artellapipe-libs-drive/

.. image:: https://img.shields.io/badge/code_style-pep8-blue
    :target: https://www.python.org/dev/peps/pep-0008/

