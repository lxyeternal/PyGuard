from setuptools import setup

from artellapipe.libs.drive import __version__

setup()
