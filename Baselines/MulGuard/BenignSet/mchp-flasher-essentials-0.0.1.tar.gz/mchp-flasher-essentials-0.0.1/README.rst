
How to install
--------------
.. code-block:: bash

    pip install mchp-flasher-essentials
    

List of packages
----------------
#. colorama==0.4.4,
#. inputimeout==1.0.4,
#. intelhex==2.3.0,
#. psutil==5.8.0,
#. PyDirectInput==1.0.4,
#. pyelftools==0.27,
#. pywin32==301,
#. termcolor==1.1.0