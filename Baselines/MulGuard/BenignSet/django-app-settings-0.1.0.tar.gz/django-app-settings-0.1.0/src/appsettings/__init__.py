# -*- coding: utf-8 -*-

u"""Django AppSettings package."""

__version__ = '0.1.0'
