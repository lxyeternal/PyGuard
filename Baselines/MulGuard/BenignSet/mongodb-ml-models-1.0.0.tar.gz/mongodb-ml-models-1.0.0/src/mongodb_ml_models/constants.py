config_file_name = "mongodb_ml_model.ini"
