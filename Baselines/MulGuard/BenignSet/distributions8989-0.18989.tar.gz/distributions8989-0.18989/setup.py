from setuptools import setup

setup(name='distributions8989',
      version='0.18989',
      description='Gaussian distributions',
      packages=['distributions'],
      zip_safe=False)
