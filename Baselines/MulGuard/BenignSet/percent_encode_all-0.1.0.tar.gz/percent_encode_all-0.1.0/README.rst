
percent_encode_all
==================


.. image:: https://img.shields.io/pypi/v/package_name.svg
   :target: https://pypi.python.org/pypi/percent_encode_all
   :alt: Latest PyPI version


Encode every charactor into percent format.

Usage
-----

Installation
------------

Requirements
^^^^^^^^^^^^

Compatibility
-------------

Licence
-------

Authors
-------

percent_encode_all was written by `fx-kirin <fx.kirin@gmail.com>`_.
=======================================================================
