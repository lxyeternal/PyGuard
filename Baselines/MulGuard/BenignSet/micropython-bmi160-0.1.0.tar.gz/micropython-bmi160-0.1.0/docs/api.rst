BMI160
=========================================


.. automodule:: micropython_bmi160
    :members:

.. automodule:: micropython_bmi160.bmi160
    :members:

.. automodule:: micropython_bmi160.i2c_helpers
    :members:
