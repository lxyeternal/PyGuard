import pypleasant.cli

if __name__ == "__main__":
    pypleasant.cli.main()
