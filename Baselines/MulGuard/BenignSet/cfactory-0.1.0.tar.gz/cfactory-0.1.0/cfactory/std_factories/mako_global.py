import illuminate.__config__.illuminate_config as il_cfg
from mako.lookup import TemplateLookup

class_ids = {}
trampoline_classes = {}
trampoline_bases = {}
class_conversions = {}

dash_eye = []
