# cfactory
C/C++, et al., metaprogramming tool implemented in python
