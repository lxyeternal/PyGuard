"""SEO Analyzer
"""

def analyze_all(website, keyword):
    """Analyze all the params for a website and keyword pair."""
    params = {'header'        : "Hello Little Bear"
                         }

    return params
