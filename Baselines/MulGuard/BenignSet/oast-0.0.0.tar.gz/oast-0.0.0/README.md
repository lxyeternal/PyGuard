# oast

This package provides our awesome spectral toolbox for performing analysis of hyperspectral data.
