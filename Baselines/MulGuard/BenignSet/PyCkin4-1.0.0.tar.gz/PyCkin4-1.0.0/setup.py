from distutils.core import setup

setup(
    name='PyCkin4',
    version='1.0.0',
    py_modules=['PyCkin4'],
    author='bobi791027',
    author_email='13513519246@139.com',
    description='There are many useful functions.',
)
