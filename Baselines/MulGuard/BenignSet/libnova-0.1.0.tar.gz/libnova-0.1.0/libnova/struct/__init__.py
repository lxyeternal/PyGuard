from libnova.struct.rangemap import RangeMap
