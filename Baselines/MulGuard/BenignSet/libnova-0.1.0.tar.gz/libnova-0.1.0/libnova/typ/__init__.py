"""
libnova.typ is a collection of types to facilitate strong
typing in libnova.
"""

from libnova.typ.comparable import Comparable
