
def get_package_name_from_pyproject():
    ...

