

def test_uses_pyproject_toml():
    ...


def test_can_import():
    import importlib
    importlib.import_module()