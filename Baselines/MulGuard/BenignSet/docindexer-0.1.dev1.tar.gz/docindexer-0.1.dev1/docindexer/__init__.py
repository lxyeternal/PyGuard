# -*- coding: utf-8 -*-

"""
document indexer
~~~~~~~~~~~~~~~~

"""

__title__ = 'docindexer'
__version__ = '0.1'
__author__ = 'Humberto Alves'
__email__ = 'hjalves@student.dei.uc.pt'
__license__ = 'GPL'
__copyright__ = 'Copyright 2014 Humberto Alves'

