from dataclasses import dataclass

@dataclass
class Interval:
    start: str
    end: str
