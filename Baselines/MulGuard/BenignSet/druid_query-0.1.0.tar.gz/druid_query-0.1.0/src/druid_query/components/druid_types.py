from typing import Union

DruidNativeType = Union[str, int, float]

DruidSqlType = Union[str, int, float, bool]
