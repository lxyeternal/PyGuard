from __future__ import unicode_literals

from pymess.models import AbstractOutputSMSMessage


class OutputSMS(AbstractOutputSMSMessage):
    pass
