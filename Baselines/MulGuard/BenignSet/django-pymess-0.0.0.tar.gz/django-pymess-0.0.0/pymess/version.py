VERSION = (0, 0, 0)


def get_version():
    return '.'.join(map(str, VERSION))
