import click


@click.command()
def cli():
    """Not implemented"""
    pass
