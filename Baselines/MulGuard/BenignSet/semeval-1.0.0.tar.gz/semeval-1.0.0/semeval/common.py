from mikatools import *


def supported_languages(): return ['eng', 'fin', 'rus', 'myv', 'mdf', 'kpv', 'sms', ]


def download_path(): return script_path("data/")
