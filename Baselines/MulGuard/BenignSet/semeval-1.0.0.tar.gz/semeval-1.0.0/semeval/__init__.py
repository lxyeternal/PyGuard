from .embeddings import Embeddings
from .serviecs.embeddings import EmbeddingsAPI
