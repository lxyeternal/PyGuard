CitedBy API Client
------------------

Biblioteca para fornecer metodos para recuperar dados de acessos em endpoints 
da API RPC do CitedBy.

Build Status
------------

.. image:: https://travis-ci.org/scieloorg/accessstatsapi.svg?branch=master
    :target: https://travis-ci.org/scieloorg/accessstatsapi

Como Instalar
-------------

pip install accessstatsapi

Como usar
---------
