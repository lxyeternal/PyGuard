# bmynab
Bancolombia to YNAB translator.
