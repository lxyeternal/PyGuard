from setuptools import setup, find_packages

setup(
   name='mytestlib20210124',
   version='1.0.0',
   url='https://www.google.co.jp/',
   author='kiyosima00',
   author_email='kiyosima00@test.net',
   description='test',
   packages=find_packages()
)
