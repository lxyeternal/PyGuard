rorm
======

Wraps redis data structures in python objects.
