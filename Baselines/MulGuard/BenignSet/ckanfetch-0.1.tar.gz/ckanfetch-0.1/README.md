# ckanext-mongodatastore-fetcher
commandline tool to retrieve persistently identified datasets of CKAN repositories
