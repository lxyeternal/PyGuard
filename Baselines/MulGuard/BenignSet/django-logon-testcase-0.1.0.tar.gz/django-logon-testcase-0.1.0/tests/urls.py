# -*- coding: utf-8

urlpatterns = []
