============
Installation
============

At the command line::

    $ easy_install django-logon-testcase

Or, if you have virtualenvwrapper installed::

    $ mkvirtualenv django-logon-testcase
    $ pip install django-logon-testcase
