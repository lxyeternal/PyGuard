.. :changelog:

History
-------

0.1.0 (2017-08-10)
++++++++++++++++++

* First release on PyPI.
