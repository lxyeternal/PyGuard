from setuptools import setup, find_packages

setup(
    name='bashland',
    version='0.0.1',
    description='A demo Python package',
    author='bashland',
    author_email='bash.land@hotmail.com',
    packages=find_packages(),
    include_package_data=True,
    install_requires=[],
)