# -*- coding: utf-8 -*-
from .depends import Depends  # noqa: F401
from .inject import inject  # noqa: F401
