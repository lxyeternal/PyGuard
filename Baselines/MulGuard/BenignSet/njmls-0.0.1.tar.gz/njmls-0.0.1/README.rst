njmls
==========================

|PyPi Version| |License Status|

Python wrapper for njmls. Requires Python 3.6+.

Development
-----------

Setup
~~~~~

::

    make install

Test
~~~~

::

    make test


Disclaimer
----------

.. |PyPI Version| image:: https://img.shields.io/pypi/v/njmls.svg
   :target: https://pypi.python.org/pypi/njmls
.. |License Status| image:: https://img.shields.io/badge/license-MIT-blue.svg
   :target: https://raw.githubusercontent.com/AlJohri/njmls/master/LICENSE
