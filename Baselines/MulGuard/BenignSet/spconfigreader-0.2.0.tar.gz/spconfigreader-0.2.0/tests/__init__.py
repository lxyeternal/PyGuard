from configreader import config

config.__configfile__="tests/config.yml"