import webbrowser

def run():		webbrowser.open("https://ultramarine-linux.org")
