This tool helps you install bears interactively.
To see more about bears, check https://github.com/coala-analyzer/coala-bears.
