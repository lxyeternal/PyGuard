Changelog
=========

master
------


v0.1.0
------

- (`#18 <https://github.com/znicholls/CMIP6-json-data-citation-generator/pull/18>`_) Added basic citation generator setup

