def func(a,b):
    return a+b