# -*- coding:utf-8 -*-
#从python发布工具中导入setup函数
from distutils.core import setup
setup(
    name =  'readlistsmod',
    version = '1.0.0',
    py_modules = ['readlistsmod'],
    author = 'Hisea',
    author_email = 'hiseamail@foxmail.com',
    url = '',
    description= '对列表进行简单的打印',
	)
