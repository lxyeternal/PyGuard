def fun():
    print('Greetings, Himeros.')