odbcutils
=========

| |Version| |Build Status|

A small helper library for executing SQL using pyodbc. 


Releases
--------

0.1 (02/07/2019)
++++++++++++++++

+ Initial release

Author
------

* Seth Girvin `@geographika <https://github.com/geographika>`_

.. |Version| image:: https://img.shields.io/pypi/v/odbcutils.svg
   :target: https://pypi.python.org/pypi/odbcutils

.. |Build Status| image:: https://travis-ci.org/geographika/odbcutils.svg?branch=master
   :target: https://travis-ci.org/geographika/odbcutils
