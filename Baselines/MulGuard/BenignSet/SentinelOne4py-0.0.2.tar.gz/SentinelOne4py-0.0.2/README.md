# SentinelOne for Python

This package creates an Api for SentinelOne in Python. It also has an alert parser.
