This is a security placeholder package.
If you want to claim this name for legitimate purposes,
please contact us at secuirty@yandex-team.ru or pypi-security@yandex-team.ru