from distutils.core import setup

setup(
    name='blob',
    version='0.1',
    packages=['blob'],
    install_requires=[
    ],
)
