class BlobError(Exception):
    pass

class XORError(BlobError):
    pass
