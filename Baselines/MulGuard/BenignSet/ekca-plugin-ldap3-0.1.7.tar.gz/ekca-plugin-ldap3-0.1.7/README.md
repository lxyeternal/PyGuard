EKCA password checker plugin
============================

This module package implements a LDAP password plugin for the server 
component of [EKCA](https://ekca.stroeder.com).
