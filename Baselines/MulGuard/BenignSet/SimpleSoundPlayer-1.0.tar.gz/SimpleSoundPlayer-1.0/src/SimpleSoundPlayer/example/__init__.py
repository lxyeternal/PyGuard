import SimpleSoundPlayer

# Play file sound
# SimpleSoundPlayer.playSoundFile(SOUND)

# Play sound from a file
# SimpleSoundPlayer.playSoundURL(URL)

# Play audio from youtube (using music Illusion - Pepe_Java)
SimpleSoundPlayer.playSoundYoutube("https://www.youtube.com/watch?v=vNaQo_WDfY8")