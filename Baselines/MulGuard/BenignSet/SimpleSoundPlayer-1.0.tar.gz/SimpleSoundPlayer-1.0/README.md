# Simple Sound Player

- Biblioteca de python.

## Suporte:

- Youtube
- Arquivos
- URL's

## Requer:

- VLC Media Player
- playsound
- vlc