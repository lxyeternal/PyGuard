__TITLE__ = "DI-searching"
__VERSION__ = "0.0.0"
__DESCRIPTION__ = "Decision AI"
__AUTHOR__ = "OpenDILab Contributors"
__AUTHOR_EMAIL__ = "opendilab.contact@gmail.com"
__version__ = __VERSION__
