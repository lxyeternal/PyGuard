ite_content_data_dict = {
    "program_buffer": 10240000,
}
