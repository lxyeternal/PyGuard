class BarkNotificatorException(Exception):
    pass
