from setuptools import setup

setup(name='deepdft', version='0.0.0', packages=['deepdft'])
