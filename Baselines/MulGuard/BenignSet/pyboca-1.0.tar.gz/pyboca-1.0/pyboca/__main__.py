import fire
from pyboca import ch2en

def main():
    fire.Fire(ch2en)

if __name__ == '__main__':
    main()