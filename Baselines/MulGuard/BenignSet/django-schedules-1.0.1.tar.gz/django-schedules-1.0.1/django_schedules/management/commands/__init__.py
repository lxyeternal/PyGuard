"""Each file is one command for ./manage.py."""
