// enble contrib.admins jQuery outside the djang namespace
var jQuery = django.jQuery;
var $ = jQuery
//var django = {
//    "jQuery": django.jQuery.noConflict(false)
//};
