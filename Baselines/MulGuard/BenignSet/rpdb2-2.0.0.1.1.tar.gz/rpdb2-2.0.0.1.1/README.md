# rpdb2

rpdb2 module extracted from winpdb package.

In contrast to winpdb, this module can be installed without wxpython.

Note that it contain rpdb module with may conflict with the one that comes with rpdb package.

Version of this package is the same as version of winpdb that rpdb2 was stolen from.

