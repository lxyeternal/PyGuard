# microscope-metrics-omero
A python package for interacting with microscope-metrics in OMERO