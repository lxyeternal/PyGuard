py-unisender
====================

Use REST API unisender.ru

=======
Install
=======

.. code-block:: bash

    pip install py-unisender
