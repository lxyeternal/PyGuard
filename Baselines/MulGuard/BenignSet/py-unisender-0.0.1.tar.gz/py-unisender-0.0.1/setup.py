from setuptools import setup, find_packages

setup(
    name='py-unisender',
    version='0.0.1',
    packages=find_packages(),
    author='Dmitry Kalinin',
    author_email='dmitry.kalinin.email@gmail.com',
    url='https://github.com/null-none/py-unisender',
)
