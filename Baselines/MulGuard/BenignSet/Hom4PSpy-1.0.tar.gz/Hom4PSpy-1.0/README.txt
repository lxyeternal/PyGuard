========
Hom4PSpy
========

Hom4PSpy provides a simplified Python interface for Hom4PS-3,
a numerical solver for systems of polynomial equations based 
on homotopy continuation methods.
