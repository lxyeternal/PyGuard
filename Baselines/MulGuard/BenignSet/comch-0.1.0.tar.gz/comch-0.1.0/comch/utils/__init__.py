from .utils import pairwise
from .utils import partitions
