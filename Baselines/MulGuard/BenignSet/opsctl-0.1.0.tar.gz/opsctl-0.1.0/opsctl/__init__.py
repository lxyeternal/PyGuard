#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# Author: v.stone@163.com


if __name__ == '__main__':
    print('This is Python scripts')
