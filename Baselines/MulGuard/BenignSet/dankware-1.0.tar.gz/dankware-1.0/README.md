# dankware
 Python module with various features
