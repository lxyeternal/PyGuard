metadsl_core.boolean
========================

.. automodule:: metadsl_core.boolean
