metadsl_core.integer
========================

.. automodule:: metadsl_core.integer
