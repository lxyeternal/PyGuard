metadsl_core
============

.. automodule:: metadsl_core

.. toctree::
   :maxdepth: 3

   abstraction
   boolean
   conversion
   either
   integer
   maybe
   numpy_engine
   numpy
   pair
   vec



