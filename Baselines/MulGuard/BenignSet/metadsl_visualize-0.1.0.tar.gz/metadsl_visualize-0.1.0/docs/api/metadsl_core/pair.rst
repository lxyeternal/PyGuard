metadsl_core.pair
========================

.. automodule:: metadsl_core.pair
