metadsl_core.vec
========================

.. automodule:: metadsl_core.vec
