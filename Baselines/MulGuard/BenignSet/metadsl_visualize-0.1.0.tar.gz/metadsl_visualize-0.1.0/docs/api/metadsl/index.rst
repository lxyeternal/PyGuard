metadsl
=======

.. automodule:: metadsl

.. toctree::
   :maxdepth: 3

   expressions
   rules
   matching


