import {Ext} from 'cytoscape'

const ext: Ext;
export default ext;