collect_ignore = ["docs/conf.py"]
