extern int crypto_hash_sha3_512(unsigned char *out,const unsigned char *in,unsigned long long inlen);

#define crypto_hash_sha3_512_BYTES 64
