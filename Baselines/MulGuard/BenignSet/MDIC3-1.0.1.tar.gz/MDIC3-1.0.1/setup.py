import setuptools


setuptools.setup(
    name="MDIC3",
    version="1.0.1",
    author="Lyxiaotai",
    author_email="liuyi54894xiaotai@163.com",  
    description="A Lucky Python Package",  
    url="https://github.com/LYxiaotai/MDIC3",     
   
)


