### FEIOS_UTILS
* This is a library for feios to run.
* This includes some small and useful utils.
* You can use it in your app like:
```python
import feios_utils
feios_utils.out("Hello")
```
* Note that the library is licensed under GNU GPL v3+.Your app should be licensed under that too.
