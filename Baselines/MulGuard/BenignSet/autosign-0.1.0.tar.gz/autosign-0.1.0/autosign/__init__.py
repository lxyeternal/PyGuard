#!/usr/bin/env python2

##
# autosign
# https://github.com/leosartaj/autosign.git
# 
# copyright (c) 2014 sartaj singh
# licensed under the mit license.
##

from info.version import __version__ # define __version__ variable
from info.desc import __desc__ # define __desc__ variable for description
