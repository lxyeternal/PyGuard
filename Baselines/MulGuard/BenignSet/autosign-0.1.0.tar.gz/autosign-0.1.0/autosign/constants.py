#!/usr/bin/env python2

##
# autosign
# https://github.com/leosartaj/autosign.git
# 
# copyright (c) 2014 sartaj singh
# licensed under the mit license.
##

"""
Various constants fro defining sign
"""
__sigstart__ = '##'
__sigline__  = '#'
__sigend__   = '##'
__inter__    = '#!'
