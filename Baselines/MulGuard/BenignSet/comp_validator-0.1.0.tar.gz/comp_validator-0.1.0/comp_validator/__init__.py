
__author__ = """Dinara Issagaliyeva"""
__email__ = 'dinarissaa@gmail.com'
__version__ = '0.1.0'

from comp_validator.check import *
from comp_validator.issues import *
