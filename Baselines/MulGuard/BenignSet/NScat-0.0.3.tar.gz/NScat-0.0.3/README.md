# NScat
'A package python to query various neutron star parameters from publicly available databases'

Here is the link to the documentation- https://nscat.readthedocs.io/en/latest/

For queries, comments, feedback and suggestions please contact Rohit Chinchwadkar (chinchwadkarrohit4@gmail.com)