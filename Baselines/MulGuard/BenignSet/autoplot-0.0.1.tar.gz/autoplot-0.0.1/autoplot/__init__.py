# Allow "from autoplot import javaaddpath"
from autoplot.jpypeutil import javaaddpath
