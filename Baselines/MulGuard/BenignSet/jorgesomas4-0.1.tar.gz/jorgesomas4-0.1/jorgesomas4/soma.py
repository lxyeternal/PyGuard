def jorgesomas4(a, b):
    return(a + b)

# Path: jorgesomas4\tests\test_soma.py