"""matheo - Matheo is a python package with mathematical algorithms for use in earth observation data and tools."""

__author__ = "Sam Hunt, Pieter De Vis <kavya.jagan@npl.co.uk>"
__all__ = []

from ._version import __version__

