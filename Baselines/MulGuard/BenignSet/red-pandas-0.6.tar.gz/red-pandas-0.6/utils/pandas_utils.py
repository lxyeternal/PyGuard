def message(name):
    print "Red panda {} is awesome!".format(name)
