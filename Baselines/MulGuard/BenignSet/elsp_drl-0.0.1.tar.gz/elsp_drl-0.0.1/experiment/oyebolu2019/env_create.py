import os

from elsp_env_manager.elsp_env import ELSPEnv


def env_creator():
    return ELSPEnv("/home/mi-nan/workspace/myPyCharm/elsp_drl/experiment/oyebolu2019/envs/elsp_env_00108",
                   "/home/mi-nan/workspace/myPyCharm/elsp_drl/experiment/oyebolu2019/envs/")
