=====================================================================================
iRPC — lightning-fast transport-agnostic RPC with asyncio support [Under Development]
=====================================================================================

.. image:: https://api.travis-ci.org/thodnev/irpc.svg
    :target: https://travis-ci.org/thodnev/irpc

.. image:: https://coveralls.io/repos/github/thodnev/irpc/badge.svg
    :target: https://coveralls.io/github/thodnev/irpc

.. image:: https://readthedocs.org/projects/irpc/badge/?version=dev
    :target: https://irpc.readthedocs.io
