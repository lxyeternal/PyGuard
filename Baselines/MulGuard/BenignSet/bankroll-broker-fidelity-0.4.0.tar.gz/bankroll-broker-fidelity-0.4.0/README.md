# bankroll-broker-fidelity [![PyPI version](https://badge.fury.io/py/bankroll-broker-fidelity.svg)](https://badge.fury.io/py/bankroll-broker-fidelity) [![CircleCI](https://circleci.com/gh/bankroll-py/bankroll-broker-fidelity.svg?style=svg&circle-token=67d5ae8a2bd7f35982260904d468ee2a04a6d8f8)](https://circleci.com/gh/bankroll-py/bankroll-broker-fidelity)

[Fidelity](https://www.fidelity.com) support for [bankroll](https://github.com/bankroll-py).
