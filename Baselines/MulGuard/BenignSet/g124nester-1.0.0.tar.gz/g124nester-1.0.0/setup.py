from distutils.core import setup

setup(
        name         = 'g124nester',
        version      = '1.0.0',
        py_modules   = ['nester'],
        author       = 'gipson',
        author_email = 'gipsonpulla@live.com',
        url          = 'http://www.headfirstlabs.com',
        description  = 'A simple printer of nested list',
)
