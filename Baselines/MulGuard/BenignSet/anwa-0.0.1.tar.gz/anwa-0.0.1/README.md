  
[![Build Status](https://travis-ci.org/mjirik/anwa.svg?branch=master)](https://travis-ci.org/mjirik/anwa)
[![Coverage Status](https://coveralls.io/repos/github/mjirik/anwa/badge.svg?branch=master)](https://coveralls.io/github/mjirik/anwa?branch=master)
[![PyPI version](https://badge.fury.io/py/anwa.svg)](http://badge.fury.io/py/anwa)


anwa

Automatic animal detection in video

