from setuptools import setup, find_packages

setup(name="arrpy", packages=find_packages())