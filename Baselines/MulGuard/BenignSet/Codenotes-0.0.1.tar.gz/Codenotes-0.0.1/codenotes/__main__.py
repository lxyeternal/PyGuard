import codenotes

if __name__ == '__main__':
    codenotes.main()
