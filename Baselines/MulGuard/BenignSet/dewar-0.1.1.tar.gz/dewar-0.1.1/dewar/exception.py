class ValidationError(TypeError):
    pass
