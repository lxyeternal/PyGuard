from sadie.models import AbstractModel


class SimpleModel(AbstractModel):
    pass
