"""Top-level package for Sadie: Stochastic Agents in DIscrete time and Euclidean space."""

__author__ = """Chris von Csefalvay"""
__email__ = 'chris@chrisvoncsefalvay.com'
__version__ = '0.1.0'
