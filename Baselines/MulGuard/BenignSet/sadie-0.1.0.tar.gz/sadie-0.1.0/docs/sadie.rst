sadie package
=============

Subpackages
-----------

.. toctree::

    sadie.agents
    sadie.models

Submodules
----------

sadie.sadie module
------------------

.. automodule:: sadie.sadie
    :members:
    :undoc-members:
    :show-inheritance:


Module contents
---------------

.. automodule:: sadie
    :members:
    :undoc-members:
    :show-inheritance:
