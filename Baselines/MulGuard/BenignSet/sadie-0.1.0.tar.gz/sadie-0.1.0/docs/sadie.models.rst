sadie.models package
====================

Submodules
----------

sadie.models.base module
------------------------

.. automodule:: sadie.models.base
    :members:
    :undoc-members:
    :show-inheritance:

sadie.models.simple module
--------------------------

.. automodule:: sadie.models.simple
    :members:
    :undoc-members:
    :show-inheritance:


Module contents
---------------

.. automodule:: sadie.models
    :members:
    :undoc-members:
    :show-inheritance:
