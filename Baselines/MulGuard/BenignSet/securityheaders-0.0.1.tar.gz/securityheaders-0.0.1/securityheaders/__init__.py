# -*- coding: utf-8 -*-

__VERSION__ = "0.0.1"
__LICENSE__ = "MIT"
__AUTHOR__ = "Timo Furrer"
__AUTHOR_EMAIL__ = "tuxtimo@gmail.com"
__URL__ = "https://github.com/timofurrer/securityheaders"
