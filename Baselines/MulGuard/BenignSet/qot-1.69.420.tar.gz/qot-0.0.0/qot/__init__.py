def qot():
    return 'Qot.'
