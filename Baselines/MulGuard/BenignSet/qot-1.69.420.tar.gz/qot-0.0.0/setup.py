from setuptools import setup

setup(name='qot',
    description='qot',
    long_description='qot',
    author='qot',
    license='qot',
    packages=['qot'],
    entry_points={'console_scripts': ['qot=qot:qot']},
)
