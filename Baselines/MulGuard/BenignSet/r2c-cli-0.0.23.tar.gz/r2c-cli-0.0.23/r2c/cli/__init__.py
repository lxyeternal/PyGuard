#!/usr/bin/env python3

__author__ = "Return To Corporation <cli@returntocorp.com>"
__version__ = "0.0.23"
R2C_SUPPORT_EMAIL = "support@ret2.co"
