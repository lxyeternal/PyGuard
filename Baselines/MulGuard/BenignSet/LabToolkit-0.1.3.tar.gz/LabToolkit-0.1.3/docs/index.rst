Welcome to LabToolkit's documentation!
======================================

Contents:

.. toctree::
   :maxdepth: 2

   readme
   installation
   usage
   contributing
   authorshistory
   pages

Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`
