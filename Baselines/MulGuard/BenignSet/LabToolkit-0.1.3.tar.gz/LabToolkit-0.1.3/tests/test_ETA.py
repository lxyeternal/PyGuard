#!/usr/bin/env python3

# from ETA import ETA


def test_ETA():
    times = []
    times.append(84.43)
    times.append(21.231)
    times.append(21.231)
    # assert(ETA(times, 48) == "33.8")
