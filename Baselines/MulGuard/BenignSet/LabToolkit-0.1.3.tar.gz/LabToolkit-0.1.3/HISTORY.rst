=======
History
=======

0.1.2 (2017-09-21)
------------------

* Fix history to enable 0.1.1 and 0.1.2.

0.1.1 (2017-09-21)
------------------

* Fix cross reference of package not imported.

0.1.0 (2017-01-24)
------------------

* First release on PyPI.
