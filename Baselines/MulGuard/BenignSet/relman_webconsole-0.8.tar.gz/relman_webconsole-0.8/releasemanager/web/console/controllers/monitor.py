from releasemanager.web.console.lib.base import *

class MonitorController(BaseController):
    def index(self):
        return Response('')
