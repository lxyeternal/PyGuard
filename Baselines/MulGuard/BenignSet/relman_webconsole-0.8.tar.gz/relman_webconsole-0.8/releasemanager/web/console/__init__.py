"""
releasemanager.web.console

This file loads the finished app from releasemanager.web.console.config.middleware.

"""

from releasemanager.web.console.config.middleware import make_app
