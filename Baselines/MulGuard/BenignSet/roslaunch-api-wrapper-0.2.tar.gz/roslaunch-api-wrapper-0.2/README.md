### Installation

```sh
$ sudo pip install "git+https://github.com/ACarfi/roslaunch-api-wrapper"
```
