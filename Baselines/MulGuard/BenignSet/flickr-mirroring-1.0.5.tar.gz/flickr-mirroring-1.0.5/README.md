# Flickr Mirroring

## Installation

```bash
$ pipenv shell --three
$ pipenv install flickr-mirroring
Installing flickr-mirroring…
Adding flickr-mirroring to Pipfile's [packages]…
✔ Installation Succeeded
Pipfile.lock not found, creating…
Locking [dev-packages] dependencies…
Locking [packages] dependencies…
✔ Success!
Updated Pipfile.lock (96799b)!
Installing dependencies from Pipfile.lock (96799b)…
  🐍   ▉▉▉▉▉▉▉▉▉▉▉▉▉▉▉▉▉▉▉▉▉▉▉▉▉▉▉▉▉▉▉▉ 32/32 — 00:00:15
```

## Execution

```bash
$ flickr_mirror
```
