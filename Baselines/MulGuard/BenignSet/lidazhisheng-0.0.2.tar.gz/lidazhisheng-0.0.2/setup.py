# -*- coding: utf-8 -*-
# @Time    : 2020/4/22 下午4:58
# @Author  : zyg
# @File    : setup.py.py
# @Desc
#!/usr/bin/env python
# coding: utf-8

from setuptools import setup

setup(
    name='lidazhisheng',
    version='0.0.2',
    author='zyg',
    author_email='zyg8929@163.com',
    url='https://zhuanlan.zhihu.com',
    description='',
    packages=['lidazhisheng'],
    install_requires=[],

)