from setuptools import setup

setup (
    name = "maxembeds",
    version = "0.0.1",
    description = "Awesome EmbedBuilder for discord.py",
    py_modules = ["MaxEmbeds"],
    package_dir = {"": "src"}
)