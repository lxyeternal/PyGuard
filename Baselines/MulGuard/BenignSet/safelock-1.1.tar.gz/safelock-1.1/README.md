
DeNova Safelock
-------------__

Locks are usually the simplest way to get safe concurrent access to a shared resource.
But they are a bear to get right.
Safelog makes it easy.
Get simple systemwide multithread, multiprocess, multiprogram locks.


Learn more about Safelock at https://denova.com/open_source/safelock/
