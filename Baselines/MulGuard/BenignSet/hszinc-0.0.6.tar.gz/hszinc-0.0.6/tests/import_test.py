import hszinc
