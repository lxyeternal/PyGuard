Accern-XYME
===========

*accern\_xyme* is a python library for accessing XYME functionality.

Usage
-----

You can install *accern\_xyme* with pip:

.. code:: sh

    pip install --user accern_xyme

Import it in python via:

.. code:: python

    from accern_xyme import create_xyme_client

You will need python3.6 or later.
