try:
    from molotov.fmwk import scenario               # NOQA
except ImportError:
    pass   # first import

__version__ = '0.1'
