TRI Coding Challenge Parser
==========================

Parser Instructions
----------------------
To run parser, `python3 run_parser.py`.
Enter the path of your file `Enter the absolute path of input file:`
Enter the x-largest `Enter value for X-largest:`

Algorithmic Complexity
----------------------
- The parser reads in the document file line by line.
- O(n) * [file I/O]
- Note: scan_document(file_path) is modular to be replaced with more optimal scanning performane.
- An example of faster scanning solution: read file in chunks(1024) or chunks depending on size of file.
- The parser keeps the parsed data in a max-Heap.
- Returning the x-largest values from the max-Heap (delete-max) is O(log n).
- The space complexity of a heap is O(n).

Unit Test Suite
----------------------
To run unit tests `python3 setup.py test`

Hours Spent
----------------------
- I took 1-2 hours to write the parser, 2-4 hours on trying different unit test tools and structure.
