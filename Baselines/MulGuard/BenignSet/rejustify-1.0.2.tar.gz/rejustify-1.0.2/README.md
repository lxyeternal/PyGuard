## rejustify Python client

The  `rejustify` module provides plug and play support for the rejustify API. Quick and easy installation process requires a token, which you can get by creating a free account at <a href='https://rejustify.com' target='_blank'>rejustify.com</a>.  

To install `rejustify` module:

```
pip install rejustify
```

For tutorials and practical examples how to use the package efficiently, visit <a href="https://rejustify.com/python" target="_blank">rejustify.com/python</a>.
