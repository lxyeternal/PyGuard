Python Client Library
=====================

Look at publisher.py for an example. This standardizes units and sensor types
before putting them on the conix broker. It also automates the use of wave.

Currently requires a running waved service to work. Look in smart-cities-demo/wave
to get that service running
