#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Tue Feb  2 15:34:52 2021

@author: zhaoyang
"""

from setuptools import find_packages,setup
setup(
    name = 'feature_eva',
    version = '0.1',
    packages = find_packages(),
    author='zhaoyang',
)