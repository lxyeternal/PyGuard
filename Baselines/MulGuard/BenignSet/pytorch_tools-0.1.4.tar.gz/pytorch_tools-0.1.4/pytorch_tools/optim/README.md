# Custom optimizers and utils
Self-explanatory