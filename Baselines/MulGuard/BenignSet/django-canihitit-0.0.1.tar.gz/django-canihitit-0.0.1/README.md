django-canihitit
================

Can I hit it? Yes you can! A tiny object hit counter for Django.
