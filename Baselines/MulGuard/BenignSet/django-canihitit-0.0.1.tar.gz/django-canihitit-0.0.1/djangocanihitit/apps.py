from django.apps import AppConfig


class DjangoCanIHitItConfig(AppConfig):
    name = 'djangocanihitit'
    verbose_name = 'Django Can I Hit It?'
