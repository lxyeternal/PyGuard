# Reed-Solomon

Reed Solomon (255, 223) CCSDS in Python.

Library based on https://github.com/crozone/ReedSolomonCCSDS
