import sys
from figshare_get.cli import figshare_get

if __name__ == "__main__":
    figshare_get(sys.argv[1:])
