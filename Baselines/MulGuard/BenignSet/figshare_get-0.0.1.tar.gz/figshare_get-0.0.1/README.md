# figshare_get

Download a figshare collection.

```
figshare_get 10.6084/m9.figshare.c.4081802.v1
```
