from .simple_locize import SimpleLocize
