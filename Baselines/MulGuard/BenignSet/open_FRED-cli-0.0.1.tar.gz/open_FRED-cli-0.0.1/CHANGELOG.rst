
Changelog
=========

0.0.1 (2019-12-03)
------------------

* First release on PyPI.
