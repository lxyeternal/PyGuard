major = 0
minor = 0
patch = 1
status = ''
