open_FRED
=========

.. testsetup::

    from open_FRED import *

.. automodule:: open_FRED
    :members:
