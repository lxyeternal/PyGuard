=====
Usage
=====

To use "open_FRED CLI" in a project::

	import open_FRED
