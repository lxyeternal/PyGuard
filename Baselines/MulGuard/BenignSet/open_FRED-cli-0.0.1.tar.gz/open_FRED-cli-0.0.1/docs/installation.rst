============
Installation
============

At the command line::

    pip install open_FRED-cli
