relife package
==============

Submodules
----------

relife.data module
------------------

.. automodule:: relife.data
   :members:
   :undoc-members:
   :show-inheritance:
   :noindex:

relife.datasets module
----------------------

.. automodule:: relife.datasets
   :members:
   :undoc-members:
   :show-inheritance:
   :noindex:

relife.discounting module
-------------------------

.. automodule:: relife.discounting
   :members:
   :undoc-members:
   :show-inheritance:
   :noindex:

relife.distribution module
--------------------------

.. automodule:: relife.distribution
   :members:
   :undoc-members:
   :show-inheritance:
   :noindex:

relife.model module
-------------------

.. automodule:: relife.model
   :members:
   :undoc-members:
   :show-inheritance:
   :noindex:

relife.nonparametric module
---------------------------

.. automodule:: relife.nonparametric
   :members:
   :undoc-members:
   :show-inheritance:
   :noindex:

relife.parametric module
------------------------

.. automodule:: relife.parametric
   :members:
   :undoc-members:
   :show-inheritance:
   :noindex:

relife.regression module
------------------------

.. automodule:: relife.regression
   :members:
   :undoc-members:
   :show-inheritance:
   :noindex:

relife.renewal\_process module
------------------------------

.. automodule:: relife.renewal_process
   :members:
   :undoc-members:
   :show-inheritance:
   :noindex:

relife.replacement\_policy module
---------------------------------

.. automodule:: relife.replacement_policy
   :members:
   :undoc-members:
   :show-inheritance:
   :noindex:

relife.reward module
--------------------

.. automodule:: relife.reward
   :members:
   :undoc-members:
   :show-inheritance:
   :noindex:

relife.utils module
-------------------

.. automodule:: relife.utils
   :members:
   :undoc-members:
   :show-inheritance:
   :noindex:

Module contents
---------------

.. automodule:: relife
   :members:
   :undoc-members:
   :show-inheritance:
   :noindex:
