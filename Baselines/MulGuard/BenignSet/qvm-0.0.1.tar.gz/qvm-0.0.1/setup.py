#!/usr/bin/env python

from setuptools import setup

setup(
    name="qvm",
    version="0.0.1"
)
