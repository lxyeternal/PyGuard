__author__ = "LmR <letmer00t@gmail.com>"
__license__ = "MIT"
__contributors__ = []
__version__ = "1.0.0"

from pycheckpoint_api.firewallManagement import FirewallManagement  # noqa
