
# fdlock - python file lock

secure and comfortable locking file regions

features:
    
- tracks already locked regions
  - checks overlapping regions
- with context manager included
  - automatic unlocking
- custom locking backends (currently Linux only)
- 


