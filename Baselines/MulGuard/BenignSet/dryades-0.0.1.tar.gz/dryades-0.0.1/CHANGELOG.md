
see [`BACKLOG`](./BACKLOG.md)
for open development tasks and limitations.


# CHANGELOG


## next version v0.0.1 - 20221008

- moved other code base into dryades
  - https://github.com/kr-g/pyheapfile
  - https://github.com/kr-g/pydllfile
  - https://github.com/kr-g/pybimfile
  - https://github.com/kr-g/pyfdlock
  - https://github.com/kr-g/pybtreecore
  - https://github.com/kr-g/pybtreeplus
  -
- heapfile: 
  - parameter max_size for limiting the size of the heapfile
- fdlock:
  - added backend for calling lockf and ulockf abstraction
  - added `VirtualBackend` passing all lock functions
-  
- all tests are running !
- 


## version v0.0.0 - 20221001

- first release of empty project 
- 
