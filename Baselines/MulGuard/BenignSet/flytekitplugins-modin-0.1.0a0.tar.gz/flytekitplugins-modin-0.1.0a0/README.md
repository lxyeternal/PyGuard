# Flytekit Modin Plugin

Modin is an emerging drop-in replacement or rather extension of Pandas. This plugin could be helpful to use Modin as a data type.

To install the plugin, run the following command:

```bash
pip install flytekitplugins-modin
```

_Example coming soon!_
