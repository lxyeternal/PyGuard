# scalcbr

Description. 
The package simple_calculator is used to:
	- simple calc operation
	- sum, subtract, multiply or divide
	![import and call](scalcbr/image/import_and_calls.png)

## Installation

Use the package manager [pip](https://pip.pypa.io/en/stable/) to install package_name

```bash
pip install scalcbr
```

## Author
Daniel Victor

## License
[MIT](https://choosealicense.com/licenses/mit/)

###### Folder old
First package version - don't exist more, but if you execute file call_calculator.py
will have a iterative, interactive simple calculator
