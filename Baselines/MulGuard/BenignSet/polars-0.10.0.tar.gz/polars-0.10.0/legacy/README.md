# Py-polars
This is a temporary proxy from py-polars to the renamed polars package.
This should smoothen the transition.

Please install [polars](https://pypi.org/project/polars/) instead of this package!
