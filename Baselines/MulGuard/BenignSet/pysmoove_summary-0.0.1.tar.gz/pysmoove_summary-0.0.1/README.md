# pysmoove-summary

Summarize pysmoove SV calling VCF results in a BED-like format
