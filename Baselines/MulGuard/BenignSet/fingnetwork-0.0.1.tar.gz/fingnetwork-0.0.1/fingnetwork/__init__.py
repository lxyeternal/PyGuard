def pyonly(s):
    print("This project will be available soon!")