"""
Example output for https://github.com/nickderobertis/copier-pypi-sphinx-flexlate
"""
