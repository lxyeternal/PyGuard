# Marco test package


[![PyPI version](https://badge.fury.io/py/marco_test_package.svg)](https://badge.fury.io/py/marco_test_package)
![versions](https://img.shields.io/pypi/pyversions/marco_test_package.svg)
[![GitHub license](https://img.shields.io/github/license/mgancita/marco_test_package.svg)](https://github.com/mgancita/marco_test_package/blob/main/LICENSE)



[![Code style: black](https://img.shields.io/badge/code%20style-black-000000.svg)](https://github.com/psf/black)


Test package for marco


- Free software: MIT
- Documentation: https://mgancita.github.io/marco-test-package.


## Features

* TODO

## Credits


This package was created with [Cookiecutter](https://github.com/audreyr/cookiecutter) and the [`mgancita/cookiecutter-pypackage`](https://mgancita.github.io/cookiecutter-pypackage/) project template.
