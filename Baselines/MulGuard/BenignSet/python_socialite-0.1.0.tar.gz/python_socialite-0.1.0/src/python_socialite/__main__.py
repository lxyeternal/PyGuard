import sys  # pragma: no cover
from python_socialite.cli import main  # pragma: no cover


if __name__ == "__main__":  # pragma: no cover
    sys.exit(main())
