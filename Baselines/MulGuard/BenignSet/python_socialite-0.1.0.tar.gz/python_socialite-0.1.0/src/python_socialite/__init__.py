"""Top-level package for python-socialite."""

__author__ = """Evans Mwendwa"""
__email__ = "evans@authenticvisualsmedia.com"
__version__ = "0.1.0"
