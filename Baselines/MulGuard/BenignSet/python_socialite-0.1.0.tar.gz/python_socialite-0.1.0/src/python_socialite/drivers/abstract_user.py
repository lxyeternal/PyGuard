abstract_user = {
    "id": "",
    "name": "",
    "email": "",
    "avatar": "",
    "raw": "",
    "provider": "",
}
