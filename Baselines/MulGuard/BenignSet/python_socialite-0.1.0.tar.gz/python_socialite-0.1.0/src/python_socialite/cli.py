"""Console script for python_socialite."""
import sys  # pragma: no cover


if __name__ == "__main__":  # pragma: no cover
    sys.exit(main())
