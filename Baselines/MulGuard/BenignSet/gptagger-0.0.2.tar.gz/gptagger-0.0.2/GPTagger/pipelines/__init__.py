from GPTagger.pipelines.ner import NerConfig, NerPipeline
