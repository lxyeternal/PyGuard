__all__ = ['print_info']

from .print_info import Printer