NVIDIA-NPP-CU12
===============

**WARNING:** This project is not functional and is a placeholder from NVIDIA.
To install, please execute the following:

.. code-block:: bash

    pip install nvidia-pyindex
    pip install nvidia-npp-cu12
