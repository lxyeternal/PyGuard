from distutils.core import setup

setup(
	name        = 'nester_zz7zz7z',
	version     ='1.0.0',
	py_modules  =['nester'],
	auther      ='Joanna',
	auther_email='joyhu0814@icloud.com',
	url         ='http://www.headfirstlabs.com',
	description ='A simple printer of nest lists',
	)
