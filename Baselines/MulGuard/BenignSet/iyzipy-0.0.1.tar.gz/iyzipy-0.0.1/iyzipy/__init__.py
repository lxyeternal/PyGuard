__title__ = 'Iyzipy'
__version__ = '0.0.1'
__author__ = 'Omer Kala'
__license__ = 'MIT'
__copyright__ = 'Copyright 2020 Omer Kala'

# Version synonym
VERSION = __version__

from .iyzipy import Iyzipy