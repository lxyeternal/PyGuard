## K Ultimate pacKage Installer

Refer to [wiki](https://github.com/jshinonome/kuki/wiki) for documentations.

### Commands

`kuki` includes a set of 3 commands

- kuki: _K Ultimate pacKage Installer cli_, manage q/k packages
- kest: _K tEST cli_, test q/k codes
- ktrl: _K conTRoL cli_,control

### Registry Site

`kuki` can publish and install packages from central registry site [kuki.ninja](https://kuki.ninja/), thanks to [verdaccio](https://verdaccio.org/)
