from g200s.teapot import Teapot

name = "g200s"
