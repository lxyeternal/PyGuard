# g200s

Python module for interacting with Ready For Sky Skykettle G200S Teapot