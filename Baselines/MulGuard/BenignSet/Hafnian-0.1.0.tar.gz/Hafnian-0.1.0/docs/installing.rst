.. _installation:

Installation and Downloads
#################################

.. include:: ../README.rst
   :start-line: 37
   :end-line: 99