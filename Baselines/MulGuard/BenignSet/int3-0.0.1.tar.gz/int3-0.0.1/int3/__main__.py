import sys


def main():
    print("In development...")
    sys.exit(1)


if __name__ == "__main__":
    main()
