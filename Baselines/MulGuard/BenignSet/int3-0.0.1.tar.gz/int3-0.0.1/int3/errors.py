"""Library exception hierarchy."""


class Int3Error(Exception):
    """Base exception type for int3 library errors."""
