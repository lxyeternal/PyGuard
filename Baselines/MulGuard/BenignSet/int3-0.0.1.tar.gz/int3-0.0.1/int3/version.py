"""Library version information."""

__version_info__ = (0, 0, 2)
__version__ = '.'.join(str(i) for i in __version_info__)
