import re

GREEDY_WHITESPACE_RE = re.compile('[ ]+')
