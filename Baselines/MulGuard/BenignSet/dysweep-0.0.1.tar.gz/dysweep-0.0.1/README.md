# DySweep: Use W&B Sweep for Everything!

## Installation

```bash
pip install dysweep
```

## Usage
