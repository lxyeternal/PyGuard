# RunIn


## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**status** | [**RunStatus**](RunStatus.md) | PLANNED: planned&lt;br/&gt;RUNNING: running&lt;br/&gt;COMPLETED: completed&lt;br/&gt;CANCELLED: cancelled&lt;br/&gt;FAILED: failed | [optional] 
**batch_run_id** | **int** |  | 
**file_id** | **int** |  | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


