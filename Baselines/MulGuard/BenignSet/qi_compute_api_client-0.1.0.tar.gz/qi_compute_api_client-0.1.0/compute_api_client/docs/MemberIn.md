# MemberIn


## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**role** | [**Role**](Role.md) | MEMBER: member&lt;br/&gt;ADMIN: admin | 
**is_active** | **bool** |  | [optional] [default to False]
**team_id** | **int** |  | 
**user_id** | **int** |  | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


