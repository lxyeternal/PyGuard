# User


## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **int** |  | 
**full_name** | **str** |  | 
**email** | **str** |  | 
**is_superuser** | **bool** |  | [optional] [default to False]
**is_staff** | **bool** |  | [optional] [default to False]
**is_active** | **bool** |  | [optional] [default to False]
**is_confirmed** | **bool** |  | [optional] [default to False]

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


