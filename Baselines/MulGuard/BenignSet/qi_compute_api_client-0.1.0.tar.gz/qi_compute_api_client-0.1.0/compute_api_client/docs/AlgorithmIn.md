# AlgorithmIn


## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**type** | [**AlgorithmType**](AlgorithmType.md) | HYBRID: hybrid&lt;br/&gt;QUANTUM: quantum | 
**shared** | [**ShareType**](ShareType.md) | PRIVATE: private&lt;br/&gt;LINK_ONLY: link_only&lt;br/&gt;TEAM: team | 
**link** | **str** |  | [optional] 
**project_id** | **int** |  | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


