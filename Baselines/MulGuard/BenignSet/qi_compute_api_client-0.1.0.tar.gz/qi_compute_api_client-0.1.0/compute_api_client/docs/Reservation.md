# Reservation


## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **int** |  | 
**start_time** | **datetime** |  | 
**end_time** | **datetime** |  | 
**is_terminated** | **bool** |  | [optional] [default to False]
**member_id** | **int** |  | 
**runtime_id** | **int** |  | [optional] 
**runtime_type_id** | **int** |  | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


