# Project


## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**created_on** | **datetime** |  | [readonly] 
**id** | **int** |  | 
**name** | **str** |  | 
**description** | **str** |  | 
**starred** | **bool** |  | [optional] [default to False]
**owner_id** | **int** |  | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


