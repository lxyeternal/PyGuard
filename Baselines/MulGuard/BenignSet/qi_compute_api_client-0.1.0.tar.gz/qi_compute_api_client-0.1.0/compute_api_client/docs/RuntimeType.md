# RuntimeType


## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **int** |  | 
**name** | **str** |  | 
**infrastructure** | **str** |  | 
**description** | **str** |  | 
**image_id** | **str** |  | 
**is_hardware** | **bool** |  | 
**features** | **object** |  | [optional] 
**default_compiler_config** | **object** |  | [optional] 
**native_gateset** | **object** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


