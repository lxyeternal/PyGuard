# BatchRunIn


## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**runtime_type_id** | **int** |  | 
**user_id** | **int** |  | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


