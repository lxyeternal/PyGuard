# FileIn


## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**content** | **str** |  | 
**compile_stage** | [**CompileStage**](CompileStage.md) | NONE: none&lt;br/&gt;MAPPED: mapped&lt;br/&gt;NATIVE_GATESET: native_gateset&lt;br/&gt;SCHEDULED: scheduled | [optional] 
**compile_properties** | **object** |  | [optional] 
**generated** | **bool** |  | [optional] [default to False]
**commit_id** | **int** |  | 
**language_id** | **int** |  | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


