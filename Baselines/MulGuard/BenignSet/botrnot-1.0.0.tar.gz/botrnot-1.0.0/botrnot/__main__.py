from .botrnot import main
main()
