# botrnot
Bot or Not detector

## WIP!

`pip3 install botrnot` coming soon
