from enum import Enum

class Bert_size_enum(Enum):
    TINY = 1
    SMALL = 2
    MEDIUM = 3
    BASE = 4
    LARGE = 5
    ALL = 6