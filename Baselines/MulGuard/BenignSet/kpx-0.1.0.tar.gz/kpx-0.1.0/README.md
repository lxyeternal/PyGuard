# Install

```bash
pip install -U kpx --index-url https://gitlab.com/api/v4/projects/24038501/packages/pypi/simple
```
