# Django_RouteView
Implement an auto-registered view
