'''
Created on 25 Mar 2020

@author: ms
'''

class SmartHomeLibrary:
    
    def helloWorld(self):
        print('hello world')