from django.apps import AppConfig


class BookrestConfig(AppConfig):
    name = "bookrest"
