# convert2json
Convert compatible python data types, CSV, XLSX, XLS files to JSON string.
