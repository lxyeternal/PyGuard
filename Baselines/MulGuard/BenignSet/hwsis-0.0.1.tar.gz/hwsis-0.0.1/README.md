HuaWeiCloud SIS
