# -*- coding: utf-8 -*-
from airtest.cli.__main__ import main


if __name__ == '__main__':
    main()
