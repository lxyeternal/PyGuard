from airtest.utils.version import __version__
