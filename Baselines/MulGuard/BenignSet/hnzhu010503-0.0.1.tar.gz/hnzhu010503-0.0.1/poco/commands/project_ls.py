from .catalog import Catalog


class ProjectLs(Catalog):

    sub_command = "project"
    command = "ls"
