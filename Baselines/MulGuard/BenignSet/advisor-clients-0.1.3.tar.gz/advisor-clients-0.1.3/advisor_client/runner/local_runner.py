from .abstract_runner import AbstractRunner


class LocalRunner(AbstractRunner):
  def __init__(self):
    pass

  def run(self):
    pass
