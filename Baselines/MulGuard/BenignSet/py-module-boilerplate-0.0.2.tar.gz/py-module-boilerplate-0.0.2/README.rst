Python module boilerplate
===============================

.. image:: https://coveralls.io/repos/github/alvassin/ramlpy/badge.svg?branch=master
    :target: https://coveralls.io/github/alvassin/py-module-bootstrap
    :alt: Coveralls

.. image:: https://travis-ci.org/alvassin/ramlpy.svg
    :target: https://travis-ci.org/alvassin/py-module-bootstrap
    :alt: Travis CI

.. image:: https://img.shields.io/pypi/v/ramlpy.svg
    :target: https://pypi.python.org/pypi/py-module-bootstrap/
    :alt: Latest Version

.. image:: https://img.shields.io/pypi/wheel/ramlpy.svg
    :target: https://pypi.python.org/pypi/py-module-bootstrap/

.. image:: https://img.shields.io/pypi/pyversions/ramlpy.svg
    :target: https://pypi.python.org/pypi/py-module-bootstrap/

.. image:: https://img.shields.io/pypi/l/ramlpy.svg
    :target: https://pypi.python.org/pypi/py-module-bootstrap/