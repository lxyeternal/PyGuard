def get_message():
    return 'Hello, world!'


def main():
    print(get_message())
