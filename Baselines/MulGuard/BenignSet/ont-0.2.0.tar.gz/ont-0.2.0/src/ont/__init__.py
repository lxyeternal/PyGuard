from ._imdir import imreads

__version__ = '0.2.0'
