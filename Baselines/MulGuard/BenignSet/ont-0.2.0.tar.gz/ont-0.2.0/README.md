# ont

A random collection of useful functions for @jni that haven't yet found a
home elsewhere.

# FAQ

## What's with the name?

It's three characters and easy to type in the Dvorak keyboard layout and the
name was available on PyPI. Also jni was taken by the java native interface.
