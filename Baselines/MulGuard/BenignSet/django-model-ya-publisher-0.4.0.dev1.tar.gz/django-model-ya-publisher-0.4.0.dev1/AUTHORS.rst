=======
Credits
=======

Development Lead (current)
--------------------------

* Jens Diemer

Development Lead (old)
----------------------

* Lee Solway
* Ashley Wilson
* Mishbah Razzaque
* Nathan Walsh
* Fabien Wald

Contributors
------------

* Basil Shubin
* Chris Dobbyn
