
# https://packaging.python.org/tutorials/distributing-packages/#choosing-a-versioning-scheme

__version__ = '0.4.0.dev1'
