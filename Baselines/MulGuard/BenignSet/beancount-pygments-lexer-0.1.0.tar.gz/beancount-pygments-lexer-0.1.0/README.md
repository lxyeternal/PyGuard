# beancount pygments Lexer

[![plaintextaccounting.org](https://img.shields.io/badge/plaintextaccounting.org-beancount-red.svg)]()
[![PyPI](https://img.shields.io/pypi/l/beancount-pygments-lexer.svg)]()
[![PyPI](https://img.shields.io/pypi/v/beancount-pygments-lexer.svg)]()

[pygments](http://pygments.org)-Lexer for
[beancount](http://furius.ca/beancount/)-files.

## TODO

- [ ] Rework matching-rules
- [ ] Add test cases

**Caution**: This is far from finished. Consider it *beta*-software.
Contributions are very welcome :-)
