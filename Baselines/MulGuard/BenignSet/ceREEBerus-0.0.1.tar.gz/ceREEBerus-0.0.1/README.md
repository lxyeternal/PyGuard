# ceREEBerus
Code to do lots of fun things with Reeb graphs
