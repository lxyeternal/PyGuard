#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""python-zhongwen-wendang-3-7-rumenjiaocheng
https://github.com/apachecn/python-zhongwen-wendang-3-7-rumenjiaocheng"""

__author__ = "ApacheCN"
__email__ = "apachecn@163.com"
__license__ = "CC BY-NC-SA 4.0"
__version__ = "2024.3.4.0"