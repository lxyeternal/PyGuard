from setuptools import setup, find_packages

setup(
    name="itar-cmi-etl-functions",
    version="0.0.1",
    packages=find_packages(),
)
        