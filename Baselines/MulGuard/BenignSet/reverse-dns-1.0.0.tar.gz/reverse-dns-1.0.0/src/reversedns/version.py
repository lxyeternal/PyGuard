VERSION = '1.0.0'
LIBRARY_NAME = 'reverse-dns-python'
