
Changelog
=========

1.0.0 (2021-12-09)
------------------

* First release