import setuptools
setuptools.setup(
    version="0.0.1",
    name="alsobrowser",
    author="alsobrowser",
    author_email="3182305655@qq.com",
    description="爱搜浏览器功能库，由爱搜浏览器团队制作，爱搜浏览器团队版权所有。",
    long_description_content_type="text/markdown",
    url="https://github.com/",
    packages=setuptools.find_packages(),
    classifiers=["Programming Language :: Python :: 3",
                 "License :: OSI Approved :: MIT License",
                 "Operating System :: OS Independent",
                 ],
)