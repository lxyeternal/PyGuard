from distutils.core import setup

setup(
    name = 'nesterpelu',
    version = '1.0.2',
    py_modules = ['nesterpelu'],
    author = 'Jose',
    author_email = 'jose.rivascoloma@gmail.com',
    url = 'http://www.google.com',
    description = 'Un simple impresor de listas anidadas',
)