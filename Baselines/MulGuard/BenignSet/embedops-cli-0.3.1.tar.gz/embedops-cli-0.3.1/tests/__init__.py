"""
Group of tests for the embedops_cli and eo_tools
"""

GLYML_FILENAME = "tests/test-.gitlab-ci.yml"
BBYML_FILENAME = "tests/test-bitbucket-pipelines.yml"
GHYML_FILENAME = "tests/test-.github-ci.yml"
