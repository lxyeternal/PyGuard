"""
The version of the EmbedOps CLI tool
"""
__version__ = "0.3.1"
