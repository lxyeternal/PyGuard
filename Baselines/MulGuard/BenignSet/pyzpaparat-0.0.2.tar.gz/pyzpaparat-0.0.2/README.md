## Download Aparat Videos

```python
usage : 
    from main import Main

    a = Main("url", 'quality')
    a.download()
```