# S3 Image Optimizer

S3 Image Optimizer optimizes all images found in an Amazon S3 bucket.


# Installation

Simply run:

    $ pip install s3-image-optimizer


# Usage

To use it:

    $ s3-optimize --help

