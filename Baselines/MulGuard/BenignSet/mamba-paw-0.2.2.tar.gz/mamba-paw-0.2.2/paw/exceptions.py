class PawError(Exception):
    pass
