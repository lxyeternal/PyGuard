.. mdinclude:: ../README.md

.. toctree::
   :caption: Contents
   :hidden:

   Home <self>
   API Reference <source/api>
   Source Code <https://github.com/kubeflow/pipelines/tree/master/kubernetes_platform/python>
