#!/usr/bin/env python3

def main():
	print("It works!")

if __name__ == "__main__":
    main(**vars(args))
