from cleanapi.server import *

name = 'cleanapi'
