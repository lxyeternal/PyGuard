from setuptools import setup, find_packages

setup(
    name='equal-odds',
    version='0.0.0',
    url='https://github.com/AndreFCruz/equal-odds.git',
    author='AndreFCruz',
    author_email='andrecruz97@gmail.com',
    description='TODO: in construction',
    long_description_content_type='text/markdown',
    packages=find_packages(),    
    install_requires=['numpy >= 1.11.1', 'matplotlib >= 1.5.1'],
)

