class TooManyArguments(Exception):
    pass


class TooFewArguments(Exception):
    pass
