ECoXiPy - Easy Creation of XML in Python
========================================

This Python project allows for easy creation of XML. The hierarchical
structure of XML is easy to spot and the code to create XML is much shorter
than using SAX, DOM or Beautiful Soup.
