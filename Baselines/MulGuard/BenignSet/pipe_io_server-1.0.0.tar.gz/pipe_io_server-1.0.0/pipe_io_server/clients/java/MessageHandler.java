public interface MessageHandler {
    public void call(String msg);
}
