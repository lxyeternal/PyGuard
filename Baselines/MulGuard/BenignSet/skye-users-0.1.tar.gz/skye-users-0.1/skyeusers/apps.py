from django.apps import AppConfig


class SkyeusersConfig(AppConfig):
    name = 'skyeusers'
