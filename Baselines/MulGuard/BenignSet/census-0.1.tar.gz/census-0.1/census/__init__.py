from census.core import Census, ALL
