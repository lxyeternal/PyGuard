from setuptools import setup

setup(name='jctestmod',
      version='0.1',
      description='Test wheel package mod',
      url='http://github.com/storborg/funniest',
      author='Juan Carlos',
      author_email='jcmago@gmail.com',
      license='MIT',
      packages=['jctestmod'],
      zip_safe=False)
