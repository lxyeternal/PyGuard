def joke():
	return (u'Line 1',
		u'Line 2')

