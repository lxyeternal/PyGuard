""" QueueCatalog unit tests package.

$Id: __init__.py 67898 2003-06-04 15:15:21Z tseaver $
"""
