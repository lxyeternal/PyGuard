###Install Options

. jetmlgpt/install.sh
or
pip install jetmlgpt