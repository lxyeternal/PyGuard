api_key = ''
environment = 'production'
version = {'JuspayAPILibrary': 'Python v1.0'}