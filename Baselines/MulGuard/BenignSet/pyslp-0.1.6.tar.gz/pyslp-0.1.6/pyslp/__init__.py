# -*- coding: utf-8 -*-

__version__ = '0.1.6'
__author__ = 'Seliverstov Maksim'
__email__ = 'Maksim.V.Seliverstov@yandex.ru'
