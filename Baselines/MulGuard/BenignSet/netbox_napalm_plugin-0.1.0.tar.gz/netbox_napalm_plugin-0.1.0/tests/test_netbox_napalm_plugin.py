#!/usr/bin/env python

"""Tests for `netbox_napalm_plugin` package."""

from netbox_napalm_plugin import netbox_napalm_plugin

