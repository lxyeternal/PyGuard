BASE_URL = 'http://api.statbank.dk/v1'

DELIMITER = ';'

DEFAULT_LANGUAGE = 'da'
LOCALES = {'da': 'en_DK.UTF-8',
           'en': 'en_US.UTF-8'}
