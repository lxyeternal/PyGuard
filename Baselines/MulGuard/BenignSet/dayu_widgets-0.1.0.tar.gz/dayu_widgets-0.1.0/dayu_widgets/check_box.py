#!/usr/bin/env python
# -*- coding: utf-8 -*-
###################################################################
# Author: Mu yanru
# Date  : 2019.2
# Email : muyanru345@163.com
###################################################################
"""
MCheckBox
"""
# Import future modules
from __future__ import absolute_import
from __future__ import division
from __future__ import print_function

# Import third-party modules
from Qt import QtWidgets
from dayu_widgets.mixin import cursor_mixin


@cursor_mixin
class MCheckBox(QtWidgets.QCheckBox):
    """
    MCheckBox just use stylesheet and set cursor shape when hover. No more extend.
    """

    def __init__(self, text="", parent=None):
        super(MCheckBox, self).__init__(text=text, parent=parent)
