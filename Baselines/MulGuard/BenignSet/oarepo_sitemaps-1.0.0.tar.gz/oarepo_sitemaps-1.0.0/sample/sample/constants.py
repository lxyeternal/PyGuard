SAMPLE_ALLOWED_SCHEMAS = ['sample/sample-v1.0.0.json']
SAMPLE_PREFERRED_SCHEMA = 'sample/sample-v1.0.0.json'
