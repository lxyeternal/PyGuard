from ..entity.answer import Answer


class Module:
    """
    出话模块
    """
    def __init__(self, app_id, name):
        self.app_id = app_id
        self.name = name

    def query(self, text: str) -> Answer:
        """
        :param text: 用户问
        :return: 机器人回答
        """
        raise NotImplemented
