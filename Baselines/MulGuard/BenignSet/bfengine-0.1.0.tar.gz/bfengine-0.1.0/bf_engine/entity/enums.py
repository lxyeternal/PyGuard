class QuestionType:
    SQ_ANS = "SQ_ANS"
    LQ = "LQ"
    TQ = "TQ"


class QuestionMode:
    FULL = "full"
    INCRE = "incre"
