class Answer:
    """
    机器人回答
    """
    def __init__(self, text: str, score: float):
        self.text = text
        self.score = score
