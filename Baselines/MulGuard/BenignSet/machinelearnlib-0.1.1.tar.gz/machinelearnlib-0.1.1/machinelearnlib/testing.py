def testing():
    print("Kai Bailey for President 2020")