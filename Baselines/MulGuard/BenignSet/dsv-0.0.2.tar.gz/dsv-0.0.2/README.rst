dsv - Read/write automagically "Delimiter" Seperated Value files.
