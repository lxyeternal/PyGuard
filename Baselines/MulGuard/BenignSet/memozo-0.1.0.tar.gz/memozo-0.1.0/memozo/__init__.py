from .memozo import Memozo

__all__ = ['Memozo']
