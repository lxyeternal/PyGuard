Distance calculator that has these functions
-convert address to lat and lon
-covert lat and lon to address
-Haversine formula - distance in km
-Spherical Law of Cosines - distance in km
-Equirectangular Approximation

to calculate distances you need to use lat and lon