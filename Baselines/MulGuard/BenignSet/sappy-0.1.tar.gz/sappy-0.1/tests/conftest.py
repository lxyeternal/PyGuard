"""Integration tests configuration file."""

from sappy.tests.conftest import pytest_configure  # pylint: disable=unused-import
