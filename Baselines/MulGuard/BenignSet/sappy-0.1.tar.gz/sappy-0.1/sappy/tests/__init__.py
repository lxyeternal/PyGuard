"""Unit tests for the `sappy` package."""
