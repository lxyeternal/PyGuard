<p align="center">
  <img src="https://img.shields.io/pypi/v/pip-install-bitches?style=flat-square" </a>
  <img src="https://img.shields.io/pypi/l/pip-install-bitches?style=flat-square" </a>
  <img src="https://img.shields.io/pypi/dm/pip-install-bitches?style=flat-square" </a>
  <img src="https://img.shields.io/github/stars/Rdimo/pip-install-bitches?label=Stars&style=flat-square" </a>
  <img src="https://img.shields.io/github/forks/Rdimo/pip-install-bitches?label=Forks&style=flat-square" </a>
</p>

#### pip-install-bitches was made by
Love ❌ code ✅

---
### 🎈・Code example
Example of how you can use [bitches](https://pypi.org/project/bitches/)
```py
import bitches #valid

bitches.get()

or

bitches.get("yes") #yes is the name of the directory
```
