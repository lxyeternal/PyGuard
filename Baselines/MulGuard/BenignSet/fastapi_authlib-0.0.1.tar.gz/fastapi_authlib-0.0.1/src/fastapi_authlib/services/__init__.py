"""services"""

from fastapi_authlib.services.auth import AuthService

__all__ = ['AuthService']
