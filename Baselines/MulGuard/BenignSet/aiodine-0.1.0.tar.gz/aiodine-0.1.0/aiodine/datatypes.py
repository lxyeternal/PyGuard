from typing import Callable, Awaitable

CoroutineFunction = Callable[..., Awaitable]
