from platform import system,python_version
version_number = 0.01
version = 'HOPYBOX {} (default, May 1 2022, 9:25:11)\n[Python {}] on {}\nType "help" or "license" for more information'.format(version_number,python_version(),system())