# HOPYBOX
This is an open source, practical and exquisite command box
So I named it 'hopybox'
Hopybox contains a large number of practical functions
It can help your use the device easily
All you need to do is type in a concise line of commands,It can take care of everything

# Installation method
pip install hopybox
pip install -U hopybox

# Import method
import 

# usage method
See help built in the program