from setuptools import setup

setup(name='Metric_Functions',
      version='1.0',
      description='Tulsa Public School distric data team data analysis functions',
      packages=['Metric_Functions'],
      author='Charline LI',
      author_email='lch129444@hotmail.com',
      zip_safe=False)
