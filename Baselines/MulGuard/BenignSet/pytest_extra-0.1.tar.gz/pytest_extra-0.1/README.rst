Contains some small helpers for py.test.

Currently undocumented (read the source - sorry).
