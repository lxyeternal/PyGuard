# !/usr/bin/env python
# -*- coding:utf-8 -*-

# (c)Ing. Zdenek Dlauhy, Michal Dlauhý, pripravto.cz

class log(object):

    @staticmethod
    def debug(msg):
        print(msg)
    info = debug
    warn = debug
    error = debug

# import logging
# logging.basicConfig(level=logging.DEBUG)
# log = logging.getLogger("ans wrapper")

import subprocess

import os
try:
    import ansible.runner
    import ansible.inventory
except:
    log.error("Ansible is not installed! Ansiblator will not work. ")
    log.error("Run:  pip install ansible")



"""
main module of ansiblator - wrapper around ansible
"""
try:
    from .version import __version__
except ImportError:
    __version__ = 0

__version__ = "0.5-{}".format(__version__)
__author__ = "Zdenek Dlauhy"
__email__ = "test@dlauhy.cz"
__url__ = "http://pripravto.cz"
__desc__ = "Ansiblator - make ansible api more pythonic and usefull"
__sys_name__ = "ansiblator"
__license__ = "MIT"



class DictToInventory(object):
    """

    dict to inventory file mapper

        import ansiblator.api as an
        dict_data = {'pc':[{'ssh_host':'192.168.0.10', 'ssh_user':'test_user', 'su_user':'root'},
               {'ssh_host':'192.168.0.8', 'ssh_user':'test_user', 'su_user':'root'}],
        'test':[{'ssh_host':'example.cz', 'ssh_user':'test_user2', 'su_user':'root', 'su_pass':'pass'}]}
        inv = an.DictToInventory(dict_data, filename="/tmp/out")
        inv = ansible.inventory.Inventory("/tmp/out")
        inv.get_hosts("example.cz")[0].vars

    """
    def __init__(self, dict_data, filename="/tmp/out"):
        self.data = []
        self.filename = filename
        self.dict_to_inverntory(dict_data)
        self.data_to_text()

    def dict_to_inverntory(self, dict_data):
        """convert dict data into inventory file"""
        for group, variables in dict_data.items():
            self.data.append("[{}]".format(group))
            for host_vars in variables:
                self.data.append(self.host_into_text(**host_vars))
            self.data.append("\n")

    def host_into_text(self, ssh_host="hostname", ssh_user=None, su_pass=None, su_user=None, sudo_pass=None, **kwargs):
        data = locals()
        data.update(kwargs)
        del data['kwargs']
        del data['self']
        buff = []
        _buffer = ['ssh_host', 'ssh_user', 'su_pass', 'su_user', 'sudo_pass'] + kwargs.keys()
        for k in _buffer:
            if k in data and data[k] is not None:
                if k == 'ssh_host':
                    buff.append(data[k])
                else:
                    buff.append("ansible_{}={}".format(k, data[k]))
        return " ".join("{}".format(key) for key in buff)

    def data_to_text(self, filename=None):
        if filename is None:
            filename = self.filename
        with open(filename, "w") as writer:
            for text in self.data:
                writer.write(text)
                writer.write("\n")
            writer.close()


class Ansiblator(object):
    """
    Ansiblator
    ==========

    This wrapper allows more quicker and easier way to use ansible in python
    ansible without playbooks, so more like fabric.

    Ansible is then more powerfull and it will allow to chain commands with
    python commands.

    Get started
    ===========

    For instalation you can download package and then just unpack and use

        python setup.py install

    or

        pip install ansiblator


    Quick use case
    ==============

    For most quickest example you can just create your ansible file named
    ansible_hosts inside your home directory or full path

        from ansiblator.api import Ansiblator
        ans = Ansiblator()
        ret = ans.local("uname -a", now=True, use_shell=True)
        ans.run("uname -a", now=True)
        ans.runner("uptime")
        ans.run_all()
        ans.copy(src="/tmp/aabc.csv", dest="/tmp/",pattern="pc",now=True)

    More useable way
    ================

    Ansiblator automatically save return json values for actuall runs, so
    you can use them for testing and conditions


    Info
    ====
    For more information consult functions or ansible documentation.
    more information can be also used on www.pripravto.cz. You can also
    contact me there


    """
    def __init__(self, inventory="ansible_hosts", pattern="all",
                 module_name="command", run_at_once=False, sudo=False, su=False,
                 su_user=None, host=None, stop_on_error=False, use_shell=False):
        """
        :param inventory: string or dict, which defines inventory
        :type inventory: str or dict
        :param pattern: pattern maching
        :type pattern: str
        :param module_name: ansible module
        :type module_name: str
        :param run_at_once: run commands when issued or wait
        :type run_at_once: bool
        :param sudo: run as sudo
        :type sudo: bool
        :param su: run as su
        :type su: bool
        :param su_user: specify su user
        :type su_user: str
        :param host: specify host
        :type host: list
        :param stop_on_error: stop exection on return error
        :type stop_on_error: bool
        :param use_shell: use shell on subprocess
        :type use_shell: bool
        """
        self.pattern = pattern
        self.module_name = module_name
        self.runners = []
        self.ret_codes = []
        self.run_at_once = run_at_once
        self.sudo = sudo
        self.su = su
        self.su_user = su_user
        self.host = host
        self.stop_on_error = stop_on_error
        self.use_shell = use_shell
        # parse inventory (str, dict, etc)
        inventory = self.parse_inventory(inventory)
        self.inventory = ansible.inventory.Inventory(inventory)

        log.debug("Intializing ansible: {}".format(self))

    def get_host_var(self, host):
        return self.inventory.get_variables(host)

    def parse_inventory(self, inventory):
        home = os.environ.get('HOME', '/tmp/')
        if isinstance(inventory, str):
            if not inventory.startswith("/"):
                inventory = "{}/{}".format(home, inventory)
        elif isinstance(inventory, dict):
            filename = "{}/{}".format(home, "ansible_hosts")
            DictToInventory(inventory, filename=filename)
            inventory = filename
        else:
            pass
        return inventory


    def get_group_host(self, group):
        host_list = self.inventory.get_group(group).hosts
        data = None
        for host in host_list:
            if "ansible_su_pass" in host.vars or "ansible_sudo_pass" in host.vars:
                data = host.vars
                break
        return data

    def get_host_vars(self, data, su=None, sudo=None, su_pass=None, sudo_pass=None, su_user=None):
        if data:
            if su:
                su_pass = data.get("ansible_su_pass", su_pass)
                su_user = data.get("ansible_su_user", su_user)
            if sudo:
                sudo_pass = data.get("ansible_sudo_pass", sudo_pass)
            return su_pass, sudo_pass, su_user
        else:
            return None, None, None

    def create_argument(self, cmd, kwargs):
        """
        :param cmd: command to run
        :type cmd: str
        :param kwargs: optional arguments
        :type kwargs: dict
        """
        args = " ".join("{}={}".format(k, v) for k, v in kwargs.items())
        if args == " ":
            args = ""
        if cmd is None:
            cmd = "{}".format(args)
        else:
            if args == "":
                cmd = "{}".format(cmd)
            else:
                cmd = "{} {}".format(cmd, args)
        return cmd

    def runner_ans(self, cmd="uptime", pattern=None, module_name=None, inventory=None,
                   now=None, su=None, sudo=None, su_user=None, su_pass=None,
                   sudo_pass=None, host=None, **kwargs):
        if module_name is None:
            module_name = self.module_name
        if pattern is None:
            pattern = self.pattern
        if inventory is None:
            inventory = self.inventory
        else:
            inventory = ansible.inventory.Inventory(inventory)
        if now is None:
            now = self.run_at_once
        if sudo is None:
            sudo = self.sudo
        if su is None:
            su = self.su
        if su_user is None:
            su_user = self.su_user

        if host is None:
            host = self.host
        if host is None:
            data = self.get_group_host(pattern)
            host_list = None
        else:
            host_list = [host]
            pattern = None
            data = self.get_host_var(host)
        su_pass, sudo_pass, su_user = self.get_host_vars(data, su, sudo, su_pass, sudo_pass, su_user)
        info = dict(locals())
        del info['data']  # remove to skip output of password out to shell
        del info['su_pass']
        del info['sudo_pass']
        log.info(info)
        cmd = self.create_argument(cmd, kwargs)
        log.info("Creating new command '{}' on '{}'".format(cmd, module_name))
        runner = ansible.runner.Runner(pattern=pattern, host_list=host_list, module_name=module_name,
                                       module_args=cmd, inventory=inventory,
                                       su=su, sudo=sudo, su_user=su_user, su_pass=su_pass,
                                       sudo_pass=sudo_pass)
        return self._run(runner, now)

    def runner_local(self, cmd="uptime", module_name=None, now=None, **kwargs):
        """
        :param cmd: command to run
        :type cmd: str
        :param module_name: module name -
        :type module_name:
        :param now: when to run command
        :type now: bool
        """
        if now is None:
            now = self.run_at_once
        runner = {'cmd':cmd, 'module_name':module_name}
        return self._run(runner, now)

    def _run(self, runner, now=None, use_shell=None):
        """
        :param runner: runner object to run
        :type runner: dict or obj
        :param now: run now?
        :type now: bool

        function to run or append runner
        """
        if now is None:
            now = self.run_at_once
        if use_shell is None:
            use_shell = self.use_shell
        if now:
            log.info("Running {}".format(runner))
            if isinstance(runner, dict):
                # TODO: Check output
                ret_code = subprocess.Popen(runner['cmd'], stdout=subprocess.PIPE, shell=use_shell)
                out, err = ret_code.communicate()
                if err == 0:
                    failed = False
                else:
                    failed = True
                ret_code = {'contacted':{'local':{'stdout':out, 'failed':failed , 'stderr':err, 'ret_code':ret_code.returncode}}, 'dark':{}}
            else:
                ret_code = runner.run()
            self.parse_ret_code(ret_code)
            self.ret_codes.append(ret_code)
            log.info(ret_code)
            return ret_code
        else:
            self.runners.append(runner)
            return {"run":False}


    def runner(self, cmd="uptime", use_ansible=True, module_name="command", inventory=None, now=None, pattern=None, **kwargs):
        """
        :param cmd: command to run
        :type cmd: str
        :param use_ansible: do you want to use ansible or local subprocess?
        :type use_ansible: bool
        :param module_name: name of ansible module
        :type module_name: str
        :param inventory: inventory object
        :type inventory: <inventory>
        :param now: should this run be imideatly created?
        :type now: bool
        :param pattern: pattern matching on machines
        :type pattern: str

        main runner method which acts as medium to other calls
        """
        log.debug("Making new runner: {}".format(cmd))
        if use_ansible:
            return self.runner_ans(cmd=cmd, module_name=module_name, inventory=inventory, now=now, pattern=pattern, **kwargs)
        else:
            return self.runner_local(cmd=cmd, module_name=module_name, inventory=inventory, now=now, pattern=pattern, **kwargs)

    run = runner

    def copy(self, cmd=None, module_name="copy", src="", dest="", **kwargs):
        return self.runner(cmd=cmd, use_ansible=True, module_name=module_name, src=src, dest=dest, **kwargs)
    put = copy

    def fetch(self, cmd=None, module_name="fetch", src="", dest="", **kwargs):
        return self.runner(cmd=cmd, use_ansible=True, module_name=module_name, src=src, dest=dest, **kwargs)
    get = fetch

    def ping(self, cmd=None, module_name="ping", **kwargs):
        return self.runner(cmd=cmd, use_ansible=True, module_name=module_name, **kwargs)

    def local(self, cmd=None, use_shell=False, **kwargs):
        return self.runner(cmd=cmd, use_ansible=False, use_shell=use_shell, **kwargs)
    run_cmd = local

    def run_all(self, now=True):
        """run all runners inside class"""
        for runner in self.runners:
            self._run(runner, now)

    def parse_ret_errors(self, code):
        if self.stop_on_error:
            for k, v in code['contacted'].items():
                # log.info(v)
                if v.get('failed', False):  # assuming, that run was mostly succesfull
                    raise Exception("ERROR: run was not successfull {}".format(v))

    def parse_ret_code(self, code):
        """parse return code"""
        self.parse_ret_errors(code)
        log.info("Contacted servers :")
        log.info("\n".join("{}: {}".format(k, v.get('stdout', v.get('msg', None))) for k, v in code['contacted'].items()))
        log.warn("Error in contacting :")
        log.info("\n".join("{}: {}".format(k, v.get('msg', None)) for k, v in code['dark'].items()))
        pass


__description__ = Ansiblator.__doc__

if __name__ == "__main__":
    ans = Ansiblator(pattern="pc")
    ans.local(["uname", "-a"], now=True)
    ans.run("uptime")
    ans.run("touch /tmp/aaa.csv")
    ans.local(["uname", "-a"])
    ans.get(src="/tmp/aaa.csv", dest="/tmp/")
    ans.run_all()


