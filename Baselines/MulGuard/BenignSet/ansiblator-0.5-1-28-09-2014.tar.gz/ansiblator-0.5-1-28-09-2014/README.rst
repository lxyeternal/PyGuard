Ansiblator
==========

This wrapper allows more quicker and easier way to use ansible in python
ansible without playbooks, so more like fabric.

Ansible is then more powerfull and it will allow to chain commands with
python commands.

Get started
===========

For instalation you can download package and then just unpack and use

	python setup.py install

or

	pip install ansiblator


Quick use case
==============

For most quickest example you can just create your ansible file named
ansible_hosts inside your home directory or full path


        from ansiblator.ansiblator import Ansiblator
        ans = Ansiblator()
        ret = ans.local("uname -a", now=True, use_shell=True)
        ans.run("uname -a", now=True)
        ans.runner("uptime")
        ans.run_all()
        ans.copy(src="/tmp/aabc.csv", dest="/tmp/",pattern="pc",now=True)


More useable way
================

Ansiblator automatically save return json values for actuall runs, so
you can use them for testing and conditions


Info
====
For more information consult functions or ansible documentation.
more information can be also used on http://www.pripravto.cz . You can also
contact me there.  License MIT.
