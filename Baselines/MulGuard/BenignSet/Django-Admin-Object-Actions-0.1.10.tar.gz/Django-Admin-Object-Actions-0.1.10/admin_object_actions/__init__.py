# Python
from __future__ import unicode_literals

__version__ = '0.1.10'

default_app_config = 'admin_object_actions.apps.AdminObjectActionsConfig'
