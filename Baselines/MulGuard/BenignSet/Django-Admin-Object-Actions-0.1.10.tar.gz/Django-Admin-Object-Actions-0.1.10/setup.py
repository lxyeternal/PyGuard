#!/usr/bin/env python

# Setuptools
from setuptools import setup


setup()
