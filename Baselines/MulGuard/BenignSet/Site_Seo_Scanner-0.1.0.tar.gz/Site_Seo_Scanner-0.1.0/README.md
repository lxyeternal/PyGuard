# Site Seo Scanner | ![Made_with_python](https://img.shields.io/badge/Made%20with-Python-1f425f.svg) ![Licence](https://img.shields.io/github/license/onuratakan/Site_Seo_Scanner.svg)
# Installing
```console
pip install Site-Seo-Scanner
```
# Import
```python
from ssc import SSC
```