# ClickSQL
 
ClickSQL is a smart client for clickhouse database, which may help clickhouse users to use clickhouse more easier and smoother. 
it aim to make the clickhouse to be the good alternative Relational Database of MySQL. 

more information for clickhouse can be found at [here](http://clikchouse.tech)

