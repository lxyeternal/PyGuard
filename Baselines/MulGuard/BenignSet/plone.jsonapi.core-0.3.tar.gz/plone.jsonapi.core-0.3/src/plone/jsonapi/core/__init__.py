# -*- coding: utf-8 -*-

__author__ = 'Ramon Bartl <ramon.bartl@googlemail.com>'
__docformat__ = 'plaintext'

# convenience imports
import version
from browser import router
from browser import decorators

# vim: set ft=python ts=4 sw=4 expandtab :
