# -*- coding: utf-8 -*-
#
# File: interfaces.py

from browser.interfaces import IRouter
from browser.interfaces import IRouteProvider

# vim: set ft=python ts=4 sw=4 expandtab :
