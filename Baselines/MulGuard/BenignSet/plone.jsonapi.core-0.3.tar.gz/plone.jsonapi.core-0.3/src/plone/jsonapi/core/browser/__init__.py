# -*- coding: utf-8 -*-
#
# File: __init__.py

__author__ = 'Ramon Bartl <ramon.bartl@googlemail.com>'
__docformat__ = 'plaintext'

# vim: set ft=python ts=4 sw=4 expandtab :
