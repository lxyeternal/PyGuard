sparkler
========

A command line too for generating sparklines from GitHub stats.

GitHub has several APIs for extracting activity statistics in a raw JSON
format. Sparkler is a tool that can take this raw data and generate sparkline
images to show the activity level over a period of time.

Installing
----------

Sparkler can be installed with pip::

  $ pip install --user sparkler

Using
-----

To be filled in as development progresses.
