from setuptools import setup, find_packages

setup(
    name="myhlcb",
    version="0.1.0",
    description="An example package",
    author="myhlcb",
    author_email="osimple23@email.com",
    packages=find_packages(),
)