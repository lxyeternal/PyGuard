### CSS explanations

The only styling was written with SCSS (`cookie_consent.scss`) and compiled here.

Run with:

```
sass cookie_consent.scss index.css
```
