from setuptools import setup

setup(name='pun_probability',
      version='0.1',
      description='Gaussian and Binomial distributions',
      packages=['pun_probability'],
      author = 'Tawatwee Aiem',
      author_email = 'punnyoz1103@gmail.com',
      zip_safe=False)
