
.. include:: ../../CONTRIBUTING.rst