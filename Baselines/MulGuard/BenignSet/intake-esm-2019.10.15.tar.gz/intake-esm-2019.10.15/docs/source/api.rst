API Reference
=============

This page provides an auto-generated summary of intake-esm’s API.
For more details and examples, refer to the relevant chapters in the main part of the documentation.


ESM Datastore
~~~~~~~~~~~~~

.. autosummary::

   intake_esm.core.esm_datastore


.. autoclass:: intake_esm.core.esm_datastore
   :members:
