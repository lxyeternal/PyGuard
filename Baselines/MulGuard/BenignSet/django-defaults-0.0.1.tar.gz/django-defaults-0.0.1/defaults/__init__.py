"""
Django settings sans boilerplate
"""

from .functions import emplace, setenv

__all__ = ['emplace', 'setenv']
