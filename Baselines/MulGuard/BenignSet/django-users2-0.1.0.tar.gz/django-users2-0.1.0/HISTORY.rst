.. :changelog:

History
-------

0.1.0 (2014-01-01)
++++++++++++++++++

* First release on PyPI.