class CodeExpired(Exception):
    pass


class InvalidCode(Exception):
    pass
