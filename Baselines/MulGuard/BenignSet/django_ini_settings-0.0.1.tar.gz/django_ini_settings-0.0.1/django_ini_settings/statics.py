"""Static variables used in the module"""

# Using integers because it shouldn't be matchable to anything in the config
ANY = 0
NAME_TO_UPPER = 1
NAME_AS_IS = 2
