from setuptools import setup ,find_packages



setup(

name = "pycosmic",
version="3.0",
description="This is a very useful pacakge that saves time ",
author="Rishabh",
author_email="rishivisionworld@gmail.com",
install_requires=['qrcode','opencv-python'],
packages=find_packages(),


)