
# replize
Tools to create REPL interfaces


To install:	```pip install replize```
