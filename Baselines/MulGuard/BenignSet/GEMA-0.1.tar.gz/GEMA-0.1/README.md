# GEMA
GEMA is a Python library which can be used to develop and train Self-Organizing Maps (SOMs). It also allows users to classify new individuals, obtain reports and visualize the information with interactive graphs.
NOTE: GEMA has only been implemented in Python 3.0

## Home page
https://gema.adriiiprieto.es/
### Installation
GEMA is still not available to be installed using pip
### Requirements:
- NumPy
- Pandas
- matplotlib
- Plotly
- scikit-learn
- scipy
- numba

## Contact
- Responsible: Alberto Nogales alberto.nogales@ceiec.es
- Supervisors: Alberto Nogales, Álvaro José García-Tejedor
- Main developers: Adrián Prieto and Gonzalo de las Heras de Matías (actual developer)
- Contributors: Santiago Donaher Naranjo

Under license of CEIEC http://www.ceiec.es
