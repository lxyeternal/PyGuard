# Hello PyPi

This repo is a small demo for publishing a pure python package to PyPi.

Watch [this livestream][livestream] to see this process in action.

[livestream]: https://example.com/todo
