# Summarize dataframe
