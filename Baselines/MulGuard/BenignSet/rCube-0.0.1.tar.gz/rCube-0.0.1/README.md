Lightweight package for creating, scrambling, solving generalized nxnxn puzzle cube using numpy, using matplotlib for graphical rendering

To-do:
Convert cube datatype to non-numpy

Add support for standard cube notation

Add naive solver for nxnxn cubes

Add support for nxmxl cuboid shapes

Add support for 4D and higher cuboids

Add support for non-cuboid regular geometries