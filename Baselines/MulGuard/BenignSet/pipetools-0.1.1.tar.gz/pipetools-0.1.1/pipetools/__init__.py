from pipetools.utils import foreach

__version__ = VERSION = 0, 1, 1

__versionstr__ = VERSION > foreach(str) | '.'.join

from pipetools.main import pipe, X
from pipetools.utils import *
