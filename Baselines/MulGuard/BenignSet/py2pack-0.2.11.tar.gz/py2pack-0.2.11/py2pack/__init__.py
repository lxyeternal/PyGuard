__doc__ = 'Generate distribution packages from Python packages on PyPI'
__author__ = 'Sascha Peilicke <saschpe@gmx.de>'
__version__ = '0.2.11'

from py2pack import list, search, fetch, generate, main
