
# -*- coding: utf-8 -*-
"""
open-discussions python REST API client
"""

__version__ = '0.1.0'  # pragma: no cover
