# backle

Portfolio **BACK**testing made simp**LE**.

Inspiration: [Corey Hoffstein](https://twitter.com/choffstein/status/1613244565548310528)

### Current Limitations:
- Probably lacks ability to do intraday due to the reindexing on the allocation matrix (should probably only do this if the lengths of price/allocation df are different).