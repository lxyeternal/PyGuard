A Custom Mesh Widget Library

Package Install
---------------

**Prerequisites**
- [node](http://nodejs.org/)

```bash
npm install --save ipymesh-widgets
```
