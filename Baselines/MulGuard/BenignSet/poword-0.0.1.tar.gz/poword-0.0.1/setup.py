#!/usr/bin/env python
# -*- coding:utf-8 -*-

#############################################
# File Name: setup.py
# Author: 程序员晚枫
# Mail: 1957875073@qq.com
# Created Time:  2022-4-19 10:17:34
# Description: https://mp.weixin.qq.com/s/zzD4pxNMFd0ZuWqXlVFdAg
#############################################

from setuptools import setup

setup()