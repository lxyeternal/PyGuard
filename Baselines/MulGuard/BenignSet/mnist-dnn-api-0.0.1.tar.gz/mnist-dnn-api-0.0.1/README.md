# MNIST_DNN_API

TODO: Update document