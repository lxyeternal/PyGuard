class Test:
	name="test"
	price=0
	def getName(self):
		return "geekbruce"
	def hello_price(self):
		"""return price would be error!"""
		return self.price + 2
