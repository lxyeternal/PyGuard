Party Type Module
#################
