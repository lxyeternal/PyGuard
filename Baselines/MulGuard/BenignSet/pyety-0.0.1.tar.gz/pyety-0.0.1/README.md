
# pyety
DynamoDB experimentation.


To install:	```pip install pyety```
