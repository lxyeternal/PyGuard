# -*- coding: utf-8 -*
__author__ = 'mizhgun@gmail.com'

from distutils.core import setup

setup(
        name='scrapy-proxymesh',
        version='0.0.3',
        packages=['scproxymesh'],
        url='',
        license='MIT',
        author='mizhgun',
        author_email='mizhgun@gmail.com',
        description='Proxymesh downloader middleware for Scrapy'
)
