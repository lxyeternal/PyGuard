For questions reach out to security@plaid.com
