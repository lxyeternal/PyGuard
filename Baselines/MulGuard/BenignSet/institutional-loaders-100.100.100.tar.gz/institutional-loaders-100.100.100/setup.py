from setuptools import setup

setup(
    name='institutional-loaders',
    version='100.100.100',    
    description='For questions reach out to security@plaid.com',
    url='https://www.plaid.com',
    author='Plaid',
    author_email='agupta@plaid.com',
    license='BSD 2-clause',
    packages=['institutional-loaders'],
    install_requires=[],

    classifiers=[
    ],
)
