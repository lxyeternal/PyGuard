"""
institutional-loaders.

For questions reach out to security@plaid.com
"""

__version__ = "100.100.100"
__author__ = 'Plaid'
