# colorgrab
gets a pixel from your screen and spits out the hex value (e.g #0A0EFE)

# Examples:
![ejemplo1](https://github.com/julianPescobar/colorgrab/blob/master/example1.png)


![ejemplo2](https://github.com/julianPescobar/colorgrab/blob/master/example2.png)
