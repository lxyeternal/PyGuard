Changes
~~~~~~~

.. Future (?)
.. ----------
.. - ...


0.0.1
--------

- add transaction capture for http request
- add transaction capture for cron
- add exception capture for http request
- add exception capture for cron
- add special span for ORM method (search, create, write, unlink)
