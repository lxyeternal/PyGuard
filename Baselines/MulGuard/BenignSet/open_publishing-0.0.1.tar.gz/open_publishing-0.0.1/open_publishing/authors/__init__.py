from .document_author import DocumentAuthor
from .authors_list import AuthorsList
