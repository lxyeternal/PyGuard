from . import catalog_types

def Academic():
    return catalog_types.Academic(None)

def NonAcademic():
    return catalog_types.NonAcademic(None)

