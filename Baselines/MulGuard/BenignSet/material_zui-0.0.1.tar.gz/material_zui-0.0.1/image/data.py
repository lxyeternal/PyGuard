MAX_MP: int = 4_000_000

IMG_EXT = ('.jpg', 'jpeg', '.png')

K_SIZE: int = 89
