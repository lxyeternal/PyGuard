# from natasy.neural_network.layers.fullyconnectedlayer import FullyConnectedLayer


class NeuralNetworkLayer:
    def __init__(self, *args, **kwargs):
        pass


if __name__ == '__main__':
    pass