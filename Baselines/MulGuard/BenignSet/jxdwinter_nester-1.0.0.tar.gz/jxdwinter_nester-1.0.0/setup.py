
# coding:UTF-8 

from distutils.core import setup
setup(
    name='jxdwinter_nester', 
    version='1.0.0', 
    py_modules=['jxdwinter_nester'], 
    author='jxdwinter',
    author_email = 'jxdwinter@gmail.com',
    url = 'http://jiangxiaodong.me',
    description = 'A simple printer of nested lists'
)