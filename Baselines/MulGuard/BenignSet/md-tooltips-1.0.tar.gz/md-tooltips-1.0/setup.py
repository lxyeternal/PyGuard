from setuptools import setup

setup(
    name='md-tooltips',
    version='1.0',
    py_modules=['mdtooltips'],
    install_requires = ['markdown>=2.5'],
)