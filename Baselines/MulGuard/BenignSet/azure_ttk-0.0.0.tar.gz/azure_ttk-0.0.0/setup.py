from setuptools import setup

setup(
    name="azure_ttk",
    version="0.0.0",
    author="rdbende",
    author_email="rdbende@gmail.com",
    license="MIT license",
    python_requires=">=3.7",
    classifiers=[
        "Development Status :: 1 - Planning",
    ],
)
