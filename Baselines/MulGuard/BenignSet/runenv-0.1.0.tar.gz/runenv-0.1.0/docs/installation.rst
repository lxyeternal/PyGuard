============
Installation
============

At the command line::

    $ easy_install runenv

Or, if you have virtualenvwrapper installed::

    $ mkvirtualenv runenv
    $ pip install runenv
