===============================
runenv
===============================

.. image:: https://img.shields.io/travis/onjin/runenv.svg
        :target: https://travis-ci.org/onjin/runenv

.. image:: https://img.shields.io/pypi/v/runenv.svg
        :target: https://pypi.python.org/pypi/runenv


Wrapper to run programs with different env

* Free software: BSD license
* Documentation: https://runenv.readthedocs.org.

Features
--------

* TODO
