import sys


def _exit_error(message: str):
    print(f'ERROR: {message}')
    sys.exit(1)
