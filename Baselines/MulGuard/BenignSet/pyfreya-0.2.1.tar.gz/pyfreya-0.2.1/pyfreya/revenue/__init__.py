"""Inits revenue"""

from .revenue import BaseRevenue, ARPDAU
