"""inits cohort"""

from .cohort import Cohort
# module level doc-string
