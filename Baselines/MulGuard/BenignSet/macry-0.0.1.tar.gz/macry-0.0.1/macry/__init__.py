"""Python object-document mapper (ODM) for google FireStore"""

__version__ = '0.0.1'

from . import fields
from .builder import FireModel
