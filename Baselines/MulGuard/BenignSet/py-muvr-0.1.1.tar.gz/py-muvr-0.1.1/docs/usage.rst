=====
Usage
=====

To use py_muvr in a project::

    import py_muvr
