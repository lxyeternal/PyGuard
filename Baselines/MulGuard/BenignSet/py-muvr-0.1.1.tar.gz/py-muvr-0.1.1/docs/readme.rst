======
Readme
======

The package README is available on the `landing page of the repository  <https://github.com/datarevenue-berlin/py_muvr>`_
