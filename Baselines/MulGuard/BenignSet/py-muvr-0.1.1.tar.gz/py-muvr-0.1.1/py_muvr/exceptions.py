class NotFitException(Exception):
    pass
