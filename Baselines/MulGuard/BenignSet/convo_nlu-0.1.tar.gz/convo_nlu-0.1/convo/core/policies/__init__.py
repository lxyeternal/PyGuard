# we need to import the policy first
from convo.core.policies.policy import Policy

# and after that any implementation
from convo.core.policies.ensemble import SimplePolicyEnsemble, PolicyEnsemble
