from convo.nlu.components import Component


class IntentClassifier(Component):
    pass
