dry
===

Automate and enhance your web development workflow

dry will do for you in one command line `dry build`:

* compile & minify coffee scripts
* compile & minify sass & css
* minify js
* inject minified css/js into html
* minify html
