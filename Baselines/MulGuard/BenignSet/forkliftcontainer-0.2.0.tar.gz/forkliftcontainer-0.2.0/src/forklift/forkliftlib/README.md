This utility depends on `pyyaml` for dealing with _.yaml_ files and python curses for 
the user interface. If you already have python installed you probably have them too.  
There's no need to create a virtual environment for it, curses widgets are self contained
in this utility.