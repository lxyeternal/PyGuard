# -*- coding: utf-8 -*-
#
# @description      utility widgets for the program
#
UUID=1
