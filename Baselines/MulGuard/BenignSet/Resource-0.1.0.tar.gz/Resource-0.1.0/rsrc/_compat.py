#!/usr/bin/env python
# -*- coding: utf-8 -*-

import sys


if sys.version_info[0] == 3:
    str_type = str
else:
    str_type = basestring
