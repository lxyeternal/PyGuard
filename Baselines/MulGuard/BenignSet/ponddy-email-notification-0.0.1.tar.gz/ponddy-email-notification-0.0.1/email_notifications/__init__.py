default_app_config = 'email_notifications.apps.EmailNotificationsConfig'
