from drb.exceptions import DrbException, DrbFactoryException


class DrbGribNobeException(DrbException):
    pass


class DrbGribNobeFactoryException(DrbFactoryException):
    pass
