# Lexartifacts

A python package for computation and reporting of lexical artifacts. For more information, check the repository and associated research paper [here](https://github.com/dhfbk/hate-speech-artifacts).