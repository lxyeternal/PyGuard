#
# Copyright (C) 2014 pytest-multihost contributors. See COPYING for license
#

from pytest_multihost.plugin import make_multihost_fixture
