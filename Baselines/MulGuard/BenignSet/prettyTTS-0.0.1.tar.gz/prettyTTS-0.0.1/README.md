<p align="center">
  <h1 align="center">prettyTTS has been migrated to <b>mateco</b> package</h1>
</p>

### This is dummy package to avoid the others create the new package with this name.

### URL: https://github.com/tquangsdh20/mateco/
