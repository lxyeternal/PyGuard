from .node import ThrottleNode
from .task import task

node = ThrottleNode()  # master node

__all__ = ('task', )
