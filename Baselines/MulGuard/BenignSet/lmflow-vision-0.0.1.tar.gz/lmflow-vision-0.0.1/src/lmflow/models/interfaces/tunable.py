#!/usr/bin/env python
# coding=utf-8
"""Tunable class
"""

from abc import ABC


class Tunable(ABC):
    pass
