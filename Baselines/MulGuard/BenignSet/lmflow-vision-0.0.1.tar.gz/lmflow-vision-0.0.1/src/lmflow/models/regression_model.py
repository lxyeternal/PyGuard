#!/usr/bin/env python
# coding=utf-8
"""General regression model."""

from lmflow.models.base_model import BaseModel


class RegressionModel(BaseModel):

    def __init__(self, *args, **kwargs):
        pass
