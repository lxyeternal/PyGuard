from .version import __version__

__author__ = "Joe R. J. Healey"
__email__ = "jrj.healey@gmail.com"
