This is a handy package to convert your Junit XML files to Pretty HTML Reports.

Usage 

prettyjunit <path-to-your-junit-xml-folder> <report-name>