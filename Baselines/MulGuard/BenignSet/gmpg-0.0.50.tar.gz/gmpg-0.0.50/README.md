Git is distributed by design. It's use has centralized through GitHub. Host
your own repositories on your own website and decentralize.

Python is distributed by design. It's use has centralized through PyPI. Host
your own package index on your own website and decentralize.

Design in accordance with the meta system.
