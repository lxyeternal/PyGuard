from setuptools import setup

setup(name='predicts',
      version='0.1',
      description='Predicting Titanic Survivor',
      url='https://github.com/abbiyanaila/predicts',
      author='Desi Ratna Ningsih',
      author_email='abbiyanaila@gmail.com',
      license='MIT',
      packages=['predicts'],
      zip_safe=False)


