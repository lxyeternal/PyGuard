
# s3dol
s3 (through boto3) with a simple (dict-like or list-like) interface


To install:	```pip install s3dol```
