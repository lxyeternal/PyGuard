"""Module containing the logic for oga entry-points."""
