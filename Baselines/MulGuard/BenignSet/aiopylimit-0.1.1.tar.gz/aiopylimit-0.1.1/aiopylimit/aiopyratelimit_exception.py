class AIOPyRateLimitException(Exception):
    pass
