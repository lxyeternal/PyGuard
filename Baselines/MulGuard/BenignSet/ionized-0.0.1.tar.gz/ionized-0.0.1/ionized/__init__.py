"""Top-level package for ionized."""

__author__ = """Theo "Bob" Massard"""
__email__ = 'tbobm@protonmail.com'
__version__ = '0.0.1'
