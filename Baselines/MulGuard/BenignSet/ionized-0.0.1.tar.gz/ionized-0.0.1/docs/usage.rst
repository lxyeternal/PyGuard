=====
Usage
=====

To use ionized in a project::

    import ionized
