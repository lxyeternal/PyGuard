from .cnes_checker import register

def register(linter):
    cnes_checker.register(linter)