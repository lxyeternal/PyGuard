from distutils.core import setup

setup(name='daiwk',version='1.0.0',py_modules=['daiwk'])
