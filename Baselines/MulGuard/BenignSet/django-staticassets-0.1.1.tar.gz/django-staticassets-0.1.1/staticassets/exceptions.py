class AssetNotFound(Exception):
    pass


class CircularDependencyError(Exception):
    pass
