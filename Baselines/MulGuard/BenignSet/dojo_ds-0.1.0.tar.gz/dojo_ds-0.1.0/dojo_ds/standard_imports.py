"""
Standard Imports module: lazy importing of essential packages

Example Use:
>> from dojo_ds.standard_imports import *
"""
import pandas as pd
import numpy as np
import matplotlib as mpl
import matplotlib.pyplot as plt
import seaborn as sns

