=======
dojo-ds
=======


.. image:: https://img.shields.io/pypi/v/dojo_ds.svg
        :target: https://pypi.python.org/pypi/dojo_ds

.. image:: https://img.shields.io/travis/jirvingphd/dojo_ds.svg
        :target: https://travis-ci.com/jirvingphd/dojo_ds

.. image:: https://readthedocs.org/projects/dojo-ds/badge/?version=latest
        :target: https://dojo-ds.readthedocs.io/en/latest/?version=latest
        :alt: Documentation Status




Code from Coding Dojo's Online Part-Time Data Science boot camp


* Free software: GNU General Public License v3
* Documentation: https://dojo-ds.readthedocs.io.


Features
--------

* TODO

Credits
-------

This package was created with Cookiecutter_ and the `audreyr/cookiecutter-pypackage`_ project template.

.. _Cookiecutter: https://github.com/audreyr/cookiecutter
.. _`audreyr/cookiecutter-pypackage`: https://github.com/audreyr/cookiecutter-pypackage
