=====
Usage
=====

To use dojo-ds in a project::

    import dojo_ds
