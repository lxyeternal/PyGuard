#!/usr/bin/env python3
# -*- coding: utf-8 -*-

from exoskeleton.__main__ import Exoskeleton

name = "exoskeleton"
__version__ = "0.5.2"
