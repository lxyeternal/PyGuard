from setuptools import setup, find_packages

setup(
    name="My-Serializer-For-Json-And-XML-For_Lab3-7",
    version="0.1.1",
    description="Demo library",
    author="Teplyakov Arseny",
    author_email="teplyakovarseni@mail.ru",
    packages=find_packages(),
    include_package_data=True
)

