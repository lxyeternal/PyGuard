Authors of Django SAML2 Auth AI
===============================

This project is based on Django SAML2 Auth which is written by
`Fang Li <https://github.com/fangli>`_ and various contributors.

The Django SAML2 Auth AI fork is maintained by
`Anders Innovations <https://www.anders.fi/en/>`_.

List of Authors and Contributors
--------------------------------

- `Fang Li <https://github.com/fangli>`_
- `DSpeichert <https://github.com/DSpeichert>`_
- `jacobh <https://github.com/jacobh>`_
- `Gene Wood <http://github.com/gene1wood/>`_
- `Terry <https://github.com/tpeng>`_
- `Tim Pierce <https://github.com/qwrrty/>`_ (Adobe Systems)
- `Tonymke <https://github.com/tonymke/>`_
- `pintor <https://github.com/pintor>`_
- `BaconAndEggs <https://github.com/BaconAndEggs>`_
- `Tuomas Suutari <https://github.com/suutari-ai>`_ (Anders Innovations)
