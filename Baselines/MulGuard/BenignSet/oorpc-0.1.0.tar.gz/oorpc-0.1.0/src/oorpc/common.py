




class ProtocalInfo:
    supportVersions = [1]
