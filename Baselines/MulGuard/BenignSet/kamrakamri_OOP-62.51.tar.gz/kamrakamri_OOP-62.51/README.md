# A text-based adventure game using OOP.

An effort to implement object-oriented programming paradigm by creating a text-based, role-playing adventure game.
It is an interactive invented world described in text. 
The environment is filled with different rooms, items, obstacles, or anything one's imagination allows. 
The player interacts with the world by typing commands, and the game describes the result of the player’s commands.
