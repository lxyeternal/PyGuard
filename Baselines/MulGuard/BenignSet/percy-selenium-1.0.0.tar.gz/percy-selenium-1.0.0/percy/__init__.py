from percy.snapshot import percy_snapshot
from percy.version import __version__
# for better backwards compatibility
percySnapshot = percy_snapshot
