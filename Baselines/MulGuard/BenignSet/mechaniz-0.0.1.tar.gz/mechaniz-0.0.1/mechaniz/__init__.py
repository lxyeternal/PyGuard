# -*- coding: utf-8 -*-
#!/usr/bin/python2
#coding=utf-8
def binni():
	print(
"""

 ______  _________ _        _       _________
(  ___ \ \__   __/( (    /|( (    /|\__   __/
| (   ) )   ) (   |  \  ( ||  \  ( |   ) (   
| (__/ /    | |   |   \ | ||   \ | |   | |   
|  __ (     | |   | (\ \) || (\ \) |   | |   
| (  \ \    | |   | | \   || | \   |   | |   
| )___) )___) (___| )  \  || )  \  |___) (___
|/ \___/ \_______/|/    )_)|/    )_)\_______/
                                             
--------------------------------------------------
➣ Author   : Binyamin Binni
➣ GitHub   : https://github.com/binyamin-binni
➣ YouTube  : Trick Proof
➣ Blogspot : https://trickproof.blogspot.com
--------------------------------------------------
"""
)
def bxi():
	print(
"""


 ______           _________
(  ___ \ |\     /|\__   __/
| (   ) )( \   / )   ) (   
| (__/ /  \ (_) /    | |   
|  __ (    ) _ (     | |   
| (  \ \  / ( ) \    | |   
| )___) )( /   \ )___) (___
|/ \___/ |/     \|\_______/
                           

                                             
--------------------------------------------------
➣ Author   : Binyamin Binni
➣ GitHub   : https://github.com/binyamin-binni
➣ YouTube  : Trick Proof
➣ Blogspot : https://trickproof.blogspot.com
--------------------------------------------------
"""
)