=======
Credits
=======

Maintainer
----------

* Dinesh Kumar Dandu <dandu.8x@gmail.com>

Contributors
------------

None yet. Why not be the first? See: CONTRIBUTING.rst
