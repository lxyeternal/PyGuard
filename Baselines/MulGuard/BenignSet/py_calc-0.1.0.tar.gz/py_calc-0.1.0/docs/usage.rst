========
Usage
========

To use py_calc in a project::

    import py_calc
