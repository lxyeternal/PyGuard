============
Installation
============

At the command line::

    $ pip install py_calc

Or, if you have virtualenvwrapper installed::

    $ mkvirtualenv py_calc
    $ pip install py_calc
