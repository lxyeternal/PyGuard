===============================
py_calc
===============================

.. image:: https://img.shields.io/travis/dandu1008/py_calc.svg
        :target: https://travis-ci.org/dandu1008/py_calc

.. image:: https://img.shields.io/pypi/v/py_calc.svg
        :target: https://pypi.python.org/pypi/py_calc


its a simple python math calculator package

* Free software: MIT license
* Documentation: (COMING SOON!) https://py_calc.readthedocs.org.

Features
--------

* TODO
