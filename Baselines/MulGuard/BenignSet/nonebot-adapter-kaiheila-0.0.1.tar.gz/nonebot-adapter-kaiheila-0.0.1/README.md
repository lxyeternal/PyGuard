# nonebot-adapter-kaiheila
nonebot adapter for kaiheila bot

开黑啦 `nonebot` 适配器
