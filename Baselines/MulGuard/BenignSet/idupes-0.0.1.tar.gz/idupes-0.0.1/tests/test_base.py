from idupes.base import NAME


def test_base():
    assert NAME == "idupes"
