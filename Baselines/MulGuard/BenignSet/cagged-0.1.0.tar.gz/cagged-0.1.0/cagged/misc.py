from rich.console import Console

console = Console(log_path=False)

console_without_time = Console(log_time=False, log_path=False)
