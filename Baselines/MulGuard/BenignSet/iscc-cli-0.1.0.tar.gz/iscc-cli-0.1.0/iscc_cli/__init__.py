import os

os.environ["TIKA_VERSION"] = "1.21"
__version__ = "0.1.0"
