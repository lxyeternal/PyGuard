# __init__.py

# Version of the jfw-encoder-decoder package
__version__ = "1.1.1"