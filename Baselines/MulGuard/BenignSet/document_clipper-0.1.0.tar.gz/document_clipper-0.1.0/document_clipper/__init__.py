# -*- coding: utf-8 -*-

"""Top-level package for document-clipper."""

__author__ = """Nick Jaremek"""
__email__ = 'nick13jaremek@gmail.com'
__version__ = '0.1.0'
