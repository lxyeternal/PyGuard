=====
Usage
=====

To use document-clipper in a project::

    import document_clipper
