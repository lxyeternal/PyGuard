================
document-clipper
================


.. image:: https://img.shields.io/pypi/v/document_clipper.svg
        :target: https://pypi.python.org/pypi/document_clipper

.. image:: https://img.shields.io/travis/reclamador/document_clipper.svg
        :target: https://travis-ci.org/reclamador/document_clipper

.. image:: https://readthedocs.org/projects/document-clipper/badge/?version=latest
        :target: https://document-clipper.readthedocs.io/en/latest/?badge=latest
        :alt: Documentation Status

.. image:: https://pyup.io/repos/github/reclamador/document_clipper/shield.svg
     :target: https://pyup.io/repos/github/reclamador/document_clipper/
     :alt: Updates


A set of utility classes and functions to process documents with Python


* Free software: MIT license
* Documentation: https://document-clipper.readthedocs.io.


Features
--------

* TODO

Credits
---------

This package was created with Cookiecutter_ and the `audreyr/cookiecutter-pypackage`_ project template.

.. _Cookiecutter: https://github.com/audreyr/cookiecutter
.. _`audreyr/cookiecutter-pypackage`: https://github.com/audreyr/cookiecutter-pypackage

