# -*- coding: utf-8 -*-

"""Unit test package for document_clipper."""
