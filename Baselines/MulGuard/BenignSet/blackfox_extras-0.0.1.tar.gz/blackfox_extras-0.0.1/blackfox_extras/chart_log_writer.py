from blackfox import LogWriter

class ChartLogWriter(LogWriter):

    def __init__(self):
        pass

    def write_status(self, id, status):
        pass

    def write_string(self, msg):
        pass