# BlackfoxPythonExtras
Extra function for BlackFox
