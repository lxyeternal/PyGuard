IVERSION = (0, 0, 1)
VERSION = ".".join(str(i) for i in IVERSION)
MINORVERSION = ".".join(str(i) for i in IVERSION[:2])
NAME = "plist"
NAMEVERSION = NAME + " " + VERSION
