#!/usr/bin/env python3

from atramentarium.atramentarium import prompt, CommandCompleter
