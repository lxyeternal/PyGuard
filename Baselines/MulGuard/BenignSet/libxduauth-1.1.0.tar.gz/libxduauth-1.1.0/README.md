### ref to [xidian-scripts](https://github.com/xdlinux/xidian-scripts)
