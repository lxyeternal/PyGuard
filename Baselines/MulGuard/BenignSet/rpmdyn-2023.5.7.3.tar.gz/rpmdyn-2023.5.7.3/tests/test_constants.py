def test_sample_constants(rpm):
    assert rpm.RPMFILE_README == 256
    assert rpm.RPMTAG_EPOCH == 1003
