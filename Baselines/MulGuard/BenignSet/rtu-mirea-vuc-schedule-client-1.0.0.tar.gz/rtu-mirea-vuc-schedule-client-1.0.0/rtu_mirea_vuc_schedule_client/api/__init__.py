# flake8: noqa

# import apis into api package
from rtu_mirea_vuc_schedule_client.api.healthcheck_api import HealthcheckApi
from rtu_mirea_vuc_schedule_client.api.schedule_api import ScheduleApi
from rtu_mirea_vuc_schedule_client.api.workbook_api import WorkbookApi

