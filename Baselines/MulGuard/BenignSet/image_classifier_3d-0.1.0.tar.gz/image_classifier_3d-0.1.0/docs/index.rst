Welcome to Image Classifier 3D's documentation!
======================================

.. toctree::
   :hidden:
   :maxdepth: 1
   :caption: Contents:

   Overview <self>
   installation
   Package modules <modules>
   contributing
   math

.. mdinclude:: ../README.md

Indices and tables
==================
* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`
