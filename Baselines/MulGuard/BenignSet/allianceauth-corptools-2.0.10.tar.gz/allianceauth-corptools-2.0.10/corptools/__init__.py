default_app_config = 'corptools.apps.CorpToolsConfig'
__version__ = "2.0.10"
