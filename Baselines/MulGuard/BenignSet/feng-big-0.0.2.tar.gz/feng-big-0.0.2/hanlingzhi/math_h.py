

def addition(x:int,y:int)->int:
    return x + y

def subtraction(x:int,y:int)->int:
    return x - y
