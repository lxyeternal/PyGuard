
def str_reverse(a:str)->str:
    return a[::-1]