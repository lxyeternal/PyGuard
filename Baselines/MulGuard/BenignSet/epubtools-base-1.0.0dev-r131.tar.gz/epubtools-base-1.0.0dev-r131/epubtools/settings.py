MIMETYPE = 'mimetype'
MIMETYPE_CONTENT = 'application/epub+zip'
COVER_IS_LINEAR = True

# Our Java executable
JAVA = '/usr/bin/java'

# epubcheck location
EPUBCHECK =  '/path/to/epubcheck'
