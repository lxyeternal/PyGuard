# -*- coding: utf-8 -*-
class EspionExportError(Exception):
    """
    Base class for exceptions importing espion files
    """
