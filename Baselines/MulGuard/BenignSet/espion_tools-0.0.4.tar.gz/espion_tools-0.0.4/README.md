# Espion Tools

Utilities for reading and manipulating Espion (http://diagnosys.com/) export files.

Basic use:

```python
data = parse_espion_export.load_file(fname)
```