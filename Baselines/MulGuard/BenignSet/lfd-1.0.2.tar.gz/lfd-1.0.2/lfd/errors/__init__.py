import sys

#try:
    #import errors
from errors import QsubErr, DetectTrailsLogs, Errors #Errors
#except: sys.stderr.write("Errors module was not loaded\n.")

