"""JobCreator is a GUI interface to createjobs module. It provides an
easier to manage graphical interace to the functionality contained in
the createjobs module and has additional practical features such as
in-place template editing.
"""
from lfd.gui.jobcreator import jobcreator
