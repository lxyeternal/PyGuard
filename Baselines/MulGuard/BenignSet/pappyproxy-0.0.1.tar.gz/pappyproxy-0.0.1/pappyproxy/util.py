
class PappyException(Exception):
    pass
