# MBS

Simple Python library for loading and plotting MB Scientific ARPES detector data in both KRX and TXT format.
