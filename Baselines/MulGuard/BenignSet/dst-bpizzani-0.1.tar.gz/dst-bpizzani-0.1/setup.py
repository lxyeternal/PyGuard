from setuptools import setup

setup(name='dst-bpizzani',
      version='0.1',
      description='Gaussian distributions',
      packages=['dst-bpizzani'],
      zip_safe=False)
