def pip_install_func():
    %pip install jupyterthemes 
    %pip install py5paisa
    %pip install pandas
    %pip install numpy

    %pip install py5paisa --upgrade
    
    output="RESTART KERNEL"
    return output