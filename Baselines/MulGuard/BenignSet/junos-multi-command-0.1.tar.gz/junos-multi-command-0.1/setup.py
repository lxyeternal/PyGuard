from distutils.core import setup

setup(
    name='junos-multi-command',
    version='0.1',
    packages=['junos-multi-command',],
    license='Creative Commons Attribution-Noncommercial-Share Alike license',
    long_description=open('README.md').read(),
)
