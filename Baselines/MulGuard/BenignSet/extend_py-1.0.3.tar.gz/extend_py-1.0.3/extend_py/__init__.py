from __future__ import absolute_import
from .extend_py import *

name = "extend_py"