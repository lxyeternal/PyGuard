# https://www.python.org/dev/peps/pep-0440/
__version__ = '1.10.0'
