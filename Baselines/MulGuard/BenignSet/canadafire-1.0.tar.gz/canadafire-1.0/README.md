# Canada Fire Index Calculator

Compute the Canada Fire Weather indices.  You can use

To package and upload to PyPI:
https://packaging.python.org/tutorials/packaging-projects/
