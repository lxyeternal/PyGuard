# Copyright (c) Microsoft Corporation
# Licensed under the MIT License.

name = 'responsibleai_text'
_major = '0'
_minor = '0'
_patch = '1'
version = '{}.{}.{}'.format(_major, _minor, _patch)
