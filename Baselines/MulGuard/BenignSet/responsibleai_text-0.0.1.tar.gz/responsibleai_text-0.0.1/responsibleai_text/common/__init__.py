# Copyright (c) Microsoft Corporation
# Licensed under the MIT License.

"""Common infrastructure, constants and utilities."""
