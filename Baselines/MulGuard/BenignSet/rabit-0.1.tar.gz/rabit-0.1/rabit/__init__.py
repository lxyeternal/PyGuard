from rabit.gif import convert2gif
from rabit.rabit import Rabit

__version__ = "0.1"
__author__ = 'Shanxun Gao'
