from setuptools import setup
 
NAME = 'Mydemos_pkg'
VERSION = '1.00.1.1'
PACKAGES = ['', 'Mydemos_pkg']
setup(name = NAME
        , version = VERSION
        , packages = PACKAGES
        ) 
