__doc__='''
This is some demos to learn about turtle, sorting, and something else.
this is only 1.00.1.1 version.
Released in 2020/5/1, the first day of May.
I'll release 1.20.1.0 version in 2020/6/18!
┌───────────────────┐
·demo:bytedesign
 USAGE:
from Mydemos_pkg import bytedesign as bd
bd.bytedesign()
·chaos
·clock
·colormixer
·forest
·fractalcurves
  ...
-------------------------------------------
Anyway, have fun!

'''
name="Mydemos_pkg"
