"""Metaoptimization of genetic algorithms for machine learning"""
#__init__.py

__version__ = "0.0.0"
