# GeneLearn
A Machine Learning optimization project.<br>
Using a genetic algorithm for hyperparameter tuning.<br>
Collecting data on this process to optimize efficiency.
