# Quick-Prophet
A quick workflow using Prophet with relatively easy datasets. It can be modified to take any of the usual behaviours of Prophet, and can run a Prophet model on each group in a specified collection of groups.
