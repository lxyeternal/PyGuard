Replacement pipeline for the STIS superdarks and superbiases
---
