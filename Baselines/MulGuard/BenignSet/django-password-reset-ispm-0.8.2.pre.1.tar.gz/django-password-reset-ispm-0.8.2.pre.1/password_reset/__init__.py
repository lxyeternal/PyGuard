__version__ = '0.8.2.pre.1'
