phrases = {'person':
            {
                'shaggy':['like zoinks scoob!'],
                'fred':["c'mon gang!","Let's split up gang!"],
                'velma':["my glasses! I can't see without my glasses"],
                'daphne':[''],
            },
            'animal':
            {
                'scooby':['Ruh-Roh-Raggie!','Reeheeheeheehee'],
                'scrappy':['Puppy Power!', "Let me at 'em, Let me at 'em!"]
            },
            'villain':
            {
                "Redbeard's ghost":["Arrrrgh!"],
                "Black Knight":[],

            }
            }