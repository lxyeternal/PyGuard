

Ceedee Project
===============
This is an example project that is used to demonstrate how to publish
Python packages on PyPI.
