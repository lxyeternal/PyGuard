from csv2notion.cli import main

if __name__ == "__main__":  # pragma: no cover
    main()
