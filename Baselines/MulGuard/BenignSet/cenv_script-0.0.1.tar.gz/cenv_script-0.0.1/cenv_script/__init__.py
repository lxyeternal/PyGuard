"""Top-level package for conda environment helper script."""

__author__ = """Alex Maystrenko"""
__email__ = 'alexeytech@gmail.com'
__version__ = '0.0.1'
