==========
*pygitpub*
==========

.. image:: https://img.shields.io/pypi/v/pygitpub

.. image:: https://img.shields.io/github/license/veltzer/pygitpub

.. image:: https://img.shields.io/badge/code%20style-black-000000.svg

project website: https://veltzer.github.io/pygitpub

author: Mark Veltzer

version: 0.0.1


