LOGGER_NAME = "pygitpub"
