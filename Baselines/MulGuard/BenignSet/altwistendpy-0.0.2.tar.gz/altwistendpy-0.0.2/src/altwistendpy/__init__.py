from altwistendpy.core import sleep

import altwistendpy._version
__version__ = _version.get_versions()['version']
