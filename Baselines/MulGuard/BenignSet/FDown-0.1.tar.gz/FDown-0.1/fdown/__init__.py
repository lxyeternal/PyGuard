from .fdown import *

__version__ = "0.1"

if __name__ == "__main__":
    print('Current version:', __version__)

