# FDown
Simple File Downloader Module for Python

##### You can use it as a module in your python file.

### Install FDown with Pip (Recommend)
```pip3 install fdown```
