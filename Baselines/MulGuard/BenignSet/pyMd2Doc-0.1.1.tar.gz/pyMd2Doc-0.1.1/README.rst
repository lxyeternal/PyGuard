# 1. Introduction of pyMd2Doc




# 2. use method



## 2.1 prepare Markdown document

Copy and paste the prepared Markdown file that needs to be documented into the pyMd2Doc / APP / title. MD file and save it.



## 2.2 conversion

Double click to execute the start.bat file, which does two operations.

Installation dependent needs

Converting Markdown files into documents with directory structure



## 2.3 view document

Open the newly generated title.html file with browser.

Click the directory to jump to the contents of the corresponding document.