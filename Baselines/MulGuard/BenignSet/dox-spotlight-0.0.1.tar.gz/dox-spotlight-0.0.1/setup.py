import setuptools

setuptools.setup(
    name="dox-spotlight",
    version="0.0.1",
    packages=setuptools.find_packages(),
)
