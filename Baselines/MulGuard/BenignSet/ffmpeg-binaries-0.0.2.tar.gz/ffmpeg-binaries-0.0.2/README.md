# ffmpeg for Python

[![CI/CD](https://github.com/MatteoH2O1999/ffmpeg-binaries/actions/workflows/ci.yml/badge.svg)](https://github.com/MatteoH2O1999/ffmpeg-binaries/actions/workflows/ci.yml)
[![codecov](https://codecov.io/github/MatteoH2O1999/ffmpeg-binaries/graph/badge.svg?token=9jkgMvjxxs)](https://codecov.io/github/MatteoH2O1999/ffmpeg-binaries)
![GitHub](https://img.shields.io/github/license/MatteoH2O1999/ffmpeg-binaries)

Static builds of ffmpeg for Python
