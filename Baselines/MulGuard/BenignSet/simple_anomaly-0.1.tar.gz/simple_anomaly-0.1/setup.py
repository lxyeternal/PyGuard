from setuptools import setup

setup(name='simple_anomaly',
      version='0.1',
      description='Anomaly detection',
      packages=['simple_anomaly'],
      author_email='rodrigosannn@gmail.com',
      zip_safe=False)
