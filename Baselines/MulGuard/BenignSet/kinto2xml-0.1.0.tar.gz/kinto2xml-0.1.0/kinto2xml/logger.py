import logging

logger = logging.getLogger("kinto2xml")
