from zope.interface import Interface
# -*- Additional Imports Here -*-


class IMediaPerson(Interface):
    """sPerson with media such as video and images"""

    # -*- schema definition goes here -*-
