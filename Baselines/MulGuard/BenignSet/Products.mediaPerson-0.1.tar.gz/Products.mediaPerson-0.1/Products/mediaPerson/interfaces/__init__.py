# -*- extra stuff goes here -*-
from mediaperson import IMediaPerson
