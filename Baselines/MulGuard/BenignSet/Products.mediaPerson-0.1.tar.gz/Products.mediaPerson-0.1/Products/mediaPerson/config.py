"""Common configuration constants
"""

PROJECTNAME = 'Products.mediaPerson'

ADD_PERMISSIONS = {
    # -*- extra stuff goes here -*-
    'MediaPerson': 'Products.mediaPerson: Add Media Person',
}
