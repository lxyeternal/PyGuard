<h1 align="center">
  <br>
  <a href="https://discord.com/channels/804774474444046407/804775262424137782"><img src="https://cdn.discordapp.com/icons/804774474444046407/777c1a5814f66c8ae5d8c0d5156b4f29.png?size=128" alt="Amino.py" width="200"></a>
  <br>
  CaptureS
  <br>
</h1>

### More Info About Use -> [Capture Discord](https://discord.com/channels/804774474444046407/810877242200686654)
###
#### What is this lib?
Python API to easily connect capture chat servers
#### How to install?
`python3 -m pip install amino.py`

- **TO FOCUS!:** Make sure you type `captures` **Not** `capture`
###
#### API Reference documentation

Soon...