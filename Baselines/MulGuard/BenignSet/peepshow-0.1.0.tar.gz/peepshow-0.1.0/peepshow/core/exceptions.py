
class CommandError(Exception): pass
