from setuptools import setup

setup(name= "EsosaAI_probability",
        version= "1.1",
        description = "Guassian and Binomial distributions",
        packages= ["EsosaAI_probability"],
        author= "Esosa Asemota",
        author_email= "a_esosa@yahoo.com",
        zip_safe= False)