def sayHelloy():
    print('HELLO')