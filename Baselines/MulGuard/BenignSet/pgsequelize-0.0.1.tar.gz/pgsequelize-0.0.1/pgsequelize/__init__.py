from main import sayHelloy

sayHelloy()