# Python Cassandra CLI tool

## Descirptoin
  CLI has 5 main commands:
  1. copy-snapshot-folder       Copy folder with snapshots from s3 bucket
  2. restore-snapshot-keyspace  Restore Keyspace snapshot from s3 bucket
  3. restore-snapshot-table     Restore Table snapshot from s3 bucket
  4. store-snapshot-keyspace    Take and store Keyspace snapshot to s3 bucket
  5. store-snapshot-table       Take and store Table snapshot to s3 bucket

## AWS resources access

## AWS S3 bucket
  1. You need to set -s3(--s3-bucket), -id(--aws-access-key-id) and  -key(--aws-secret-access-key) options for the connection to AWS S3
    bucket via access key. 
  2. If your host has AWS profile setup in .aws/credentials and/or IAM role with s3 bucket permissons then CLI
    needs only -s3(--s3-bucket) option.
## AWS Systems Manager
  1. You need to set -sn(--secret-name), -id(--aws-access-key-id) and  -key(--aws-secret-access-key) for getting secrest from Paramenter Store.
  2. If your host has AWS profile setup in .aws/credentials and/or IAM role with SSM permissons then CLI
    needs only -sn(--secret-name) option.
  3. Optionally you can change -r(--aws-region) for SSM. Default value is 'us-east-1'


## Commands examples:

### Store keyspace snapshot on s3 
```
python-cassandra-cli store-snapshot-keyspace  -k my_keyspace -t tag-01-keyspace -e dev -s3 my.s3.bucket -h "10.99.3.55"   --ssm-secret -sn /cassandra/dev 
```

### Store keyspace snapshot on s3 with keyspace schema
```
python-cassandra-cli store-snapshot-keyspace  -k my_keyspace -t tag-01-keyspace -e dev -s3 my.s3.bucket -h "10.99.3.55"  --ssm-secret -sn /cassandra/dev --create-keyspace-schema
``` 

### Store table snapshot on s3 with keyspace schema
```
python-cassandra-cli store-snapshot-table -k my_keyspace -tn my_table -t tag-01-table -e dev -s3 my.s3.bucket -h "10.99.3.55"  --ssm-secret -sn /cassandra/dev --create-keyspace-schema
```

### Resotore table

```
python-cassandra-cli restore-snapshot-table -sf 1608700346_snapshots_tag-01-keyspace_my_keyspace_develop -t tag-01-table -k my_keyspace -tn my_table -h "10.99.3.55" --ssm-secret -sn /cassandra/dev -s3 my.s3.bucket
```
### Restore table ssl
```
python-cassandra-cli restore-snapshot-table  -sf 1608700346_snapshots_tag-01-table_my_table_develop -t tag-01-table -k my_keyspace -tn my_table -h "10.99.3.55" --ssm-secret -s3 my.s3.bucket -sn /cassandra/dev -cf /etc/cassandra/conf/cassandra.yaml  -ks /etc/cassandra/conf/keystore.node0 -ts /etc/cassandra/conf/truststore.node0 -ssl -pt 9142 
```
### Restore keyspace ssl with keyspace creation
```
python-cassandra-cli restore-snapshot-keyspace  -sf 608700346_snapshots_tag-01-keyspace_my_keyspace_develop -t tag-01-keyspace -k my_keyspace  -h "10.99.3.55" --ssm-secret -s3 my.s3.bucket -sn /cassandra/dev --create-keyspace-schema -e develop -cf /etc/cassandra/conf/cassandra.yaml  -ks /etc/cassandra/conf/keystore.node0 -ts /etc/cassandra/conf/truststore.node0 -ssl -pt 9142 --create-keyspace-schema
```
### Copy folder wiht sanpshot on local
```
python-cassandra-cli copy-snapshot-folder -s3 my.s3.bucket -sf 1608700346_snapshots_tag-01-keyspace_my_keyspace_develop
```
