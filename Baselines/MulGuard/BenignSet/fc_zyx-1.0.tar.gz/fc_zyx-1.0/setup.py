from setuptools import setup

setup(
            name = "fc_zyx",
            version = "1.0",
            py_modules = ["fc_xd_bigdata3"],
            author = "大数据3",
            author_email = "fc@bigdata.com",
            description = "大数据3",    
)