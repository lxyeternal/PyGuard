print "use my_pack __init__.py"
import mlp
import dec
