
def init():
	print "mlp init"

def uinit():
	print "mlp uinit"
