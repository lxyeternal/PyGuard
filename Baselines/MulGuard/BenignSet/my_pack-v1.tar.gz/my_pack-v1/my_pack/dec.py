
def init():
	print "dec init"

def uinit():
	print "dec uinit"
