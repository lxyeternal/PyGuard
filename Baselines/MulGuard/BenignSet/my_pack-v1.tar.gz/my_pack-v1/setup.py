from distutils.core import setup

setup(name="my_pack", version="v1", discription="test", autohr="tingwu", py_modules=['my_pack.mlp', 'my_pack.dec'])
