from distutils.core import setup

setup(
        name        = 'practise',
        version     = '1.0.0',
        py_modules  = ['practise'],
        author      = 'zephyr',
        author_email= 'zephyr.nju@gmail.com',
        url         = 'http://zzli.me',
        description = 'A simple printer of nested lists',
     )
