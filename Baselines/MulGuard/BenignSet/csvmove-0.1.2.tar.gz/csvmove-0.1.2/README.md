# csvmove
CLI utility that moves files based on columns in a csv.