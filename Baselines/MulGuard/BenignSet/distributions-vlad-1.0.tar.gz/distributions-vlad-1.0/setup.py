from setuptools import setup

setup(name='distributions-vlad',
      version='1.0',
      description='Gaussian and Binomial distributions',
      packages=['distributions-vlad'],
      author='Vlad Ionescu',
      zip_safe=False)
