
class ApiError(Exception):
    pass