# _init_.py

# from .Gaussiandistribution import Gaussian

class File:
    x = 50

