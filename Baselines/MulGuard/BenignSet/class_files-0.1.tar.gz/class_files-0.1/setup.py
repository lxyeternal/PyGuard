from setuptools import setup

setup(name='class_files',
      version='0.1',
      description='Удобный класс для работы с файлами.',
      packages=['class_files'],
      author_email='BusinessJson6@gmail.com',
      zip_safe=False)
