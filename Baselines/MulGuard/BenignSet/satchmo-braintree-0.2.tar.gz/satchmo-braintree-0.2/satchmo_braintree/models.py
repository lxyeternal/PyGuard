import config


PAYMENT_PROCESSOR=True
