API_ENDPOINT = "https://api.mauna.cloud/v1/graphql"
# TODO: replace with the shorter url
AUTH_ENDPOINT = "https://us-central1-mauna-ai-290409.cloudfunctions.net/generateHasuraJWT"
