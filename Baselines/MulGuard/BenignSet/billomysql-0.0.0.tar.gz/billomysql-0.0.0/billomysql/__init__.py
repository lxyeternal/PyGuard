from .__version__ import __version__, __version_info__  # noqa

__author__ = "Billogram"
__email__ = "platform@billogram.com"
