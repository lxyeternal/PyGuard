name = "aviationFormula"

__author__ = "Oliver Clemens"

__email__ = "sowintuu@aol.com"

__version__ = "0.0.1"
