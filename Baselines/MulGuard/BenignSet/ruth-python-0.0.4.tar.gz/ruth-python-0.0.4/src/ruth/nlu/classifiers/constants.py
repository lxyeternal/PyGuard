# Bert IntentClassifier
EPOCHS = 4
BATCH_SIZE = 1  # TODO: Change to 32
MAX_LENGTH = 60
MODEL_NAME = "bert-base-uncased"
