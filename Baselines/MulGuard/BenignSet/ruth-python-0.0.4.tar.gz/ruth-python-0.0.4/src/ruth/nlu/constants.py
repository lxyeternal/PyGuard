ELEMENT_UNIQUE_NAME = "unique_name"
INDEX = "index"
DEFAULT_MODEL_NAME = "models"
RUTH = "ruth"
