=======
History
=======

0.2.0 (2022-10-04)
----------------------

* Fixed bug where not setting a name on a network
  would cause ``CommunityDetection.run_community_detection()``
  to raise a ``TypeError``. When encountered code now sets network
  name to **unknown** `Issue #1 <https://github.com/idekerlab/cdapsutil/issues/1>`__

0.2.0a1 (2021-03-30)
----------------------

* First release on PyPI.
