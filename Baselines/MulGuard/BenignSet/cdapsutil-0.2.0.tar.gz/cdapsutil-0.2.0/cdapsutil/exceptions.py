# -*- coding: utf-8 -*-


class CommunityDetectionError(Exception):
    """
    Base class for CommunityDetection Errors
    """
    pass
