# Job Application Tracker
A simple command line interface to track job applications.
Built using [Typer](https://github.com/tiangolo/typer). This project
was an exercise in basic software development, testing, and packaging. Tutorials followed:
<br />
* [https://realpython.com/command-line-interfaces-python-argparse/](https://realpython.com/command-line-interfaces-python-argparse/)
* [https://realpython.com/pypi-publish-python-package/#prepare-your-package-for-publication](https://realpython.com/pypi-publish-python-package/#prepare-your-package-for-publication)