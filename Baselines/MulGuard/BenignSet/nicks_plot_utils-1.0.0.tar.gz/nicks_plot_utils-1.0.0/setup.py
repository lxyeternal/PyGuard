from setuptools import setup

with open("README.md", "r", encoding="utf-8") as fh:
    long_description = fh.read()

setup(
    name='nicks_plot_utils',
    version='1.0.0',
    description='A example Python package',
    url='https://github.com/tylern4/nicks_plot_utils',
    author='Nick Tyler',
    author_email='nicholas.s.tyler.4@gmail.com',
    license='BSD 2-clause',
    long_description=long_description,
    long_description_content_type="text/markdown",
    packages=['nicks_plot_utils'],
    install_requires=['matplotlib',
                      'numpy',
                      'boost-histogram',
                      'scipy',
                      'lmfit'
                      ],

    classifiers=[
        'Development Status :: 1 - Planning',
        'Intended Audience :: Science/Research',
        'License :: OSI Approved :: BSD License',
        'Operating System :: POSIX :: Linux',
        'Programming Language :: Python :: 3.5',
        'Programming Language :: Python :: 3.7',
        'Programming Language :: Python :: 3.8',
        'Programming Language :: Python :: 3.9',
    ],
    python_requires='>=3.5',
)
