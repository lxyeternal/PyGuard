class BaseConfiguration:
    BASE_API_URL = "https://dog.ceo/api"
    BASE_REQUEST_TIMEOUT = 10
