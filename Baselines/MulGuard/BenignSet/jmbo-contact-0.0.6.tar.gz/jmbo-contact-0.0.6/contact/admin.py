from django.contrib import admin

from contact.models import ContactPreferences

admin.site.register(ContactPreferences)
