from ._serve_module import PixelyAIServeTorch
