from .inference import GGMLModel
