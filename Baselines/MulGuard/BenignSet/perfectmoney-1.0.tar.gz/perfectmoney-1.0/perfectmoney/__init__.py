__version__ = 1.0
__description__ = 'API for perfectmoney payments'
__author__= "Sina Namadian"
__email__="quitegreensky@gmail.com"

