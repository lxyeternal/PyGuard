from setuptools import setup

setup(name='dd_distributions',
      version='0.1',
      description='Gaussian distributions',
      packages=['dd_distributions'],
      author='Omer Sarfraz',
      zip_safe=False)
