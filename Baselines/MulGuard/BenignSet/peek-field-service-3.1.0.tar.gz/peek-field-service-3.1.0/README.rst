==============================
Peek Platform - Client Service
==============================

The Peek Client service is where Peek Apps can run their user interface.
This is the for this service, for the browser side see peek_field_service_fe.
