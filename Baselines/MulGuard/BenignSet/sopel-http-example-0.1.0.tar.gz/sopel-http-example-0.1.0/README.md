# sopel-http-example
[![PyPi Version](https://img.shields.io/pypi/v/sopel-http-example.svg)](https://pypi.org/project/sopel-http-example/)

An example plugin for [sopel-http](https://github.com/half-duplex/sopel-http)

## Setup
Just `pip install sopel-http-example` into your
[Sopel](https://github.com/sopel-irc/sopel) environment.

## Usage
Once this plugin is installed and your bot is restarted, you should be able to
access the web UI on https://localhost:8094/ (or whatever host/port you
configured `sopel-http` to use).
