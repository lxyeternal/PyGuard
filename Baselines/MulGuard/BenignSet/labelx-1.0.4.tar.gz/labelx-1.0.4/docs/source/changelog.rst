=========
Changelog
=========

1.0.4 [02.04.2020]
------------------

* Create labels with default values
* Show package information
* Added more tests
* Re-newed documentation

1.0.3 (unreleased) [30.03.2020]
-------------------------------

* Show package information
* Added test cases
