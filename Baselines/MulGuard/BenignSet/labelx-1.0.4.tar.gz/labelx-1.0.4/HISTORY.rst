=======
History
=======

1.0.1 (2020-03-26)
------------------

* First release on PyPI.
