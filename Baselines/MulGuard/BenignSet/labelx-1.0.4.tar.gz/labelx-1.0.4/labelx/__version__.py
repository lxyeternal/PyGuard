#!/usr/bin/env python3
# -*- coding: utf-8 -*-

# Package Metadata
__package_name__ = "labelx"
__author__ = "Dalwar Hossain"
__author_email = "dalwar23@protonmail.com"
__version__ = "1.0.4"
__copyright__ = "Copyright 2020 Dalwar Hossain"
__license__ = "GNU General Public License v3"
