from setuptools import setup

setup(name='juiceutils-base', version='0.0.47', author_email='pannet.sec@gmail.com')
