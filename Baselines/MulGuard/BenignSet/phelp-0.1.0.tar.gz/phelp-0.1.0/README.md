# Phelp (Please help)

A set of python helper functions for dealing with files
