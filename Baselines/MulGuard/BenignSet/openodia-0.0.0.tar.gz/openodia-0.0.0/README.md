# openodia

`openodia` is a Python package which contains various tools on Odia language.