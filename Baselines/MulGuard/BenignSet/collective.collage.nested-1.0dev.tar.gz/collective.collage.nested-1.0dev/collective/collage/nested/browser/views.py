from Products.Collage.browser.collage import CollageView
from Products.Collage.browser.views import BaseView

class NestedCollageView(BaseView, CollageView):
    """ A nested collage view """
