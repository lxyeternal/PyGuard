from setuptools import setup

setup(
    name='nora',
    version='0.0.1',
    description='',
    long_description='',
    url='https://www.example.com',
    author='summer',
    packages=[],
    classifiers=['Development Status :: 1 - Planning'],
)
