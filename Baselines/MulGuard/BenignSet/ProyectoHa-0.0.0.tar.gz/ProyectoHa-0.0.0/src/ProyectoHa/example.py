import __init__ as sexo

resultado = sexo.suma(3,5)
print(resultado)