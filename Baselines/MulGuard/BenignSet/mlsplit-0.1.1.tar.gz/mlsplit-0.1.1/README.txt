mlsplit
=======

This script splits Malayalam words into letters.
Ref: http://tinyurl.com/3v729s

Usage:

  python mlsplit.py input.txt [input.txt-out.txt]
