# nwave
[![Build](https://github.com/ionite34/nwave/actions/workflows/build.yml/badge.svg?branch=main)](https://github.com/ionite34/nwave/actions/workflows/build.yml)
[![codecov](https://codecov.io/gh/ionite34/nwave/branch/main/graph/badge.svg?token=ZXM5Y46XBI)](https://codecov.io/gh/ionite34/nwave)
[![FOSSA Status](https://app.fossa.com/api/projects/git%2Bgithub.com%2Fionite34%2Fnwave.svg?type=shield)](https://app.fossa.com/projects/git%2Bgithub.com%2Fionite34%2Fnwave?ref=badge_shield)


![PyPI - Python Version](https://img.shields.io/pypi/pyversions/nwave)
[![PyPI version](https://badge.fury.io/py/nwave.svg)](https://pypi.org/project/nwave/)


Low latency multi-thread audio transforms and conversions


## License
The code in this project is released under the [MIT License](LICENSE).

[![FOSSA Status](https://app.fossa.com/api/projects/git%2Bgithub.com%2Fionite34%2Fnwave.svg?type=large)](https://app.fossa.com/projects/git%2Bgithub.com%2Fionite34%2Fnwave?ref=badge_large)