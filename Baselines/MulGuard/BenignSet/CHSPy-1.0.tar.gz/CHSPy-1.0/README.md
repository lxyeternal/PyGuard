# Cubic Hermite Splines for Python

This module provides Python tools for cubic Hermite splines with one argument (time) and multiple values.
It was branched of from `JiTCDDE <http://github.com/neurophysik/jitcdde>`_, which uses it for representing the past of a delay differential equation.
