"""Top-level package for flatmake."""

__author__ = """Maxime De Waegeneer"""
__email__ = 'mdewaegeneer@gmail.com'
__version__ = '0.1.0'
