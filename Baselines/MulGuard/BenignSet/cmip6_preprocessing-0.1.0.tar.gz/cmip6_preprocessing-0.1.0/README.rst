===============================
cmip6_preprocessing
===============================

.. image:: https://badge.fury.io/py/cmip6_preprocessing.svg
        :target: https://badge.fury.io/py/cmip6_preprocessing
.. image:: https://img.shields.io/travis/jbusecke/cmip6_preprocessing.svg
        :target: https://travis-ci.org/jbusecke/cmip6_preprocessing
.. image:: https://circleci.com/gh/jbusecke/cmip6_preprocessing.svg?style=svg
    :target: https://circleci.com/gh/jbusecke/cmip6_preprocessing
.. image:: https://codecov.io/gh/jbusecke/cmip6_preprocessing/branch/master/graph/badge.svg
   :target: https://codecov.io/gh/jbusecke/cmip6_preprocessing


Some useful functions to make analysis across cmip6 modesl easier
