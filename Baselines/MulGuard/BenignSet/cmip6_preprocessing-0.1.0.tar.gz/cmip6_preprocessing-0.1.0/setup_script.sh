#!/bin/bash

#pip install git+https://github.com/jbusecke/cmip6_preprocessing.git
pip install git+https://github.com/NCAR/intake-esm.git
cd ~/cmip6_preprocessing
pip install -e .
