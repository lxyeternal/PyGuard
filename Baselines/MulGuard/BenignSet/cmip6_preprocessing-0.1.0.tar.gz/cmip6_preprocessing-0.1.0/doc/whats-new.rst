.. currentmodule:: cmip6_preprocessing

What's New
===========

.. _whats-new.0.1.0:

v0.1.0 (2/21/2020)
----------------------

Initial release.
