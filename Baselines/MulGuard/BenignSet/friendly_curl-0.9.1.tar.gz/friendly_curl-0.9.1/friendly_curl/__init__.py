"""Friendly CURL Module

Presents a friendly interface to CURL."""

from friendly_curl import *
