# not used anymore with the new JSONConfig.slug
EIP_CONFIG = "eip.json"
EIP_SERVICE_EXPECTED_PATH = "1/config/eip-service.json"
