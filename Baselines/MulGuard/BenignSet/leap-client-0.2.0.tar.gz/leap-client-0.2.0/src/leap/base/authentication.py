"""
Authentication Base Class
"""


class Authentication(object):
    """
    I have no idea how Authentication (certs,?)
    will be done, but stub it here.
    """
    pass
