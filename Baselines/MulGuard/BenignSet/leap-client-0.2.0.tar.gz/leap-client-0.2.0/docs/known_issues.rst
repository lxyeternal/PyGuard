0.2.0
-----

* On the login page, the error messages are not descriptive.
