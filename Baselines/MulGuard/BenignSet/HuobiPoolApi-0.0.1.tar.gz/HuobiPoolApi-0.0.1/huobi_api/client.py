

class Client:
    def __init__(self, access_api_key: str, secret_key: str) -> None:
        self.access_api_key = access_api_key
        self.secret_key = secret_key


