# nope  
  
swap file extension to nope and back (default to tf for terraform files).  
  
### dependencies  
  
python3  
  
### usage  
  
`$ nope filename`  
