
from keywords import DiffKeywords

class DiffLibrary(DiffKeywords):
    ROBOT_LIBRARY_SCOPE = 'GLOBAL'

