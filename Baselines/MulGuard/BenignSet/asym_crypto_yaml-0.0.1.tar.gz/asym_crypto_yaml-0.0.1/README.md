# asym-crypto-yaml

Encrypt values for yaml keys without modifying the structure of the document

Installation
------------