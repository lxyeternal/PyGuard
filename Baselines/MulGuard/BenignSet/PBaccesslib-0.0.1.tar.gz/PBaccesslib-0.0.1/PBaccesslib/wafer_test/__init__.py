from PBaccesslib import logger

logger = logger.getChild(__name__)


__all__ = [
    "logger",
]
