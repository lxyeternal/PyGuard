# import logging
# from PBaccesslib import log_add_file_handler, log_to_screen
# from K2600acceslib import log_to_screen as k2600_screen, log_add_file_handler as k2600_add_file
# from Commacceslib import log_to_screen as comm_screen, log_add_file_handler as comm_add_file
#
#
# def std_file_on(file_path):
#     """ Add data to file """
#     log_add_file_handler(file_path)
#     k2600_add_file(file_path)
#     comm_add_file(file_path)
#
#     """ Std out log """
#     log_to_screen()
#     k2600_screen()
#     comm_screen()
