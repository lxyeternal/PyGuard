from distutils.core import setup

setup(
        name            = 'my_first_python_app',
        version         = '1.0.0',
        py_modules      = ['my_first_python_app'],
        author          = 'druss',
        author_email    = 'python@druss.com',
        url             = 'http://www.druss.com',
        description     = 'Experimental first app',
        )
