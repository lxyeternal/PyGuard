=======
History
=======

0.0.0 (2022-02-22)
------------------

* First release on PyPI.
