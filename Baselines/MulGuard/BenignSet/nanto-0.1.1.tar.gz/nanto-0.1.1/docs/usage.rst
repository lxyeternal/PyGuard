=====
Usage
=====

To use nanto in a project::

    import nanto as opyt
