#!/usr/bin/python
# -*- coding: utf-8 -*-

import sys
from os.path import join, dirname
import argparse

def main(arguments=None):
    if arguments is None:
        arguments = sys.argv
    parser = argparse.ArgumentParser(description='Renames a folder or file.', prog="ren")
    parser.add_argument('path', help='the source path to rename', nargs=1)
    parser.add_argument('name', help='the name of the file', nargs=1)

    options = parser.parse_args(arguments)
    from_path = options.path[0]
    to_path = join(dirname(from_path), options.name[0])

    print "moving from %s to %s" % (from_path, to_path)

if __name__ == '__main__':
    arguments = sys.argv[1:]
    main(arguments)
