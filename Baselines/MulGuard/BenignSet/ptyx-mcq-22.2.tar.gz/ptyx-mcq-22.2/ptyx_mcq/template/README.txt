All questions must be in `questions` folder.
Scanned sheets must be put in `scan` folder, as `pdf` files.
