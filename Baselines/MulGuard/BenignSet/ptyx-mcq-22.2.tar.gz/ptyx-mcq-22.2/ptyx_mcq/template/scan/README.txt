Put scanned students MCQs in this directory, as `pdf` files.
You may use subdirectories if you want, as the `pdf` files will be recursively searched for in this d1irectory.