""" Command line interfaces to Seed Service HTTP APIs. """

__version__ = "0.0.1"
