# pymongtic

Simple pymongo ODM that uses pydantic for validation
