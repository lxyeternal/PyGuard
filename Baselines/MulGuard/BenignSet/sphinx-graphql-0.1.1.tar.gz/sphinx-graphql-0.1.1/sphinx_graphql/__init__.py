from sphinx_graphql._version_git import __version__

__all__ = ["__version__"]
