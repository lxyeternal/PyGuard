pyfinance
=========

Python package designed for general financial and security returns analysis.

Work in progress; docs forthcoming. Feedback appreciated.