# Oracle
Open oracle for illiquid collection pricing.
