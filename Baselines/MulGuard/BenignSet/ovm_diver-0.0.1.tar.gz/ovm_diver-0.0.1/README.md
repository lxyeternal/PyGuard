# OVM Diver package

This package, for now, contains one function ( calc_mix() ) which calculates the resulting trimix after topping of the tanks.