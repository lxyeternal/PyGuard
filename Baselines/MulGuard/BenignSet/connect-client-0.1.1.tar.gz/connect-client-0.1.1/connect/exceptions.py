# -*- coding: utf-8 -*-

class InvalidEventError(Exception):
    pass