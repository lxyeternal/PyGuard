# SAP_Data_CE_PC_Daily

This is a Python package that connects to a specific database and fetches certain data based on user permissions.

## Installation

Before installing this package, ensure that `pymssql` is installed. You can install it via conda:

```bash
conda install -c anaconda pymssql
pip install HQ_Daily_Cube
