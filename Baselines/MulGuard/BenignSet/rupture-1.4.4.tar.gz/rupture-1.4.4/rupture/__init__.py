# -*- coding: utf-8 -*-

from .rupture import Rupture
