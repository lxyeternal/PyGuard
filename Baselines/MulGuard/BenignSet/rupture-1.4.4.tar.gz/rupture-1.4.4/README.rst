Rupture
=================

Rupture is Wrapper class for requests and beautifulsoup for easily usage.

Features
--------

* Support GET, POST, and other
* Support Ajax requests

Documentation can not be found yet.
`Read the Docs <http://readthedocs.org/>`_.
