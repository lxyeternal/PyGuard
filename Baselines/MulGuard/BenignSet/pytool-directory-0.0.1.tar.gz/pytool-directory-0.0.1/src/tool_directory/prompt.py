TOOL_DESCRIPTION = '''Description: {description}
Endpoint: {endpoint}'''
