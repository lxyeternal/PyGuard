# -*- coding: utf-8 -*-
from .google_tts import GoogleTTS
from .version import __version__  # noqa: F401

__all__ = ["GoogleTTS"]
