def output():
    print("晴姐，你会安装Python的包了吗？")
