from setuptools import setup
setup(
    name='rocket-launcher',
    version='0.2.1',
    author='who',
    author_email='who@whooami.me',
    scripts=['rocket-launcher'],
    packages=['rockets']
)
