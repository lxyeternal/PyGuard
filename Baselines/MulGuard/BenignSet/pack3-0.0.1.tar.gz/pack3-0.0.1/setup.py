from setuptools import setup

setup(
    name='pack3',
    version='0.0.1',
    description='a pip-installable package example',
    license='MIT',
    packages=['pack3'],
    author='vinay279',
    author_email='mudiraj.vinay.279@gmail.com',
    keywords=['example'],
    #url='https://github.com/bgse/hellostackoverflow'
)