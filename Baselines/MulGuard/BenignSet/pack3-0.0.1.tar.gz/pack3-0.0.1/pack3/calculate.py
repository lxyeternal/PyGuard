'''
Created on 26 Dec 2019

@author: VINAY
'''


class Calculation:
    
    def sum(a=0,b=0,c=0,d=0):
        print("sum :",a+b+c+d)
        
    def sub(a=0,b=0):
        print("sub :",a-b)
        
    def mul(a=0,b=0):
        print("mul :",a*b)
        
    def div(a=0,b=0):
        print("div :",a/b)

