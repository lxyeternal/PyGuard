from arst.mainapp import main


def launch():
    main()


if __name__ == '__main__':
    main()
