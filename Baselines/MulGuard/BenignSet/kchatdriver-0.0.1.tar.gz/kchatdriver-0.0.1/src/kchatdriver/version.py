full_version = "0.0.1"
short_version = ".".join(full_version.split(".", 2)[:2])
