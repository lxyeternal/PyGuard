from helloworld import say_hello

def test_helloworld():
    assert say_hello() == "hello"