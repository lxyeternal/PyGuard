def say_hello():
    print("hello")
    return "hello"