class Line(str):
    """Text line.

    Then main unit of which `Lines` is composed.
    """
