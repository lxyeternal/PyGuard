**rembrandt_cli**

Python [Cryptic-Game](https://github.com/cryptic-game/cryptic) library. 
Maybe I will also add a frontend to this lib.

needed environment variables
|variable| value |
|--|--|
| USERNAME | the username of your cryptic account |
|PASSWORD  | password of your cryptic account |


