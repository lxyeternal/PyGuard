"""Please import a backend explicitly.

Currently only one backend is implemented: block.algebraic.hazmath
"""

active_backend = None

from .precond import *
