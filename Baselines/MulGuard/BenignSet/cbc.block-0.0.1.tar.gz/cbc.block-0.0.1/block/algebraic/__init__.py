"""Please import a backend explicitly.

Currently only two backends are implemented: block.algebraic.petsc
and block.algebraic.hazmath. Trilinos is depreciated. 
"""

active_backend = None
