from django.apps import AppConfig


class DjwaiterConfig(AppConfig):
    name = 'djwaiter'
