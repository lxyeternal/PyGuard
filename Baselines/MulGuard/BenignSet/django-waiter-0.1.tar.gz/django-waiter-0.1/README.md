# django-waiter
Django useful tools for developments.
