Semantic Utils
==============

.. automodule:: quepy.semantic_utils
    :members:
    :undoc-members:
