Freeling
========

.. automodule:: quepy.freeling
    :members:
