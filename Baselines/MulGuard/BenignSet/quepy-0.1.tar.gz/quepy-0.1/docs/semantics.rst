Semantics
=========

.. automodule:: quepy.semantics
    :members:
