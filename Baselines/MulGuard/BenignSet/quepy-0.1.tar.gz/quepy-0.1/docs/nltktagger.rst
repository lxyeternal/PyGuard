NLTK Tagger
===========

.. automodule:: quepy.nltktagger
    :members:
