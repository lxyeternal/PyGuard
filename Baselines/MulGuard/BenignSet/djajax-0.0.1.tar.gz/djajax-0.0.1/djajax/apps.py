from django.apps import AppConfig


class DjajaxConfig(AppConfig):
    name = 'djajax'
    label = 'djajax'
    verbose_name = "djajax"
