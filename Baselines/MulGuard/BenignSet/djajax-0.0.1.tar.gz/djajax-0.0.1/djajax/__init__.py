default_app_config = 'djajax.apps.DjajaxConfig'
