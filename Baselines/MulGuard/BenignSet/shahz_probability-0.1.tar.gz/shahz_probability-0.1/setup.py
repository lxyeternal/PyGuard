from setuptools import setup

setup(name='shahz_probability',
      version='0.1',
      description='Gaussian and Binomial distributions',
      packages=['shahz_probability'],
      author='shah bhatti',
      author_email='cleashahbhatti@gmail.com',
      zip_safe=False)
