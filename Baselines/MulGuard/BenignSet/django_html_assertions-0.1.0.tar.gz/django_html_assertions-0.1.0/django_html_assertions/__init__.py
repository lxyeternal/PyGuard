__version__ = ('0', '1', '0')


def get_version():
    """
    Returns the version string for this library

    :return: library version string
    """
    return '.'.join(__version__)
