
__docformat__ = "restructuredtext en"
__author__ = "John Westbrook"
__email__ = "john.westbrook@rcsb.org"
__license__ = "Apache 2.0"
__version__ = "0.10"

__apiUrl__ = "https://mmcif.wwpdb.org"
