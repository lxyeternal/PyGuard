from distutils.core import setup

setup(
    name='SmsBot',
    version= '1.0',
    description='A Python Package which can be used to send Sms to any Number in India using Way2Sms',
    author='Nishchith Shetty',
    author_email='inishchith@gmail.com',
    url='https://github.com/inishchith/SmsBot',
    packages=['Bot'],
)
