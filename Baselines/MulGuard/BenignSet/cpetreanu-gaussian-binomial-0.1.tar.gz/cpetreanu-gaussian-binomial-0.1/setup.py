from setuptools import setup

setup(name='cpetreanu-gaussian-binomial',
      version='0.1',
      description='Gaussian distributions',
      packages=['cpetreanu-gaussian-binomial'],
      author='cpetreanu',
      author_email='catanzaropetreanu@gmail.com',
      zip_safe=False)
