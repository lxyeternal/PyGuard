Foobar is a Python library developed by cpetreanu during AWS Machine Learning Foundations Course

## Installation

Use the package manager [pip](https://pip.pypa.io/en/stable/) to install foobar.

```bash
pip install cpetreanu-gaussian-binomial
```

## Usage

```python
# TODO
```

## Contributing

## License
[MIT](https://choosealicense.com/licenses/mit/)