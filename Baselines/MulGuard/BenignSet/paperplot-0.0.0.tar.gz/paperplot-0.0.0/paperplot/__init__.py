print("The first version of paperplot.")
