
License
=======

.. literalinclude:: ../NOTICE
    :language: none
