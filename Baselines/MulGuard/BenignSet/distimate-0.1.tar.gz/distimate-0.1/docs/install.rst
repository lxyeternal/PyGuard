
Installation
============

Distimate requires Python 3.6 or newer. It can be installed using pip:

.. code-block:: shell

    pip install distimate


