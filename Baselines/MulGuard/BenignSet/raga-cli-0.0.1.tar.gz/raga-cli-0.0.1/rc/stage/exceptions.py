from rc.exceptions import RcException


class StageCommitError(RcException):
    pass