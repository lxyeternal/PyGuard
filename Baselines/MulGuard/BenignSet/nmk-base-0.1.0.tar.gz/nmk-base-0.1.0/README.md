# nmk-base
Base plugin for nmk build system

## Usage

To reference this plug-in in your **`nmk`** project, insert this reference:
```
refs:
    - pip://nmk-base/plugin.yml
```

## Documentation

This plugin documentation is available [here](https://github.com/dynod/nmk/wiki/nmk-base-plugin)

## Issues

Issues for this plugin shall be reported on the [main  **`nmk`** project](https://github.com/dynod/nmk/issues), using the **plugin:base** label.
