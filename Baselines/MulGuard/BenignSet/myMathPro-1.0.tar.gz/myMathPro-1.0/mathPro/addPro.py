#!usr/bin/env python
# -*- coding:utf-8 _*-
"""
@author: Administrator
@file: addPro.py
@time: 2020/10/04
@desc:
"""
def addPro(a,b):
    return a+b
