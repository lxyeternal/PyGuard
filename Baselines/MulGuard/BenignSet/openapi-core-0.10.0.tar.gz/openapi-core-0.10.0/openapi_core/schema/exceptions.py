"""OpenAPI core schema exceptions module"""


class OpenAPIError(Exception):
    pass


class OpenAPIMappingError(OpenAPIError):
    pass
