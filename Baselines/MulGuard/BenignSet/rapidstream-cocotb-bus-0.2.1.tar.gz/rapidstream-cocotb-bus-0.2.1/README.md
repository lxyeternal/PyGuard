# cocotb-bus

[![PyPI](https://img.shields.io/pypi/dm/cocotb-bus.svg?label=PyPI%20downloads)](https://pypi.org/project/cocotb-bus/)

The new home of the [cocotb](https://github.com/cocotb) project's pre-packaged testbenching tools and reusable bus interfaces.
