import PyLucene
from pyndexter import *

class LuceneIndexer(Indexer):
    pass
