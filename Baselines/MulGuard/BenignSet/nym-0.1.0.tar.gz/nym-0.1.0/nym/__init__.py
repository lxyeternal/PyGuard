"""Top-level package for nym."""

__author__ = """Goncalo Magno"""
__email__ = 'goncalo.magno@gmail.com'
__version__ = '0.1.0'
