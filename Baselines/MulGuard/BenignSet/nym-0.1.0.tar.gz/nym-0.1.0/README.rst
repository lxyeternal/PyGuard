===
nym
===


.. image:: https://img.shields.io/pypi/v/nym.svg
        :target: https://pypi.python.org/pypi/nym

.. image:: https://img.shields.io/travis/gmagno/nym.svg
        :target: https://travis-ci.com/gmagno/nym

.. image:: https://readthedocs.org/projects/nym/badge/?version=latest
        :target: https://nym.readthedocs.io/en/latest/?version=latest
        :alt: Documentation Status




Nim extension for Python, example project


* Free software: MIT license
* Documentation: https://nym.readthedocs.io.
