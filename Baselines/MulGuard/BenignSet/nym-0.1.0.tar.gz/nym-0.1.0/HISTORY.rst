=======
History
=======

0.1.0 (2022-05-14)
------------------

* First release on PyPI.
