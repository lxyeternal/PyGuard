=====
Usage
=====

To use nym in a project::

    import nym
