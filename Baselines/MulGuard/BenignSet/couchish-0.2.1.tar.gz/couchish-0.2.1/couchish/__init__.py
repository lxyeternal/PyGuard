# Export the typical public API.
from couchish.store import CouchishStore
from couchish.errors import CouchishError, NotFound, TooMany
from couchish.config import Config

