"""Pipeline defects danger calculation."""


class Error(Exception):
    """Pipe dunger base error class."""
