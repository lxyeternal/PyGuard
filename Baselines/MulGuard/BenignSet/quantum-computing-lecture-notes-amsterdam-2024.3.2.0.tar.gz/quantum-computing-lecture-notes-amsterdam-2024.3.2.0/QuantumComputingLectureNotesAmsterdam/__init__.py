#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""quantum-computing-lecture-notes-amsterdam
https://github.com/apachecn/quantum-computing-lecture-notes-amsterdam"""

__author__ = "ApacheCN"
__email__ = "apachecn@163.com"
__license__ = "CC BY-NC-SA 4.0"
__version__ = "2024.3.2.0"