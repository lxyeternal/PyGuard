# Ringkasan

Explore different ways to consume a website by converting it into different medium

## Developer Setup

### Publish

```
poetry build && poetry publish
```
