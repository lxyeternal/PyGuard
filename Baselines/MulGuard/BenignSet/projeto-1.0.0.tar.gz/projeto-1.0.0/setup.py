from distutils.core import setup

setup(
       name            = 'projeto',
       version         = '1.0.0',
       py_modules      = ['projeto'],
       author          = 'raphael',
       author_email    = 'raphael.ramos99@hotmail.com',
       url             = 'https://www.facebook.com/raphael.ramos.524',
       description     = 'impressor de listas dentro de listas',
       )
