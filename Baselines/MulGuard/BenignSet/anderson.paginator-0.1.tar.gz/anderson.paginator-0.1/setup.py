from distutils.core import setup

setup(
    name='anderson.paginator',
    version='0.1',
    packages=['anderson_paginator'],
    url='https://bitbucket.org/jochangmin/mket-paginator',
    license='MIT',
    author='Anderson Jo',
    author_email='a141890@gmail.com',
    description=''
)
