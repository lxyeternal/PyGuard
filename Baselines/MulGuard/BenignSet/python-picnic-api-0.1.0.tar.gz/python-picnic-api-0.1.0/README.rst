python_picnic_api
=================

python wrapper around the Picnic API