import pytest


@pytest.fixture
def map():
    return {'one': 1, 'two': 2, 'three': 3}
