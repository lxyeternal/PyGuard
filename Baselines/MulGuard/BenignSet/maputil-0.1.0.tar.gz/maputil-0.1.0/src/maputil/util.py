from sequtil.api_generics import is_generic, copy_docstrings

is_generic = is_generic
copy_docstrings = copy_docstrings
