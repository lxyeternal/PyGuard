__all__ = ['FlightLabsClient']

from real_time_flights_api.client  import FlightLabsClient