"""Provide crypto payment essential to the drf-shop"""

__version__ = "0.1.0"
