from django.apps import AppConfig


class DrfCryptoConfig(AppConfig):
    default_auto_field = "django.db.models.BigAutoField"
    name = "drf_crypto"
