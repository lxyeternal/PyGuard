Openshift SDK python
包名为：openshiftx
