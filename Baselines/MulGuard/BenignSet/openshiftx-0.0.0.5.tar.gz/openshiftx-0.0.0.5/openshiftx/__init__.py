# -*- coding: utf-8 -*-
"""
-------------------------------------------------
   File Name：     __init__.py
   Description :
   Author :       潘晓华
   date：          2018/7/3
-------------------------------------------------
"""


class Object(object):
    def __init__(self):
        pass


if __name__ == '__main__':
    pass