# -*- coding: utf-8 -*-


class DirectoryException(Exception):
    pass


class DirectoryValidationException(Exception):
    pass
