SL for python
--------------

python version 3.5
===================

`Github repo <https://github.com/linnil1/sl>`_

This is modify from 
`https://github.com/mtoyoda/sl <https://github.com/mtoyoda/sl>`_


How to use it
-------------

>>> import time
>>> for i in slpy.sl(columns,rows,arg="-F"):
>>>   print(i)
>>>   time.sleep(0.04)

If you want to see argument 

you can type ``man sl`` if you install ``sl`` on your command line

