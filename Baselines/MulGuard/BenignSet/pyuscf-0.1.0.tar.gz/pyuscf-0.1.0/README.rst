The Unofficial USCF Member Service Area (MSA) API.

The United States Chess Federation (USCF) website for publicly available
chess member information. The package is nothing more than a client, but there
are some limitations on searching for chess members' information.

Visit www.uschess.org for further information on the limitations.