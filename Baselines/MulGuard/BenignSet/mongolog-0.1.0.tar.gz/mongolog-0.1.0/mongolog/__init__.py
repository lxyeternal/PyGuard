# -*- coding: utf-8 *-*
__author__ = 'Andrei Savu <contact@andreisavu.ro>'
__version__ = (0, 1, 0)
__maintainer__ = 'Jorge Puente Sarrín <puentesarrin@gmail.com>'
