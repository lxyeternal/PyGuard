class clien:
    web = {
        "app_name": "Main",
        "app_version": "4.1.11",
        "platform": "Web",
        "package": "web.rubika.ir",
        "lang_code": "fa"
    }

    android = {
        "app_name": "Main",
        "app_version": "3.0.9",
        "platform": "Android",
        "package": "ir.resaneh1.iptv",
        "lang_code": "fa"
    }