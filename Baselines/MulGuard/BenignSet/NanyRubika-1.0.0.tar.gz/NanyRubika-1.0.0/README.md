#Nanymous

How to import Nany's library is as follows:

<< from NanyRubika.client import Nanybot >>

An example:

from NanyRubika.client import Nanybot

bot = Nanybot("Your Auth Account")


Made by Team Nanymous

Address of our team's GitHub :

https://github.com/Nanymous/NanyRubika.git