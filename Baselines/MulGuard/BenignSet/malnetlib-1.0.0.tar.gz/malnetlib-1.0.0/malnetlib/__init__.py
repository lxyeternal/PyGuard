from pythonnet import load
load("coreclr")

import clr
clr.AddReference("dnlib")