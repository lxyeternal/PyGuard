# DALEX
moDel Agnostic Language for Exploration and eXplanation
https://ModelOriented.github.io/DALEX/

# Installation

```
git clone https://github.com/hbaniecki/dalex.git
pip install .
```
