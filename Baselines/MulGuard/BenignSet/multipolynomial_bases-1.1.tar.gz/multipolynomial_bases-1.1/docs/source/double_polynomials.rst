.. nodoctest

Double Polynomials
===================

.. automodule:: multipolynomial_bases.double_multivariate_polynomials
   :members:
   :undoc-members:
   :show-inheritance:
