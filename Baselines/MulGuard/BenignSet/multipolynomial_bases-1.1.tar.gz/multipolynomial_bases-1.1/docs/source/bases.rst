.. nodoctest

Main Polynomial bases
=====================

.. automodule:: multipolynomial_bases.bases
   :members:
   :undoc-members:
   :show-inheritance:

