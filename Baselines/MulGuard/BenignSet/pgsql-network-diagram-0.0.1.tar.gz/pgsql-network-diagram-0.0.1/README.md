# pgsql-network-diagram
Parses SQL and builds an interactive table relational diagram using vis.js. Built on sqlparse and focused on PostgreSQL.
https://github.com/juglaz/pgsql-network-diagram