# coding: utf-8
"""
    tests.ext
    ~~~~~~~~~

    The package contains tests for standard extensions.

    :copyright: (c) 2014 by the Holocron Team, see AUTHORS for details.
    :license: 3-clause BSD, see LICENSE for details.
"""
