# coding: utf-8
"""
    tests.ext.commands
    ~~~~~~~~~~~~~~~~~~

    The package contains tests for standard commands.

    :copyright: (c) 2015 by the Holocron Team, see AUTHORS for details.
    :license: 3-clause BSD, see LICENSE for details.
"""
