# coding: utf-8
"""
    tests.ext.generators
    ~~~~~~~~~~~~~~~~~~~~

    The package contains tests for holocron generators.

    :copyright: (c) 2014 by the Holocron Team, see AUTHORS for details.
    :license: 3-clause BSD, see LICENSE for details.
"""
