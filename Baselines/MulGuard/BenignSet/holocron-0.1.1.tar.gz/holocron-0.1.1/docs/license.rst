.. _license:

License
=======

Holocron is licensed under a three clause BSD License. That means
do whatever you want with it as long as the copyright in Holocron
sticks around.

.. include:: ../LICENSE
