=====================================
 Holocron: may the blog be with you!
=====================================

|travis-ci|  |coveralls|

Holocron is an extendable static blog generator powered by the Force. Like
others, it reads text files in various formats, renders them using templates
and produces a ready-to-publish static website which could be served by
Nginx or another web server. Unlike others, it tries to retrieve as many
information as possible from the filesystem. Its core follows the KISS
principle and any wheel reinventions were avoided during the process.

Feel the Force? Then use Holocron!

.. code:: bash

    $ [sudo] pip install holocron


Features
~~~~~~~~

Here is an incomplete list of features:

* Supports `Markdown`_ code syntax highlighting.
* Provides simple & powerful plugin system.
* Supports third-party themes via `Jinja2`_ templates.
* Generates both `Atom feed`_ and `sitemap.xml`_.
* Has clear and 100% mobile responsive default theme.
* Supports `Google Analytics`_ & `Yandex.Metrika`_ counters.
* Has SEO friendly URLs.
* Provides a debug server to preview content.

Check out Holocron's documentation for further information -
https://holocron.readthedocs.org/.


Why The Name Holocron?
~~~~~~~~~~~~~~~~~~~~~~

Holocron (*short for holographic chronicle*) is a device in which Jedi
stored different data. In most cases, they used it as diary.


.. Links

.. _Markdown: http://daringfireball.net/projects/markdown/
.. _Jinja2: http://jinja.pocoo.org
.. _Atom feed: http://en.wikipedia.org/wiki/Atom_(standard)
.. _sitemap.xml: http://www.sitemaps.org/
.. _Google Analytics: http://www.google.com/analytics/
.. _Yandex.Metrika: https://metrica.yandex.com/

.. Images

.. |travis-ci| image::
       https://travis-ci.org/ikalnitsky/holocron.svg?branch=master
   :target: https://travis-ci.org/ikalnitsky/holocron
   :alt: Travis CI: continuous integration status

.. |coveralls| image::
       https://coveralls.io/repos/ikalnitsky/holocron/badge.png?branch=master
   :target: https://coveralls.io/r/ikalnitsky/holocron?branch=master
   :alt: Coverall: code coverage status
