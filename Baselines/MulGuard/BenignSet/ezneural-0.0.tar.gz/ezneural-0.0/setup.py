from setuptools import setup

setup(name='ezneural',
      version='0.0',
      description='Gaussian and Binomial distributions',
      packages=['ezneural'],
      author_email='kimka230510@gmail.com',
      zip_safe=False)