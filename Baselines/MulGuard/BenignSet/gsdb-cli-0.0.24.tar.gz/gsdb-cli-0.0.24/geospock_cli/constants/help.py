# Copyright (c) 2014-2021 GeoSpock Ltd.

flag_ca_cert_file = "Optional location of the certificate for your deployment CA."
flag_disable_verification = "Disable verification of endpoint certification."
flag_password = "Optional password. If not provided, you will be asked to enter one when issuing a command requiring authentication."
