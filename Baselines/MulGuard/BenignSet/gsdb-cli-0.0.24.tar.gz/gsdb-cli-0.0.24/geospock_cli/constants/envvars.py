# Copyright (c) 2014-2021 GeoSpock Ltd.

endpoint = 'GEOSPOCK_ENDPOINT'
user_password = 'GEOSPOCK_PASSWORD'
user_name = 'GEOSPOCK_USER'
ca_cert_file = 'GEOSPOCK_CA_CERT_FILE'
