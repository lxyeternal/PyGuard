# Copyright (c) 2014-2021 GeoSpock Ltd.

endpoint_port = 443
