# github-stats-pages
Retrieve statistics for a user's repositories and populate the information onto a GitHub static page
