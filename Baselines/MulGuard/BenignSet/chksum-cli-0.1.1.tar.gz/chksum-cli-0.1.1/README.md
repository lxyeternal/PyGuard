# chksum
CLI for comparing two check sums
