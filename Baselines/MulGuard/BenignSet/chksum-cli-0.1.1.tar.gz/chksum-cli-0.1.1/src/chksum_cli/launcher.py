# Copyright (c) 2022, espehon
# All rights reserved.

#  This file is used to launch chksum's non-CLI version

from chksum import stand_alone

if __name__ == "__main__":
    stand_alone()