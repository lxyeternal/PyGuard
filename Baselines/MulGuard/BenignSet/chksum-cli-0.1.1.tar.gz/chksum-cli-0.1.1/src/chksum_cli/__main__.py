# Copyright (c) 2022, espehon
# All rights reserved.

#  This file is used as the entry point for chksum
import sys

from chksum.chksum import cli

if __name__ == "__main__":
    sys.exit()