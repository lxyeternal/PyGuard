FireCloud-GDC Tools
====================

A python project containing utilities for integrating FireCloud with
the NIH/NCI Genomics Data Commons.  Initially we provide tools for
creating FireCloud workspace load files from a file manifest downloaded
from the GDC.

----

To do:

- project overview
- basic usage examples
- what's new section

