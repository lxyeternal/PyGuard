# gpam-stfdigital-client

A package with all custom client necessary for setup a service in stfdigital architecture