#!/usr/bin/python3
# -*- coding: UTF-8 -*-

from . import ccat

if __name__ == "__main__":
    ccat.run()