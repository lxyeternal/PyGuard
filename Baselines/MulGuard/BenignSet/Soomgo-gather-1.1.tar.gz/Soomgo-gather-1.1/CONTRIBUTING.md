# Contributing to _Soomgo-gather_

TODO::작성해야함

Contributors
------------

Paul Cho, 2021/11/11
Rosa Kim, 2021/11/23