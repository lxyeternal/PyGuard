# shuriken

[![Build Status](https://travis-ci.com/ChrisTimperley/shuriken.svg?token=NEepgzkwf1KGUTphtdZ4&branch=master)](https://travis-ci.com/ChrisTimperley/shuriken)
