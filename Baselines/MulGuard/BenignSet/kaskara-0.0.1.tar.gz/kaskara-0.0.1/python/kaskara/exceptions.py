class BondException(Exception):
    pass
