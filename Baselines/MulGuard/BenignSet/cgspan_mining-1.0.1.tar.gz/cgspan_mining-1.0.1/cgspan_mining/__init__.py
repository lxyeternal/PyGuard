from __future__ import absolute_import
from __future__ import division
from __future__ import print_function

from .cgspan import cgSpan


__version__ = '0.2.2'
