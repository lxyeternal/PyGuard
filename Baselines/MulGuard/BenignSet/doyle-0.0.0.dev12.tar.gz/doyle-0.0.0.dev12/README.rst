Description
===========
pass

Installation
============
.. code-block:: bash
    pip install doyle

Usage
=====
.. code-block:: bash
    >>> import doyle
    >>> doyle.DataExplorer.explore_files("./data")
