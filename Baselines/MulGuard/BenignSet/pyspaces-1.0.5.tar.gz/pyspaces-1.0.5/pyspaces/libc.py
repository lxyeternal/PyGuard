#!/usr/bin/env python
# coding=utf-8


from ctypes import *


libc = CDLL("libc.so.6")
"""Import libc.so.6 as libc"""
