__version__ = 'v0.1.0'
__author__ = 'Nathan Henrie'
__email__ = 'nate@n8henrie.com'
