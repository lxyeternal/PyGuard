sci-package
===========

A collection of functions used in scientific computing
