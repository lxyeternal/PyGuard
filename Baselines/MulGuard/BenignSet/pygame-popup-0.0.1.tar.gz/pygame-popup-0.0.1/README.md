# Pygame Popup Manager

Pygame Popup Manage is a very small engine permitting to easily build all kind of popup in a pygame project.

Here is an example of basic menus that could be created with this manager:

![Main menu with side menu](https://github.com/Grimmys/pygame_popup_manager/blob/main/screenshots/main_menu_with_side_menu.png)

# Installation


# Use


# Customization

Unfortunatelly, the customization is limited for the moment.

But you can still provide your own graphical assets to the components, as you can see in the screenshot below.

![Options menu with assets](https://github.com/Grimmys/pygame_popup_manager/blob/main/screenshots/options_menu_with_assets.png)

# Contact

You can contact me directly by [e-mail](mailto:grimmys.programming@gmail.com?subject=[GitHub]%20Pygame%20Popup%20Manager) if you have any question regarding the package.
Also, I will be really happy to know you are using this package, so don't hesitate to share me the link to your project if you tried something!

For suggestions or bugs, please create an issue in the GitHub repository: https://github.com/Grimmys/pygame_popup_manager/issues

Thanks!
