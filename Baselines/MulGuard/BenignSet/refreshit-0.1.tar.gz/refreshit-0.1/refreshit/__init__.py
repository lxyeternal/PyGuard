from .refreshit import *

__title__ = 'refreshit'
__description__ = 'A print which can be refreshed'
__url__ = 'https://github.com/estevaofon/refreshit'
__version__ = '0.1'
__author__ = 'Estevao Fonseca'
__license__ = 'MIT'
