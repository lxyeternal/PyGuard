from setuptools import setup


setup(
    name='rootconfig',
    version='0.1.0',
    author='Hanzhi Yin',
    author_email='yinhanzhi@gmail.com',
    where='rootconfig'
)
