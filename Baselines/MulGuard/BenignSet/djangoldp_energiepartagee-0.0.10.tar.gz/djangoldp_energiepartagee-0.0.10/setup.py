#!/usr/bin/env python

"""Setup script."""

from setuptools import setup
setup()
