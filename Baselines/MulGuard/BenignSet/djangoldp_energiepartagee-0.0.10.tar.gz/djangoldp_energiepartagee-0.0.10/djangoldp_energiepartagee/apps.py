from django.apps import AppConfig


class DjangoldEnergiepartageeConfig(AppConfig):
    name = 'djangoldp_energiepartagee'
