========
Usage
========

To use jupyter-forward in a project::

	import jupyter_forward
