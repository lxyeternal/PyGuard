
.. include:: ../../CONTRIBUTING.rst
