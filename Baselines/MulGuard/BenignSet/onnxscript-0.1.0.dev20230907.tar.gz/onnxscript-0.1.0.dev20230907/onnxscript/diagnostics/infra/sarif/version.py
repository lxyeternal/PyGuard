from typing import Final

SARIF_VERSION: Final = "2.1.0"
SARIF_SCHEMA_LINK: Final = (
    "https://docs.oasis-open.org/sarif/sarif/v2.1.0/cs01/schemas/sarif-schema-2.1.0.json"
)
# flake8: noqa
