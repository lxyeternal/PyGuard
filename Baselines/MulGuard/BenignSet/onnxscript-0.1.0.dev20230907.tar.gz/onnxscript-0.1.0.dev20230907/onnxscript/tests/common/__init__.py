"""Shared components for testing."""
