import sys
import os
import ComPP
from .ComPP import main

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))