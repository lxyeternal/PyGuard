from .api import Xero

NUM_VERSION = (0, 5, 0)
VERSION = ".".join(str(nv) for nv in NUM_VERSION)
