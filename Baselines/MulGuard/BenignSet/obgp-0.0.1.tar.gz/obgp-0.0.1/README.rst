# sequencer
A collection of tasks for sequencing and fingerprinting book fulltext
