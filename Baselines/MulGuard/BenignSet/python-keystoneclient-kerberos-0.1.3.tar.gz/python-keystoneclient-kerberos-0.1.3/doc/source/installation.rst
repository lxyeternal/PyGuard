============
Installation
============

At the command line::

    $ pip install python-keystoneclient-kerberos

Or, if you have virtualenvwrapper installed::

    $ mkvirtualenv python-keystoneclient-kerberos
    $ pip install python-keystoneclient-kerberos