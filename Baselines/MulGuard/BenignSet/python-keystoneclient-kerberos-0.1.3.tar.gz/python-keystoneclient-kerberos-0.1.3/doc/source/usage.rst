========
Usage
========

To use python-keystoneclient-kerberos in a project::

    import keystoneclient_kerberos