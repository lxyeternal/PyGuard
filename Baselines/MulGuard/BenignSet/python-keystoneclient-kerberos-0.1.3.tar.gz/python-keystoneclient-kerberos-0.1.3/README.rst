===============================
python-keystoneclient-kerberos
===============================

Kerberos authentication for the OpenStack clients

* Free software: Apache license
* Documentation: http://docs.openstack.org/developer/python-keystoneclient-kerberos
* Source: http://git.openstack.org/cgit/openstack/python-keystoneclient-kerberos
* Bugs: http://bugs.launchpad.net/python-keystoneclient

Features
--------

* TODO