.. :changelog:

History
-------

1.0.0 (2013-12-03)
++++++++++++++++++

* First release on PyPI.
