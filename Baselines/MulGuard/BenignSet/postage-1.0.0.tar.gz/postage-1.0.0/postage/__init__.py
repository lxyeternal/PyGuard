#!/usr/bin/env python
# -*- coding: utf-8 -*-

from __future__ import absolute_import

__author__ = 'Leonardo Giordani'
__email__ = 'giordani.leonardo@gmail.com'
__version__ = '1.0.0'

from postage import messaging
