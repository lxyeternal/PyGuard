.. automodule:: WebPlot
	:members:
	:undoc-members:
	:show-inheritance: