# main.py
"""Main fail of PAK UNIOR EEG WEBPlotter"""

from PlotDynamicUpdate import PlotDynamicUpdate

d = PlotDynamicUpdate()

d()
