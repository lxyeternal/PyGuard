"""Louie version information."""


NAME = 'Louie-latest'
DESCRIPTION = 'Signal dispatching mechanism'
VERSION = '1.2a1'


