"""Questions about the core Python language.

https://docs.python.org/3.6/reference/index.html
"""
__all__ = ["compound_statements"]