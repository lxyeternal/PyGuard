"""Questions about compound statements.

https://docs.python.org/3.6/reference/compound_stmts.html
"""