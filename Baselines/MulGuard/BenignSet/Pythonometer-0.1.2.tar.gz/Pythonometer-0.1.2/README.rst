Pythonometer
============

*A tool for measuring and improving Python skills*

What is Pythonometer?
---------------------

Pythonometer is tool for measuring how good someone is at Python.

The goal of this project is to have a comprehensive set of code
questions covering all areas of Python, so that a Pythonometer score
will accurately represent how good someone is at python, and that anyone
practicing for the sake of getting a good score will actually become
very good at coding in Python.

Status
------

This project is currently at prototype stage, with just a small number
of questions.
