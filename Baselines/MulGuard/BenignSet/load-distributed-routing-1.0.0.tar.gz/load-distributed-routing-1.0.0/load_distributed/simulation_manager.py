

class SimulationManager():
    """
    Allows nodes to end the simualtion when a node goes offline
    """
    def __init__(self):
        self.sim_running = True
