Introduction
============



If both products plone.app.discussion and Products.PloneGazette are installed 
the creation of any PloneGazette contenttype fails, because PloneGazette 
contenttypes not provide the adapter for a particular interface.

This product makes possible the creation of the PloneGazette contenttypes
if there is an installation of plone.app.discussion in your instance.