from zope.interface import Interface

class INewsletter(Interface):
    """ 
    """
    
class ISubscriber(Interface):
    """ 
    """
    
class ISection(Interface):
    """ 
    """