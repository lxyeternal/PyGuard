# ScanlationGroupResponse

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**result** | **str** |  | [optional] 
**data** | [**ScanlationGroup**](ScanlationGroup.md) |  | [optional] 
**relationships** | [**list[ScanlationGroupResponseRelationships]**](ScanlationGroupResponseRelationships.md) |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

