# CheckResponse

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**ok** | **str** |  | [optional] 
**is_authenticated** | **bool** |  | [optional] 
**roles** | **list[str]** |  | [optional] 
**permissions** | **list[str]** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

