# AuthorList

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**results** | [**list[AuthorResponse]**](AuthorResponse.md) |  | [optional] 
**limit** | **int** |  | [optional] 
**offset** | **int** |  | [optional] 
**total** | **int** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

