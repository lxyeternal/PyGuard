# ChapterRequest

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**title** | **str** |  | [optional] 
**volume** | **str** |  | [optional] 
**chapter** | **str** |  | [optional] 
**translated_language** | **str** |  | [optional] 
**data** | **list[str]** |  | [optional] 
**data_saver** | **list[str]** |  | [optional] 
**version** | **int** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

