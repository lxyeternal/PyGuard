from .__meta__ import version as __version__

from .custom_template import MY_DIR, ThemeTemplates
