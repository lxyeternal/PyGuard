=======
Credits
=======

Development Lead
----------------
* SatelliteQE Team

Contributors
------------

* Bruno Rocha <rochacbruno@gmail.com>
