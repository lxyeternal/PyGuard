from flask_gulp.static import Static
from flask_gulp.extensions import extension
