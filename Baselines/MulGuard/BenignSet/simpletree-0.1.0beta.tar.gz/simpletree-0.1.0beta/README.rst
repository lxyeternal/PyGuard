Simpletree
==========

Fastest and simplest tree implementation for Django framework.
