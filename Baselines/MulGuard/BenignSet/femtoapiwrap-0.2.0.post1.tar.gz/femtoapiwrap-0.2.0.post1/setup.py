from setuptools import setup

# Please do not add more here -- this project is configured via setup.cfg.
setup()
