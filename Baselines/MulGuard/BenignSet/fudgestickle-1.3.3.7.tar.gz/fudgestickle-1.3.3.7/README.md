# Fudgestickle

A python package to get an update of the "This means war" contest table at the beta program wikiversity site.

## usage

The following query on the terminal will provide you an update of the "This means war" contest table at the beta program wikiversity site according to the current state of the contest.

```
fudgestickle
```