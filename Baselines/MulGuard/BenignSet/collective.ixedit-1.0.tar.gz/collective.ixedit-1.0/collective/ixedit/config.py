"""Common configuration constants
"""

PROJECTNAME = 'collective.ixedit'

ADD_PERMISSIONS = {
    # -*- extra stuff goes here -*-

}
