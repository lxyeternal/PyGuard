Introduction
============

This product integrated IXEdit (http://www.ixedit.com/) into Plone.

Install this product and ure good to go. If theres css issues on
the ixedit widget, try enabling debugging mode in portal_css.

More details of using IXEdit is in http://www.ixedit.com/userguide
