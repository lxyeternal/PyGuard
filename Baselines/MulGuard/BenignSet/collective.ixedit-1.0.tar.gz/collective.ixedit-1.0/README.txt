This product added IXEdit (http://www.ixedit.com) into Plone for aiding rich Javascript effects development on plone
