from .core import *

__version_num__ = (0, 7, 0)
__version__ = ".".join(map(str, __version_num__))

__author__ = "Mateo Contenla"
__credits__ = ["Sebastián Henríquez O."]
