"Main interface for acm service"

from mypy_boto3_acm.client import Client

__all__ = ("Client",)
