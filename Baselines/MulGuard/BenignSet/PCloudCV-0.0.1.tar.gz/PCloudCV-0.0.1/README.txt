=======================
CloudCV - Python API's
=======================

These are the python APIs for CloudCV: Large Scale Distributed Computer Vision as a Cloud Service.
Using this package will require a config file that can be downloaded from 
https://github.com/batra-mlp-lab/pcloudcv/blob/master/pcloudcv/config.json

Wiki(Documentation):  
https://github.com/batra-mlp-lab/pcloudcv/wiki

