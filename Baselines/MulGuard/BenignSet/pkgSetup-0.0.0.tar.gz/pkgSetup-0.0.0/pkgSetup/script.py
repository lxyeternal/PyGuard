#!/bin/python3
import os
from time import ctime

def test():
    print('balls')

