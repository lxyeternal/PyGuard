运行  sh run.sh

环境依赖： pytz(处理时区)
环境依赖： py_zipkin(链路追踪)
环境依赖： kafka(写入日志到kafka)
