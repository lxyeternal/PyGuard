Example Project
===============
This is an example project that is used to demonstrate how to publish
Python packages on PyPI. 

Installing
============

.. code-block:: bash

    pip install r00auth

Usage
=====

.. code-block:: bash

    UNKNOWN