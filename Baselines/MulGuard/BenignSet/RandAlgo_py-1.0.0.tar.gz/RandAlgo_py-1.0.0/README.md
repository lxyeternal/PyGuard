#Weather Reporter

A Python package that fetches random algorithm questions from the internet

#Usage
 Following query on terminal will provide algorithm questions when you
 register and login 
 
```buildoutcfg
Randalgo_cli -q 
```