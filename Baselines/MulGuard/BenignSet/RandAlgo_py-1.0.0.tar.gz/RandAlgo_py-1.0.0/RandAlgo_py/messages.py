message1 = 'login succesful'
message2 = 'login not successful please try again'
mesage3 = 'invalid response, respond with 1, or 2'
message4 = 'invalid response, respond with 1, 2, or 3'


def message_log(message):
    '''
This functions prints all types of messages in our app ranging from error messages
to welcome meassages'''
    print(message)
    return message


