from setuptools import setup, find_packages

setup(name='izh2143',
      version='0.0',
      description='Numerical methods',
      packages=find_packages(),
      author_email='ustinovkirill23@gmail.com',
      zip_safe=False,
      )