Tools & utilities used during suds development.

Only stand-alone scripts should be located in this folder. Any imported
additional modules should be located under the suds_devel package folder.

All Python scripts under this folder should be prepared so their sources are
directly compatible with both Python 2.x & 3.x without the need for any py2to3
based source code transformation.
