#!/usr/bin/env python
# -*- coding: utf-8 -*-

"""
test_nshowrss
----------------------------------

Tests for `nshowrss` module.
"""

import unittest

from nshowrss import nshowrss


class TestNshowrss(unittest.TestCase):

    def setUp(self):
        pass

    def test_something(self):
        pass

    def tearDown(self):
        pass

if __name__ == '__main__':
    unittest.main()
