========
Usage
========

To use ShowRss.info ncurses interface in a project::

    import nshowrss
