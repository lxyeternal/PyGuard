============
Installation
============

At the command line::

    $ easy_install nshowrss

Or, if you have virtualenvwrapper installed::

    $ mkvirtualenv nshowrss
    $ pip install nshowrss
