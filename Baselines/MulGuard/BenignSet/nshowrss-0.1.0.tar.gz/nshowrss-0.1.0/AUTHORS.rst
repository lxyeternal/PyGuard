=======
Credits
=======

Development Lead
----------------

* David Francos Cuartero <me@davidfrancos.net>

Contributors
------------

None yet. Why not be the first?
