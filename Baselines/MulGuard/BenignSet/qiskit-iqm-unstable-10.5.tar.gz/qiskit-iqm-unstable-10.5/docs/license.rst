.. _license:

=======
License
=======

.. include:: ../LICENSE
   :literal:
