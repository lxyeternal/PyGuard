""" Initialize version number (__version__). """
from corrscope.version import get_version


app_name = "corrscope"
__version__ = get_version()
