# led-cube-view
A PySide6 widget to display a LED cube on a 3D graph and manipulate its LEDs.
This is being developed for use with my [LED cube animation editor](https://github.com/crash8229/led-cube-animation-editor).
