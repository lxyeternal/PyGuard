# ferveo

## Benchmarks

### Benchmarking primitives size

```sh
cargo run --example bench_primitives_size
```
