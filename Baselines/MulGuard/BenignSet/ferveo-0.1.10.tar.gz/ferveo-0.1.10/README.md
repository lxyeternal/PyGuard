# Python bindings for `ferveo`

## Build

You will need to have `setuptools-rust` installed. Then, for development, you can just do `pip install -e .` as usual.

## Publish

```bash
maturin build --release
maturin publish
```
