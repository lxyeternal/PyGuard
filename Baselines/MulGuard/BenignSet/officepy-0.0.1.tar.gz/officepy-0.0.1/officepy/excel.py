import requests

class Workbook:
    def test(self):
        print("Test")


def getWorkbook() -> Workbook:
    return Workbook()

