import examplepackagefb1258.wisdom as wisdom


def main():
  line = wisdom.get()
  print(line)

if __name__ == '__main__':
    main()

