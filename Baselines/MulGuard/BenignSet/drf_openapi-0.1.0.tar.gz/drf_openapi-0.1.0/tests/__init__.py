# -*- coding: utf-8 -*-

"""Unit test package for drf_openapi."""
