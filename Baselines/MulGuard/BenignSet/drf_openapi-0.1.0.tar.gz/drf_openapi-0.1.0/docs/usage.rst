=====
Usage
=====

To use DRF OpenAPI in a project::

    import drf_openapi
