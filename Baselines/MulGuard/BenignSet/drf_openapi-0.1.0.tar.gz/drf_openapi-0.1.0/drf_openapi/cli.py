# -*- coding: utf-8 -*-

"""Console script for drf_openapi."""

import click


@click.command()
def main(args=None):
    """Console script for drf_openapi."""
    click.echo("Replace this message by putting your code into "
               "drf_openapi.cli.main")
    click.echo("See click documentation at http://click.pocoo.org/")


if __name__ == "__main__":
    main()
