# -*- coding: utf-8 -*-

"""Top-level package for DRF OpenAPI."""

__author__ = """Lim H."""
__email__ = 'limdauto@gmail.com'
__version__ = '0.1.0'
