from ._bol import query

__version__ = '1.0.0'

__plugin_main_language__ = 'en'
__plugin_service_name__ = 'bol'
__plugin_type__ = 'metadata'
