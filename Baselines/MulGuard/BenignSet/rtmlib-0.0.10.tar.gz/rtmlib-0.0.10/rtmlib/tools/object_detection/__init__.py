from .rtmdet import RTMDet
from .yolox import YOLOX

__all__ = ['RTMDet', 'YOLOX']
