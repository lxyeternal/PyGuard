from distutils.core import setup

setup(
    name = 'newworld',
    version = '1.0.0',
    py_modules = ['newworld'],
    author = 'vb',
    author_email = 'vitali.baranov@gmail.com',
    url = 'http://www.headfirstlabs.com',
    description = 'A simple printer of phrase'
    )
