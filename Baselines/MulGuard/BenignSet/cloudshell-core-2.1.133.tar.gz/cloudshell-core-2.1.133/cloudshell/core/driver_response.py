class DriverResponse(object):
    def __init__(self):
        self.actionResults = []

