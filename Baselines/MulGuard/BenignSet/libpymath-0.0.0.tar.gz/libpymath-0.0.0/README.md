
# Pygon
### A fast, general purpose Python library
---

## Install
1. Run ```pip install pygon``` to dowload and install Pygon
2. For the latest release, type ```pip install pygon==1.0.0```

---

## Features and usage
Currently there is only one feature -- run a system command from within Python
To use it, import the ```pygon.testModule``` module and run ```testModule.system(<your command>)``` to run the system command.
