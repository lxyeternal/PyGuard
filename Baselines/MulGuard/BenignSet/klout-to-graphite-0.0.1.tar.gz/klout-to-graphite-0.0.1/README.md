# Klout to Graphite

A tool to send Klout scores to Graphite

## Usage

    export  KLOUT_KEY="YOUR KLOUT KEY"
    cat twitter_usernames.txt | klout_to_graphite --graphite-host graphite.seatgeek.com
