from distutils.core import setup

setup(
	name			= 'listlooper',
	version 		= '1.1.0',
	py_modules 		= ['listlooper'],
	author 			= 'Ben Pinter',
	author_email		= 'N/A',
	url			= 'N/A',
	discription 		= 'A simple nested list printer',
     )
