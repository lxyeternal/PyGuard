# Generated from ./aslutils/ASL.g4 by ANTLR 4.5.3
# encoding: utf-8
from antlr4 import *
from io import StringIO

def serializedATN():
    with StringIO() as buf:
        buf.write("\3\u0430\ud6d1\u8206\uad2d\u4417\uaef1\u8d80\uaadd\3\\")
        buf.write("\u017c\4\2\t\2\4\3\t\3\4\4\t\4\4\5\t\5\4\6\t\6\4\7\t\7")
        buf.write("\4\b\t\b\4\t\t\t\3\2\7\2\24\n\2\f\2\16\2\27\13\2\3\3\3")
        buf.write("\3\3\3\3\3\3\3\3\3\3\3\3\3\3\3\7\3\"\n\3\f\3\16\3%\13")
        buf.write("\3\3\3\3\3\5\3)\n\3\3\3\3\3\3\3\3\3\3\3\3\3\3\3\5\3\62")
        buf.write("\n\3\3\3\7\3\65\n\3\f\3\16\38\13\3\3\3\3\3\5\3<\n\3\3")
        buf.write("\3\3\3\3\3\3\3\3\3\3\3\3\3\3\3\5\3F\n\3\3\3\3\3\3\3\3")
        buf.write("\3\3\3\3\3\3\3\3\3\3\3\3\3\3\3\3\3\3\3\3\3\3\3\5\3W\n")
        buf.write("\3\5\3Y\n\3\3\4\3\4\3\4\3\4\3\4\3\4\3\4\3\4\3\4\3\4\3")
        buf.write("\4\3\4\3\4\3\4\3\4\3\4\3\4\3\4\3\4\3\4\3\4\7\4p\n\4\f")
        buf.write("\4\16\4s\13\4\3\4\3\4\3\4\5\4x\n\4\3\4\3\4\3\4\3\4\7\4")
        buf.write("~\n\4\f\4\16\4\u0081\13\4\3\4\3\4\3\4\5\4\u0086\n\4\3")
        buf.write("\4\5\4\u0089\n\4\3\4\3\4\3\4\3\4\3\4\3\4\3\4\3\4\3\4\3")
        buf.write("\4\7\4\u0095\n\4\f\4\16\4\u0098\13\4\5\4\u009a\n\4\3\4")
        buf.write("\3\4\5\4\u009e\n\4\3\5\3\5\6\5\u00a2\n\5\r\5\16\5\u00a3")
        buf.write("\3\5\3\5\3\5\7\5\u00a9\n\5\f\5\16\5\u00ac\13\5\3\5\5\5")
        buf.write("\u00af\n\5\3\6\3\6\3\6\3\6\3\6\3\6\3\6\3\6\3\6\3\6\3\6")
        buf.write("\3\6\3\6\3\6\3\6\7\6\u00c0\n\6\f\6\16\6\u00c3\13\6\3\6")
        buf.write("\3\6\3\6\3\6\3\6\3\6\3\6\3\6\3\6\3\6\3\6\7\6\u00d0\n\6")
        buf.write("\f\6\16\6\u00d3\13\6\5\6\u00d5\n\6\3\6\3\6\3\6\3\6\3\6")
        buf.write("\3\6\7\6\u00dd\n\6\f\6\16\6\u00e0\13\6\5\6\u00e2\n\6\3")
        buf.write("\6\3\6\3\6\3\6\3\6\3\6\3\6\5\6\u00eb\n\6\3\6\3\6\3\6\3")
        buf.write("\6\3\6\3\6\3\6\3\6\3\6\3\6\3\6\3\6\3\6\3\6\3\6\3\6\3\6")
        buf.write("\3\6\3\6\3\6\5\6\u0101\n\6\3\6\3\6\3\6\3\6\5\6\u0107\n")
        buf.write("\6\3\6\3\6\3\6\3\6\5\6\u010d\n\6\7\6\u010f\n\6\f\6\16")
        buf.write("\6\u0112\13\6\3\6\3\6\3\6\3\6\3\6\3\6\3\6\3\6\3\6\3\6")
        buf.write("\3\6\7\6\u011f\n\6\f\6\16\6\u0122\13\6\3\6\3\6\7\6\u0126")
        buf.write("\n\6\f\6\16\6\u0129\13\6\3\7\3\7\3\7\3\7\3\7\3\7\3\7\7")
        buf.write("\7\u0132\n\7\f\7\16\7\u0135\13\7\3\7\3\7\3\7\3\7\3\7\3")
        buf.write("\7\3\7\7\7\u013e\n\7\f\7\16\7\u0141\13\7\5\7\u0143\n\7")
        buf.write("\3\7\3\7\3\7\5\7\u0148\n\7\3\7\3\7\3\7\3\7\3\7\5\7\u014f")
        buf.write("\n\7\3\7\3\7\3\7\3\7\5\7\u0155\n\7\3\7\3\7\3\7\3\7\5\7")
        buf.write("\u015b\n\7\7\7\u015d\n\7\f\7\16\7\u0160\13\7\3\7\3\7\3")
        buf.write("\7\3\7\5\7\u0166\n\7\3\7\7\7\u0169\n\7\f\7\16\7\u016c")
        buf.write("\13\7\3\b\3\b\3\t\3\t\3\t\3\t\3\t\3\t\3\t\3\t\3\t\3\t")
        buf.write("\5\t\u017a\n\t\3\t\2\4\n\f\n\2\4\6\b\n\f\16\20\2\n\3\2")
        buf.write("\f\r\5\2\36\36>>FG\4\2\33\34DE\3\2FG\3\2HI\3\2\66;\5\2")
        buf.write("\35\35\37 <=\4\2SSUZ\u01c0\2\25\3\2\2\2\4X\3\2\2\2\6\u009d")
        buf.write("\3\2\2\2\b\u00ae\3\2\2\2\n\u00ea\3\2\2\2\f\u0147\3\2\2")
        buf.write("\2\16\u016d\3\2\2\2\20\u0179\3\2\2\2\22\24\5\4\3\2\23")
        buf.write("\22\3\2\2\2\24\27\3\2\2\2\25\23\3\2\2\2\25\26\3\2\2\2")
        buf.write("\26\3\3\2\2\2\27\25\3\2\2\2\30\31\7\3\2\2\31\32\5\n\6")
        buf.write("\2\32\33\7\4\2\2\33#\5\b\5\2\34\35\7\5\2\2\35\36\5\n\6")
        buf.write("\2\36\37\7\4\2\2\37 \5\b\5\2 \"\3\2\2\2!\34\3\2\2\2\"")
        buf.write("%\3\2\2\2#!\3\2\2\2#$\3\2\2\2$(\3\2\2\2%#\3\2\2\2&\'\7")
        buf.write("\6\2\2\')\5\b\5\2(&\3\2\2\2()\3\2\2\2)Y\3\2\2\2*+\7\7")
        buf.write("\2\2+,\5\n\6\2,-\7\b\2\2-\66\7\63\2\2.\61\7\t\2\2/\62")
        buf.write("\5\16\b\2\60\62\7T\2\2\61/\3\2\2\2\61\60\3\2\2\2\62\63")
        buf.write("\3\2\2\2\63\65\5\b\5\2\64.\3\2\2\2\658\3\2\2\2\66\64\3")
        buf.write("\2\2\2\66\67\3\2\2\2\67;\3\2\2\28\66\3\2\2\29:\7\n\2\2")
        buf.write(":<\5\b\5\2;9\3\2\2\2;<\3\2\2\2<=\3\2\2\2=>\7\64\2\2>Y")
        buf.write("\3\2\2\2?@\7\20\2\2@A\5\b\5\2AB\7\21\2\2BC\5\n\6\2CE\7")
        buf.write("R\2\2DF\7\65\2\2ED\3\2\2\2EF\3\2\2\2FY\3\2\2\2GH\7\16")
        buf.write("\2\2HI\5\n\6\2IJ\7\17\2\2JK\5\b\5\2KY\3\2\2\2LM\7\13\2")
        buf.write("\2MN\5\f\7\2NO\7K\2\2OP\5\n\6\2PQ\t\2\2\2QR\5\n\6\2RS")
        buf.write("\5\b\5\2SY\3\2\2\2TV\5\6\4\2UW\7\65\2\2VU\3\2\2\2VW\3")
        buf.write("\2\2\2WY\3\2\2\2X\30\3\2\2\2X*\3\2\2\2X?\3\2\2\2XG\3\2")
        buf.write("\2\2XL\3\2\2\2XT\3\2\2\2Y\5\3\2\2\2Z[\7\"\2\2[\u009e\7")
        buf.write("R\2\2\\]\7$\2\2]\u009e\7R\2\2^_\7&\2\2_`\5\n\6\2`a\7R")
        buf.write("\2\2a\u009e\3\2\2\2bc\7\'\2\2cd\7Z\2\2d\u009e\7R\2\2e")
        buf.write("f\7\23\2\2fg\5\n\6\2gh\7R\2\2h\u009e\3\2\2\2ij\7\25\2")
        buf.write("\2jk\7T\2\2kl\7N\2\2lq\7T\2\2mn\7P\2\2np\7T\2\2om\3\2")
        buf.write("\2\2ps\3\2\2\2qo\3\2\2\2qr\3\2\2\2rt\3\2\2\2sq\3\2\2\2")
        buf.write("tu\7O\2\2u\u009e\7R\2\2vx\7\26\2\2wv\3\2\2\2wx\3\2\2\2")
        buf.write("xy\3\2\2\2yz\5\20\t\2z\177\5\f\7\2{|\7P\2\2|~\5\f\7\2")
        buf.write("}{\3\2\2\2~\u0081\3\2\2\2\177}\3\2\2\2\177\u0080\3\2\2")
        buf.write("\2\u0080\u0082\3\2\2\2\u0081\177\3\2\2\2\u0082\u0083\7")
        buf.write("R\2\2\u0083\u009e\3\2\2\2\u0084\u0086\7\26\2\2\u0085\u0084")
        buf.write("\3\2\2\2\u0085\u0086\3\2\2\2\u0086\u0088\3\2\2\2\u0087")
        buf.write("\u0089\5\20\t\2\u0088\u0087\3\2\2\2\u0088\u0089\3\2\2")
        buf.write("\2\u0089\u008a\3\2\2\2\u008a\u008b\5\f\7\2\u008b\u008c")
        buf.write("\7K\2\2\u008c\u008d\5\n\6\2\u008d\u008e\7R\2\2\u008e\u009e")
        buf.write("\3\2\2\2\u008f\u0090\7T\2\2\u0090\u0099\7L\2\2\u0091\u0096")
        buf.write("\5\n\6\2\u0092\u0093\7P\2\2\u0093\u0095\5\n\6\2\u0094")
        buf.write("\u0092\3\2\2\2\u0095\u0098\3\2\2\2\u0096\u0094\3\2\2\2")
        buf.write("\u0096\u0097\3\2\2\2\u0097\u009a\3\2\2\2\u0098\u0096\3")
        buf.write("\2\2\2\u0099\u0091\3\2\2\2\u0099\u009a\3\2\2\2\u009a\u009b")
        buf.write("\3\2\2\2\u009b\u009c\7M\2\2\u009c\u009e\7R\2\2\u009dZ")
        buf.write("\3\2\2\2\u009d\\\3\2\2\2\u009d^\3\2\2\2\u009db\3\2\2\2")
        buf.write("\u009de\3\2\2\2\u009di\3\2\2\2\u009dw\3\2\2\2\u009d\u0085")
        buf.write("\3\2\2\2\u009d\u008f\3\2\2\2\u009e\7\3\2\2\2\u009f\u00a1")
        buf.write("\7\63\2\2\u00a0\u00a2\5\4\3\2\u00a1\u00a0\3\2\2\2\u00a2")
        buf.write("\u00a3\3\2\2\2\u00a3\u00a1\3\2\2\2\u00a3\u00a4\3\2\2\2")
        buf.write("\u00a4\u00a5\3\2\2\2\u00a5\u00a6\7\64\2\2\u00a6\u00af")
        buf.write("\3\2\2\2\u00a7\u00a9\5\6\4\2\u00a8\u00a7\3\2\2\2\u00a9")
        buf.write("\u00ac\3\2\2\2\u00aa\u00a8\3\2\2\2\u00aa\u00ab\3\2\2\2")
        buf.write("\u00ab\u00ad\3\2\2\2\u00ac\u00aa\3\2\2\2\u00ad\u00af\7")
        buf.write("\65\2\2\u00ae\u009f\3\2\2\2\u00ae\u00aa\3\2\2\2\u00af")
        buf.write("\t\3\2\2\2\u00b0\u00b1\b\6\1\2\u00b1\u00b2\7\3\2\2\u00b2")
        buf.write("\u00b3\5\n\6\2\u00b3\u00b4\7\4\2\2\u00b4\u00b5\5\n\6\2")
        buf.write("\u00b5\u00b6\7\6\2\2\u00b6\u00b7\5\n\6\2\u00b7\u00eb\3")
        buf.write("\2\2\2\u00b8\u00eb\5\16\b\2\u00b9\u00ba\7L\2\2\u00ba\u00bb")
        buf.write("\5\n\6\2\u00bb\u00bc\7P\2\2\u00bc\u00c1\5\n\6\2\u00bd")
        buf.write("\u00be\7P\2\2\u00be\u00c0\5\n\6\2\u00bf\u00bd\3\2\2\2")
        buf.write("\u00c0\u00c3\3\2\2\2\u00c1\u00bf\3\2\2\2\u00c1\u00c2\3")
        buf.write("\2\2\2\u00c2\u00c4\3\2\2\2\u00c3\u00c1\3\2\2\2\u00c4\u00c5")
        buf.write("\7M\2\2\u00c5\u00eb\3\2\2\2\u00c6\u00c7\7L\2\2\u00c7\u00c8")
        buf.write("\5\n\6\2\u00c8\u00c9\7M\2\2\u00c9\u00eb\3\2\2\2\u00ca")
        buf.write("\u00cb\7T\2\2\u00cb\u00d4\7L\2\2\u00cc\u00d1\5\n\6\2\u00cd")
        buf.write("\u00ce\7P\2\2\u00ce\u00d0\5\n\6\2\u00cf\u00cd\3\2\2\2")
        buf.write("\u00d0\u00d3\3\2\2\2\u00d1\u00cf\3\2\2\2\u00d1\u00d2\3")
        buf.write("\2\2\2\u00d2\u00d5\3\2\2\2\u00d3\u00d1\3\2\2\2\u00d4\u00cc")
        buf.write("\3\2\2\2\u00d4\u00d5\3\2\2\2\u00d5\u00d6\3\2\2\2\u00d6")
        buf.write("\u00eb\7M\2\2\u00d7\u00d8\7T\2\2\u00d8\u00e1\7B\2\2\u00d9")
        buf.write("\u00de\5\n\6\2\u00da\u00db\7P\2\2\u00db\u00dd\5\n\6\2")
        buf.write("\u00dc\u00da\3\2\2\2\u00dd\u00e0\3\2\2\2\u00de\u00dc\3")
        buf.write("\2\2\2\u00de\u00df\3\2\2\2\u00df\u00e2\3\2\2\2\u00e0\u00de")
        buf.write("\3\2\2\2\u00e1\u00d9\3\2\2\2\u00e1\u00e2\3\2\2\2\u00e2")
        buf.write("\u00e3\3\2\2\2\u00e3\u00eb\7C\2\2\u00e4\u00e5\t\3\2\2")
        buf.write("\u00e5\u00eb\5\n\6\f\u00e6\u00e7\5\20\t\2\u00e7\u00e8")
        buf.write("\7#\2\2\u00e8\u00eb\3\2\2\2\u00e9\u00eb\7T\2\2\u00ea\u00b0")
        buf.write("\3\2\2\2\u00ea\u00b8\3\2\2\2\u00ea\u00b9\3\2\2\2\u00ea")
        buf.write("\u00c6\3\2\2\2\u00ea\u00ca\3\2\2\2\u00ea\u00d7\3\2\2\2")
        buf.write("\u00ea\u00e4\3\2\2\2\u00ea\u00e6\3\2\2\2\u00ea\u00e9\3")
        buf.write("\2\2\2\u00eb\u0127\3\2\2\2\u00ec\u00ed\f\13\2\2\u00ed")
        buf.write("\u00ee\t\4\2\2\u00ee\u0126\5\n\6\f\u00ef\u00f0\f\n\2\2")
        buf.write("\u00f0\u00f1\t\5\2\2\u00f1\u0126\5\n\6\13\u00f2\u00f3")
        buf.write("\f\t\2\2\u00f3\u00f4\7A\2\2\u00f4\u0126\5\n\6\n\u00f5")
        buf.write("\u00f6\f\b\2\2\u00f6\u00f7\t\6\2\2\u00f7\u0126\5\n\6\t")
        buf.write("\u00f8\u00f9\f\7\2\2\u00f9\u00fa\t\7\2\2\u00fa\u0126\5")
        buf.write("\n\6\b\u00fb\u00fc\f\6\2\2\u00fc\u00fd\t\b\2\2\u00fd\u0126")
        buf.write("\5\n\6\7\u00fe\u0100\f\16\2\2\u00ff\u0101\7Q\2\2\u0100")
        buf.write("\u00ff\3\2\2\2\u0100\u0101\3\2\2\2\u0101\u0102\3\2\2\2")
        buf.write("\u0102\u0103\7N\2\2\u0103\u0106\5\n\6\2\u0104\u0105\7")
        buf.write("@\2\2\u0105\u0107\5\n\6\2\u0106\u0104\3\2\2\2\u0106\u0107")
        buf.write("\3\2\2\2\u0107\u0110\3\2\2\2\u0108\u0109\7P\2\2\u0109")
        buf.write("\u010c\5\n\6\2\u010a\u010b\7@\2\2\u010b\u010d\5\n\6\2")
        buf.write("\u010c\u010a\3\2\2\2\u010c\u010d\3\2\2\2\u010d\u010f\3")
        buf.write("\2\2\2\u010e\u0108\3\2\2\2\u010f\u0112\3\2\2\2\u0110\u010e")
        buf.write("\3\2\2\2\u0110\u0111\3\2\2\2\u0111\u0113\3\2\2\2\u0112")
        buf.write("\u0110\3\2\2\2\u0113\u0114\7O\2\2\u0114\u0126\3\2\2\2")
        buf.write("\u0115\u0116\f\r\2\2\u0116\u0117\7Q\2\2\u0117\u0126\7")
        buf.write("T\2\2\u0118\u0119\f\5\2\2\u0119\u011a\7!\2\2\u011a\u011b")
        buf.write("\7N\2\2\u011b\u0120\5\n\6\2\u011c\u011d\7P\2\2\u011d\u011f")
        buf.write("\5\n\6\2\u011e\u011c\3\2\2\2\u011f\u0122\3\2\2\2\u0120")
        buf.write("\u011e\3\2\2\2\u0120\u0121\3\2\2\2\u0121\u0123\3\2\2\2")
        buf.write("\u0122\u0120\3\2\2\2\u0123\u0124\7O\2\2\u0124\u0126\3")
        buf.write("\2\2\2\u0125\u00ec\3\2\2\2\u0125\u00ef\3\2\2\2\u0125\u00f2")
        buf.write("\3\2\2\2\u0125\u00f5\3\2\2\2\u0125\u00f8\3\2\2\2\u0125")
        buf.write("\u00fb\3\2\2\2\u0125\u00fe\3\2\2\2\u0125\u0115\3\2\2\2")
        buf.write("\u0125\u0118\3\2\2\2\u0126\u0129\3\2\2\2\u0127\u0125\3")
        buf.write("\2\2\2\u0127\u0128\3\2\2\2\u0128\13\3\2\2\2\u0129\u0127")
        buf.write("\3\2\2\2\u012a\u012b\b\7\1\2\u012b\u012c\7L\2\2\u012c")
        buf.write("\u012d\5\f\7\2\u012d\u012e\7P\2\2\u012e\u0133\5\f\7\2")
        buf.write("\u012f\u0130\7P\2\2\u0130\u0132\5\f\7\2\u0131\u012f\3")
        buf.write("\2\2\2\u0132\u0135\3\2\2\2\u0133\u0131\3\2\2\2\u0133\u0134")
        buf.write("\3\2\2\2\u0134\u0136\3\2\2\2\u0135\u0133\3\2\2\2\u0136")
        buf.write("\u0137\7M\2\2\u0137\u0148\3\2\2\2\u0138\u0139\7T\2\2\u0139")
        buf.write("\u0142\7B\2\2\u013a\u013f\5\n\6\2\u013b\u013c\7P\2\2\u013c")
        buf.write("\u013e\5\n\6\2\u013d\u013b\3\2\2\2\u013e\u0141\3\2\2\2")
        buf.write("\u013f\u013d\3\2\2\2\u013f\u0140\3\2\2\2\u0140\u0143\3")
        buf.write("\2\2\2\u0141\u013f\3\2\2\2\u0142\u013a\3\2\2\2\u0142\u0143")
        buf.write("\3\2\2\2\u0143\u0144\3\2\2\2\u0144\u0148\7C\2\2\u0145")
        buf.write("\u0148\7T\2\2\u0146\u0148\7G\2\2\u0147\u012a\3\2\2\2\u0147")
        buf.write("\u0138\3\2\2\2\u0147\u0145\3\2\2\2\u0147\u0146\3\2\2\2")
        buf.write("\u0148\u016a\3\2\2\2\u0149\u014a\f\7\2\2\u014a\u014b\7")
        buf.write("A\2\2\u014b\u0169\5\f\7\b\u014c\u014e\f\6\2\2\u014d\u014f")
        buf.write("\7Q\2\2\u014e\u014d\3\2\2\2\u014e\u014f\3\2\2\2\u014f")
        buf.write("\u0150\3\2\2\2\u0150\u0151\7N\2\2\u0151\u0154\5\n\6\2")
        buf.write("\u0152\u0153\7@\2\2\u0153\u0155\5\n\6\2\u0154\u0152\3")
        buf.write("\2\2\2\u0154\u0155\3\2\2\2\u0155\u015e\3\2\2\2\u0156\u0157")
        buf.write("\7P\2\2\u0157\u015a\5\n\6\2\u0158\u0159\7@\2\2\u0159\u015b")
        buf.write("\5\n\6\2\u015a\u0158\3\2\2\2\u015a\u015b\3\2\2\2\u015b")
        buf.write("\u015d\3\2\2\2\u015c\u0156\3\2\2\2\u015d\u0160\3\2\2\2")
        buf.write("\u015e\u015c\3\2\2\2\u015e\u015f\3\2\2\2\u015f\u0161\3")
        buf.write("\2\2\2\u0160\u015e\3\2\2\2\u0161\u0162\7O\2\2\u0162\u0169")
        buf.write("\3\2\2\2\u0163\u0165\f\5\2\2\u0164\u0166\7Q\2\2\u0165")
        buf.write("\u0164\3\2\2\2\u0165\u0166\3\2\2\2\u0166\u0167\3\2\2\2")
        buf.write("\u0167\u0169\7T\2\2\u0168\u0149\3\2\2\2\u0168\u014c\3")
        buf.write("\2\2\2\u0168\u0163\3\2\2\2\u0169\u016c\3\2\2\2\u016a\u0168")
        buf.write("\3\2\2\2\u016a\u016b\3\2\2\2\u016b\r\3\2\2\2\u016c\u016a")
        buf.write("\3\2\2\2\u016d\u016e\t\t\2\2\u016e\17\3\2\2\2\u016f\u017a")
        buf.write("\7.\2\2\u0170\u017a\7/\2\2\u0171\u0172\7\60\2\2\u0172")
        buf.write("\u0173\7L\2\2\u0173\u0174\5\n\6\2\u0174\u0175\7M\2\2\u0175")
        buf.write("\u017a\3\2\2\2\u0176\u017a\7\61\2\2\u0177\u017a\7\62\2")
        buf.write("\2\u0178\u017a\7T\2\2\u0179\u016f\3\2\2\2\u0179\u0170")
        buf.write("\3\2\2\2\u0179\u0171\3\2\2\2\u0179\u0176\3\2\2\2\u0179")
        buf.write("\u0177\3\2\2\2\u0179\u0178\3\2\2\2\u017a\21\3\2\2\2/\25")
        buf.write("#(\61\66;EVXqw\177\u0085\u0088\u0096\u0099\u009d\u00a3")
        buf.write("\u00aa\u00ae\u00c1\u00d1\u00d4\u00de\u00e1\u00ea\u0100")
        buf.write("\u0106\u010c\u0110\u0120\u0125\u0127\u0133\u013f\u0142")
        buf.write("\u0147\u014e\u0154\u015a\u015e\u0165\u0168\u016a\u0179")
        return buf.getvalue()


class ASLParser ( Parser ):

    grammarFileName = "ASL.g4"

    atn = ATNDeserializer().deserialize(serializedATN())

    decisionsToDFA = [ DFA(ds, i) for i, ds in enumerate(atn.decisionToState) ]

    sharedContextCache = PredictionContextCache()

    literalNames = [ "<INVALID>", "'if'", "'then'", "'elsif'", "'else'", 
                     "'case'", "'of'", "'when'", "'otherwise'", "'for'", 
                     "'to'", "'downto'", "'while'", "'do'", "'repeat'", 
                     "'until'", "'return'", "'assert'", "'Consistent'", 
                     "'enumeration'", "'constant'", "'is'", "'array'", "'QUOT'", 
                     "'REM'", "'DIV'", "'MOD'", "'AND'", "'NOT'", "'OR'", 
                     "'EOR'", "'IN'", "'UNDEFINED'", "'UNKNOWN'", "'UNPREDICTABLE'", 
                     "'CONSTRAINED_UNPREDICTABLE'", "'SEE'", "'IMPLEMENTATION_DEFINED'", 
                     "'SUBARCHITECTURE_DEFINED'", "'RAISE'", "'try'", "'catch'", 
                     "'throw'", "<INVALID>", "'integer'", "'boolean'", "'bits'", 
                     "'bit'", "'real'", "'START'", "'END'", "'NEWLINE'", 
                     "'=='", "'!='", "'>'", "'<'", "'>='", "'<='", "'||'", 
                     "'&&'", "'!'", "'+:'", "'-:'", "':'", "'['", "']'", 
                     "'*'", "'/'", "'+'", "'-'", "'<<'", "'>>'", "'^'", 
                     "'='", "'('", "')'", "'{'", "'}'", "','", "'.'", "';'" ]

    symbolicNames = [ "<INVALID>", "If", "Then", "Elsif", "Else", "Case", 
                      "Of", "When", "Otherwise", "For", "To", "Downto", 
                      "While", "Do", "Repeat", "Until", "Return", "Assert", 
                      "Consistent", "Enumeration", "Constant", "Is", "Array", 
                      "Quot", "Rem", "Div", "Mod", "And", "Not", "Or", "Eor", 
                      "In", "Undefined", "Unknown", "Unpredictable", "Constrained_Unpredictable", 
                      "See", "Implementation_Defined", "Subarchitecture_Defined", 
                      "Raise", "Try", "Catch", "Throw", "Typeof", "IntegerType", 
                      "BooleanType", "BitsType", "BitType", "RealType", 
                      "Start", "End", "Newline", "Equal", "NotEqual", "Greater", 
                      "Less", "GreaterEqual", "LessEqual", "Lor", "Land", 
                      "Negation", "RangeUp", "RangeDown", "Colon", "LeftBracket", 
                      "RightBracket", "Mult", "Divide", "Plus", "Minus", 
                      "LeftShift", "RightShift", "Pow", "Assign", "LeftParen", 
                      "RightParen", "LeftBrace", "RightBrace", "Comma", 
                      "Dot", "Semicolon", "Bool", "Identifier", "Integer", 
                      "Hex", "FixedPointNum", "BitVector", "BitMask", "String", 
                      "Ws", "LineComment" ]

    RULE_start = 0
    RULE_statement = 1
    RULE_simpleStatement = 2
    RULE_block = 3
    RULE_expression = 4
    RULE_assignableExpr = 5
    RULE_literal = 6
    RULE_typeName = 7

    ruleNames =  [ "start", "statement", "simpleStatement", "block", "expression", 
                   "assignableExpr", "literal", "typeName" ]

    EOF = Token.EOF
    If=1
    Then=2
    Elsif=3
    Else=4
    Case=5
    Of=6
    When=7
    Otherwise=8
    For=9
    To=10
    Downto=11
    While=12
    Do=13
    Repeat=14
    Until=15
    Return=16
    Assert=17
    Consistent=18
    Enumeration=19
    Constant=20
    Is=21
    Array=22
    Quot=23
    Rem=24
    Div=25
    Mod=26
    And=27
    Not=28
    Or=29
    Eor=30
    In=31
    Undefined=32
    Unknown=33
    Unpredictable=34
    Constrained_Unpredictable=35
    See=36
    Implementation_Defined=37
    Subarchitecture_Defined=38
    Raise=39
    Try=40
    Catch=41
    Throw=42
    Typeof=43
    IntegerType=44
    BooleanType=45
    BitsType=46
    BitType=47
    RealType=48
    Start=49
    End=50
    Newline=51
    Equal=52
    NotEqual=53
    Greater=54
    Less=55
    GreaterEqual=56
    LessEqual=57
    Lor=58
    Land=59
    Negation=60
    RangeUp=61
    RangeDown=62
    Colon=63
    LeftBracket=64
    RightBracket=65
    Mult=66
    Divide=67
    Plus=68
    Minus=69
    LeftShift=70
    RightShift=71
    Pow=72
    Assign=73
    LeftParen=74
    RightParen=75
    LeftBrace=76
    RightBrace=77
    Comma=78
    Dot=79
    Semicolon=80
    Bool=81
    Identifier=82
    Integer=83
    Hex=84
    FixedPointNum=85
    BitVector=86
    BitMask=87
    String=88
    Ws=89
    LineComment=90

    def __init__(self, input:TokenStream):
        super().__init__(input)
        self.checkVersion("4.5.3")
        self._interp = ParserATNSimulator(self, self.atn, self.decisionsToDFA, self.sharedContextCache)
        self._predicates = None



    class StartContext(ParserRuleContext):

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def statement(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(ASLParser.StatementContext)
            else:
                return self.getTypedRuleContext(ASLParser.StatementContext,i)


        def getRuleIndex(self):
            return ASLParser.RULE_start

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitStart" ):
                return visitor.visitStart(self)
            else:
                return visitor.visitChildren(self)




    def start(self):

        localctx = ASLParser.StartContext(self, self._ctx, self.state)
        self.enterRule(localctx, 0, self.RULE_start)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 19
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            while (((_la) & ~0x3f) == 0 and ((1 << _la) & ((1 << ASLParser.If) | (1 << ASLParser.Case) | (1 << ASLParser.For) | (1 << ASLParser.While) | (1 << ASLParser.Repeat) | (1 << ASLParser.Assert) | (1 << ASLParser.Enumeration) | (1 << ASLParser.Constant) | (1 << ASLParser.Undefined) | (1 << ASLParser.Unpredictable) | (1 << ASLParser.See) | (1 << ASLParser.Implementation_Defined) | (1 << ASLParser.IntegerType) | (1 << ASLParser.BooleanType) | (1 << ASLParser.BitsType) | (1 << ASLParser.BitType) | (1 << ASLParser.RealType))) != 0) or ((((_la - 69)) & ~0x3f) == 0 and ((1 << (_la - 69)) & ((1 << (ASLParser.Minus - 69)) | (1 << (ASLParser.LeftParen - 69)) | (1 << (ASLParser.Identifier - 69)))) != 0):
                self.state = 16
                self.statement()
                self.state = 21
                self._errHandler.sync(self)
                _la = self._input.LA(1)

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx

    class StatementContext(ParserRuleContext):

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def If(self):
            return self.getToken(ASLParser.If, 0)

        def expression(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(ASLParser.ExpressionContext)
            else:
                return self.getTypedRuleContext(ASLParser.ExpressionContext,i)


        def Then(self, i:int=None):
            if i is None:
                return self.getTokens(ASLParser.Then)
            else:
                return self.getToken(ASLParser.Then, i)

        def block(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(ASLParser.BlockContext)
            else:
                return self.getTypedRuleContext(ASLParser.BlockContext,i)


        def Elsif(self, i:int=None):
            if i is None:
                return self.getTokens(ASLParser.Elsif)
            else:
                return self.getToken(ASLParser.Elsif, i)

        def Else(self):
            return self.getToken(ASLParser.Else, 0)

        def Case(self):
            return self.getToken(ASLParser.Case, 0)

        def Of(self):
            return self.getToken(ASLParser.Of, 0)

        def Start(self):
            return self.getToken(ASLParser.Start, 0)

        def End(self):
            return self.getToken(ASLParser.End, 0)

        def When(self, i:int=None):
            if i is None:
                return self.getTokens(ASLParser.When)
            else:
                return self.getToken(ASLParser.When, i)

        def Otherwise(self):
            return self.getToken(ASLParser.Otherwise, 0)

        def literal(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(ASLParser.LiteralContext)
            else:
                return self.getTypedRuleContext(ASLParser.LiteralContext,i)


        def Identifier(self, i:int=None):
            if i is None:
                return self.getTokens(ASLParser.Identifier)
            else:
                return self.getToken(ASLParser.Identifier, i)

        def Repeat(self):
            return self.getToken(ASLParser.Repeat, 0)

        def Until(self):
            return self.getToken(ASLParser.Until, 0)

        def Semicolon(self):
            return self.getToken(ASLParser.Semicolon, 0)

        def Newline(self):
            return self.getToken(ASLParser.Newline, 0)

        def While(self):
            return self.getToken(ASLParser.While, 0)

        def Do(self):
            return self.getToken(ASLParser.Do, 0)

        def For(self):
            return self.getToken(ASLParser.For, 0)

        def assignableExpr(self):
            return self.getTypedRuleContext(ASLParser.AssignableExprContext,0)


        def Assign(self):
            return self.getToken(ASLParser.Assign, 0)

        def To(self):
            return self.getToken(ASLParser.To, 0)

        def Downto(self):
            return self.getToken(ASLParser.Downto, 0)

        def simpleStatement(self):
            return self.getTypedRuleContext(ASLParser.SimpleStatementContext,0)


        def getRuleIndex(self):
            return ASLParser.RULE_statement

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitStatement" ):
                return visitor.visitStatement(self)
            else:
                return visitor.visitChildren(self)




    def statement(self):

        localctx = ASLParser.StatementContext(self, self._ctx, self.state)
        self.enterRule(localctx, 2, self.RULE_statement)
        self._la = 0 # Token type
        try:
            self.state = 86
            token = self._input.LA(1)
            if token in [ASLParser.If]:
                self.enterOuterAlt(localctx, 1)
                self.state = 22
                self.match(ASLParser.If)
                self.state = 23
                self.expression(0)
                self.state = 24
                self.match(ASLParser.Then)
                self.state = 25
                self.block()
                self.state = 33
                self._errHandler.sync(self)
                _la = self._input.LA(1)
                while _la==ASLParser.Elsif:
                    self.state = 26
                    self.match(ASLParser.Elsif)
                    self.state = 27
                    self.expression(0)
                    self.state = 28
                    self.match(ASLParser.Then)
                    self.state = 29
                    self.block()
                    self.state = 35
                    self._errHandler.sync(self)
                    _la = self._input.LA(1)

                self.state = 38
                _la = self._input.LA(1)
                if _la==ASLParser.Else:
                    self.state = 36
                    self.match(ASLParser.Else)
                    self.state = 37
                    self.block()



            elif token in [ASLParser.Case]:
                self.enterOuterAlt(localctx, 2)
                self.state = 40
                self.match(ASLParser.Case)
                self.state = 41
                self.expression(0)
                self.state = 42
                self.match(ASLParser.Of)
                self.state = 43
                self.match(ASLParser.Start)
                self.state = 52
                self._errHandler.sync(self)
                _la = self._input.LA(1)
                while _la==ASLParser.When:
                    self.state = 44
                    self.match(ASLParser.When)
                    self.state = 47
                    token = self._input.LA(1)
                    if token in [ASLParser.Bool, ASLParser.Integer, ASLParser.Hex, ASLParser.FixedPointNum, ASLParser.BitVector, ASLParser.BitMask, ASLParser.String]:
                        self.state = 45
                        self.literal()

                    elif token in [ASLParser.Identifier]:
                        self.state = 46
                        self.match(ASLParser.Identifier)

                    else:
                        raise NoViableAltException(self)

                    self.state = 49
                    self.block()
                    self.state = 54
                    self._errHandler.sync(self)
                    _la = self._input.LA(1)

                self.state = 57
                _la = self._input.LA(1)
                if _la==ASLParser.Otherwise:
                    self.state = 55
                    self.match(ASLParser.Otherwise)
                    self.state = 56
                    self.block()


                self.state = 59
                self.match(ASLParser.End)

            elif token in [ASLParser.Repeat]:
                self.enterOuterAlt(localctx, 3)
                self.state = 61
                self.match(ASLParser.Repeat)
                self.state = 62
                self.block()
                self.state = 63
                self.match(ASLParser.Until)
                self.state = 64
                self.expression(0)
                self.state = 65
                self.match(ASLParser.Semicolon)
                self.state = 67
                _la = self._input.LA(1)
                if _la==ASLParser.Newline:
                    self.state = 66
                    self.match(ASLParser.Newline)



            elif token in [ASLParser.While]:
                self.enterOuterAlt(localctx, 4)
                self.state = 69
                self.match(ASLParser.While)
                self.state = 70
                self.expression(0)
                self.state = 71
                self.match(ASLParser.Do)
                self.state = 72
                self.block()

            elif token in [ASLParser.For]:
                self.enterOuterAlt(localctx, 5)
                self.state = 74
                self.match(ASLParser.For)
                self.state = 75
                self.assignableExpr(0)
                self.state = 76
                self.match(ASLParser.Assign)
                self.state = 77
                self.expression(0)
                self.state = 78
                _la = self._input.LA(1)
                if not(_la==ASLParser.To or _la==ASLParser.Downto):
                    self._errHandler.recoverInline(self)
                else:
                    self.consume()
                self.state = 79
                self.expression(0)
                self.state = 80
                self.block()

            elif token in [ASLParser.Assert, ASLParser.Enumeration, ASLParser.Constant, ASLParser.Undefined, ASLParser.Unpredictable, ASLParser.See, ASLParser.Implementation_Defined, ASLParser.IntegerType, ASLParser.BooleanType, ASLParser.BitsType, ASLParser.BitType, ASLParser.RealType, ASLParser.Minus, ASLParser.LeftParen, ASLParser.Identifier]:
                self.enterOuterAlt(localctx, 6)
                self.state = 82
                self.simpleStatement()
                self.state = 84
                _la = self._input.LA(1)
                if _la==ASLParser.Newline:
                    self.state = 83
                    self.match(ASLParser.Newline)



            else:
                raise NoViableAltException(self)

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx

    class SimpleStatementContext(ParserRuleContext):

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def Undefined(self):
            return self.getToken(ASLParser.Undefined, 0)

        def Semicolon(self):
            return self.getToken(ASLParser.Semicolon, 0)

        def Unpredictable(self):
            return self.getToken(ASLParser.Unpredictable, 0)

        def See(self):
            return self.getToken(ASLParser.See, 0)

        def expression(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(ASLParser.ExpressionContext)
            else:
                return self.getTypedRuleContext(ASLParser.ExpressionContext,i)


        def Implementation_Defined(self):
            return self.getToken(ASLParser.Implementation_Defined, 0)

        def String(self):
            return self.getToken(ASLParser.String, 0)

        def Assert(self):
            return self.getToken(ASLParser.Assert, 0)

        def Enumeration(self):
            return self.getToken(ASLParser.Enumeration, 0)

        def Identifier(self, i:int=None):
            if i is None:
                return self.getTokens(ASLParser.Identifier)
            else:
                return self.getToken(ASLParser.Identifier, i)

        def LeftBrace(self):
            return self.getToken(ASLParser.LeftBrace, 0)

        def RightBrace(self):
            return self.getToken(ASLParser.RightBrace, 0)

        def Comma(self, i:int=None):
            if i is None:
                return self.getTokens(ASLParser.Comma)
            else:
                return self.getToken(ASLParser.Comma, i)

        def typeName(self):
            return self.getTypedRuleContext(ASLParser.TypeNameContext,0)


        def assignableExpr(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(ASLParser.AssignableExprContext)
            else:
                return self.getTypedRuleContext(ASLParser.AssignableExprContext,i)


        def Constant(self):
            return self.getToken(ASLParser.Constant, 0)

        def Assign(self):
            return self.getToken(ASLParser.Assign, 0)

        def LeftParen(self):
            return self.getToken(ASLParser.LeftParen, 0)

        def RightParen(self):
            return self.getToken(ASLParser.RightParen, 0)

        def getRuleIndex(self):
            return ASLParser.RULE_simpleStatement

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitSimpleStatement" ):
                return visitor.visitSimpleStatement(self)
            else:
                return visitor.visitChildren(self)




    def simpleStatement(self):

        localctx = ASLParser.SimpleStatementContext(self, self._ctx, self.state)
        self.enterRule(localctx, 4, self.RULE_simpleStatement)
        self._la = 0 # Token type
        try:
            self.state = 155
            self._errHandler.sync(self);
            la_ = self._interp.adaptivePredict(self._input,16,self._ctx)
            if la_ == 1:
                self.enterOuterAlt(localctx, 1)
                self.state = 88
                self.match(ASLParser.Undefined)
                self.state = 89
                self.match(ASLParser.Semicolon)
                pass

            elif la_ == 2:
                self.enterOuterAlt(localctx, 2)
                self.state = 90
                self.match(ASLParser.Unpredictable)
                self.state = 91
                self.match(ASLParser.Semicolon)
                pass

            elif la_ == 3:
                self.enterOuterAlt(localctx, 3)
                self.state = 92
                self.match(ASLParser.See)
                self.state = 93
                self.expression(0)
                self.state = 94
                self.match(ASLParser.Semicolon)
                pass

            elif la_ == 4:
                self.enterOuterAlt(localctx, 4)
                self.state = 96
                self.match(ASLParser.Implementation_Defined)
                self.state = 97
                self.match(ASLParser.String)
                self.state = 98
                self.match(ASLParser.Semicolon)
                pass

            elif la_ == 5:
                self.enterOuterAlt(localctx, 5)
                self.state = 99
                self.match(ASLParser.Assert)
                self.state = 100
                self.expression(0)
                self.state = 101
                self.match(ASLParser.Semicolon)
                pass

            elif la_ == 6:
                self.enterOuterAlt(localctx, 6)
                self.state = 103
                self.match(ASLParser.Enumeration)
                self.state = 104
                self.match(ASLParser.Identifier)
                self.state = 105
                self.match(ASLParser.LeftBrace)
                self.state = 106
                self.match(ASLParser.Identifier)
                self.state = 111
                self._errHandler.sync(self)
                _la = self._input.LA(1)
                while _la==ASLParser.Comma:
                    self.state = 107
                    self.match(ASLParser.Comma)
                    self.state = 108
                    self.match(ASLParser.Identifier)
                    self.state = 113
                    self._errHandler.sync(self)
                    _la = self._input.LA(1)

                self.state = 114
                self.match(ASLParser.RightBrace)
                self.state = 115
                self.match(ASLParser.Semicolon)
                pass

            elif la_ == 7:
                self.enterOuterAlt(localctx, 7)
                self.state = 117
                _la = self._input.LA(1)
                if _la==ASLParser.Constant:
                    self.state = 116
                    self.match(ASLParser.Constant)


                self.state = 119
                self.typeName()
                self.state = 120
                self.assignableExpr(0)
                self.state = 125
                self._errHandler.sync(self)
                _la = self._input.LA(1)
                while _la==ASLParser.Comma:
                    self.state = 121
                    self.match(ASLParser.Comma)
                    self.state = 122
                    self.assignableExpr(0)
                    self.state = 127
                    self._errHandler.sync(self)
                    _la = self._input.LA(1)

                self.state = 128
                self.match(ASLParser.Semicolon)
                pass

            elif la_ == 8:
                self.enterOuterAlt(localctx, 8)
                self.state = 131
                _la = self._input.LA(1)
                if _la==ASLParser.Constant:
                    self.state = 130
                    self.match(ASLParser.Constant)


                self.state = 134
                self._errHandler.sync(self);
                la_ = self._interp.adaptivePredict(self._input,13,self._ctx)
                if la_ == 1:
                    self.state = 133
                    self.typeName()


                self.state = 136
                self.assignableExpr(0)
                self.state = 137
                self.match(ASLParser.Assign)
                self.state = 138
                self.expression(0)
                self.state = 139
                self.match(ASLParser.Semicolon)
                pass

            elif la_ == 9:
                self.enterOuterAlt(localctx, 9)
                self.state = 141
                self.match(ASLParser.Identifier)
                self.state = 142
                self.match(ASLParser.LeftParen)
                self.state = 151
                _la = self._input.LA(1)
                if (((_la) & ~0x3f) == 0 and ((1 << _la) & ((1 << ASLParser.If) | (1 << ASLParser.Not) | (1 << ASLParser.IntegerType) | (1 << ASLParser.BooleanType) | (1 << ASLParser.BitsType) | (1 << ASLParser.BitType) | (1 << ASLParser.RealType) | (1 << ASLParser.Negation))) != 0) or ((((_la - 68)) & ~0x3f) == 0 and ((1 << (_la - 68)) & ((1 << (ASLParser.Plus - 68)) | (1 << (ASLParser.Minus - 68)) | (1 << (ASLParser.LeftParen - 68)) | (1 << (ASLParser.Bool - 68)) | (1 << (ASLParser.Identifier - 68)) | (1 << (ASLParser.Integer - 68)) | (1 << (ASLParser.Hex - 68)) | (1 << (ASLParser.FixedPointNum - 68)) | (1 << (ASLParser.BitVector - 68)) | (1 << (ASLParser.BitMask - 68)) | (1 << (ASLParser.String - 68)))) != 0):
                    self.state = 143
                    self.expression(0)
                    self.state = 148
                    self._errHandler.sync(self)
                    _la = self._input.LA(1)
                    while _la==ASLParser.Comma:
                        self.state = 144
                        self.match(ASLParser.Comma)
                        self.state = 145
                        self.expression(0)
                        self.state = 150
                        self._errHandler.sync(self)
                        _la = self._input.LA(1)



                self.state = 153
                self.match(ASLParser.RightParen)
                self.state = 154
                self.match(ASLParser.Semicolon)
                pass


        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx

    class BlockContext(ParserRuleContext):

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def Start(self):
            return self.getToken(ASLParser.Start, 0)

        def End(self):
            return self.getToken(ASLParser.End, 0)

        def statement(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(ASLParser.StatementContext)
            else:
                return self.getTypedRuleContext(ASLParser.StatementContext,i)


        def Newline(self):
            return self.getToken(ASLParser.Newline, 0)

        def simpleStatement(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(ASLParser.SimpleStatementContext)
            else:
                return self.getTypedRuleContext(ASLParser.SimpleStatementContext,i)


        def getRuleIndex(self):
            return ASLParser.RULE_block

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitBlock" ):
                return visitor.visitBlock(self)
            else:
                return visitor.visitChildren(self)




    def block(self):

        localctx = ASLParser.BlockContext(self, self._ctx, self.state)
        self.enterRule(localctx, 6, self.RULE_block)
        self._la = 0 # Token type
        try:
            self.state = 172
            token = self._input.LA(1)
            if token in [ASLParser.Start]:
                self.enterOuterAlt(localctx, 1)
                self.state = 157
                self.match(ASLParser.Start)
                self.state = 159 
                self._errHandler.sync(self)
                _la = self._input.LA(1)
                while True:
                    self.state = 158
                    self.statement()
                    self.state = 161 
                    self._errHandler.sync(self)
                    _la = self._input.LA(1)
                    if not ((((_la) & ~0x3f) == 0 and ((1 << _la) & ((1 << ASLParser.If) | (1 << ASLParser.Case) | (1 << ASLParser.For) | (1 << ASLParser.While) | (1 << ASLParser.Repeat) | (1 << ASLParser.Assert) | (1 << ASLParser.Enumeration) | (1 << ASLParser.Constant) | (1 << ASLParser.Undefined) | (1 << ASLParser.Unpredictable) | (1 << ASLParser.See) | (1 << ASLParser.Implementation_Defined) | (1 << ASLParser.IntegerType) | (1 << ASLParser.BooleanType) | (1 << ASLParser.BitsType) | (1 << ASLParser.BitType) | (1 << ASLParser.RealType))) != 0) or ((((_la - 69)) & ~0x3f) == 0 and ((1 << (_la - 69)) & ((1 << (ASLParser.Minus - 69)) | (1 << (ASLParser.LeftParen - 69)) | (1 << (ASLParser.Identifier - 69)))) != 0)):
                        break

                self.state = 163
                self.match(ASLParser.End)

            elif token in [ASLParser.Assert, ASLParser.Enumeration, ASLParser.Constant, ASLParser.Undefined, ASLParser.Unpredictable, ASLParser.See, ASLParser.Implementation_Defined, ASLParser.IntegerType, ASLParser.BooleanType, ASLParser.BitsType, ASLParser.BitType, ASLParser.RealType, ASLParser.Newline, ASLParser.Minus, ASLParser.LeftParen, ASLParser.Identifier]:
                self.enterOuterAlt(localctx, 2)
                self.state = 168
                self._errHandler.sync(self)
                _la = self._input.LA(1)
                while (((_la) & ~0x3f) == 0 and ((1 << _la) & ((1 << ASLParser.Assert) | (1 << ASLParser.Enumeration) | (1 << ASLParser.Constant) | (1 << ASLParser.Undefined) | (1 << ASLParser.Unpredictable) | (1 << ASLParser.See) | (1 << ASLParser.Implementation_Defined) | (1 << ASLParser.IntegerType) | (1 << ASLParser.BooleanType) | (1 << ASLParser.BitsType) | (1 << ASLParser.BitType) | (1 << ASLParser.RealType))) != 0) or ((((_la - 69)) & ~0x3f) == 0 and ((1 << (_la - 69)) & ((1 << (ASLParser.Minus - 69)) | (1 << (ASLParser.LeftParen - 69)) | (1 << (ASLParser.Identifier - 69)))) != 0):
                    self.state = 165
                    self.simpleStatement()
                    self.state = 170
                    self._errHandler.sync(self)
                    _la = self._input.LA(1)

                self.state = 171
                self.match(ASLParser.Newline)

            else:
                raise NoViableAltException(self)

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx

    class ExpressionContext(ParserRuleContext):

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def If(self):
            return self.getToken(ASLParser.If, 0)

        def expression(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(ASLParser.ExpressionContext)
            else:
                return self.getTypedRuleContext(ASLParser.ExpressionContext,i)


        def Then(self):
            return self.getToken(ASLParser.Then, 0)

        def Else(self):
            return self.getToken(ASLParser.Else, 0)

        def literal(self):
            return self.getTypedRuleContext(ASLParser.LiteralContext,0)


        def LeftParen(self):
            return self.getToken(ASLParser.LeftParen, 0)

        def Comma(self, i:int=None):
            if i is None:
                return self.getTokens(ASLParser.Comma)
            else:
                return self.getToken(ASLParser.Comma, i)

        def RightParen(self):
            return self.getToken(ASLParser.RightParen, 0)

        def Identifier(self):
            return self.getToken(ASLParser.Identifier, 0)

        def LeftBracket(self):
            return self.getToken(ASLParser.LeftBracket, 0)

        def RightBracket(self):
            return self.getToken(ASLParser.RightBracket, 0)

        def Not(self):
            return self.getToken(ASLParser.Not, 0)

        def Plus(self):
            return self.getToken(ASLParser.Plus, 0)

        def Minus(self):
            return self.getToken(ASLParser.Minus, 0)

        def Negation(self):
            return self.getToken(ASLParser.Negation, 0)

        def typeName(self):
            return self.getTypedRuleContext(ASLParser.TypeNameContext,0)


        def Unknown(self):
            return self.getToken(ASLParser.Unknown, 0)

        def Mult(self):
            return self.getToken(ASLParser.Mult, 0)

        def Divide(self):
            return self.getToken(ASLParser.Divide, 0)

        def Div(self):
            return self.getToken(ASLParser.Div, 0)

        def Mod(self):
            return self.getToken(ASLParser.Mod, 0)

        def Colon(self):
            return self.getToken(ASLParser.Colon, 0)

        def RightShift(self):
            return self.getToken(ASLParser.RightShift, 0)

        def LeftShift(self):
            return self.getToken(ASLParser.LeftShift, 0)

        def Greater(self):
            return self.getToken(ASLParser.Greater, 0)

        def Less(self):
            return self.getToken(ASLParser.Less, 0)

        def Equal(self):
            return self.getToken(ASLParser.Equal, 0)

        def NotEqual(self):
            return self.getToken(ASLParser.NotEqual, 0)

        def GreaterEqual(self):
            return self.getToken(ASLParser.GreaterEqual, 0)

        def LessEqual(self):
            return self.getToken(ASLParser.LessEqual, 0)

        def And(self):
            return self.getToken(ASLParser.And, 0)

        def Eor(self):
            return self.getToken(ASLParser.Eor, 0)

        def Or(self):
            return self.getToken(ASLParser.Or, 0)

        def Lor(self):
            return self.getToken(ASLParser.Lor, 0)

        def Land(self):
            return self.getToken(ASLParser.Land, 0)

        def LeftBrace(self):
            return self.getToken(ASLParser.LeftBrace, 0)

        def RightBrace(self):
            return self.getToken(ASLParser.RightBrace, 0)

        def Dot(self):
            return self.getToken(ASLParser.Dot, 0)

        def RangeDown(self, i:int=None):
            if i is None:
                return self.getTokens(ASLParser.RangeDown)
            else:
                return self.getToken(ASLParser.RangeDown, i)

        def In(self):
            return self.getToken(ASLParser.In, 0)

        def getRuleIndex(self):
            return ASLParser.RULE_expression

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitExpression" ):
                return visitor.visitExpression(self)
            else:
                return visitor.visitChildren(self)



    def expression(self, _p:int=0):
        _parentctx = self._ctx
        _parentState = self.state
        localctx = ASLParser.ExpressionContext(self, self._ctx, _parentState)
        _prevctx = localctx
        _startState = 8
        self.enterRecursionRule(localctx, 8, self.RULE_expression, _p)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 232
            self._errHandler.sync(self);
            la_ = self._interp.adaptivePredict(self._input,25,self._ctx)
            if la_ == 1:
                self.state = 175
                self.match(ASLParser.If)
                self.state = 176
                self.expression(0)
                self.state = 177
                self.match(ASLParser.Then)
                self.state = 178
                self.expression(0)
                self.state = 179
                self.match(ASLParser.Else)
                self.state = 180
                self.expression(0)
                pass

            elif la_ == 2:
                self.state = 182
                self.literal()
                pass

            elif la_ == 3:
                self.state = 183
                self.match(ASLParser.LeftParen)
                self.state = 184
                self.expression(0)
                self.state = 185
                self.match(ASLParser.Comma)
                self.state = 186
                self.expression(0)
                self.state = 191
                self._errHandler.sync(self)
                _la = self._input.LA(1)
                while _la==ASLParser.Comma:
                    self.state = 187
                    self.match(ASLParser.Comma)
                    self.state = 188
                    self.expression(0)
                    self.state = 193
                    self._errHandler.sync(self)
                    _la = self._input.LA(1)

                self.state = 194
                self.match(ASLParser.RightParen)
                pass

            elif la_ == 4:
                self.state = 196
                self.match(ASLParser.LeftParen)
                self.state = 197
                self.expression(0)
                self.state = 198
                self.match(ASLParser.RightParen)
                pass

            elif la_ == 5:
                self.state = 200
                self.match(ASLParser.Identifier)
                self.state = 201
                self.match(ASLParser.LeftParen)
                self.state = 210
                _la = self._input.LA(1)
                if (((_la) & ~0x3f) == 0 and ((1 << _la) & ((1 << ASLParser.If) | (1 << ASLParser.Not) | (1 << ASLParser.IntegerType) | (1 << ASLParser.BooleanType) | (1 << ASLParser.BitsType) | (1 << ASLParser.BitType) | (1 << ASLParser.RealType) | (1 << ASLParser.Negation))) != 0) or ((((_la - 68)) & ~0x3f) == 0 and ((1 << (_la - 68)) & ((1 << (ASLParser.Plus - 68)) | (1 << (ASLParser.Minus - 68)) | (1 << (ASLParser.LeftParen - 68)) | (1 << (ASLParser.Bool - 68)) | (1 << (ASLParser.Identifier - 68)) | (1 << (ASLParser.Integer - 68)) | (1 << (ASLParser.Hex - 68)) | (1 << (ASLParser.FixedPointNum - 68)) | (1 << (ASLParser.BitVector - 68)) | (1 << (ASLParser.BitMask - 68)) | (1 << (ASLParser.String - 68)))) != 0):
                    self.state = 202
                    self.expression(0)
                    self.state = 207
                    self._errHandler.sync(self)
                    _la = self._input.LA(1)
                    while _la==ASLParser.Comma:
                        self.state = 203
                        self.match(ASLParser.Comma)
                        self.state = 204
                        self.expression(0)
                        self.state = 209
                        self._errHandler.sync(self)
                        _la = self._input.LA(1)



                self.state = 212
                self.match(ASLParser.RightParen)
                pass

            elif la_ == 6:
                self.state = 213
                self.match(ASLParser.Identifier)
                self.state = 214
                self.match(ASLParser.LeftBracket)
                self.state = 223
                _la = self._input.LA(1)
                if (((_la) & ~0x3f) == 0 and ((1 << _la) & ((1 << ASLParser.If) | (1 << ASLParser.Not) | (1 << ASLParser.IntegerType) | (1 << ASLParser.BooleanType) | (1 << ASLParser.BitsType) | (1 << ASLParser.BitType) | (1 << ASLParser.RealType) | (1 << ASLParser.Negation))) != 0) or ((((_la - 68)) & ~0x3f) == 0 and ((1 << (_la - 68)) & ((1 << (ASLParser.Plus - 68)) | (1 << (ASLParser.Minus - 68)) | (1 << (ASLParser.LeftParen - 68)) | (1 << (ASLParser.Bool - 68)) | (1 << (ASLParser.Identifier - 68)) | (1 << (ASLParser.Integer - 68)) | (1 << (ASLParser.Hex - 68)) | (1 << (ASLParser.FixedPointNum - 68)) | (1 << (ASLParser.BitVector - 68)) | (1 << (ASLParser.BitMask - 68)) | (1 << (ASLParser.String - 68)))) != 0):
                    self.state = 215
                    self.expression(0)
                    self.state = 220
                    self._errHandler.sync(self)
                    _la = self._input.LA(1)
                    while _la==ASLParser.Comma:
                        self.state = 216
                        self.match(ASLParser.Comma)
                        self.state = 217
                        self.expression(0)
                        self.state = 222
                        self._errHandler.sync(self)
                        _la = self._input.LA(1)



                self.state = 225
                self.match(ASLParser.RightBracket)
                pass

            elif la_ == 7:
                self.state = 226
                _la = self._input.LA(1)
                if not(((((_la - 28)) & ~0x3f) == 0 and ((1 << (_la - 28)) & ((1 << (ASLParser.Not - 28)) | (1 << (ASLParser.Negation - 28)) | (1 << (ASLParser.Plus - 28)) | (1 << (ASLParser.Minus - 28)))) != 0)):
                    self._errHandler.recoverInline(self)
                else:
                    self.consume()
                self.state = 227
                self.expression(10)
                pass

            elif la_ == 8:
                self.state = 228
                self.typeName()
                self.state = 229
                self.match(ASLParser.Unknown)
                pass

            elif la_ == 9:
                self.state = 231
                self.match(ASLParser.Identifier)
                pass


            self._ctx.stop = self._input.LT(-1)
            self.state = 293
            self._errHandler.sync(self)
            _alt = self._interp.adaptivePredict(self._input,32,self._ctx)
            while _alt!=2 and _alt!=ATN.INVALID_ALT_NUMBER:
                if _alt==1:
                    if self._parseListeners is not None:
                        self.triggerExitRuleEvent()
                    _prevctx = localctx
                    self.state = 291
                    self._errHandler.sync(self);
                    la_ = self._interp.adaptivePredict(self._input,31,self._ctx)
                    if la_ == 1:
                        localctx = ASLParser.ExpressionContext(self, _parentctx, _parentState)
                        self.pushNewRecursionContext(localctx, _startState, self.RULE_expression)
                        self.state = 234
                        if not self.precpred(self._ctx, 9):
                            from antlr4.error.Errors import FailedPredicateException
                            raise FailedPredicateException(self, "self.precpred(self._ctx, 9)")
                        self.state = 235
                        _la = self._input.LA(1)
                        if not(((((_la - 25)) & ~0x3f) == 0 and ((1 << (_la - 25)) & ((1 << (ASLParser.Div - 25)) | (1 << (ASLParser.Mod - 25)) | (1 << (ASLParser.Mult - 25)) | (1 << (ASLParser.Divide - 25)))) != 0)):
                            self._errHandler.recoverInline(self)
                        else:
                            self.consume()
                        self.state = 236
                        self.expression(10)
                        pass

                    elif la_ == 2:
                        localctx = ASLParser.ExpressionContext(self, _parentctx, _parentState)
                        self.pushNewRecursionContext(localctx, _startState, self.RULE_expression)
                        self.state = 237
                        if not self.precpred(self._ctx, 8):
                            from antlr4.error.Errors import FailedPredicateException
                            raise FailedPredicateException(self, "self.precpred(self._ctx, 8)")
                        self.state = 238
                        _la = self._input.LA(1)
                        if not(_la==ASLParser.Plus or _la==ASLParser.Minus):
                            self._errHandler.recoverInline(self)
                        else:
                            self.consume()
                        self.state = 239
                        self.expression(9)
                        pass

                    elif la_ == 3:
                        localctx = ASLParser.ExpressionContext(self, _parentctx, _parentState)
                        self.pushNewRecursionContext(localctx, _startState, self.RULE_expression)
                        self.state = 240
                        if not self.precpred(self._ctx, 7):
                            from antlr4.error.Errors import FailedPredicateException
                            raise FailedPredicateException(self, "self.precpred(self._ctx, 7)")
                        self.state = 241
                        self.match(ASLParser.Colon)
                        self.state = 242
                        self.expression(8)
                        pass

                    elif la_ == 4:
                        localctx = ASLParser.ExpressionContext(self, _parentctx, _parentState)
                        self.pushNewRecursionContext(localctx, _startState, self.RULE_expression)
                        self.state = 243
                        if not self.precpred(self._ctx, 6):
                            from antlr4.error.Errors import FailedPredicateException
                            raise FailedPredicateException(self, "self.precpred(self._ctx, 6)")
                        self.state = 244
                        _la = self._input.LA(1)
                        if not(_la==ASLParser.LeftShift or _la==ASLParser.RightShift):
                            self._errHandler.recoverInline(self)
                        else:
                            self.consume()
                        self.state = 245
                        self.expression(7)
                        pass

                    elif la_ == 5:
                        localctx = ASLParser.ExpressionContext(self, _parentctx, _parentState)
                        self.pushNewRecursionContext(localctx, _startState, self.RULE_expression)
                        self.state = 246
                        if not self.precpred(self._ctx, 5):
                            from antlr4.error.Errors import FailedPredicateException
                            raise FailedPredicateException(self, "self.precpred(self._ctx, 5)")
                        self.state = 247
                        _la = self._input.LA(1)
                        if not((((_la) & ~0x3f) == 0 and ((1 << _la) & ((1 << ASLParser.Equal) | (1 << ASLParser.NotEqual) | (1 << ASLParser.Greater) | (1 << ASLParser.Less) | (1 << ASLParser.GreaterEqual) | (1 << ASLParser.LessEqual))) != 0)):
                            self._errHandler.recoverInline(self)
                        else:
                            self.consume()
                        self.state = 248
                        self.expression(6)
                        pass

                    elif la_ == 6:
                        localctx = ASLParser.ExpressionContext(self, _parentctx, _parentState)
                        self.pushNewRecursionContext(localctx, _startState, self.RULE_expression)
                        self.state = 249
                        if not self.precpred(self._ctx, 4):
                            from antlr4.error.Errors import FailedPredicateException
                            raise FailedPredicateException(self, "self.precpred(self._ctx, 4)")
                        self.state = 250
                        _la = self._input.LA(1)
                        if not((((_la) & ~0x3f) == 0 and ((1 << _la) & ((1 << ASLParser.And) | (1 << ASLParser.Or) | (1 << ASLParser.Eor) | (1 << ASLParser.Lor) | (1 << ASLParser.Land))) != 0)):
                            self._errHandler.recoverInline(self)
                        else:
                            self.consume()
                        self.state = 251
                        self.expression(5)
                        pass

                    elif la_ == 7:
                        localctx = ASLParser.ExpressionContext(self, _parentctx, _parentState)
                        self.pushNewRecursionContext(localctx, _startState, self.RULE_expression)
                        self.state = 252
                        if not self.precpred(self._ctx, 12):
                            from antlr4.error.Errors import FailedPredicateException
                            raise FailedPredicateException(self, "self.precpred(self._ctx, 12)")
                        self.state = 254
                        _la = self._input.LA(1)
                        if _la==ASLParser.Dot:
                            self.state = 253
                            self.match(ASLParser.Dot)


                        self.state = 256
                        self.match(ASLParser.LeftBrace)
                        self.state = 257
                        self.expression(0)
                        self.state = 260
                        _la = self._input.LA(1)
                        if _la==ASLParser.RangeDown:
                            self.state = 258
                            self.match(ASLParser.RangeDown)
                            self.state = 259
                            self.expression(0)


                        self.state = 270
                        self._errHandler.sync(self)
                        _la = self._input.LA(1)
                        while _la==ASLParser.Comma:
                            self.state = 262
                            self.match(ASLParser.Comma)
                            self.state = 263
                            self.expression(0)
                            self.state = 266
                            _la = self._input.LA(1)
                            if _la==ASLParser.RangeDown:
                                self.state = 264
                                self.match(ASLParser.RangeDown)
                                self.state = 265
                                self.expression(0)


                            self.state = 272
                            self._errHandler.sync(self)
                            _la = self._input.LA(1)

                        self.state = 273
                        self.match(ASLParser.RightBrace)
                        pass

                    elif la_ == 8:
                        localctx = ASLParser.ExpressionContext(self, _parentctx, _parentState)
                        self.pushNewRecursionContext(localctx, _startState, self.RULE_expression)
                        self.state = 275
                        if not self.precpred(self._ctx, 11):
                            from antlr4.error.Errors import FailedPredicateException
                            raise FailedPredicateException(self, "self.precpred(self._ctx, 11)")
                        self.state = 276
                        self.match(ASLParser.Dot)
                        self.state = 277
                        self.match(ASLParser.Identifier)
                        pass

                    elif la_ == 9:
                        localctx = ASLParser.ExpressionContext(self, _parentctx, _parentState)
                        self.pushNewRecursionContext(localctx, _startState, self.RULE_expression)
                        self.state = 278
                        if not self.precpred(self._ctx, 3):
                            from antlr4.error.Errors import FailedPredicateException
                            raise FailedPredicateException(self, "self.precpred(self._ctx, 3)")
                        self.state = 279
                        self.match(ASLParser.In)
                        self.state = 280
                        self.match(ASLParser.LeftBrace)
                        self.state = 281
                        self.expression(0)
                        self.state = 286
                        self._errHandler.sync(self)
                        _la = self._input.LA(1)
                        while _la==ASLParser.Comma:
                            self.state = 282
                            self.match(ASLParser.Comma)
                            self.state = 283
                            self.expression(0)
                            self.state = 288
                            self._errHandler.sync(self)
                            _la = self._input.LA(1)

                        self.state = 289
                        self.match(ASLParser.RightBrace)
                        pass

             
                self.state = 295
                self._errHandler.sync(self)
                _alt = self._interp.adaptivePredict(self._input,32,self._ctx)

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.unrollRecursionContexts(_parentctx)
        return localctx

    class AssignableExprContext(ParserRuleContext):

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def LeftParen(self):
            return self.getToken(ASLParser.LeftParen, 0)

        def assignableExpr(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(ASLParser.AssignableExprContext)
            else:
                return self.getTypedRuleContext(ASLParser.AssignableExprContext,i)


        def Comma(self, i:int=None):
            if i is None:
                return self.getTokens(ASLParser.Comma)
            else:
                return self.getToken(ASLParser.Comma, i)

        def RightParen(self):
            return self.getToken(ASLParser.RightParen, 0)

        def Identifier(self):
            return self.getToken(ASLParser.Identifier, 0)

        def LeftBracket(self):
            return self.getToken(ASLParser.LeftBracket, 0)

        def RightBracket(self):
            return self.getToken(ASLParser.RightBracket, 0)

        def expression(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(ASLParser.ExpressionContext)
            else:
                return self.getTypedRuleContext(ASLParser.ExpressionContext,i)


        def Minus(self):
            return self.getToken(ASLParser.Minus, 0)

        def Colon(self):
            return self.getToken(ASLParser.Colon, 0)

        def LeftBrace(self):
            return self.getToken(ASLParser.LeftBrace, 0)

        def RightBrace(self):
            return self.getToken(ASLParser.RightBrace, 0)

        def Dot(self):
            return self.getToken(ASLParser.Dot, 0)

        def RangeDown(self, i:int=None):
            if i is None:
                return self.getTokens(ASLParser.RangeDown)
            else:
                return self.getToken(ASLParser.RangeDown, i)

        def getRuleIndex(self):
            return ASLParser.RULE_assignableExpr

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitAssignableExpr" ):
                return visitor.visitAssignableExpr(self)
            else:
                return visitor.visitChildren(self)



    def assignableExpr(self, _p:int=0):
        _parentctx = self._ctx
        _parentState = self.state
        localctx = ASLParser.AssignableExprContext(self, self._ctx, _parentState)
        _prevctx = localctx
        _startState = 10
        self.enterRecursionRule(localctx, 10, self.RULE_assignableExpr, _p)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 325
            self._errHandler.sync(self);
            la_ = self._interp.adaptivePredict(self._input,36,self._ctx)
            if la_ == 1:
                self.state = 297
                self.match(ASLParser.LeftParen)
                self.state = 298
                self.assignableExpr(0)
                self.state = 299
                self.match(ASLParser.Comma)
                self.state = 300
                self.assignableExpr(0)
                self.state = 305
                self._errHandler.sync(self)
                _la = self._input.LA(1)
                while _la==ASLParser.Comma:
                    self.state = 301
                    self.match(ASLParser.Comma)
                    self.state = 302
                    self.assignableExpr(0)
                    self.state = 307
                    self._errHandler.sync(self)
                    _la = self._input.LA(1)

                self.state = 308
                self.match(ASLParser.RightParen)
                pass

            elif la_ == 2:
                self.state = 310
                self.match(ASLParser.Identifier)
                self.state = 311
                self.match(ASLParser.LeftBracket)
                self.state = 320
                _la = self._input.LA(1)
                if (((_la) & ~0x3f) == 0 and ((1 << _la) & ((1 << ASLParser.If) | (1 << ASLParser.Not) | (1 << ASLParser.IntegerType) | (1 << ASLParser.BooleanType) | (1 << ASLParser.BitsType) | (1 << ASLParser.BitType) | (1 << ASLParser.RealType) | (1 << ASLParser.Negation))) != 0) or ((((_la - 68)) & ~0x3f) == 0 and ((1 << (_la - 68)) & ((1 << (ASLParser.Plus - 68)) | (1 << (ASLParser.Minus - 68)) | (1 << (ASLParser.LeftParen - 68)) | (1 << (ASLParser.Bool - 68)) | (1 << (ASLParser.Identifier - 68)) | (1 << (ASLParser.Integer - 68)) | (1 << (ASLParser.Hex - 68)) | (1 << (ASLParser.FixedPointNum - 68)) | (1 << (ASLParser.BitVector - 68)) | (1 << (ASLParser.BitMask - 68)) | (1 << (ASLParser.String - 68)))) != 0):
                    self.state = 312
                    self.expression(0)
                    self.state = 317
                    self._errHandler.sync(self)
                    _la = self._input.LA(1)
                    while _la==ASLParser.Comma:
                        self.state = 313
                        self.match(ASLParser.Comma)
                        self.state = 314
                        self.expression(0)
                        self.state = 319
                        self._errHandler.sync(self)
                        _la = self._input.LA(1)



                self.state = 322
                self.match(ASLParser.RightBracket)
                pass

            elif la_ == 3:
                self.state = 323
                self.match(ASLParser.Identifier)
                pass

            elif la_ == 4:
                self.state = 324
                self.match(ASLParser.Minus)
                pass


            self._ctx.stop = self._input.LT(-1)
            self.state = 360
            self._errHandler.sync(self)
            _alt = self._interp.adaptivePredict(self._input,43,self._ctx)
            while _alt!=2 and _alt!=ATN.INVALID_ALT_NUMBER:
                if _alt==1:
                    if self._parseListeners is not None:
                        self.triggerExitRuleEvent()
                    _prevctx = localctx
                    self.state = 358
                    self._errHandler.sync(self);
                    la_ = self._interp.adaptivePredict(self._input,42,self._ctx)
                    if la_ == 1:
                        localctx = ASLParser.AssignableExprContext(self, _parentctx, _parentState)
                        self.pushNewRecursionContext(localctx, _startState, self.RULE_assignableExpr)
                        self.state = 327
                        if not self.precpred(self._ctx, 5):
                            from antlr4.error.Errors import FailedPredicateException
                            raise FailedPredicateException(self, "self.precpred(self._ctx, 5)")
                        self.state = 328
                        self.match(ASLParser.Colon)
                        self.state = 329
                        self.assignableExpr(6)
                        pass

                    elif la_ == 2:
                        localctx = ASLParser.AssignableExprContext(self, _parentctx, _parentState)
                        self.pushNewRecursionContext(localctx, _startState, self.RULE_assignableExpr)
                        self.state = 330
                        if not self.precpred(self._ctx, 4):
                            from antlr4.error.Errors import FailedPredicateException
                            raise FailedPredicateException(self, "self.precpred(self._ctx, 4)")
                        self.state = 332
                        _la = self._input.LA(1)
                        if _la==ASLParser.Dot:
                            self.state = 331
                            self.match(ASLParser.Dot)


                        self.state = 334
                        self.match(ASLParser.LeftBrace)
                        self.state = 335
                        self.expression(0)
                        self.state = 338
                        _la = self._input.LA(1)
                        if _la==ASLParser.RangeDown:
                            self.state = 336
                            self.match(ASLParser.RangeDown)
                            self.state = 337
                            self.expression(0)


                        self.state = 348
                        self._errHandler.sync(self)
                        _la = self._input.LA(1)
                        while _la==ASLParser.Comma:
                            self.state = 340
                            self.match(ASLParser.Comma)
                            self.state = 341
                            self.expression(0)
                            self.state = 344
                            _la = self._input.LA(1)
                            if _la==ASLParser.RangeDown:
                                self.state = 342
                                self.match(ASLParser.RangeDown)
                                self.state = 343
                                self.expression(0)


                            self.state = 350
                            self._errHandler.sync(self)
                            _la = self._input.LA(1)

                        self.state = 351
                        self.match(ASLParser.RightBrace)
                        pass

                    elif la_ == 3:
                        localctx = ASLParser.AssignableExprContext(self, _parentctx, _parentState)
                        self.pushNewRecursionContext(localctx, _startState, self.RULE_assignableExpr)
                        self.state = 353
                        if not self.precpred(self._ctx, 3):
                            from antlr4.error.Errors import FailedPredicateException
                            raise FailedPredicateException(self, "self.precpred(self._ctx, 3)")
                        self.state = 355
                        _la = self._input.LA(1)
                        if _la==ASLParser.Dot:
                            self.state = 354
                            self.match(ASLParser.Dot)


                        self.state = 357
                        self.match(ASLParser.Identifier)
                        pass

             
                self.state = 362
                self._errHandler.sync(self)
                _alt = self._interp.adaptivePredict(self._input,43,self._ctx)

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.unrollRecursionContexts(_parentctx)
        return localctx

    class LiteralContext(ParserRuleContext):

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def Integer(self):
            return self.getToken(ASLParser.Integer, 0)

        def Hex(self):
            return self.getToken(ASLParser.Hex, 0)

        def BitVector(self):
            return self.getToken(ASLParser.BitVector, 0)

        def BitMask(self):
            return self.getToken(ASLParser.BitMask, 0)

        def FixedPointNum(self):
            return self.getToken(ASLParser.FixedPointNum, 0)

        def Bool(self):
            return self.getToken(ASLParser.Bool, 0)

        def String(self):
            return self.getToken(ASLParser.String, 0)

        def getRuleIndex(self):
            return ASLParser.RULE_literal

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitLiteral" ):
                return visitor.visitLiteral(self)
            else:
                return visitor.visitChildren(self)




    def literal(self):

        localctx = ASLParser.LiteralContext(self, self._ctx, self.state)
        self.enterRule(localctx, 12, self.RULE_literal)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 363
            _la = self._input.LA(1)
            if not(((((_la - 81)) & ~0x3f) == 0 and ((1 << (_la - 81)) & ((1 << (ASLParser.Bool - 81)) | (1 << (ASLParser.Integer - 81)) | (1 << (ASLParser.Hex - 81)) | (1 << (ASLParser.FixedPointNum - 81)) | (1 << (ASLParser.BitVector - 81)) | (1 << (ASLParser.BitMask - 81)) | (1 << (ASLParser.String - 81)))) != 0)):
                self._errHandler.recoverInline(self)
            else:
                self.consume()
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx

    class TypeNameContext(ParserRuleContext):

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def IntegerType(self):
            return self.getToken(ASLParser.IntegerType, 0)

        def BooleanType(self):
            return self.getToken(ASLParser.BooleanType, 0)

        def BitsType(self):
            return self.getToken(ASLParser.BitsType, 0)

        def LeftParen(self):
            return self.getToken(ASLParser.LeftParen, 0)

        def expression(self):
            return self.getTypedRuleContext(ASLParser.ExpressionContext,0)


        def RightParen(self):
            return self.getToken(ASLParser.RightParen, 0)

        def BitType(self):
            return self.getToken(ASLParser.BitType, 0)

        def RealType(self):
            return self.getToken(ASLParser.RealType, 0)

        def Identifier(self):
            return self.getToken(ASLParser.Identifier, 0)

        def getRuleIndex(self):
            return ASLParser.RULE_typeName

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitTypeName" ):
                return visitor.visitTypeName(self)
            else:
                return visitor.visitChildren(self)




    def typeName(self):

        localctx = ASLParser.TypeNameContext(self, self._ctx, self.state)
        self.enterRule(localctx, 14, self.RULE_typeName)
        try:
            self.state = 375
            token = self._input.LA(1)
            if token in [ASLParser.IntegerType]:
                self.enterOuterAlt(localctx, 1)
                self.state = 365
                self.match(ASLParser.IntegerType)

            elif token in [ASLParser.BooleanType]:
                self.enterOuterAlt(localctx, 2)
                self.state = 366
                self.match(ASLParser.BooleanType)

            elif token in [ASLParser.BitsType]:
                self.enterOuterAlt(localctx, 3)
                self.state = 367
                self.match(ASLParser.BitsType)
                self.state = 368
                self.match(ASLParser.LeftParen)
                self.state = 369
                self.expression(0)
                self.state = 370
                self.match(ASLParser.RightParen)

            elif token in [ASLParser.BitType]:
                self.enterOuterAlt(localctx, 4)
                self.state = 372
                self.match(ASLParser.BitType)

            elif token in [ASLParser.RealType]:
                self.enterOuterAlt(localctx, 5)
                self.state = 373
                self.match(ASLParser.RealType)

            elif token in [ASLParser.Identifier]:
                self.enterOuterAlt(localctx, 6)
                self.state = 374
                self.match(ASLParser.Identifier)

            else:
                raise NoViableAltException(self)

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx



    def sempred(self, localctx:RuleContext, ruleIndex:int, predIndex:int):
        if self._predicates == None:
            self._predicates = dict()
        self._predicates[4] = self.expression_sempred
        self._predicates[5] = self.assignableExpr_sempred
        pred = self._predicates.get(ruleIndex, None)
        if pred is None:
            raise Exception("No predicate with index:" + str(ruleIndex))
        else:
            return pred(localctx, predIndex)

    def expression_sempred(self, localctx:ExpressionContext, predIndex:int):
            if predIndex == 0:
                return self.precpred(self._ctx, 9)
         

            if predIndex == 1:
                return self.precpred(self._ctx, 8)
         

            if predIndex == 2:
                return self.precpred(self._ctx, 7)
         

            if predIndex == 3:
                return self.precpred(self._ctx, 6)
         

            if predIndex == 4:
                return self.precpred(self._ctx, 5)
         

            if predIndex == 5:
                return self.precpred(self._ctx, 4)
         

            if predIndex == 6:
                return self.precpred(self._ctx, 12)
         

            if predIndex == 7:
                return self.precpred(self._ctx, 11)
         

            if predIndex == 8:
                return self.precpred(self._ctx, 3)
         

    def assignableExpr_sempred(self, localctx:AssignableExprContext, predIndex:int):
            if predIndex == 9:
                return self.precpred(self._ctx, 5)
         

            if predIndex == 10:
                return self.precpred(self._ctx, 4)
         

            if predIndex == 11:
                return self.precpred(self._ctx, 3)
         




