from setuptools import setup

setup(name='dist_test_oj',
      version='0.2',
      description='Gaussian distributions',
      packages=['dist_test_oj'],
      author = 'OJ Liseth',
      author_email = 'myemail@something.com',
      zip_safe=False)
