# Alkwaz
It is a library to handle some data problems
### to install:
'''bash
pip install Alkwaz
'''
