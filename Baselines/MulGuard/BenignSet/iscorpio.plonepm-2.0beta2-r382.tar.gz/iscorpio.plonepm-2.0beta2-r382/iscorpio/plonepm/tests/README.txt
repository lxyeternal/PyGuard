Testing doctest.

    >>> print 'hello doctest'
    hello doctest
