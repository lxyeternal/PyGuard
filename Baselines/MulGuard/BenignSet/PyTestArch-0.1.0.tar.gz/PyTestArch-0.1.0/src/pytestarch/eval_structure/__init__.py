"""This model contains abstract types as well as their implementations to represent the imported dependencies in a
queryable structure, such as graphs.
"""
