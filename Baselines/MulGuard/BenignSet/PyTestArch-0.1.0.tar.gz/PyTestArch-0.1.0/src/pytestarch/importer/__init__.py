"""Contains all functionality relating to loading and parsing python source code and creating custom import objects
representing the dependencies between the modules.
"""
