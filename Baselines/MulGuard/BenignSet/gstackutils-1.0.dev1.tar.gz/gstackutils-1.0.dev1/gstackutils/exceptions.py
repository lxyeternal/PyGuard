class ImproperlyConfigured(Exception):
    pass


class DatabaseNotPresent(Exception):
    pass
