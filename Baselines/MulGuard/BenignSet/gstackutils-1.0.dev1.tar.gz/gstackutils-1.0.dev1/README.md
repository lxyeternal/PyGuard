# gstackutils

Utilities for the `gstack` project.

## After cloning

- `docker-compose build`
- `make init`
