# prometry
A library for calculating protein geoemtry paramaters and searching based on criteria.
