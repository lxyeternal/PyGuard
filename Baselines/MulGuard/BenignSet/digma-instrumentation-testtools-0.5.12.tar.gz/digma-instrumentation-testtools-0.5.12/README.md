# Internal Use Only

Utility package to allow mocking time signatures with Tracing/Digma
