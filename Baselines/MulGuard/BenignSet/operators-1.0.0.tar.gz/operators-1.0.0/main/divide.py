def divide(a,b):
    div = a/b
    print(div)
    return