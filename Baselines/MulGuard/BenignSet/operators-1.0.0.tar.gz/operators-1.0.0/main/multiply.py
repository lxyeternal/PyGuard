def multiply(a,b):
    multiply = a*b
    print(multiply)
    return