# galgenmännchen

Ein einfaches Galgenmännchen-Spiel.
[Die Website](https://leo848.github.io/galgenmännchen)

Bugs gefunden? Sendet sie gern an [leoblume@gmx.de](mailto://leoblume@gmx.de)