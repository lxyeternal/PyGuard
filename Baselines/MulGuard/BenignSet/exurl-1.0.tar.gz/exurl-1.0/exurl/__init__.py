from exurl.split import split_url
from exurl.split import split_urls