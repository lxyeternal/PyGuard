# Conpacks
A bunch of packages from ur boy conacts

## How to build bro
```sh
python3 setup.py sdist bdist_wheel
```

## Install locally
```sh
pip3 install .
```

## Uploading...
```sh
twine check dist/*
twine upload dist/*
```
