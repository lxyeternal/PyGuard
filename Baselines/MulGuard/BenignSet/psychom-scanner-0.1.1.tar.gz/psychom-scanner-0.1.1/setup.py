from setuptools import setup

setup(
    name='psychom-scanner',
    version='0.1.1',
    author='killercd',
    author_email='killercd@gmail.com',
    description='psychom scanner is a python library which helps in security scanner creation',
    packages=['psychom_scanner'],
   
)
