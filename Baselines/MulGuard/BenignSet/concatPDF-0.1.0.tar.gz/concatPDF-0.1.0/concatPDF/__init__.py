from concatPDF.builder import Build
from concatPDF.quickstart import init
