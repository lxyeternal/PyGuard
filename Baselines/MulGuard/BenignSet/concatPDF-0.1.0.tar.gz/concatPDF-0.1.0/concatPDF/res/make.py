from concatPDF import Build

a = Build()
a.build()