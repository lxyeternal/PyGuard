from setuptools import setup, find_packages

setup(
    name="linnngraphx",
    version="0.1",
    packages=find_packages(),
    package_dir={"linnngraphx": "graphx"},
    install_requires=[],
)
