# -*- coding: utf-8 -*-
# Copyright (C) 2014 via680
#
# Licensed under a BSD 3-Clause License. See LICENSE file.

VERSION = (0, 1, 0)

__version__ = "".join([".".join(map(str, VERSION[0:3])), "".join(VERSION[3:])])

