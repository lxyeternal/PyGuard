django-admin-smoke-tests
==========

Run with ``./manage.py test django_admin_smoke_tests.tests``.
