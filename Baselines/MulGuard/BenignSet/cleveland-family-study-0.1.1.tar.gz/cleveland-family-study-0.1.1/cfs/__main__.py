#!/usr/bin/env python
from cfs.check_md5 import check_md5

if __name__ == "__main__":
    check_md5()
