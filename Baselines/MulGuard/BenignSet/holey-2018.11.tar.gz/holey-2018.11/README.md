# Holey

Geometry predicates written in python, optimised with numba.


