# noqa: D400
""".. include:: ../README.rst"""

__title__ = "asciidag"
__version__ = "0.1.0"
__copyright__ = "Copyright 2016 Sam Brightman"
__license__ = "MPL 2.0"
__author__ = "Sam Brightman"
__email__ = "sam.brightman@gmail.com"
__url__ = "https://www.github.com/sambrightman/asciidag"
