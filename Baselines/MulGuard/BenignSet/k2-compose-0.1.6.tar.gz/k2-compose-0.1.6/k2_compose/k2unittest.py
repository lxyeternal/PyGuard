#!/usr/bin/env python
# -*- coding: utf-8 -*-

import unittest


class TestK2PlatformMethods(unittest.TestCase):
    def test_ps(self):
        print 'test k2compose ps ok.'

    def test_up(self):
        print 'test k2compose up ok.'


if __name__ == '__main__':
    unittest.main()
