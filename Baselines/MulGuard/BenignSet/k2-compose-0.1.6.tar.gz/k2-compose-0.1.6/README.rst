k2-compose 是docker-compose的增强版
除了支持普通版docker-compose配置文件以外，还支持以下高级功能：
    1. 主机列表
    2. 容器列表
    3. 容器与主机对应关系
    4. 容器健康检查
    5. 容器之间的依赖关系
    6. 容器部署镜像的检查

详情查看https://tsui89.github.io
