# -*- coding: utf-8 -*-
"""
common package.
"""
