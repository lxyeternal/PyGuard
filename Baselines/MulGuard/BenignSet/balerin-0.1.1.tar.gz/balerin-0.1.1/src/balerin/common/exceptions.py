# -*- coding: utf-8 -*-
"""
common exceptions module.
"""


class BalerinException(Exception):
    """
    balerin exception.
    """
    pass
