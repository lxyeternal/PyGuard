def mensaje():
    return "El numero de matricula {} pertenece a: "

def error():
    return "El numero de la matricula {} no es valido."

