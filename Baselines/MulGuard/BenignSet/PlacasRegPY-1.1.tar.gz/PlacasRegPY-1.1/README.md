Este es un pequeño código de un programa para hacer identificación de matrículas vehiculares, para conocer a que tipo de vehículo/entidad le pertenece dicha matricula.



