
class Status(object):
    BUY = "1"
    SELL = "2"

    CN_MAP = {
        BUY: "买入",
        SELL: "卖出"
    }
