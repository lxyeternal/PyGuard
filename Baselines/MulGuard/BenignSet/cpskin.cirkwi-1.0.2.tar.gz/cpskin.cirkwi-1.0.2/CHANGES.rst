Changelog
=========


1.0.2 (2015-10-08)
------------------

- Forget pdb in precedent release... -_-'


1.0.1 (2015-10-08)
------------------

- brower\cirkwiview.py : getpage : patch "return data" with a good escape sequence in data string document.writer(... <\/script>") code.


1.0 (2015-10-08)
----------------

- Initial release.
  [boulch]
