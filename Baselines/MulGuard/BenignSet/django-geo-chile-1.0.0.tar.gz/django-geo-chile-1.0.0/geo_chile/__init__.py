default_app_config = "geo_chile.apps.GeoChileConfig"
