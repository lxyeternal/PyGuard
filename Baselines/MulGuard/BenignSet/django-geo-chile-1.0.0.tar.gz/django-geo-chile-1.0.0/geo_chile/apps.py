from django.apps import AppConfig


class GeoChileConfig(AppConfig):
    lable = "geo_chile"
    name = "geo_chile"
    verbose_name = "Django Geo Chile"
