def foo():
    print("Hello world")
