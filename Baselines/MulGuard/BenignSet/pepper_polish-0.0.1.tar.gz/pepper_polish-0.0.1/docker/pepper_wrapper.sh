#!/usr/bin/env bash

# RUN PEPPER SCRIPT
python3 /opt/pepper/$@