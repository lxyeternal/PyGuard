from .app_factory import create_app

api = create_app()
