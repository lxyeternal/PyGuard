from setuptools import setup
setup(
    name='pipenv-test-public-package',
    version='1.0',
    url='https://gist.github.com/ryanwilsonperkin/d8d591e08e0996414eea27b25f4bb68c',
    license='MIT',
    py_modules=['example_public'],
)
