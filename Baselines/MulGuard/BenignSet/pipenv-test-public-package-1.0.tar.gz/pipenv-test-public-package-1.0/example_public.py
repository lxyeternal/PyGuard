import sys
sys.stdout.write('This is a public package\n')
