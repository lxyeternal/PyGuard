from zope.interface import Interface

class IJalonBDD(Interface):
    """This interface defines the jalon properties."""
