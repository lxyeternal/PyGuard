from zope.interface import Interface

class IJalonProperties(Interface):
    """This interface defines the jalon properties."""
