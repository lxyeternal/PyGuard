from setuptools import setup

setup(
    name="slimt",
    version="0.0.0",
    description="",
    long_description="",
    url="https://github.com/jerinphilip/slimt",
    author="Jerin Philip",
    author_email="jerinphilip@live.in",
    packages=[],
    classifiers=["Development Status :: 1 - Planning"],
)
