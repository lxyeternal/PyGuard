from distutils.core import setup


setup(
    name ='nester_roger',
    version = '1.0.0',
    py_modules = ['nester_roger'],
    author = 'roger_czw',
    author_email = 'roger_czw@163.com',
    url = 'http://www.163.com',
    description = 'A simple printer of nested lists',
    )
    
