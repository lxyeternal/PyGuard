# coding=utf-8

region_name = ""
access_key = ""
access_secret = ""
endpoint = None

app_id = ""
acl_ak = ""
acl_access_secret = ""
