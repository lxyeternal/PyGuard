![penterepTools](https://www.penterep.com/external/penterepToolsLogo.png)


## PTAXFR
> DNS Zone Transfer Testing Tool

Script finds authoritative nameservers for specified domain(s). AXFR record (Zone Transfer) is sent to each nameserver and result is retrieved. ptaxfr supports mass domain testing.


## Installation

```
pip install ptaxfr
```

## Add to PATH
If you cannot invoke the script in your terminal, its probably because its not in your PATH. Fix it by running commands below.
```bash
echo "export PATH=\"`python3 -m site --user-base`/bin:\$PATH\"" >> ~/.bashrc
source ~/.bashrc
```

## Usage examples
```
ptaxfr -d example.com
ptaxfr -d example1.com example2.com example3.com
ptaxfr -f domain_list.txt
```

## Options
```
-d   --domain            <domain>   Test domain
-f   --file              <file>     Test domains from file
-pd  --print_dns                    Print DNS records (default option)
-ps  --print_subdomains             Print subdomains only
-V   --vulnerable_only              Print only vulnerable domains
-s   --silent                       Silent mode (show result only)
-t   --threads           <threads>  Number of threads (default 20)
-j   --json                         Enable JSON output
-v   --version                      Show script version and exit
-h   --help                         Show this help message and exit
```

## Dependencies
- dnspython
- ptlibs
- ptthreads

## Version History

* 0.0.1
    * Alpha release

## Licence

Copyright (c) 2020 HACKER Consulting s.r.o.

ptaxfr is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

ptaxfr is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with ptaxfr.  If not, see <https://www.gnu.org/licenses/>.

## Warning

You are only allowed to run the tool against the websites which
you have been given permission to pentest. We do not accept any
responsibility for any damage/harm that this application causes to your
computer, or your network. Penterep is not responsible for any illegal
or malicious use of this code. Be Ethical!