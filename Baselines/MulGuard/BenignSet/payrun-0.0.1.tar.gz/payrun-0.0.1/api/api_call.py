def api_call():
    return 'call'