""" Test celery configuration
"""
import pytest


class TestCelery:
    """ Test Celery configuration
    """

    # TODO Need to get an actual test suite set up for celery configuration
    def test_celery_chained_task(self):
        """ Test turning on/off tools
        """
        pass
