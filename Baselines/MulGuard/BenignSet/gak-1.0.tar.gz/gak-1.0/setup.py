from distutils.core import setup

setup(
    name = "gak",
    version = "1.0",
    packages = ["gak"],
    license = "MIT",
    long_description = open("README.txt").read()
)