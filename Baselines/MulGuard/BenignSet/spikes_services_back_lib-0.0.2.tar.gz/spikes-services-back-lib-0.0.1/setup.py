import setuptools

setuptools.setup(
    name='spikes-services-back-lib',
    version='0.0.1',
    author='Michael Rubinfeld',
    description='various tools used for the Spikes algorithms',
    packages=['src']
)