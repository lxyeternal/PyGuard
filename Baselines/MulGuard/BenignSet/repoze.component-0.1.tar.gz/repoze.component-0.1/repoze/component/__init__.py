from repoze.component.registry import Registry # API
from repoze.component.registry import providedby # API
from repoze.component.registry import directlyprovidedby # API
from repoze.component.registry import provides # API
from repoze.component.registry import ALL # API

    
