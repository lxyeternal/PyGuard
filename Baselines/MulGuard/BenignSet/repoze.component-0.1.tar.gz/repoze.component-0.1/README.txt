repoze.component README
=======================

:mod:`repoze.component` is a package that software developers can use
to provide configurability and pluggability to their applications.
:mod:`repoze.plugin` provides a generalized indirection mechanism
which can be used to provide plugin points to integrators or other
developers who may wish to provide alternate implementations of
application logic or configuration values.

See docs/index.rst for more information.
