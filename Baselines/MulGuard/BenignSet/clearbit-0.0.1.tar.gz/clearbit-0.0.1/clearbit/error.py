class ClearbitError(Exception):
    pass

class ParamsInvalidError(ClearbitError):
    pass
