from aws_kinesis_consumer import main

if __name__ == '__main__':
    main()
