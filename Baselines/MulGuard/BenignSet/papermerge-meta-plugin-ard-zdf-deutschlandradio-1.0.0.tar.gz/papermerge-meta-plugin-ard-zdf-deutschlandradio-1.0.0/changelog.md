# Changelog

## [1.0.0] - 24 July 2020

### Initial commit

