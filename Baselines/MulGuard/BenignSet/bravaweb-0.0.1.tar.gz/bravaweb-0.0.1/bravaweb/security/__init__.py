#-*- coding: utf-8 -*-

from bravaweb.security import origin
