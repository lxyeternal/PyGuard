
from bravaweb.response.lib.object import ResponseObject


class Png(ResponseObject):
    pass
