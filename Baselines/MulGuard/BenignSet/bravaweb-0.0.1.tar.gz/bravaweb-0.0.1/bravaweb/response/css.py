from bravaweb.response.lib.object import ResponseObject


class Css(ResponseObject):
    pass
