
from bravaweb.response.lib.object import ResponseObject


class Mp4(ResponseObject):
    pass
