
from bravaweb.response.lib.object import ResponseObject


class Jpg(ResponseObject):
    pass
