from bravaweb.response.lib.object import ResponseObject


class Csv(ResponseObject):
    pass
