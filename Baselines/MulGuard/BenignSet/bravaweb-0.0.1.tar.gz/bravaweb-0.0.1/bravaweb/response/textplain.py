
from bravaweb.response.lib.object import ResponseObject


class TextPlain(ResponseObject):
    pass
