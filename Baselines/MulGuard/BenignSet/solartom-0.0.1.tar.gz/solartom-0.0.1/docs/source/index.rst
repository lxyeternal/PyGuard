Welcome to solartom's documentation!
====================================

Documentation will be created soon. 

.. toctree::
   :maxdepth: 2
   :caption: Contents:


Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`
