# What I have done at startup:
# pip install --user setuptools wheel twine
# Crated dirs and files
# License: Use templates from: https://choosealicense.com/licenses/gpl-3.0/#
# Build distributions (2 packages):     python setup.py <source_distribution> <build_distribution>
#                                       python setup.py sdist bdist_wheel

This is the homepage of our project.