from setuptools import setup

setup(name='snd_probability',
      version='0.1',
      description='Gaussian and Binomial distributions',
      packages=['snd_probability'],
      author = 'Divyesh Mangroliya',
      zip_safe=False)
