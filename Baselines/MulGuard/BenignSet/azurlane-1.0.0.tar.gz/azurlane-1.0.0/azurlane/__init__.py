__version__ = '1.0.0'
__authors__ = 'Noel, Spimy'

from .azurapi import AzurAPI