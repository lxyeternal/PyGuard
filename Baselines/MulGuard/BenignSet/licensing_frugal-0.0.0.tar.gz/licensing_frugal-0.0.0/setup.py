# This package is empty, just a placeholder to prevent dependency
# confusion attacks.

from setuptools import setup

setup(
    name='licensing_frugal',
    version='0.0.0',
    description='Placeholder to prevent dependency confusion',
    url='https://github.com/Workiva/',
    author='Matthew Belisle',
    author_email='matthew.belisle@workiva.com',
    license='MIT',
    packages=('licensing_frugal',),
)
