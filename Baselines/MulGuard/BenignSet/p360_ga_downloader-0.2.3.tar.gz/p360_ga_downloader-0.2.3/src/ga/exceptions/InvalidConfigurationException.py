class InvalidConfigurationException(Exception):
    """ Used for invalid credentials situations """
