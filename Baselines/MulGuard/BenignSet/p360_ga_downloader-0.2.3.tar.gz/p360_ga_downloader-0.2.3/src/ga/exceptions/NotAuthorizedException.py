class NotAuthorizedException(Exception):
    """ Used for Not-Authorized situations """
