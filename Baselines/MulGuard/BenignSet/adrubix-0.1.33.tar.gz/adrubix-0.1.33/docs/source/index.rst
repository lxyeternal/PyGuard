.. complex documentation master file, created by
   sphinx-quickstart on Tue Aug 30 09:22:46 2022.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

Complex documentation
======================

Complex is a class implementing the notion of complex number, used as a template for public packages

Contents
========
.. toctree::
   :maxdepth: 1

   readme
   complex


