# Contributing

Anyone can open Issues, both for bug reporting but also for feature suggestion. They will be treated quickly. However, pull requests are discouraged.
