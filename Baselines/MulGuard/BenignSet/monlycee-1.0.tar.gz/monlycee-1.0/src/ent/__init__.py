'''
An API wrapper for ent.iledefrance.fr.

https://github.com/Egsagon/monlycee-net-api
'''

__title__ = 'monlycee'
__author__ = 'Egsagon'
__license__ = 'GPL-3.0'
__version__ = '1.0'

from ent.core import ENT

# EOF