__version__ = '0.1.0'


def main():
    while True:
        print("revolution ")
