===============================
chicken
===============================

.. image:: https://badge.fury.io/py/chicken.png
    :target: http://badge.fury.io/py/chicken
    
.. image:: https://travis-ci.org/rgbkrk/chicken.png?branch=master
        :target: https://travis-ci.org/rgbkrk/chicken

.. image:: https://pypip.in/d/chicken/badge.png
        :target: https://crate.io/packages/chicken?version=latest


The Chicken came in the egg

* Free software: BSD license
* Documentation: http://chicken.rtfd.org.

Features
--------

* TODO