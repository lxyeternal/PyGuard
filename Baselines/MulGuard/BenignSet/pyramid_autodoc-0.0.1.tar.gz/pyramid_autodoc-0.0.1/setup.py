import setuptools

setuptools.setup(
    setup_requires=['pbr', 'setuptools-git'],
    pbr=True
)
