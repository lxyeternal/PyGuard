from .activate_virtualenv import activate_virtualenv

__all__ = ["activate_virtualenv"]
