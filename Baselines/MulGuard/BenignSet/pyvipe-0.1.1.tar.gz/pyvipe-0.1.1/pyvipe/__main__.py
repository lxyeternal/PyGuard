#!/usr/bin/env python

import sys
from .pyvipe import pyvipe

def main():
    pyvipe()

if __name__ == '__main__' :
    sys.exit(main())
