# Archivista

Transformador de contenidos a la estructura y metadatos que requiere Pelican; así puede mantenerse un depósito sencillo en la nube con directorios y archivos (con Nextcloud por ejemplo) para generar ramas (directorios y archivos que puede usar Pelican) en _content_.
