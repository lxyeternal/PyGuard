IngeoDash
==================================
.. image:: https://github.com/INGEOTEC/IngeoDash/actions/workflows/test.yaml/badge.svg
		:target: https://github.com/INGEOTEC/IngeoDash/actions/workflows/test.yaml

.. image:: https://coveralls.io/repos/github/INGEOTEC/IngeoDash/badge.svg?branch=develop
		:target: https://coveralls.io/github/INGEOTEC/IngeoDash?branch=develop

.. image:: https://badge.fury.io/py/IngeoDash.svg
		:target: https://badge.fury.io/py/IngeoDash


.. code-block:: bash

    python -m IngeoDash