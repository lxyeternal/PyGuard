import setuptools

setuptools.setup(use_scm_version={"write_to": "snip/_version.py"})
