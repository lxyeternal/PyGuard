"""Init."""
import nest_asyncio

nest_asyncio.apply()
__version__ = "0.1.0a1"
