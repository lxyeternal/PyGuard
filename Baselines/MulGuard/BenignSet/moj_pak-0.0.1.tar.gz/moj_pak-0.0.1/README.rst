adam is cool
