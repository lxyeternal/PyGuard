def three():
    print('three')