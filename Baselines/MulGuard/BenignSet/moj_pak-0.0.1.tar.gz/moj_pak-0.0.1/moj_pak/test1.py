def one():
    print('one')


def two():
    print('two')