RETRIEVER_MODULE = "genai_stack.retriever"
RETRIEVER_CONFIG_KEY = "retriever"


class Retriever:
    LANGCHAIN = "langchain"


AVAILABLE_RETRIEVER_MAPS = {Retriever.LANGCHAIN: "langchain/LangChainRetriever"}
