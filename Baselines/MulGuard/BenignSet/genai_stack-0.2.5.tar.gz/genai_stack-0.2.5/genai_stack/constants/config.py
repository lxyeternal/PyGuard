GLOBAL_REQUIRED_FIELDS = ["name"]

CUSTOM_MODEL_KEY_NAME = "custom"


class CUSTOM_MODEL_CONFIG_FIELDS:
    CLASS_NAME = "class_name"
    FILE_PATH = "path"
    HOST = "host"
    PORT = "port"
    RESPONSE_CLASS = "response_class"
