PROMPT_ENGINE_MODULE = "genai_stack.prompt_engine"
PROMPT_ENGINE_CONFIG_KEY = "prompt_engine"


class Engine:
    ENGINE = "engine"


AVAILABLE_PROMPT_ENGINE_MAPS = {Engine.ENGINE: "engine/PromptEngine"}
