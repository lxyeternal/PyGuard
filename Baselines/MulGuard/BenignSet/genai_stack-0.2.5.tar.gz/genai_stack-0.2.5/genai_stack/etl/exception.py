from genai_stack.exception import GenAIStackException


class GenAIStackETLException(GenAIStackException):
    pass
