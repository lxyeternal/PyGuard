from genai_stack.exception import GenAIStackException


class GenAIVectorDBException(GenAIStackException):
    """VectorDB Exception"""

    pass
