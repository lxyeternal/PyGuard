"""Top-level package for genai_stack."""

__author__ = """AI Planet Tech Team"""
__email__ = "support@aiplanet.com"
__version__ = "0.2.5"

import os

genai_stack_DEBUG = bool(os.environ.get("genai_stack_DEBUG"))
