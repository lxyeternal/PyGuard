class GenAIStackException(Exception):
    pass
