from .quotes import macros, q  # just testing relative macro-import

#from . import macros, aaa
