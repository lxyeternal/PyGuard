"""Unit test package for demquery."""
