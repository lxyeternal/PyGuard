# Changelog

## [0.1.0] - 2019-11-27

- Initial release on PyPI
