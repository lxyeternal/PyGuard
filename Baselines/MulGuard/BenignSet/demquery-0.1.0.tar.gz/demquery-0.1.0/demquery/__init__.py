"""Top-level package for demquery."""

__author__ = """Kyle Barron"""
__email__ = 'kylebarron2@gmail.com'
__version__ = '0.1.0'

from .demquery import Query
