# mkdocs-bioinformatic-izsam-theme

This is an MkDocs theme written to layout the documentation provided by Bioinformatic Unit of the Istituto Zooprofilattico Sperimentale dell'Abruzzo e del Molise "G. Caporale".

#### Important!

The theme is intended to work with the following **mkdocs-izsam-search** a plugin to extend search functions [https://pypi.org/project/mkdocs-izsam-search/](https://pypi.org/project/mkdocs-izsam-search/)

```bash
pip install mkdocs-izsam-search
```
