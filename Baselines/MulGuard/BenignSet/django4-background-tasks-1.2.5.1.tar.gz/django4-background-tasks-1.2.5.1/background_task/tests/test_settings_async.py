# -*- coding: utf-8 -*-
from .test_settings import *

BACKGROUND_TASK_RUN_ASYNC = True
