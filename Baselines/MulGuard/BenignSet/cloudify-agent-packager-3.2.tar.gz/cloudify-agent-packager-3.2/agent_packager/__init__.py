__all__ = ['agent_packager']
__author__ = 'Gigaspaces'
__version__ = '0.0.1'
