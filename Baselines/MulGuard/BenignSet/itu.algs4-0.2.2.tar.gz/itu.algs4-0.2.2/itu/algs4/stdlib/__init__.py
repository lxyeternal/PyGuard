"""
This module is based on the code at
https://introcs.cs.princeton.edu/python/code/
written by Robert Sedgewick, Kevin Wayne, and Robert Dondero
"""
