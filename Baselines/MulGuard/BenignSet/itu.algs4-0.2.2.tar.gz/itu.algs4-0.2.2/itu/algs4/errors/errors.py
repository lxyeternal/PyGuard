# Created for BADS 2018
# See README.md for details
# Python 3


class NoSuchElementException(Exception):
    pass


class IllegalArgumentException(Exception):
    pass


class UnsupportedOperationException(Exception):
    pass
