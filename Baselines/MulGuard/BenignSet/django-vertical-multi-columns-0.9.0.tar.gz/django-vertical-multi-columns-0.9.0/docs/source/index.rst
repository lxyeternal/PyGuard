Django-Vertical-Multi-Columns
-----------------------------

Be nice to your end user ... minimize the scrolling and paging required with vertically sorted side-by-side columns in your Django templates.

.. toctree::
   :maxdepth: 2
   :caption: User Guide

   guide/about
   guide/install
   guide/usage
   guide/example
