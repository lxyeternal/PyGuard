""" Django Vertical Multi Columns Generator

Generates a JSON-formatted list of data to enable display in
vertically sorted side-by-side columns in a Django template.

"""
__version__ = "0.9.0"
