"""Version of slack_bots package."""

from version_query import predict_version_str

VERSION = predict_version_str()
