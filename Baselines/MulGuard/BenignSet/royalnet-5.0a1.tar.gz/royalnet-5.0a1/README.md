# `royalnet` **alpha**

The fifth rewrite of [Royalnet](https://github.com/Steffo99/royalnet/)!

It includes a lot of miscellaneous useful stuff.

[Documentation available here.](https://steffo99.github.io/royalnet/html/)
