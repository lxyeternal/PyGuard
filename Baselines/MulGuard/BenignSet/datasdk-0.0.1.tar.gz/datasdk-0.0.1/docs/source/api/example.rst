Example
==============


.. code-block:: bash

                pip install chaneme[extra]


