# SPDX-FileCopyrightText: 2023-present Xavier Petit <nuxion@gmail.com>
#
# SPDX-License-Identifier: MIT
__version__ = '0.0.1'
