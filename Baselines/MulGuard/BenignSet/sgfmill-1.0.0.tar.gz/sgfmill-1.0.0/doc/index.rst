*******
Sgfmill
*******

.. toctree::
   :maxdepth: 3
   :titlesonly:
   :includehidden:

   intro
   examples
   property_types
   sgfmill_package
   properties
   encoding
   parsing
   porting
   install
   contact
   changes
   licence
   glossary

* :ref:`genindex`
* :ref:`search`

