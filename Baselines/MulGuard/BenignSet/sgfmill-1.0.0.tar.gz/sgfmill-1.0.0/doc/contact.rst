Contact
=======

Sgfmill's home page is http://mjw.woodcraft.me.uk/sgfmill/.

Updated versions will be made available for download from that site, as well
as the `Python package index`__.

.. __: https://pypi.python.org/pypi/sgfmill/

I'm happy to receive any bug reports, suggestions, patches, questions and so
on at <matthew@woodcraft.me.uk>.

There is also a Github repository at https://github.com/mattheww/sgfmill.
