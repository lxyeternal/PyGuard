Changes
=======


Sgfmill 1.0 (2017-04-17)
------------------------

* Python 3 port of the SGF code from Gomill__ 0.8.

* Added the :mod:`.sgf_board_interface` module.

.. __: https://mjw.woodcraft.me.uk/gomill/

