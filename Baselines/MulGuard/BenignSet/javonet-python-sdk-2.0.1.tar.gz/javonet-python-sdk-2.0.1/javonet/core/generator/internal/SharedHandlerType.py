from enum import Enum


class SharedHandlerType(Enum):
    ARGUMENT_NAME = 0,
    METHOD_BODY = 1,
    CLASS_NAME = 2,
    METHOD_NAME = 3,
    MODIFIER = 4,
    TYPE = 5,
    CLAZZ_INSTANCE = 6,
    RETURN_TYPE = 7
