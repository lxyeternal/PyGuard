didelcli
========

Didel_ for the command-line (work in progress).

.. _Didel: http://didel.script.univ-paris-diderot.fr/

