# Fibonacci sum

## Install

```
pip install -i https://test.pypi.org/simple/fibonacci-sum
```

## How to use

```
import fibonacci_sum as fbs

fibonacci_sum = fbs.fibosum(5)

print(fibonacci_sum)
# 13
```