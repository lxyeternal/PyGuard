# -*- coding: utf-8 -*-
"""
Pygifconvt: a very serious Python library for image to gif converter

"""
__title__ = "Pygifconvt"
__author__ = "motive"
__license__ = "MIT License"
__copyright__ = "Copyright 2021 motive"