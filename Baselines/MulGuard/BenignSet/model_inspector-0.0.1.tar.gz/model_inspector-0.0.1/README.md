# nbdev template

Use this template to more easily create your nbdev project.

