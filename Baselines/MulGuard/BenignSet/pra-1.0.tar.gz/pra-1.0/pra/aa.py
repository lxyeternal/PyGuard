
def fun_aa():
    print("这个是aa")
