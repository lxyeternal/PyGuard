def fun_b():
    print("这个是bb")