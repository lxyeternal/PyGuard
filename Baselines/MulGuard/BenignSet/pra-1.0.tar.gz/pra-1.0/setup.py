from distutils.core import setup
setup( name='pra',
# 对 外 我 们 模 块 的 名 字
version='1.0',# 版 本 号
description='这是第一个对外发布的模块，测试哦',# 描 述
author='lucky',# 作 者
author_email='1678928550@qq.com',# 邮箱
py_modules=['pra.aa','pra.bb']# 要 发 布 的 模 块
)