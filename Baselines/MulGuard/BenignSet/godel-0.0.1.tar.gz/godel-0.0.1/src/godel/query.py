
# GraphQL query objects



class Query:

    def __init__(self):






