# PhindersKeepers
This is a simple python script designed to parse data from inphared.

## Install
```
pip install PhindersKeepers==0.0.1
```

## Usage
```

```

## Example using data from 1May2023
```

```


## Output

## Citation
