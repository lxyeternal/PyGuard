from src.response import Response

response = Response()
print(response.Success())