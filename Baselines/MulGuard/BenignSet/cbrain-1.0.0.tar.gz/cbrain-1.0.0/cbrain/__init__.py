#
# Developer(s): Grigori Fursin, https://fursin.net
#

__version__ = "1.0.0"
