#
# Developer(s): Grigori Fursin, https://fursin.net
#

from . import main

main.cli()
