Radicale Dovecot Auth
#####################

Dovecot authentication plugin for Radicale.

Installation
============

.. code::

        pip3 install radicale-dovecot-auth


Configuration
=============

.. code::

        [auth]
        type = radicale_dovecot_auth

        auth_socket = path_to_socket
