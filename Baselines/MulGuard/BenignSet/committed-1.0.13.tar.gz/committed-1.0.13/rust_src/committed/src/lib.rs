#![allow(clippy::unnecessary_wraps)]

mod style;

pub mod conventional;
pub mod no_style;

pub use style::*;
