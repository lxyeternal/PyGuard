"""
A Formal Logic Framework for various applications
"""
