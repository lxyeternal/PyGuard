# Flask-Account

User account handling boilerplate for Flask.

Creates User and Role models with encrypted columns for sensitive user data.