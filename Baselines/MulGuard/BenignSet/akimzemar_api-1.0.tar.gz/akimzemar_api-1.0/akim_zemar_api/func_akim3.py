def plusplus(a):
    return a + 100



_author_ = 'Akim Zemar'
_version_ = '1.0'
_email_ = 'akim.zemar@gmail.com'