import os

test_data_directory = os.environ.get('PYTESTGEN_TEST_DATA_DIRECTORY', 'test-data')
serialisation_type = 'json'
filename_count_limit = 10
