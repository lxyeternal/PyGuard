# simple_test_generator
Automated, comprehensive and clean pytest test cases.


## Description
Helps you reach 100% test coverage with real-world test cases.
Tests that are generated "just work", i.e they are clean, unaware of implementation details, and doesn't require active maintenance.

It works well if your functions are [deterministic](https://en.wikipedia.org/wiki/Deterministic_algorithm) (e.g pure).
> If not, then you should probably make them so!

It's DDT for pytest (development-driven testing :nerd_face:)

## why?
Too tedious/hard to generate custom data for your application?

- save time by having tests generated for you :tada:
- dramatically increase test code coverage with little effort
- write more maintainable tests by separating code and data
- helps you organise your test code consistently in new projects, or:
- replace your existing disorganised test code :+1:

# Using in normal runs

# Using while running tests


then, confirm that your test cases expected value are correct.

finally, install it only as a test dependency.

# Demos
See botostubs going from 0 to 99% under 20 seconds!


# Releasing on PyPI
- `pipenv shell`
- `flit build`
- `flit publish`

Enter password when prompted.

# TODO
<!---
# TODO: in-built functions imported in a project module should be excluded but isn't.
# TODO: can we support object's methods as well?
# TODO: test with kwargs and optional parameters
# TODO: save this in test_simple_test_generator_test_cases.py
# TODO: add real-world examples of running real projects with it (like pytest itself!)
# TODO: tests may be deserialising list but asserting it against a generator
E         - <generator object iter_matching_entrypoints at 0x7ffb22bd3890>
E         + <list_iterator object at 0x7ffb23dfc700>

-->

## Docs
Running over and over write test cases in new files to avoid overwriting your previous test cases. The filenames are appended with -00, -01, ... for up to 10 files.

If your function arguments are not serialisable, then test cases won't be generated. You will see an error in the logs for that function.

# Notes
This project uses pickling to load the test data. If you're the one generated test data, then it should be fine loading it during tests. Otherwise, don't load untrusted test data. 

## TODO
- Minor issue: functions in your main module may be loaded twice, creating identical test cases twice for that function.

## Related
These projects resemble this one but mine requires much less effort on your part and generates even less boilerplate :blush:
- https://smarie.github.io/python-pytest-cases/
- https://github.com/Figglewatts/pytestgen

# Copyright
Released under the MIT licence. See file named [LICENCE](LICENCE) for details.

