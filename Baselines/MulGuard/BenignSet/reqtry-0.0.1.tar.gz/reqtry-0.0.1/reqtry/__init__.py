import requests
from .reqtry import request, get, post, put, patch, delete, options, head
