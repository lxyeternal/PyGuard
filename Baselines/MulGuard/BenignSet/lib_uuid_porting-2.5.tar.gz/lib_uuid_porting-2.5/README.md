# Just porting Lib/uuid.py to Python 2.4 and earlier.
