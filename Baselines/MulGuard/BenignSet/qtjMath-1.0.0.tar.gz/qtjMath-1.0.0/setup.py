#coding=utf-8
from distutils.core import setup
setup(
    name='qtjMath',
    version='1.0.0',
    description='这是我的第一个对外发布的模块，测试用的。',
    author='qiantianjiang',
    author_email='qiantianjiang@163.com',
    py_modules=['qtjMath.qtjjishuang']
)