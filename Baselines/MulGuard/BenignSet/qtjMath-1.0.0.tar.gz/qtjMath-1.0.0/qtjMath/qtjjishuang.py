def add(a,b):
    print('qtjjishuang add')
    return a+b

def minus(a,b):
    print('qtjjishuang minus')
    return a-b

def multiple(a,b):
    print('qtjjishuang multiple')
    return a*b

def division(a,b):
    print('qtjjishuang division')
    return a/b