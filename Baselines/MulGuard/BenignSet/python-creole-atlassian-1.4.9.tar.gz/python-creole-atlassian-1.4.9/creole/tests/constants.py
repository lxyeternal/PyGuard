from pathlib import Path

import creole


CREOLE_PACKAGE_ROOT = Path(creole.__file__).parent.parent
