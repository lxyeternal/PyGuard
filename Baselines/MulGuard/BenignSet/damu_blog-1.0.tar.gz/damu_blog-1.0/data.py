'''
数据定义模块
    定义各种项目中临时需要的数据
'''
authors = dict()

articles = dict()

current_login = None
