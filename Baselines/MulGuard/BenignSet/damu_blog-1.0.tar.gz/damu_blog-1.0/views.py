'''
界面菜单模块
    专门定义各种界面展示相关函数的
'''
def show_login():
    pass


def show_index():
    pass
