'''
数据模型定义模块
    专门用于定义项目中需要的各种类型
'''
class Author:
    pass


class Article:
    pass


class Comment:
    pass


class Album:
    pass


class Photo:
    pass

