'''
管理类型定义模块
    主要针对Models类型的对象进行增删改查的处理
'''
class AuthorManager:
    pass


class ArticleManager:
    pass