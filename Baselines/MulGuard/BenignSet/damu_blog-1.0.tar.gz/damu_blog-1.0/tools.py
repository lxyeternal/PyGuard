'''
功能函数模块
'''
def exit_system():
    pass


def get_current_time():
    pass


def encrypt(src, dst, etype='md5'):
    pass
