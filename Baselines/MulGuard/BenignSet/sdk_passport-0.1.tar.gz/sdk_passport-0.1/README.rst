=====================
passport verification
=====================

This is a Django application that does passport verification using camera.


Quick start
===========

1. To use this application, add ``sdk_passport`` to your INSTALLED_APPS in your Django settings file:

INSTALLED_APPS = [
    ...
    'sdk_passport'
    
]
