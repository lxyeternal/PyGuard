if __name__ == "__main__":
    from ARgorithmToolkit.cli import cmd
    cmd()