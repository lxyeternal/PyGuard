"""Módulo dos verificadores"""
__version__ = '0.2.0'

from .cnpj import CNPJ, CNPJ_async
from .cpf import CPF, CPF_async
