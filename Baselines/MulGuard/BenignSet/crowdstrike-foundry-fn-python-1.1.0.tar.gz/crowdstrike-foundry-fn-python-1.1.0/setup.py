from setuptools import setup
from setuptools.command.install import install
import requests


setup(name='crowdstrike-foundry-fn-python',
      version='1.1.0',
      description='test',
      author='test',
      license='MIT',
      zip_safe=False
)

