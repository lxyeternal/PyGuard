def add(a,b):
  return(a+b)

def dispInfo():
  print("Hi this is a demo code by kaustubh sadekar")

