import setuptools

setuptools.setup(name = 'calc1', packages = ['kps_calc'],version = '0.1', author = 'Kaustubh sadekar')

