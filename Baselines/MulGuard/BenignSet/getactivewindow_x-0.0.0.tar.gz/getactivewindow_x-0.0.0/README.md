# getactivewindow-x
Separate component to get information on the active window in X. Requires the executable xdotool (and xprop to get the window class).
