# [Django Sofa]

**When Django pretends to be CouchDB.**

Full documentation for the project will be available soon ... I hope ...
Full test coverage for the project will ... ok, you get the idea.

---