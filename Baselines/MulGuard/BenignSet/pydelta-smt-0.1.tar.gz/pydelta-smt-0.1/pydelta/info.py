
PROJECT_NAME = 'pyDelta'
VERSION = '0.1'
AUTHOR = 'Gereon Kremer'
AUTHOR_EMAIL  = 'gereon.kremer@gmail.com'
REPOSITORY = 'https://github.com/nafur/pydelta'
