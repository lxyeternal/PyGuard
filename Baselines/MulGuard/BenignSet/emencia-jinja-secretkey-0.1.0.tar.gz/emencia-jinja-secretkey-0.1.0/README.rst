emencia-jinja-secretkey
=======================

A very simple application to package a Jinja extension able to generate secret key.

Install
*******

    pip install emencia-jinja-secretkey

Then you can use this extension from its path ``jinja_secretkey.secret_key.SecretExtension``.
