from pyekonlib.Misc import AirconStateData, AirconMode

