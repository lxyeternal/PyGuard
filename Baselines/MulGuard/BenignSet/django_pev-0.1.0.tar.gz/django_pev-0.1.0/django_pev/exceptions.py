class PevException(Exception):
    """Base Exception"""

    pass
