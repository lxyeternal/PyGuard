#!/usr/bin/env python

# -*- coding: utf-8 -*-

from setuptools import find_packages, setup

setup(

    name='pretty-confusion-matrix-for-kaggle',
    packages=find_packages(),
    version='1.0.0',
    description='Este pacote é um clone praticamente idêntico da biblioteca pretty-confusion-matrix',
    long_description='''Ao tentar instalar a lib pretty-confusion-matrix no kaggle, foi gerado um erro de dependencia do 'sklearn'. 
    Para resolver apenas clonei o repo inteiro e alterei para o nome da dependencia para 'scikit-learn' que é mais atual. Portanto,
    os créditos deste pacote são inteiramente dos criadores do pacote original pretty-confusion-matrix.''',
    author='Rodrigo Rosa',
    author_email='',
    url='https://github.com/rsrodrigo/pretty-print-confusion-matrix',
    install_requires=['', ''],
    license='MIT',
    keywords=['confusion matrix', 'confusion matrix matlab'],
    classifiers=[
        'Intended Audience :: Developers',
        'License :: OSI Approved :: MIT License',
        'Natural Language :: English',
        'Programming Language :: Python :: 2',
        'Programming Language :: Python :: 3',
    ],

)
