# -*- coding: utf-8
from django.apps import AppConfig


class ContributionsDjangoConfig(AppConfig):
    name = "contributions_django"
