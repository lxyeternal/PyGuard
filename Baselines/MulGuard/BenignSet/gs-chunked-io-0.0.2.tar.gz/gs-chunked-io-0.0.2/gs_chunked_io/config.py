default_chunk_size = 32 * 1024 * 1024
gs_max_parts_per_compose = 32
