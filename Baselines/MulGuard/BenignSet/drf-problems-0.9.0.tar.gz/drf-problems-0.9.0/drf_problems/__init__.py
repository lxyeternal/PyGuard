__title__ = 'DRF Problems'
__version__ = '0.9.0'
__author__ = 'shivanshs9'
__license__ = 'MIT'

VERSION = __version__


PROBLEM_CODE_CHOICES = [
]


PROBLEM_EXCEPTION_MAP = {
}

default_app_config = 'drf_problems.apps.DrfProblemsConfig'
