"Main interface for sesv2 service"

from mypy_boto3_sesv2.client import Client


__all__ = ("Client",)
