from spaceone.core.error import *


class ERROR_EXIST_CLOUD_SERVICE_TYPE_IN_PROVIDER(ERROR_BASE):
    _message = 'Cloud service type "{name}" is exist in provider ({provider}).'
