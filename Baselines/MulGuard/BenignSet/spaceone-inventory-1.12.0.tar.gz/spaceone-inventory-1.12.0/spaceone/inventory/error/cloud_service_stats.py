from spaceone.core.error import *


class ERROR_INVALID_DATE_RANGE(ERROR_INVALID_ARGUMENT):
    _message = '{reason}'
