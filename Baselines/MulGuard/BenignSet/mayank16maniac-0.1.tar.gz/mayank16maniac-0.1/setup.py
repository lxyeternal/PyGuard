from setuptools import setup

setup(name='mayank16maniac',
      version='0.1',
      description='Gaussian distributions',
      packages=['mayank16maniac'],
      zip_safe=False)
