==============
Diff & Patch
==============

A simple python package which serves as a framework for diffing and patching complex objects. Inspired by Shreyas Kulkarni and git diff and patch.

Quick links
===========
    PyPi: `https://pypi.org/project/diff-and-patch/ <https://pypi.org/project/>`_


    Source: `https://github.com/thulasi-ram/diff-and-patch <https://github.com/thulasi-ram/diff-and-patch>`_


    Docs: `https://github.com/thulasi-ram/diff-and-patch <https://github.com/thulasi-ram/diff-and-patch>`_

