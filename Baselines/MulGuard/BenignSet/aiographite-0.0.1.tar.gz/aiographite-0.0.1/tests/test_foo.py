def test_foo():
    assert True
