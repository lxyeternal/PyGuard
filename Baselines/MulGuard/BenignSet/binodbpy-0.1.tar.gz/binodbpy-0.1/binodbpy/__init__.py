# -*- coding: utf-8 -*-
"""
Created on Thu Jun 11 18:06:47 2020

@author: binod
"""

def myadd(x,y):
    return(x+y)