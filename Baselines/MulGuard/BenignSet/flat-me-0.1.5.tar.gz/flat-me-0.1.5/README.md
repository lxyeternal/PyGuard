Very simply, Flat_Me is a cli-driven tool for file conversion and applying common data transformations.

Written entirely in python as a way to ditch unsecure file conversion website or the necessity to code anything.

## Setup and Usage

After installing the package straight from pypi, just type the following in your terminal:

`flat-me --path or -p= <path of the file you want to transform>`

then follow the instructions and you'll be all set!
