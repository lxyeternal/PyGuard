# -*- coding: utf-8 -*-
NAME = "notification"
