# -*- coding: utf-8 -*-


class DataError(Exception):
    """
    Generic exception type for errors in the data.
    """
    pass
