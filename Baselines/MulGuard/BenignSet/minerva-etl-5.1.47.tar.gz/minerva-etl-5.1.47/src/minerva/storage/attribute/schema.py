# -*- coding: utf-8 -*-
from minerva.db.query import Table


name = "attribute"

attribute_store = Table(name, "attribute_store")
attribute = Table(name, "attribute")
