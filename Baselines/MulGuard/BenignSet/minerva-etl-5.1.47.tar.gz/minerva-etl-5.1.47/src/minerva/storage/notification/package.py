

class Package:
    def __init__(self, attribute_names, rows):
        self.attribute_names = attribute_names
        self.rows = rows
