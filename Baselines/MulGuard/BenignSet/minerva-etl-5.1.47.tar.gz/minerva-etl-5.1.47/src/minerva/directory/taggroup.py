class TagGroup:
    def __init__(self, id, name, complementary):
        self.id = id
        self.name = name
        self.complementary = complementary
