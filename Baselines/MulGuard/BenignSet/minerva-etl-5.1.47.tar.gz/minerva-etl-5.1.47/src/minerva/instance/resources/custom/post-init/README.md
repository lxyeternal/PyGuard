# Custom post-init

Place any SQL scripts here that need to be run AFTER all regular Minerva
constructs such as trend stores and attribute stores have been initialized.

An example of this is a schema with custom tables and functions for things
like reporting. 