# Attribute Store Definitions

This directory contains attribute store definitions.