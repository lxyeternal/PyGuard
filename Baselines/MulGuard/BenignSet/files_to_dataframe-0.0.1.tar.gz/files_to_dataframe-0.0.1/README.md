# Files to DataFrame

This is a simple  package to load 7 days files to dataframe.