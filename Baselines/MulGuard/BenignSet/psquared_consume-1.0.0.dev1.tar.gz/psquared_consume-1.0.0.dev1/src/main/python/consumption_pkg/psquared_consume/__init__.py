"""Declares public members of this module"""

from .consumption import PSquaredConsumption
