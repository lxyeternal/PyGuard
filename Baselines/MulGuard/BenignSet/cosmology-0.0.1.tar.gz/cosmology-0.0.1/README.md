cosmology
=========

A Python package for cosmology.
