This is a intermediate Mathematics module with will provide you with these functions:

1. sum()
     adds two numbers

2. suminf()
     adds multiple numbers

3. subtract()
     subtracts two numbers

4. multiply()
     multiplies two numbers

5. divide()
     divides two numbers

6. average()
     finds average of two numbers

7. prob()
     finds the probabilty for event

8. areaTri()
     finds area of triangle by 1/2*base*height method

9. areaRect()
     finds area of rectangle by l*b

10. pythagoras()
     finds either base,perpendicular or hypotenuse of the basis of value given to it.
     if "x" is given value for base, it will find base using pythagoras theorem

11. angleTriangle()
     finds either of the angle of a triangle on the basis of given value
     if "x" is given value for angle1, it will find angle1

12. angleQuad()
     finds either of the angle of a rectangle on the basis of given value
     if "x" is given value for angle1, it will find angle1

13. max()
      finds the largest of the two numbers

14. min()
      finds the smallest of the two numbers