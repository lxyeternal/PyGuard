# Copyright (c) 2015, RedJack, LLC.
# All rights reserved.
#
# Please see the COPYING file in this distribution for license details.
AKAMAI_OK = 0
AKAMAI_DEFAULT = 1
AKAMAI_GENERIC_ERROR = 2
AKAMAI_SMALL_BUFFER = 3
AKAMAI_TRY_AGAIN = 4
AKAMAI_PERMISSION_DENIED = 5
AKAMAI_NOT_FOUND = 6
AKAMAI_GO_AWAY = 7
AKAMAI_LATEST = 8
