# gatzzt

Tools for data scicence

There are helper functions for:
- Pandas
- TensorFlow
- PyTorch
