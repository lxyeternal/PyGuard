from setuptools import setup

setup(name='gatzzt',
      version='0.1',
      description='tools for data science',
      url='http://github.com/GatzZ/gatzzt',
      author='GatzZ',
      author_email='instituteliew@gmail.com',
      license='MIT',
      packages=['gatzzt'],
      zip_safe=False)