from django.apps import AppConfig


class DgenesConfig(AppConfig):
    name = 'dgenome'
