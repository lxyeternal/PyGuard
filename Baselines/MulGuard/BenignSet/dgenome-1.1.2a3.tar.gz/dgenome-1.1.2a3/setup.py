from setuptools import setup

setup(setup_requires='packit', packit=True)
