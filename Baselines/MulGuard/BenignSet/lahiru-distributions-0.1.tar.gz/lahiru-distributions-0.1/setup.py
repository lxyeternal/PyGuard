from setuptools import setup

setup(name='lahiru-distributions',
      version='0.1',
      description='Gaussian and Binomial distributions',
      author = 'Lahiru Senevirathne',
      author_email = 'lahiru.16@cse.mrt.ac.lk',
      packages=['lahiru-distributions'],
      zip_safe=False)
