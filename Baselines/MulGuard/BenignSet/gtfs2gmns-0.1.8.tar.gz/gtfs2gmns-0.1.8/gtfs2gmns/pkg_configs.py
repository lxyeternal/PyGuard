# -*- coding:utf-8 -*-
##############################################################
# Created Date: Sunday, July 9th 2023
# Contact Info: luoxiangyong01@gmail.com
# Author/Copyright: Mr. Xiangyong Luo
##############################################################

# **** Package Info **** #
pkg_version = "0.1.8"
pkg_name = "gtfs2gmns"
pkg_author = "Mr. Xiangyong Luo, Mrs. Fang Tang,  Dr. Xuesong Simon Zhou"
pkg_email = "luoxiangyong01@gmail.com,fangt@asu.edu, xzhou74@asu.edu"
