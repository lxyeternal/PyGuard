USE_DOOR_VALID: float = -0.00
USE_DOOR_FAIL: float = -0.01