TEMPLATE        = '#'                   # TEMPLATE _identifier. Define your own!

# Movements
NORTH           = 'north'
EAST            = 'east'
SOUTH           = 'south'
WEST            = 'west'
NORTHEAST       = 'north_east'
SOUTHEAST       = 'south_east'
SOUTHWEST       = 'south_west'
NORTHWEST       = 'north_west'