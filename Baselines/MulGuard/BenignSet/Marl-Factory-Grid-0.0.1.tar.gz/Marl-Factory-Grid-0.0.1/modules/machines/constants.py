
MACHINES = 'Machines'
MACHINE  = 'Machine'

STATE_WORK = 'working'
STATE_IDLE = 'idling'
STATE_MAINTAIN = 'maintenance'

SYMBOL_WORK = 1
SYMBOL_IDLE = 0.6
SYMBOL_MAINTAIN = 0.3
