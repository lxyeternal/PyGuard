from typing import NamedTuple


SYMBOL_NO_ITEM      = 0
SYMBOL_DROP_OFF     = 1
# Item Env
ITEM                = 'Items'
INVENTORY           = 'Inventories'
DROP_OFF            = 'DropOffLocations'

ITEM_ACTION         = 'ITEMACTION'
