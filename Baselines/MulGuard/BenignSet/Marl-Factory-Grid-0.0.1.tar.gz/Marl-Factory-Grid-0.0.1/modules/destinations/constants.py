
# Destination Env
DESTINATION             = 'Destinations'
DEST_SYMBOL             = 1
DEST_REACHED_REWARD     = 0.5
DEST_REACHED            = 'ReachedDestinations'

WAIT_ON_DEST    = 'WAIT'

MODE_SINGLE      = 'SINGLE'
MODE_GROUPED     = 'GROUPED'

DONE_ALL         = 'DONE_ALL'
DONE_SINGLE      = 'DONE_SINGLE'
