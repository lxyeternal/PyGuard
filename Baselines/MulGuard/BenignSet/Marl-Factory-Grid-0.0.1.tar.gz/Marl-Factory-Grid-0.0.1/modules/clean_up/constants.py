DIRT = 'DirtPiles'

CLEAN_UP = 'do_cleanup_action'

CLEAN_UP_VALID = 'clean_up_valid'
CLEAN_UP_FAIL = 'clean_up_fail'
CLEAN_UP_ALL = 'all_cleaned_up'
