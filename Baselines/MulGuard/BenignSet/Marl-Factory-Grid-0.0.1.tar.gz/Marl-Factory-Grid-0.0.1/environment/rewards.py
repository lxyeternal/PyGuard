MOVEMENTS_VALID: float = -0.001
MOVEMENTS_FAIL: float  = -0.05
NOOP: float            = -0.01
COLLISION: float       = -0.5
