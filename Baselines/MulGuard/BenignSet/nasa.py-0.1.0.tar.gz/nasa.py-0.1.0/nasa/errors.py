


class InvalidAPIKey(Exception):
    pass