# Aneki
Random russian jokes (especially about computer and etc) from several sites in your terminal!  

![](https://github.com/VolkovAK/aneki/workflows/Build/badge.svg)  

## Usage  

    python aneki.py


## Dependencies
Project tested on Python 3.5 - 3.8 for Ubuntu 16.04 - 18.04.
All dependencies are described in requirements.txt, so just

    pip install -r requirements.txt


## Sites
Currently (03.01.2020) next sites are supported:
 - bash.im
 - anekdot.ru
 - nekdo.ru
 - shytok.net

Next sites won't be supported:
 - anekdotov.net - computer section is not funny IMHO
 - pikabu.ru, ithappens.me - too long stories
