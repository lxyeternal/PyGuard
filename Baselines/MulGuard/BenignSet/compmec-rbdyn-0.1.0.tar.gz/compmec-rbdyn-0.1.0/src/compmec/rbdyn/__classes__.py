
class VariableClass(object):
    instances = []
    names = []


class KinematicClass(object):
    pass


class FrameReferenceClass(object):
    instances = []


class ObjectClass(object):
    instances = []


class EnergyClass(object):
    pass
