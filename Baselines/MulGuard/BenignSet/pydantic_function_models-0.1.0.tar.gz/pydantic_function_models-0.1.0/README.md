# pydantic-function-models

Migrating v1 Pydantic ValidatedFunction to v2

![PyPI](https://img.shields.io/pypi/v/pydantic-function-models?logo=python&logoColor=%23cccccc)
[![pdm-managed](https://img.shields.io/badge/pdm-managed-blueviolet)](https://pdm.fming.dev)
[![pre-commit.ci status](https://results.pre-commit.ci/badge/github/lmmx/pydantic-function-models/master.svg)](https://results.pre-commit.ci/latest/github/lmmx/pydantic-function-models/master)
[![Supported Python versions](https://img.shields.io/pypi/pyversions/magic-scrape.svg)](https://pypi.org/project/pydantic-function-models)

<!-- [![build status](https://github.com/lmmx/pydantic-function-models/actions/workflows/master.yml/badge.svg)](https://github.com/lmmx/pydantic-function-models/actions/workflows/master.yml) -->
