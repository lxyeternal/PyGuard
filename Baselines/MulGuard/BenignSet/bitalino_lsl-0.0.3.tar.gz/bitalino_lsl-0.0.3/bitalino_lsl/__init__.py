"""Python module to stream BITalino data though the Lab Streaming Layer (LSL)
"""
from .bitalinoLSL import list_bitalino, BitalinoLSL
__version__ = "0.0.3"
name = "bitalino_lsl.pkg"
