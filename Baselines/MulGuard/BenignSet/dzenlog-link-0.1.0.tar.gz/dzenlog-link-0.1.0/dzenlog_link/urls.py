from django_dzenlog.urls import create_patterns
from models import LinkPost
urlpatterns = create_patterns(LinkPost, '')
