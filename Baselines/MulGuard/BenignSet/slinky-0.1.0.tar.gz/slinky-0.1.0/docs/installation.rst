============
Installation
============

At the command line::

    $ easy_install slinky

Or, if you have virtualenvwrapper installed::

    $ mkvirtualenv slinky
    $ pip install slinky