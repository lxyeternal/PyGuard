========
Usage
========

To use slinky in a project::

    import slinky