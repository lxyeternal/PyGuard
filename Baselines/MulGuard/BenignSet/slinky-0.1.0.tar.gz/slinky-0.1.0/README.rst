===============================
slinky
===============================

.. image:: https://badge.fury.io/py/slinky.png
    :target: http://badge.fury.io/py/slinky

.. image:: https://travis-ci.org/bwghughes/slinky.png?branch=master
        :target: https://travis-ci.org/bwghughes/slinky

.. image:: https://pypip.in/d/slinky/badge.png
        :target: https://pypi.python.org/pypi/slinky


Quick command to create signed links on S3

* Free software: BSD license
* Documentation: https://slinky.readthedocs.org.

Features
--------

* TODO