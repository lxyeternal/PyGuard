#!/usr/bin/env python
# -*- coding: utf-8 -*-

"""
test_slinky
----------------------------------

Tests for `slinky` module.
"""

import unittest

from slinky import slinky


class TestSlinky(unittest.TestCase):

    def setUp(self):
        pass

    def test_something(self):
        pass

    def tearDown(self):
        pass

if __name__ == '__main__':
    unittest.main()