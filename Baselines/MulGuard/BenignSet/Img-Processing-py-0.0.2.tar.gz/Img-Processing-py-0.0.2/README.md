# Image Processing py

Description.
 
The package Img_Processing_py is used to:

## Processing:
- Histrogram matching
- Structural similarity
- Resize image
## Utils:
- Read image
- Save image
- Plot image
- Plot results
- Plot histograms

## Installation

Use the package manager [pip](https://pip.pypa.io/en/stable/) to install image_processing

```bash
pip install Img-Processing-py
```
## Author
VagnerF

## License
[MIT](https://choosealicense.com/licenses/mit/)