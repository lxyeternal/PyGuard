from distutils.core import setup

setup(
    name="Lishuzhen97", 
    version="1.0.0", 
    author="Li shuzhen", 
    author_email="shuzhen_li97@163.com", 
    description="test", 
    long_description=open("README.md").read(), 
    license="MIT", 
    url="https://github.com/lishuzhen97/lishuzhen",
) 