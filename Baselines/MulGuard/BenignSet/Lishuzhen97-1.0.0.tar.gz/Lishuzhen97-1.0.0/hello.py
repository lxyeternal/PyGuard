def lsz():
    print("hello")