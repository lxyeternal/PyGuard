"""Cosntants for python-openei."""
BASE_URL = "https://api.openei.org/utility_rates?"
