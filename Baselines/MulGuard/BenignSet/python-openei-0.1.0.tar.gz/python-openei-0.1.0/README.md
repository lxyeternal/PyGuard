# python-openei
Python Library for OpenEI.org Rest data

A pyhton librbary for consuming OpenEI.org rest data and outputting it into an easy to use format.
