#!/usr/bin/env python

"""Tests for `LrnXPAnaToolbox` package."""


import unittest

from LrnXPAnaToolbox import LrnXPAnaToolbox


class TestLrnxpanatoolbox(unittest.TestCase):
    """Tests for `LrnXPAnaToolbox` package."""

    def setUp(self):
        """Set up test fixtures, if any."""

    def tearDown(self):
        """Tear down test fixtures, if any."""

    def test_000_something(self):
        """Test something."""
