"""Recommand some questions to a new student given the tables of marks from create_marks function."""

__author__ = """Kayané Elmayan Robach"""
__email__ = 'kaya.robach@gmail.com'
__version__ = '0.1.0'
