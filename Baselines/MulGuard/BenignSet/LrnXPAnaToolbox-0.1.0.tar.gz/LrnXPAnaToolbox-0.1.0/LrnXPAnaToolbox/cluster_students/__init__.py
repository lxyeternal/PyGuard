"""Cluster the students and predict the cluster for a new student."""

__author__ = """Kayané Elmayan Robach"""
__email__ = 'kaya.robach@gmail.com'
__version__ = '0.1.0'
