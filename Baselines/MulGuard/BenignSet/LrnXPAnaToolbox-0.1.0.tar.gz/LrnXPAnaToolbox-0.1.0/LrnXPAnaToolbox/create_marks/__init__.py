"""Create a table of marks given by each student for each question."""

__author__ = """Kayané Elmayan Robach"""
__email__ = 'kaya.robach@gmail.com'
__version__ = '0.1.0'
