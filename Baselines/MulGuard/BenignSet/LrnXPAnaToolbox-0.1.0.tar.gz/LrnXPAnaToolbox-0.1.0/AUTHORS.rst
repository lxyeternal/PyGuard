=======
Credits
=======

Development Lead
----------------

* UQDKR : Ulysse Queritet Diop & Kayané Robach

Contributors
------------

* Kayané Elmayan Robach  <robachkaya>  https://github.com/robachkaya  kaya.robach@gmail.com

* Ulysse Queritet Diop  <YLSZ>  https://github.com/ulysse-qd  ulysse.queritet-diop@epitech.eu


