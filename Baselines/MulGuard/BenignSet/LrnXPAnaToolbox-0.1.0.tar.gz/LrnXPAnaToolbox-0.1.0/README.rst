=====================
UQDKR LrnXPAnaToolbox
=====================


.. image:: https://img.shields.io/pypi/v/LrnXPAnaToolbox.svg
        :target: https://pypi.python.org/pypi/LrnXPAnaToolbox

.. image:: https://img.shields.io/travis/robachkaya/LrnXPAnaToolbox.svg
        :target: https://travis-ci.com/robachkaya/LrnXPAnaToolbox

.. image:: https://readthedocs.org/projects/LrnXPAnaToolbox/badge/?version=latest
        :target: https://LrnXPAnaToolbox.readthedocs.io/en/latest/?badge=latest
        :alt: Documentation Status

TEST


Learning Experience Analysis Toolbox contains tools to analyse learning experience data using the pandas library. This package is developped for EvidenceB leraning experience data.


* Free software: MIT license
* Documentation: https://LrnXPAnaToolbox.readthedocs.io.


Features
--------

* TODO

Credits
-------

This package was created with Cookiecutter_ and the `audreyr/cookiecutter-pypackage`_ project template.

.. _Cookiecutter: https://github.com/audreyr/cookiecutter
.. _`audreyr/cookiecutter-pypackage`: https://github.com/audreyr/cookiecutter-pypackage
