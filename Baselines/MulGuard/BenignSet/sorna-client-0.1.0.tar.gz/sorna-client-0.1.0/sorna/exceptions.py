class SornaAPIError(Exception):
    pass
