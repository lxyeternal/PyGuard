=====
Usage
=====

To use EVNRG in a project::

    import evnrg
