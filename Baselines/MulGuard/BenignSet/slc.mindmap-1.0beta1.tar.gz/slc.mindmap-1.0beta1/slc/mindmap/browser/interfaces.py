from zope.interface import Interface
from zope.viewlet.interfaces import IViewletManager

class IFileView(Interface):
    """ """

class IMindMapViewletManager(IViewletManager):
    """ A viewlet manager for the slc.mindmap viewlet. 
    """

