
# The version of PocketProtector, used in the version subcommand, as
# well as in setup.py. For full release directions, see the bottom of
# setup.py.

__version__ = '0.0.1'
