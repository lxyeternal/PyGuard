__version__ = "0.1.0"  # pragma: no cover
