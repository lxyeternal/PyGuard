from shush.muzzle import muzzle
from shush.supress import suppress

__all__ = ["suppress", "muzzle"]
