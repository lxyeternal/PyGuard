=====
Usage
=====

To use sign-xpi-lib in a project::

    import sign_xpi_lib
