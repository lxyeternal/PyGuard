# This file included so this directory can be loaded as a Python module.

from .dimorphite_dl import *

__version__ = "1.2.5-post1"
