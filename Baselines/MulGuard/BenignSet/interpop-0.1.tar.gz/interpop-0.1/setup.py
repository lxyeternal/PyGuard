from setuptools import setup

setup(name='interpop',
      version='0.1',
      description='interpolation and approximation',
      packages=['interpop'],
      author_email='shpeka4kaps4@mail.ru',
      zip_safe=False)
