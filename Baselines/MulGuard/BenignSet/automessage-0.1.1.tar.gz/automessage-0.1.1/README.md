`automessage` is a library that helps you quickly create `protorpc`-based web services that
interact with `ndb` models (Google Cloud Datastore) by automatically generating `Message` classes
for your `ndb.Model` subclasses, along with easy serialization/deserialization.