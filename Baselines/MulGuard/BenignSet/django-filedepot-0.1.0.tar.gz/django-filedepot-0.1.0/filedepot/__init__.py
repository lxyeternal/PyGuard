"""A simple application to allow async file uploads via Flow.js
"""
