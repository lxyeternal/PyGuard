Command-line interface framework
================================

This is a small framework for generating command-line in python. Each command
has a dedicated file for the command-line configuration and can have dedicated
configuration files whose values will be easily accessible.
