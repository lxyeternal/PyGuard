import random

from FakeUser import Fu