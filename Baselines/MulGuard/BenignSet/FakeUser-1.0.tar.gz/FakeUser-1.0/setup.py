from setuptools import setup

setup(name='FakeUser',
      version='1.0',
      description='FakeUser - Python library that regenerates random names, phone numbers and addresses. For now, only the Russian generation is available, but over time we will add other generations.',
      packages=['FakeUser'],
      author_email='filcher2011@mail.ru',
      zip_safe=False)