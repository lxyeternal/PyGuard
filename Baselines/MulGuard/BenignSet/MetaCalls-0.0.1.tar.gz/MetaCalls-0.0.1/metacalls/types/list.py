from metacalls.types.py_object import PyObject


class List(list, PyObject):
    pass
