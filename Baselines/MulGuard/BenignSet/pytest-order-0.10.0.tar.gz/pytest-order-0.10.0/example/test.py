"""Reference test without ordering from the quick start chapter.
See https://pytest-dev.github.io/pytest-order/dev/#quickstart
"""


def test_foo():
    assert True


def test_bar():
    assert True
