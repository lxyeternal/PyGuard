""" __init__ """
from .mdict import MDict
from .mname import MName
