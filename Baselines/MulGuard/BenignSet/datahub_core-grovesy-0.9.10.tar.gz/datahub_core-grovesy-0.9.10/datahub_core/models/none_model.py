#pylint:disable=no-self-use
class NoneModel:

    def make_one(self):
        return {}
