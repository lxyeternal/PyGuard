[![GitHub Actions CI](https://github.com/gibsramen/evident/actions/workflows/main.yml/badge.svg)](https://github.com/gibsramen/evident/actions)

# evident

Effect size calculations for microbiome data
