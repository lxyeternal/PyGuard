#coding:utf-8

__version__ = '1.1dev'
__appname__ = u'Планировщик'

__require__ = {
}
