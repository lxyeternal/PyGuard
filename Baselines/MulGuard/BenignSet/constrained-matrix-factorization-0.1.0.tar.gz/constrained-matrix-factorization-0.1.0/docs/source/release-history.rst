===============
Release History
===============

v0.1.0 (2021-11-01)
----------------------------
This initial release marks the transfer of this repository to the NSLS-II organization.
Initial publication details can be found on  `the arXiv <https://arxiv.org/abs/2104.00864>`_,
with the peer reviewed version accepted for publication in Applied Physics Reviews.