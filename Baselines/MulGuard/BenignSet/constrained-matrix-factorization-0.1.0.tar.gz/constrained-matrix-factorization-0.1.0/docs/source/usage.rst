=====
Usage
=====

Start by importing constrained-matrix-factorization.

.. code-block:: python

    import constrainedmf
