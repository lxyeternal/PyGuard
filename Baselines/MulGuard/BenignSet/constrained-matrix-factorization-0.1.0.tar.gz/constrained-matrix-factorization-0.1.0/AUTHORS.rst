=======
Credits
=======

Maintainer
----------

* Phil Maffettone <pmaffettone@bnl.gov>

Contributors
------------

None yet. Why not be the first? See: CONTRIBUTING.rst
