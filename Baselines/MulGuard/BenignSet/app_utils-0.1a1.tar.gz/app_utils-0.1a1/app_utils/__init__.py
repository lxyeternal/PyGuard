"""
Application Utilities Package

This package is meant to enable rapid application development by providing
generic, reusable functionality that is common across many applications.
"""
name = "app_utils"
