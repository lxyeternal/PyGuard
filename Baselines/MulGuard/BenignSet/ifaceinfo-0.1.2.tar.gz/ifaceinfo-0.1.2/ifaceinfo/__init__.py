from ifaceinfo import InterfacesInfos
