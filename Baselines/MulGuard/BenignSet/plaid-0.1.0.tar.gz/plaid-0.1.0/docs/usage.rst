=====
Usage
=====

To use Plaid in a project::

    import plaid
