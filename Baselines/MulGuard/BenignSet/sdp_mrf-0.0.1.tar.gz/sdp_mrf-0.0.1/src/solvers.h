float M4(int n, int d, float *A, float *h, float *V, float eps, int max_iter);
float M4_plus(int n, int d, int k, float *A, float *h, float *Z, float eps, int max_iter);
