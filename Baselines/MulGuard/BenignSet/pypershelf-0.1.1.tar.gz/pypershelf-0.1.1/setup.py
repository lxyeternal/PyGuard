from setuptools import setup

setup(name='pypershelf',
      version='0.1.1',
      description='ORM With Focus on RM. Inspired by Bookshelf.js',
      url='https://github.com/insipidish/pypershelf',
      author='insipidish',
      author_email='insipidish@gmail.com',
      license='MIT',
      packages=['pypershelf'],
      zip_safe=False)
