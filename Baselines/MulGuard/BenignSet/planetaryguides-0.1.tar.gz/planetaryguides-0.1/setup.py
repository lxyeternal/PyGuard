from setuptools import setup, find_packages

setup(name='planetaryguides',
      version='0.1',
      description='Random Target Coordinates Generator for Remote Viewing Sessions.',
      packages=find_packages(['planetaryguides']),
      zip_safe=False)
