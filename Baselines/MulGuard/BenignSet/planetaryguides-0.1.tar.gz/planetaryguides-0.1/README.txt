README.md:
```
# Package Name: Planetary_Guides

This package is an Target Coordinate generator for remote viewers to conduct SRV remote viewing sessions.
More functionality to come in the future. 

## Installation

To install the package and its dependencies, use the following command:

```
pip install Planetary Guides