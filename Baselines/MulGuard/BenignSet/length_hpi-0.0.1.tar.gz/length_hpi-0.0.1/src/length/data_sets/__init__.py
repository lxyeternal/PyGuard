from .fashion_mnist import FashionMNIST
from .mnist import MNIST
