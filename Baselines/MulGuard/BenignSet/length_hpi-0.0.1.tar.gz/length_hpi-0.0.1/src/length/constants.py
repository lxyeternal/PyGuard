import numpy as np


# the standard datatype to use for all experiments.
DTYPE = np.float32
