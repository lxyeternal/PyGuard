from setuptools import setup
execfile('lino_noi/project_info.py')
if __name__ == '__main__':
    setup(**SETUP_INFO)
