==========================
lino-noi README
==========================

The Lino application used by the Lino team for managing their work on the Lino project

Description
-----------

Lino Noi is the `Lino <http://www.lino-framework.org>`_
application used by the Lino team for managing their work on the Lino project.
The name comes from Italian "noi" which means "we".

It can be called a `DevOps tool
<https://en.wikipedia.org/wiki/DevOps>`_ in that it stresses
communication, collaboration, integration, automation, and measurement
of cooperation between software developers, users and other IT
professionals.



Read more on http://noi.lino-framework.org
