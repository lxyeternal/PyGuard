# Copyright 2015 Luc Saffre
# License: BSD (see file COPYING for details)

"""
Lino Noi extension of :mod:`lino.modlib.products`.

.. autosummary::
   :toctree:

    models

"""

from lino.modlib.products import Plugin


# class Plugin(Plugin):
    
#     extends_models = ['Product']

