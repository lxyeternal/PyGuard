from lino.modlib.users.fixtures.demo import *
