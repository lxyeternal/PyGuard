# -*- coding: UTF-8 -*-
# Copyright 2015 Luc Saffre
# License: BSD (see file COPYING for details)
"""Extended and specific plugins for Lino Noi.

.. autosummary::
   :toctree:

   contacts
   noi
   products
   users

"""
