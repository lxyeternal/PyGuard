# Copyright 2015 Luc Saffre
# License: BSD (see file COPYING for details)

"""
The main plugin for Lino Noi.

.. autosummary::
   :toctree:

    models
    roles

"""

