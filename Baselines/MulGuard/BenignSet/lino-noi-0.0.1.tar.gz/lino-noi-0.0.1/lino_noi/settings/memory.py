from .demo import *
SITE = Site(globals())
DATABASES['default']['NAME'] = ':memory:'
