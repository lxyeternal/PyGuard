from .demo import *

ROOT_URLCONF = 'lino_noi.urls'
