from distutils.core import setup

setup(
    name='nestertna',
    version='1.0.0',
    py_modules=['nestertna'],
    author='tiago',
    author_email='tiago@radactioin.com.br',
    url='http://www.headfirstlabs.com',
    description='A simple printer of nested list',

)
