'''
![Build/Deploy CI](https://github.com/pwrdrvr/microapps-app-release/actions/workflows/ci.yml/badge.svg) ![Main Build](https://github.com/pwrdrvr/microapps-app-release/actions/workflows/main-build.yml/badge.svg) ![Deploy](https://github.com/pwrdrvr/microapps-app-release/actions/workflows/deploy.yml/badge.svg)

# Overview

This is the Release Console for the MicroApps framework.
'''
import abc
import builtins
import datetime
import enum
import typing

import jsii
import publication
import typing_extensions

from ._jsii import *

import aws_cdk
import aws_cdk.aws_lambda
import aws_cdk.aws_s3
import constructs


@jsii.interface(
    jsii_type="@pwrdrvr/microapps-app-nextjs-demo-cdk.IMicroAppsAppNextjsDemo"
)
class IMicroAppsAppNextjsDemo(typing_extensions.Protocol):
    '''(experimental) Represents a NextJS Demo app.

    :stability: experimental
    '''

    @builtins.property # type: ignore[misc]
    @jsii.member(jsii_name="lambdaFunction")
    def lambda_function(self) -> aws_cdk.aws_lambda.IFunction:
        '''(experimental) The Lambda function created.

        :stability: experimental
        '''
        ...


class _IMicroAppsAppNextjsDemoProxy:
    '''(experimental) Represents a NextJS Demo app.

    :stability: experimental
    '''

    __jsii_type__: typing.ClassVar[str] = "@pwrdrvr/microapps-app-nextjs-demo-cdk.IMicroAppsAppNextjsDemo"

    @builtins.property # type: ignore[misc]
    @jsii.member(jsii_name="lambdaFunction")
    def lambda_function(self) -> aws_cdk.aws_lambda.IFunction:
        '''(experimental) The Lambda function created.

        :stability: experimental
        '''
        return typing.cast(aws_cdk.aws_lambda.IFunction, jsii.get(self, "lambdaFunction"))

# Adding a "__jsii_proxy_class__(): typing.Type" function to the interface
typing.cast(typing.Any, IMicroAppsAppNextjsDemo).__jsii_proxy_class__ = lambda : _IMicroAppsAppNextjsDemoProxy


@jsii.implements(IMicroAppsAppNextjsDemo)
class MicroAppsAppNextjsDemo(
    constructs.Construct,
    metaclass=jsii.JSIIMeta,
    jsii_type="@pwrdrvr/microapps-app-nextjs-demo-cdk.MicroAppsAppNextjsDemo",
):
    '''(experimental) NextJS Demo app for MicroApps framework.

    :see: {@link https://nextjs.org/learn/basics/create-nextjs-app | Create NextJS App }
    :stability: experimental
    :remarks: Implemented from the NextJS tutorial.
    '''

    def __init__(
        self,
        scope: constructs.Construct,
        id: builtins.str,
        *,
        static_assets_s3_bucket: aws_cdk.aws_s3.IBucket,
        function_name: typing.Optional[builtins.str] = None,
        node_env: typing.Optional[builtins.str] = None,
        removal_policy: typing.Optional[aws_cdk.RemovalPolicy] = None,
        sharp_layer: typing.Optional[aws_cdk.aws_lambda.ILayerVersion] = None,
    ) -> None:
        '''(experimental) Lambda function, permissions, and assets used by the MicroApps Release app.

        :param scope: -
        :param id: -
        :param static_assets_s3_bucket: (experimental) Bucket with the static assets of the app. Next.js apps need access to the static assets bucket.
        :param function_name: (experimental) Name for the Lambda function. While this can be random, it's much easier to make it deterministic so it can be computed for passing to ``microapps-publish``. Default: auto-generated
        :param node_env: (experimental) NODE_ENV to set on Lambda.
        :param removal_policy: (experimental) Removal Policy to pass to assets (e.g. Lambda function).
        :param sharp_layer: (experimental) ``sharp`` node module Lambda Layer for Next.js image adjustments.

        :stability: experimental
        '''
        props = MicroAppsAppNextjsDemoProps(
            static_assets_s3_bucket=static_assets_s3_bucket,
            function_name=function_name,
            node_env=node_env,
            removal_policy=removal_policy,
            sharp_layer=sharp_layer,
        )

        jsii.create(self.__class__, self, [scope, id, props])

    @builtins.property # type: ignore[misc]
    @jsii.member(jsii_name="lambdaFunction")
    def lambda_function(self) -> aws_cdk.aws_lambda.IFunction:
        '''(experimental) The Lambda function created.

        :stability: experimental
        '''
        return typing.cast(aws_cdk.aws_lambda.IFunction, jsii.get(self, "lambdaFunction"))


@jsii.data_type(
    jsii_type="@pwrdrvr/microapps-app-nextjs-demo-cdk.MicroAppsAppNextjsDemoProps",
    jsii_struct_bases=[],
    name_mapping={
        "static_assets_s3_bucket": "staticAssetsS3Bucket",
        "function_name": "functionName",
        "node_env": "nodeEnv",
        "removal_policy": "removalPolicy",
        "sharp_layer": "sharpLayer",
    },
)
class MicroAppsAppNextjsDemoProps:
    def __init__(
        self,
        *,
        static_assets_s3_bucket: aws_cdk.aws_s3.IBucket,
        function_name: typing.Optional[builtins.str] = None,
        node_env: typing.Optional[builtins.str] = None,
        removal_policy: typing.Optional[aws_cdk.RemovalPolicy] = None,
        sharp_layer: typing.Optional[aws_cdk.aws_lambda.ILayerVersion] = None,
    ) -> None:
        '''(experimental) Properties to initialize an instance of ``MicroAppsAppNextjsDemo``.

        :param static_assets_s3_bucket: (experimental) Bucket with the static assets of the app. Next.js apps need access to the static assets bucket.
        :param function_name: (experimental) Name for the Lambda function. While this can be random, it's much easier to make it deterministic so it can be computed for passing to ``microapps-publish``. Default: auto-generated
        :param node_env: (experimental) NODE_ENV to set on Lambda.
        :param removal_policy: (experimental) Removal Policy to pass to assets (e.g. Lambda function).
        :param sharp_layer: (experimental) ``sharp`` node module Lambda Layer for Next.js image adjustments.

        :stability: experimental
        '''
        self._values: typing.Dict[str, typing.Any] = {
            "static_assets_s3_bucket": static_assets_s3_bucket,
        }
        if function_name is not None:
            self._values["function_name"] = function_name
        if node_env is not None:
            self._values["node_env"] = node_env
        if removal_policy is not None:
            self._values["removal_policy"] = removal_policy
        if sharp_layer is not None:
            self._values["sharp_layer"] = sharp_layer

    @builtins.property
    def static_assets_s3_bucket(self) -> aws_cdk.aws_s3.IBucket:
        '''(experimental) Bucket with the static assets of the app.

        Next.js apps need access to the static assets bucket.

        :stability: experimental
        '''
        result = self._values.get("static_assets_s3_bucket")
        assert result is not None, "Required property 'static_assets_s3_bucket' is missing"
        return typing.cast(aws_cdk.aws_s3.IBucket, result)

    @builtins.property
    def function_name(self) -> typing.Optional[builtins.str]:
        '''(experimental) Name for the Lambda function.

        While this can be random, it's much easier to make it deterministic
        so it can be computed for passing to ``microapps-publish``.

        :default: auto-generated

        :stability: experimental
        '''
        result = self._values.get("function_name")
        return typing.cast(typing.Optional[builtins.str], result)

    @builtins.property
    def node_env(self) -> typing.Optional[builtins.str]:
        '''(experimental) NODE_ENV to set on Lambda.

        :stability: experimental
        '''
        result = self._values.get("node_env")
        return typing.cast(typing.Optional[builtins.str], result)

    @builtins.property
    def removal_policy(self) -> typing.Optional[aws_cdk.RemovalPolicy]:
        '''(experimental) Removal Policy to pass to assets (e.g. Lambda function).

        :stability: experimental
        '''
        result = self._values.get("removal_policy")
        return typing.cast(typing.Optional[aws_cdk.RemovalPolicy], result)

    @builtins.property
    def sharp_layer(self) -> typing.Optional[aws_cdk.aws_lambda.ILayerVersion]:
        '''(experimental) ``sharp`` node module Lambda Layer for Next.js image adjustments.

        :stability: experimental

        Example::

            https://github.com/zoellner/sharp-heic-lambda-layer/pull/3
        '''
        result = self._values.get("sharp_layer")
        return typing.cast(typing.Optional[aws_cdk.aws_lambda.ILayerVersion], result)

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "MicroAppsAppNextjsDemoProps(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


__all__ = [
    "IMicroAppsAppNextjsDemo",
    "MicroAppsAppNextjsDemo",
    "MicroAppsAppNextjsDemoProps",
]

publication.publish()
