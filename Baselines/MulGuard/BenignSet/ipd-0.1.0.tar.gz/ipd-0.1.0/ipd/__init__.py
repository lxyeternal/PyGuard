"""
ipd

MIT License. See LICENSE for more details.
Copyright (c) 2013, Jonathan Stoppani
"""

__version__ = '0.1.0'
__url__ = 'https://github.com/GaretJax/ipd'