


class Builder(object):
    def __init__(self, repository):
        pass
