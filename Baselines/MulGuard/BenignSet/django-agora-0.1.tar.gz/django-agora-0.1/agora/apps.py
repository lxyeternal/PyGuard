from django.apps import AppConfig


class AgoraConfig(AppConfig):
    name = 'agora'
