# Forex Library

### Installation
```
pip install FOREX_LIB