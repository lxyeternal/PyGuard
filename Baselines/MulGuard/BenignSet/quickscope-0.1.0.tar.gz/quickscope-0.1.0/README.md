# Quickscope

Quickscope is a lightweight exploit thrower for attack-defense CTFs.
This entails being able to communicate with a game interface (the *tracker*) and being able to launch exploits (the *shooter*).

`pip install quickscope`
