from .shooter import main
from .common import setup_logging

setup_logging()
main()
