class AuthException(Exception):
    pass
    
class UpdateRequiredException(Exception):
    pass

class ValidationException(Exception):
    pass

class RatelimitedException(Exception):
    pass