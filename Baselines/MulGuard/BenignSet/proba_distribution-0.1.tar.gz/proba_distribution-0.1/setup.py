from setuptools import setup

setup(name='proba_distribution',
      version='0.1',
      description='Gaussian distributions',
      packages=['proba_distribution'],
      author = 'Chidi Chukwumezie',
      author_email = 'austinmilan@yahoo.com',
      zip_safe=False)
