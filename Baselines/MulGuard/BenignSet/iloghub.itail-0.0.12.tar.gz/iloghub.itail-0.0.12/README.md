a instance log tail tool for iloghub. iloghub is a opensource instance implement for java and python
