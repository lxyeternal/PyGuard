from setuptools import setup, find_packages

setup(
    name='my_little_ansible_v4',
    version='1.0',
    author='Mihai BOSIICA',
    author_email='bosiic_m@etna-alternance.net',
    packages=find_packages(),
)