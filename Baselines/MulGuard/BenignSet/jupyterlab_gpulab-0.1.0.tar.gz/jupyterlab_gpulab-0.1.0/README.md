# JupyterLab GPUab Extension

see: https://gpulab.io