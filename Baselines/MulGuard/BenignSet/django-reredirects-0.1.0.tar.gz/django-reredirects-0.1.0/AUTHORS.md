# Credits

### Development Lead

Most of this package comes from [Django contrib](https://github.com/django/django/tree/master/django/contrib/redirects)

### Contributors

* John-Michael Oswalt <jmoswalt@gmail.com>
