# Django ReRedirects

![fury](https://badge.fury.io/py/django-reredirects.png)

![pypi](https://pypip.in/d/django-reredirects/badge.png)

Django Redirects, but with regex and without the sites framework.

* Free software: BSD license

