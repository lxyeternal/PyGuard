from setuptools import setup

setup(name='crr_distribution_package',
      version='0.1',
      description='Gaussian and Binomial distributions',
      packages=['crr_distribution_package'],
      author = 'Chetan Raj Rupakheti',
      author_email = 'chetanrrk@gmail.com',
      zip_safe=False)
