export * from './widget';
export declare const version = "1.0.0";
