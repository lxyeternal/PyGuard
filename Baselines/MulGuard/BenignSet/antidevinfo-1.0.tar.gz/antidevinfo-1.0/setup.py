import setuptools

setuptools.setup(
    name= 'antidevinfo',
    version= '1.0',
    author= 'Anti-Dev-Info',
    description= 'Library just for fun',
    packages=setuptools.find_packages(),
    classifiers=[
    "Programming Language :: Python :: 3",
    "Operating System :: OS Independent",
    "License :: OSI Approved :: MIT License"
    ]
)