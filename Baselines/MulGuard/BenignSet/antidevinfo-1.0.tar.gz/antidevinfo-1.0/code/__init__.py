def s1337() :
    print("1337 hiya ahssn madrassa w li kaykhraj manha kaykhdam f Google")


def tatabiz(data) :
    print (str(data) + " dkhlat l tatabiz")


