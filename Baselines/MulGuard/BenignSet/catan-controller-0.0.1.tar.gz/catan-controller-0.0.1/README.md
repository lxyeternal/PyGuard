# Catan Controller

This is a game controller for catan.

Most methods are commented to explain how they work.

Will add more info into readme later :)
