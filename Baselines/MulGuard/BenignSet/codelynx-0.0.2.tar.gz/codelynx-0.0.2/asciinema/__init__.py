import sys

__author__ = 'Marcin Kulik'
__version__ = '1.4.0'

if sys.version_info[0] < 3:
    raise ImportError('Python < 3 is unsupported.')
