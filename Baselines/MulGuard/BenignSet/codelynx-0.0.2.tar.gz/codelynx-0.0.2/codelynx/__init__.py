import sys
__author__ = 'Trieu Pham'
__version__ = '0.0.2'

if sys.version_info[0] < 3:
    raise ImportError('Python < 3 is unsupported.')
