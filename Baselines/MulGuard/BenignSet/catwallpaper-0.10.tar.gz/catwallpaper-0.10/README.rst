What it does?
===============
It does web scraping with python and downloads random cat images and applies it as your wallpaper acc to your operating system

Supported platforms
===============
Currently it supports

1. Windows
2. Mac
3. Linux with desktop environment: Gnome and Mate

Todo
-------------------
To make it compatible with Xfce and kde

Installation
===============

It's available on pypi as https://pypi.org/project/catwallpaper/


``pip install catwallpaper``
