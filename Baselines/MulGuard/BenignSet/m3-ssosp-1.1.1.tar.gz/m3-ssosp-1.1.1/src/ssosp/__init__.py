#coding:utf-8
from ssosp.views import sso_acs, sso_login, sso_logout
from ssosp.request_response import SSOException