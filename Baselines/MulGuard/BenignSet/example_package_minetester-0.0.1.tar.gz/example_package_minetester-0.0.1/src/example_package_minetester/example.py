def dd_one(number):
    return number + 1
