from setuptools import setup

setup(
    name = 'AIRPrediction',
    version = '0.0.1',
    scripts = ['forecast-flask-app.py'], 
    url = 'https://github.com/Data-for-Good-by-UF/AIRPrediction',
    license = 'MIT'
)