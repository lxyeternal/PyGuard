__version__ = VERSION = '0.6'
__version_info__ = tuple(__version__.split('.'))

default_app_config = 'dcf.apps.DCFConfig'
name = "django-classified"
