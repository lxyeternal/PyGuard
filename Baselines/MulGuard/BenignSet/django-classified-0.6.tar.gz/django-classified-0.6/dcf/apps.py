# -*- coding:utf-8 -*-

from django.apps import AppConfig


class DCFConfig(AppConfig):
    name = 'dcf'
    verbose_name = "DCF - Django Classified"
