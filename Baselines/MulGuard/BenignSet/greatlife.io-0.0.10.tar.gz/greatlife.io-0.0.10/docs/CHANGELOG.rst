Version 0.0.10
================================================================================

* Update title

Version 0.0.9
--------------------------------------------------------------------------------

* Change title wording and font size

Version 0.0.8
--------------------------------------------------------------------------------

* Rename to greatlife.io

Version 0.0.7
--------------------------------------------------------------------------------

* Add logo from Kate

Version 0.0.6
--------------------------------------------------------------------------------

* Switch to use React and Material-UI
* Run test before publishing

Version 0.0.5
--------------------------------------------------------------------------------

* Temporarily remove static as we do not have any

Version 0.0.4
--------------------------------------------------------------------------------

* Switch to use Jinja templates
* Add wait option when updating so it actually update
  
  Non-tty does not update without an update frequency set or within frequency.

Version 0.0.3
--------------------------------------------------------------------------------

* Remove goal info

Version 0.0.2
--------------------------------------------------------------------------------

* Add first goal

Version 0.0.1
--------------------------------------------------------------------------------

* Add mission
* Initial setup
* Initial commit
