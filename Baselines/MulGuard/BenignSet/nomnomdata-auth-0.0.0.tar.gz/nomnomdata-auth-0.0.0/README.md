
# nomnomdata-auth

Tiny library that contains KeyAuth, a requests library authorizer that signs requests with a secret key.
