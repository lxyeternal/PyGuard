from setuptools import setup

setup(name='mensolutions_distribution',
      version='1.0',
      description='Gaussian and Binomial distributions',
      packages=['mensolutions_distribution'],
      long_description='long_description to be placed here',
      author='Emmanuel Ameh',
      author_email='a@b.com',
      zip_safe=False)
