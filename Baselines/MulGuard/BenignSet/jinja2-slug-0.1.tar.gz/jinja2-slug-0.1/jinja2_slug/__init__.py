from jinja2_slug.jinja2_slug import SlugExtension

__version__ = '0.1'
__all__ = ['SlugExtension']
