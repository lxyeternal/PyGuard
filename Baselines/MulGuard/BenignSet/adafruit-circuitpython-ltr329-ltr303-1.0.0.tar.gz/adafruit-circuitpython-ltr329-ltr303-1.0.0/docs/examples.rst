Simple test
------------

Ensure your device works with this simple test.

.. literalinclude:: ../examples/ltr329_simpletest.py
    :caption: examples/ltr329_simpletest.py
    :linenos:
