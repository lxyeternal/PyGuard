# Pinakin Lite Version For Upstox API

Codebase for Upstox API made for Unofficed Community.

Unofficial Python API Wrapper and Basic Tutorials. 
