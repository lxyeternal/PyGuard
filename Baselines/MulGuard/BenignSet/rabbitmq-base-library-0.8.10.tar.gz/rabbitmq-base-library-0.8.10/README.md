# provisioning library for rabbitmq and cloudamqp

Base library to build complex scripts for rabbitmq and cloudamqp
 
### Usage 
```
# stores a secret in azure vault
```

### Setup and install dependencies
```
# hello
```

### Required configuration files
```
mkdir .secret
```

### How to use the scripts

#### store_in_vault
```
hello
```
