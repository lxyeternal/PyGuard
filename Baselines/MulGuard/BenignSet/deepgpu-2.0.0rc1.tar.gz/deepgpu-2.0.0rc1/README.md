# DEEPGPU release package

## usage

```py
import deepgpu
```
