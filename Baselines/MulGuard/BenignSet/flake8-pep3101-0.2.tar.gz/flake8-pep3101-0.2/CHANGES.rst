.. -*- coding: utf-8 -*-

Changelog
=========

0.2 (2015-09-16)
----------------
- 0.1 was a brown bag release.
  [gforcada]

0.1 (2015-09-16)
----------------
- Initial release
  [gforcada]

- Create the flake8 plugin per se.
  [gforcada]

