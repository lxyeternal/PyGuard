# Linguarita

When gettext doesn't work and you are sick of writing your own language engine for every program, you came to the right place! Linguarita is a generic language engine retrieving translations from JSON files. I also made a very simple Hello World application which simply prints out "Hello, world" in English, German and Ukrainian with Linguarita.