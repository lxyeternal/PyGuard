from . import utils
from . import vscode
from . import tuna

zsh = utils.aptWrapper("zsh")