marketools
==========

Tools for stock market analysis.

[Github](https://github.com/AlbertRtk/marketools)
