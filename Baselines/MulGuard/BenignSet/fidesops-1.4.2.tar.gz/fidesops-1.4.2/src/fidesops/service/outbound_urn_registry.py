ONETRUST_GET_ALL_REQUESTS = "https://{hostname}/api/datasubject/v2/requestqueues/en-us"
ONETRUST_GET_SUBTASKS_BY_REF_ID = (
    "https://{hostname}/v2/subtasks/{request_queue_ref_id}/subtasks"
)
ONETRUST_PUT_SUBTASK_STATUS = "https://{hostname}/v2/subtasks/{subtask_id}/status"
