from apscheduler.schedulers.background import BackgroundScheduler


scheduler = BackgroundScheduler()
