# pylib
A library of useful (to me) Python functions and classes
