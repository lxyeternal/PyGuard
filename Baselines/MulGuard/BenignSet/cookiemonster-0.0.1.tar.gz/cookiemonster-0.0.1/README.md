Cookie Monster
==============
