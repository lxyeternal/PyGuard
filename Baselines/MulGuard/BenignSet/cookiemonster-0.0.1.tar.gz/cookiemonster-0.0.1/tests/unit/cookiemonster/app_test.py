from cookiemonster import app


def test_it():
    assert True
