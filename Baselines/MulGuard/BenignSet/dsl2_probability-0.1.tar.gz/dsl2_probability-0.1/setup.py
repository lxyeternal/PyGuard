from setuptools import setup

setup(name='dsl2_probability',
      version='0.1',
      description='Gaussian and Binomial distributions',
      packages=['dsl2_probability'],
      author = 'Alexandra Jaber',
      author_email = 'alexandra.jaber@vodafone.com',
    zip_safe=False)
