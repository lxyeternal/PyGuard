####Description:
Ping website or server using ping.exe just to check is the host reachable or not.

####Usage:
```python
from ping_cmd import host
r = host.ping("127.0.0.1")
```
If r == 1 then host is reachable.