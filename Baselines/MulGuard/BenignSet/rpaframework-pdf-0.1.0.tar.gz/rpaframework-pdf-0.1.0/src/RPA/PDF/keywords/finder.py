from RPA.PDF.keywords import (
    LibraryContext,
    keyword,
)


class FinderKeywords(LibraryContext):
    """Keywords for locating elements."""

    @keyword
    def find_element(self):
        pass
