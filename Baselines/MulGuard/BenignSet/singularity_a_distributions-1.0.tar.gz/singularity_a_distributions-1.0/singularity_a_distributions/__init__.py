from .Gaussiandistribution import Gaussian
from .Binomialdistribution import Binomial

# TODO: import the Binomial class from the Binomialdistribution module