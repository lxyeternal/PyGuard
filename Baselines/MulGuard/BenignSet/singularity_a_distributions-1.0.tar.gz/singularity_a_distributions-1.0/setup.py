from setuptools import setup

setup(name='singularity_a_distributions',
      version='1.0',

      description='Gaussian distributions',

      packages=['singularity_a_distributions'],

      author= 'Abdullah Hammami',

      zip_safe=False)