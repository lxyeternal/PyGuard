class CocalcError(Exception):
    """An error while submitting request to cocalc-api."""
