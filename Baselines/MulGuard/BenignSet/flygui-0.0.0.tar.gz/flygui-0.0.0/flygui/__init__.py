from pygpt4all.models.gpt4all import GPT4All
from pygpt4all.models.gpt4all_j import GPT4All_J