from pathlib import Path

from setuptools import setup, find_packages


# read the contents of your README file
this_directory = Path(__file__).parent
long_description = (this_directory / "README.md").read_text()


setup(
    name="flygui",
    version="0.0.0",
    author="Abdeladim Sadiki",
    description="",
    long_description=long_description,
    ext_modules=[],
    zip_safe=False,
    python_requires=">=3.8",
    packages=find_packages('.'),
    package_dir={'': '.'},
    long_description_content_type="text/markdown",
    license='MIT',
    project_urls={
        'Documentation': 'https://abdeladim-s.github.io/flygui/',
        'Source': 'https://github.com/abdeladim-s/flygui',
        'Tracker': 'https://github.com/abdeladim-s/flygui/issues',
    },
    # install_requires=[""],
)
