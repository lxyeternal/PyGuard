'''
This is a resources module for the purpose os resources storage and accessing.
'''
