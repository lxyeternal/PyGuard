# nice-cx-python
This repository stores all of the code we are going to release under the name 'nicecx' on PyPi.

API documention can be found here: http://ndexbio.github.io/ndexbio/nice-cx-python


