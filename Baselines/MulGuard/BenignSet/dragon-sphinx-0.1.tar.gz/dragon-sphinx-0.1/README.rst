Sphinx extensions for the Stupeflix tasks system
================================================

This is a dependency used to compile the documentation at https://stupeflix-tasks-api.readthedocs.org/
