# -*- coding: utf-8 -*-
"""
API endpoint for enterprise data app.
"""
from __future__ import unicode_literals

default_app_config = 'enterprise_data.api.v0.apps.ApiAppConfig'  # pylint: disable=invalid-name
