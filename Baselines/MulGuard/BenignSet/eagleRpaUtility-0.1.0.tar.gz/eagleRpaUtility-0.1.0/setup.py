from setuptools import find_packages, setup

setup(
    name='eagleRpaUtility',
    packages=find_packages(include=['eagleRpaUtility']),
    version='0.1.0',
    description='EagleProjects RPA utility function pakcage',
    author='cpicciafuoco@eagleprojects.it',
    license='MIT'
)