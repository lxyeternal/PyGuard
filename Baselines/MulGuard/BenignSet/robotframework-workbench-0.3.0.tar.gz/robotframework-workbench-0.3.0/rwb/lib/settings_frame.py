import Tkinter as tk
import ttk

class AbstractSettingsFrame(ttk.Frame):
    section = []
    name = None

