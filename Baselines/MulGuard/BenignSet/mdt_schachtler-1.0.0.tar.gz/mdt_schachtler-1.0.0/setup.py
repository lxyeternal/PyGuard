from distutils.core import setup

setup(
        name            = 'mdt_schachtler',
        version         = '1.0.0',
        py_modules      = ['mdt_schachtler'],
        author          = 'MiguelArminia',
        author_email    = 'miguel.dreckschmidt@gmail.com',
        url             = 'https://www.migueldreckschmidt.de',
        description     = 'Simple printer for lists',
    )
        
