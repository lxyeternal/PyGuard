from .filechooser import FileChooser


__version__ = '0.1.2'
