from cobo_custody.client.client import Client

client = Client
