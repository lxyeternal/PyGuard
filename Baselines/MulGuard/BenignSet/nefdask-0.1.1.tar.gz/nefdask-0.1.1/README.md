# nefdask

## Install
```bash
pip install nefdask
pip install -e https://github.com/GaetanDesrues/nefdask
pip install git+ssh://git@github.com/GaetanDesrues/nefdask.git
```
