# Industrial Benchmark for Gym

`gym-industrial` is a standalone Python implementation of the [Industrial Benchmark](https://github.com/siemens/industrialbenchmark) for OpenAI Gym.

## Installation

```bash
pip install gym-industrial
```

## Environment

*Coming soon*: description of the Industrial Benchmark's dynamics and subsystems