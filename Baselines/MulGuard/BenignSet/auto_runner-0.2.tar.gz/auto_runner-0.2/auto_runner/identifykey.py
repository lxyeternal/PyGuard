# coding=utf-8

class IdentifyKey:
    '''
    IdentifyKey:exception and normal
    '''
    data_prefix = "#utyyfkfuyd9784521hkjojfnvcynsf46764oiu9872908iojkafkd#"
        