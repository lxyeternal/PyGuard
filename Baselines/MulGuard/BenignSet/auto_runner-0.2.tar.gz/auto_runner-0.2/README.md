## autorunner

通用case运行框架系统，根据用户提交的Case测试计划，运行相关case
并生成本地html报告或远程报告传送

# Usage
## case层
* model # 用于编写各功能模块的步骤对应方法，一系列的操作步骤集合
* case  # 根据模块的测试用例设计，调用model层测试步骤

# startTest启动参数
* cycle
* deviceserial
* plan

