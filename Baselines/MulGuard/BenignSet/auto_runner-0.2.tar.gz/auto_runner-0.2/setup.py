try:
    from setuptools import setup
except ImportError:
    from distutils.core import setup
    
setup(
    name='auto_runner',
    version='0.2',
    url='',
    license='',
    author='thomas.ning',
    author_email='',
    description='',
    packages=['auto_runner'],
    include_package_data=True,
    zip_safe=False
)