print('Hi there, I am getpath application!')
