#!/usr/bin/env python3
from .loadconf import *

__all__ = [
    "Config",
]
