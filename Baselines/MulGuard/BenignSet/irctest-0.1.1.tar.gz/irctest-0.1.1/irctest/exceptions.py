class NoMessageException(AssertionError):
    pass

class ConnectionClosed(Exception):
    pass

