import collections

TlsConfig = collections.namedtuple('TlsConfig',
        'enable trusted_fingerprints')
