Flask-Lastuser
==============

Flask extension for Lastuser
