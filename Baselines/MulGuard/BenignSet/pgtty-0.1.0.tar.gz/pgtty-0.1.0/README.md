# PgTTY

A terminal for Python using Pygame.

To use, put `pgtty.py` and `font.ttf` in your project directory.

An example program is in `main.py`

The main functions are:

- print(text)
- set((y, x), char)

Both functions will take foreground and background keyword arguments in the form (r, g, b)
