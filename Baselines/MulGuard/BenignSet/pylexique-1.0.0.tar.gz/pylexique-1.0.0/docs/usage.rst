=====
Usage
=====

To use pylexique in a project::

    import pylexique
