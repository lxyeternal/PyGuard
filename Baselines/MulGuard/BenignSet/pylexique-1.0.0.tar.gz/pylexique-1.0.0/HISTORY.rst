=======
History
=======

1.0.0 (2021-04-26)
------------------

* First release on PyPI.
