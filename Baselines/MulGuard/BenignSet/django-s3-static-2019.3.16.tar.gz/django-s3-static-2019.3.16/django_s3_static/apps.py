#!/usr/bin/env python
from django.apps import AppConfig


class DjangoS3StaticConfig(AppConfig):
    name = 'django_s3_static'
