"""
rest-framework.

An Implementation of the Swagger UI for Django Rest Framework.
"""


__version__ = "0.1.0"
__author__ = 'Samuel Ajibade'
__credits__ = 'Rest Swagger'
__email__ = 'samuelajibade22@gmail.com'
