__author__ = "Lie-Nielsen Toolworks"
__email__ = "mike@lie-nielsen.com"
__version__ = "0.0.1"

from .client import (
    OdooClient, OdooObject, OdooModel
)
