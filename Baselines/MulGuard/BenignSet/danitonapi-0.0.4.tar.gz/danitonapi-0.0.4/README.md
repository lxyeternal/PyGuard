# DanitonAPI
A global Artificial Intelligence Network called Daniton

API endpoint: api.daniton999.ml

### Currently Available
ChatBot

### Use
`` pip install danitonapi ``

``import danitonapi``

#### ChatBot
``getAnswer(token, message, userid, username)``
