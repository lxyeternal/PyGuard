#!/usr/bin/env python


def main():
    print("hookshot")
    return 0


if __name__ == '__main__':
    sys.exit(main())
