
class OrphanActorError(Exception):
    pass

class ActorInitializationError(Exception):
    pass

class AlreadyConnected(Exception):
    pass

class NotConnected(Exception):
    pass
