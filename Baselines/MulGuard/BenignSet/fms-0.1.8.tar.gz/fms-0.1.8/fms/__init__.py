#!/usr/bin/env python
# -*- coding: utf8 -*-
"""
This module is empty to avoid mass import from e.g. setup.py
"""
