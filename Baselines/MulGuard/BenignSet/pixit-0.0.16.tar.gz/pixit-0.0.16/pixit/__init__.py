name = "pixit"

from .image_manip import ImageSet