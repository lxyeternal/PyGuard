name = "datasets"

from .load_datasets import load_animals # , load_faces
