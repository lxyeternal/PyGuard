Welcome to `OBytes Django Stiore` documentation !
==============================================

managing ecommerce stores


Content
~~~~~~~~

.. toctree::
   :maxdepth: 2

   installation
   rest_endpoints
   models
   admin



Indices and tables
~~~~~~~~~~~~~~~~~~~

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`