
# Falcon Compression Middleware

Middleware to apply content compression to Falcon responses.
