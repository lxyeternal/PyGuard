# -*- coding: utf-8 -*-

"""Module containing some meta information about this project.

"""

__author__ = 'CLX Communication'
__copyright__ = u'Copyright © 2017 CLX Communications'
__license__ = 'Apache License, Version 2.0'
__title__ = 'clx-sdk-xms'
__version__ = '1.0.0'
