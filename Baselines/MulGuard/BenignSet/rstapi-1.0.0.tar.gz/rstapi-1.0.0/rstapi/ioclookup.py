# Copyright 2023 RST Cloud Pty Ltd

import os

import requests


class ioclookup(object):
    def __init__(self, APIKEY="", APIURL="https://api.rstcloud.net/v1"):
        self.APIKEY = os.environ.get("RST_API_KEY", APIKEY)
        self.API_URL = os.environ.get("RST_API_URL", APIURL)

    def GetIndicator(self, value):
        endpoint = "/ioc"
        apiurl = self.API_URL + endpoint + "?value=" + value
        headers = {"Accept": "*/*", "X-Api-Key": self.APIKEY}
        r = requests.get(apiurl, headers=headers)
        return r.json()

    def SubmitIndicator(self, value, desc="manual submission"):
        endpoint = "/ioc"
        apiurl = self.API_URL + endpoint
        payload = {"ioc_value": value, "description": desc}
        headers = {"Accept": "*/*", "X-Api-Key": self.APIKEY}
        r = requests.post(apiurl, json=payload, headers=headers)
        return r.json()

    def SubmitFalsePositive(self, value, desc="manual submission"):
        endpoint = "/ioc"
        payload = {"ioc_value": value, "description": desc}
        apiurl = self.API_URL + endpoint
        headers = {"Accept": "*/*", "X-Api-Key": self.APIKEY}
        r = requests.put(apiurl, json=payload, headers=headers)
        return r.json()
