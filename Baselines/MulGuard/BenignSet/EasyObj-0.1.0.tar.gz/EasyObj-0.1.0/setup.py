from setuptools import setup
from setuptools import find_packages

VERSION = '0.1.0'

setup(
    name='EasyObj',
    version=VERSION,
    description='A js-like object for python',
    packages=["EasyObj"],
    zip_safe=False,
)
