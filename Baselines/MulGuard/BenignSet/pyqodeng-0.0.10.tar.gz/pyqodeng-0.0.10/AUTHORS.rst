Main Authors
============

Colin Duquesnoy (@ColinDuquesnoy) <colin.duquesnoy@gmail.com>

Contributors
============

Andres Granada (@ogranada)
