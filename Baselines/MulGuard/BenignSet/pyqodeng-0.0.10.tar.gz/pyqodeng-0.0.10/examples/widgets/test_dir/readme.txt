Fake directory structure for testing the filesystem treeview, don't be afraid
to copy/paste/delete/move files here to experiment with the widget!