# -*- coding: utf-8 -*-
"""
This package contains the python scripts for the Qt designer forms/qrc files (
stored in the forms directory at the root of the example).

To update python scripts, you need to install pyqt_distutils and
pyqode-uic packages and run::

    python setup.py build_ui

"""
