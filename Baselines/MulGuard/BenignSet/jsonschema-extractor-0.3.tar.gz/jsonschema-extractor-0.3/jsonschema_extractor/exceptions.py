class AttrJSONSchemaError(Exception):
    pass

class UnextractableSchema(AttrJSONSchemaError):
    pass
