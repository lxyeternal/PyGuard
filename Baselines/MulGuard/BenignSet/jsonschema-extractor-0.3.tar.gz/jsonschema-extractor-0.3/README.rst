====================
jsonschema-extractor
====================

jsonschema-extractor can extract jsonschema definitions from a variety
of different serialization frameworks:

- `cattrs <https://cattrs.readthedocs.io/>`_
- `schematics <http://schematics.readthedocs.io/>`_
