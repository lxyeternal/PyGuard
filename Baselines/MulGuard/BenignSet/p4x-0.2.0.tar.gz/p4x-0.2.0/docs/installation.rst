============
Installation
============

At the command line::

    pip install p4x
