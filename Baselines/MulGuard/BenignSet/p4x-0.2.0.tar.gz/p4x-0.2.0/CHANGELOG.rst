
Changelog
=========


0.1.3 (2020-01-22)
------------------

* Add module :code:`laboratory`  with :code:`experiments` submodule to manage experimental trials into projects, sessions, and trials
* Add module :code:`timing`
* Drop support for :code:`python3.5`

0.1.2 (2019-12-27)
------------------

* Add a :code:`Makefile` with targets for testing, building, releasing, etc.

0.1.1 (2019-12-17)
------------------

* Changes in :code:`bumpversion` configuration
* Change how module :code:`colorschemes` behaves resulting in much cleaner code

0.1.0 (2019-11-25)
------------------

* First release on PyPI.
