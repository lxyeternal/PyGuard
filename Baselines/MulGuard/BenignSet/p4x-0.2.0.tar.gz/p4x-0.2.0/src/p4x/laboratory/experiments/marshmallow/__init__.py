from p4x.laboratory.experiments.marshmallow.project import ProjectSchema

__all__ = [
        'ProjectSchema',
]
