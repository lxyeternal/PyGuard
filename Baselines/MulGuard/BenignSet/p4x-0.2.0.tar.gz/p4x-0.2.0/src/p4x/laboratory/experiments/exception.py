__author__ = "Philipp Tempel"
__email__ = "p.tempel@tudelft.nl"


class ProjectNotFoundError(OSError):
    pass


__all__ = [
        'ProjectNotFoundError',
]
