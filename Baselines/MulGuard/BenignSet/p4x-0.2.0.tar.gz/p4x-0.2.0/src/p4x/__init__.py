from p4x import colorschemes, timing

__author__ = "Philipp Tempel"
__email__ = "p.tempel@tudelft.nl"
__version__ = '0.2.0'

__all__ = [
        'colorschemes',
        'timing',
]
