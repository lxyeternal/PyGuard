url = "https://qa-marcuslion.web.app/"
webbrowser.open(url)