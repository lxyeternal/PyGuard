class FluentHttpException(Exception):

    pass
