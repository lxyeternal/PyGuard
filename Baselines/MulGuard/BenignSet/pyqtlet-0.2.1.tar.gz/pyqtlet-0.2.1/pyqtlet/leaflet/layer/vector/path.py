from ..layer import Layer


class Path(Layer):
    pass
