from .. import Layer

class GridLayer(Layer):
    pass
