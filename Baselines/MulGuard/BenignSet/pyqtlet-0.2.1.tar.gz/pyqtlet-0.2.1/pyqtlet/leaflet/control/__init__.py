from .layers import Layers
from .draw import Draw

class Control:
    layers = Layers
    draw = Draw
