from django.apps import AppConfig


class JuminConfig(AppConfig):
    name = 'jumin'
