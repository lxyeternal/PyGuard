from distutils.core import setup
setup(
            name='denester123',
            version='1.0.0',
            py_modules=['denester123'],
            author='dekingder',
            author_email='53974747@qq.com',
            url='http://www.headfirstlabs.com',
            description='A simple printer of nested lists',
        )
