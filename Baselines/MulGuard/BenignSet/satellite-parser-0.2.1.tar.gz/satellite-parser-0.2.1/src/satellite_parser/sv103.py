from .sv101 import SV101Satellite


class SV103Satellite(SV101Satellite):
    """
    高景一号03遥感卫星
    """
