from .sv101 import SV101Satellite


class SV102Satellite(SV101Satellite):
    """
    高景一号02遥感卫星
    """
