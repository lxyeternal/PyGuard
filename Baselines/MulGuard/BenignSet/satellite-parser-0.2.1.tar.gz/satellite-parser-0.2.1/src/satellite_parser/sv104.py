from .sv101 import SV101Satellite


class SV104Satellite(SV101Satellite):
    """
    高景一号04遥感卫星
    """
