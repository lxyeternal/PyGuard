"""Exception module for AWS NSM interface."""

class IoctlError(Exception):
    """Excepion raised when an error occurs in Ioctl."""
