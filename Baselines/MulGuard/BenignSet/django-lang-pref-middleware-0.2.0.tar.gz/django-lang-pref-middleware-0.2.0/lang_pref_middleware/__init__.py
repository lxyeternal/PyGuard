"""Init module for lang_pref_middleware."""

from __future__ import unicode_literals


__version__ = '0.2.0'
