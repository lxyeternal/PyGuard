Django-testing-utils
==================

Django-Testing-Utils is a package providing test helpers for django app testing.

![build](https://github.com/just-work/django-testing-utils/workflows/build/badge.svg?branch=master)
[![codecov](https://codecov.io/gh/just-work/django-testing-utils/branch/master/graph/badge.svg)](https://codecov.io/gh/just-work/django-testing-utils)
[![PyPI version](https://badge.fury.io/py/django-testing-utils.svg)](https://badge.fury.io/py/django-testing-utils)

Installation
------------

```shell script
pip install django-testing-utils
```

Usage
-----

In progress...

Happy testing! :)
