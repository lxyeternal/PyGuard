# River Python bindings

A future home for River's Python bindings. For now, the [MyPI package is registered](https://pypi.org/project/riverqueue/), but nothing else is done.
