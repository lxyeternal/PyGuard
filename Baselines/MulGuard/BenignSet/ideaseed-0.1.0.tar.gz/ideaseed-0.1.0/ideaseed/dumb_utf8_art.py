from ideaseed.utils import dye

DUMB_UTF8_ART = """


                ██████████  ██  ██  
                ██      ██  ██  ██  
                ██████████  ██  ██ 
                ██      ██  ██  ██ 
                ██████████████████  <- that's my personal logo,
                ██      ██      ██     i didn't make one for 
                ██████████      ██     ideaseed, yet™
                ██      ██      ██ 
                ██████████      ██ 
      
            ideaseed v{version}
            by Ewen Le Bihan
            more at https://ewen.works
      
                ~ thx to these ppl ~

https://github.com/kiwiz
    This madman reverse-engineered Google Keep's
    internal REST API so that anyone could 
    use it with ease.
                    
https://github.com/PyGithub
    This one of the cleanest libs I've ever used.
    Like `requests`-level cleanliness.
                    
https://github.com/docopt
    Designing CLIs with this is a fucking breeze.
    I can almost copy-paste documentation into
    a docstring and call it a day, it's crazy.
"""
