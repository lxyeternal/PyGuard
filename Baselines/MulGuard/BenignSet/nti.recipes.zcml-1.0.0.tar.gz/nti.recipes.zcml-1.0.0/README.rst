==================
 nti.recipes.zcml
==================

.. image:: https://img.shields.io/pypi/v/nti.recipes.zcml.svg
        :target: https://pypi.python.org/pypi/nti.recipes.zcml/
        :alt: Latest release

.. image:: https://img.shields.io/pypi/pyversions/nti.recipes.zcml.svg
        :target: https://pypi.org/project/nti.recipes.zcml/
        :alt: Supported Python versions

.. image:: https://travis-ci.org/NextThought/nti.recipes.zcml.png?branch=master
        :target: https://travis-ci.org/NextThought/nti.recipes.zcml

.. image:: https://coveralls.io/repos/github/NextThought/nti.recipes.zcml/badge.svg?branch=master
        :target: https://coveralls.io/github/NextThought/nti.recipes.zcml?branch=master

.. include:: src/nti/recipes/zcml/README.rst
