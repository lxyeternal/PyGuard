# -*- coding: utf-8 -*-

"""Top-level package for ksv."""

__author__ = """Dave Parfitt"""
__email__ = 'dparfitt@mozilla.com'
__version__ = '0.1.0'
