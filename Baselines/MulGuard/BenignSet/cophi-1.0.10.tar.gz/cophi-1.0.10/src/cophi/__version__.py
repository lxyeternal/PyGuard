VERSION = (1, 0, 10)

__version__ = ".".join(map(str, VERSION))
