from .setuppanel import SetupPanel

__version__ = "1.0.0"
__author__ = "Marwynn Somridhivej"
__license__ = "MIT"