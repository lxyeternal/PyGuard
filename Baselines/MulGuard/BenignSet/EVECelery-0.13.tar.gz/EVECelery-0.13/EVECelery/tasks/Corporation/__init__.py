from .CorporationInfo import CorporationInfo
