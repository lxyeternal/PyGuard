class NotResolved(Exception):
    pass


class InputValidationError(Exception):
    pass
