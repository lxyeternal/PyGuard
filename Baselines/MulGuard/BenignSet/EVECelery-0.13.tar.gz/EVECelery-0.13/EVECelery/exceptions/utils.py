class MissingHeaderEmail(Exception):
    pass


class ErrorLimitExceeded(Exception):
    pass
