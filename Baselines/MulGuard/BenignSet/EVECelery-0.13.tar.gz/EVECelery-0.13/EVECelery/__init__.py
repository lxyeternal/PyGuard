from .__version__ import __author_email__, __description__, __license__, __title__, __url__, __version__
