__author__ = 'Oleg Butovich'
__version__ = '0.1.1'
__licence__ = 'MIT'

from core import *
