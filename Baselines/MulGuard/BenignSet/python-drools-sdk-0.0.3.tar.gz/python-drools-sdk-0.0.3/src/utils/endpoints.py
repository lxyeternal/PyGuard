BASE_URL = '/kie-server/services/rest/server'
KIE_SESSION_ASSETS = BASE_URL + '/containers/instances/'
KIE_CONTAINER = BASE_URL + '/containers/'