from ..kie.drools import Drools


class AbstractCommand:
    pass