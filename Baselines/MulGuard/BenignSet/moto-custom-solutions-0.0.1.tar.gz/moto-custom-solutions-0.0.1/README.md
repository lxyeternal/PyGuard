# Custom Sol Package

 This is a package of functions used for custom solutions.

 Visit the Confluence for documentation.
