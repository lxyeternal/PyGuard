# GrowBot Python Library

The GrowBot Python Library provides convenient access to the GrowBot API from applications written in the Python programming language.

## Installation

...

## Usage

...

## Software License

This software is governed by the license defined in [/LICENSE](/LICENSE) at the root of this repository.
