# edamam-python

Python library to interact with the edamam online food database
