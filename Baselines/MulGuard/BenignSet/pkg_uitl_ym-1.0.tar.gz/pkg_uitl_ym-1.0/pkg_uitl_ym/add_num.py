def add_num(a, b):
    return a + b