from __future__ import absolute_import

__version__ = '1.0.0'

from .passninja import (
    PassNinjaClient, SimplePassObject, PassNinjaException, PassNinjaInvalidArgumentsException
)
