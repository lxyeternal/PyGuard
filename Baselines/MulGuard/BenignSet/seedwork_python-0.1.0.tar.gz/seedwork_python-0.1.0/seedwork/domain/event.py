from dataclasses import dataclass

__all__ = ['Event']


@dataclass(frozen=True)
class Event:
    ...
