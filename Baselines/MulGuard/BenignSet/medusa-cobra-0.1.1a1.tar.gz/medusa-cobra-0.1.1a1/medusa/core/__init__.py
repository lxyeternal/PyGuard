from medusa.core.ensemble import Ensemble
