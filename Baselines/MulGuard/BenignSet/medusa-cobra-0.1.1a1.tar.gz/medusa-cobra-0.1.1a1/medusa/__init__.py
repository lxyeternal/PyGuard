from __future__ import absolute_import

from medusa.core import Ensemble

__version__ = "0.1"
