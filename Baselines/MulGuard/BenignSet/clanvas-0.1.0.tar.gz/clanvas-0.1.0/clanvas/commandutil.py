
course_complete_dict = dict.fromkeys(['-c', '--course'], )