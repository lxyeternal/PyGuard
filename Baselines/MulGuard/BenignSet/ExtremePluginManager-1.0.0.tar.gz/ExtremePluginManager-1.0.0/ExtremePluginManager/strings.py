INFO = """\
{
    "id": "{{id}}"
}
"""


MAIN = """\
def {{start_event}}():
    print("Start")
    
    
def {{end_event}}():
    print("End")
"""
