import pathlib
import typing

PATH_TYPEHINT = typing.Union[str, pathlib.Path, bytes]
