"""
Base classes for and specific exceptions
"""


class OscError(Exception):
    """
    Base class for expcetions to be raised by ``osctiny``
    """
