# pylint: disable=missing-docstring
from .osc import Osc


__all__ = ['Osc']
__version__ = "0.1.0"
