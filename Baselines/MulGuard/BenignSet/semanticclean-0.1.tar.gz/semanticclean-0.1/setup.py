from distutils.core import setup
from setuptools import find_packages

setup(
	name = 'semanticclean',
	version = '0.1',
	description = 'A simple package to find label issues',
	packages=['semanticclean'],
	author = 'elshehawy@iSemantics',
	author_email = 'a.elshehawy64@gmail.com',
	zip_safe=False
)
