from django.apps import AppConfig


class ItemOwnerConfig(AppConfig):
    name = 'item_owner'
