"""Python implementation of Locality Preserving Projections"""
from __future__ import absolute_import

from .lpproj import LocalityPreservingProjection

__version__ = '0.1'
