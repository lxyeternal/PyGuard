from pkg_resources import get_distribution, DistributionNotFound
from .database import FileXdb


__version__ = "0.1.0"

