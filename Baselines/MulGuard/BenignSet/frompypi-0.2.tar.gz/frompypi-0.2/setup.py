#!/usr/bin/env python3

from distutils.core import setup
setup(
    name='frompypi',
    version='0.2',
    description='from pypy import anything',
    author='Oren Tirosh',
    author_email='orent@hishome.net',
    url='http://github.com/orent/frompypy',
    py_modules=['pypi'],
)
