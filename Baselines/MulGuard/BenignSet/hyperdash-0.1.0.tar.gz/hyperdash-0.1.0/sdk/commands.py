STOP = "stop"
