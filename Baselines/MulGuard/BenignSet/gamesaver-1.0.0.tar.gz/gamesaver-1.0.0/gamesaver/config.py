base_uri = "https://www.cheapshark.com/api/1.0/"
deals_uri = base_uri + "deals"
stores_uri = base_uri + "stores"
