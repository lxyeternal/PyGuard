from gitsweep.entrypoints import test

__test__ = False

if __name__ == "__main__":
    test()
