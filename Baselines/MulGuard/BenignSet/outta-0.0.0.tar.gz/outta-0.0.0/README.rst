outta

ANSI control code parsing
