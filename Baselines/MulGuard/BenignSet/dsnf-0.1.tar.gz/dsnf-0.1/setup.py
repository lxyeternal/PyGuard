from setuptools import setup

setup(name='dsnf',
      version='0.1',
      description='Gaussian distributions',
      packages=['dsnf'],
      zip_safe=False)
