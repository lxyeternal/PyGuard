Base classes for [Lapis](https://github.com/lapis-project/lapis) OpenAPI client generator
