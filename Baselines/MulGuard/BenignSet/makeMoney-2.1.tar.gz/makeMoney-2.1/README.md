<pre> 
We report a computational method and program（makeMonye）based on the Python programming language for basic data 
analysis and processing in Convertible bonds.This is also a makeMonye package for processing Convertible bonds data,
which the input file must be TXT format and it will output the result into a single EXCEL file 
friendly and frequently as basic data for further analysis.

If you have trouble running the makeMonye program, please copy the issues to the packaging-problems repository on GitHub. We’ll do our best to help you, thanks!
History
<pre> 	