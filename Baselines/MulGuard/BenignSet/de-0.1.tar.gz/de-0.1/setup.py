from setuptools import setup

setup(name='de',
      version='0.1',
      description='de',
      url='https://github.com/desantis/python-de',
      author='Andrew T. DeSantis',
      author_email='atd@deos.org',
      license='MIT',
      packages=['de'],
      zip_safe=False)
