def ping():
	return 'pong'
