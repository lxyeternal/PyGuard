=======
Credits
=======

Development Lead
----------------

* Louis Taylor <louis@kragniz.eu>

Contributors
------------

* Giuseppe Lavagetto <glavagetto@wikimedia.org>
* InvalidInterrupt <invalidinterrupt@users.noreply.github.com>
