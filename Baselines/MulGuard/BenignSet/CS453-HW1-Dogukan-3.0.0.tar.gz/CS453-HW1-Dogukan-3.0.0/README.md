This is the example Python repository for the homework.
Check the homework description file for the instructions on Moodle.



Trigger PR Test.

