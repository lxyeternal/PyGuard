from dictionary.dictionary import getDefinition
