djinn_announcements
===================

Djinn module for announcements