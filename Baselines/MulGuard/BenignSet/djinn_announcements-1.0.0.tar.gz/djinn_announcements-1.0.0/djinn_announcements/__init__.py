from urls import urlpatterns

def get_urls():

    return urlpatterns

def get_js():

    return ["djinn_announcements.js"]

def get_css():

    return ["djinn_announcements.css"]
