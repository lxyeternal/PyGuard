#!/usr/bin/env python
#-*- coding:utf-8 -*-


#############################################
# File Name: container2dict.py
# Author: derektmq
# Mail: derektmq@gmail.com
# Created Time:  2021-03-21 20:23:50 AM
#############################################

def container2dict(c1,c2):
    return(dict(zip(c1,c2)))

def help():
    print("Bwaaah!")
