#!/usr/bin/env python

#!/usr/bin/env python
#-*- coding:utf-8 -*-


#############################################
# File Name: container2dict.py
# Author: derektmq
# Mail: derektmq@gmail.com
# Created Time:  2021-03-21 20:23:50 AM
#############################################


from setuptools import setup, find_packages

setup(
    name = "container2dict",
    version = "0.0.1",
    keywords = ("pip", "Bwaaah"),
    description = "two container to dictionary",
    long_description = "two container to dictionary",
    license = "MIT Licence",

    url = "https://pypi.org/",
    author = "derek",
    author_email = "derektmq@gmail.com",

    packages = find_packages(),
    include_package_data = True,
    platforms = "any",
    install_requires = []
)
