#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on May 03 2021
@author: MohammadHossein Salari
"""
from .davat import normalize, clean
