# -*- coding: utf-8 -*-
#
class DTShellConstants(object):
    commands_remote_url = 'https://github.com/duckietown/duckietown-shell-commands'
    ROOT = '~/.dt-shell/'
