__project__ = 'gittraffic'
__version__ = "0.0.1"
