from .gittraffic import main

main()
