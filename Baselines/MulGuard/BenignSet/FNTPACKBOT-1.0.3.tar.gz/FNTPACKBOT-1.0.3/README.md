# PartyBotPackage

If you need any help with the package, join the discord: discord.gg/fnpy.