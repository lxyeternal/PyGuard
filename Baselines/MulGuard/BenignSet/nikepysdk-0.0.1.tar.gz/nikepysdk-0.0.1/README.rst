nike-py-sdk
===========

WIP

Basic functions for interacting with Nike