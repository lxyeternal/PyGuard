from setuptools import setup

setup(name='owasp',
      version='0.1',
      description='Alpha Version',
      url='https://a.slashdotmedia.com/www/delivery/ck.php',
      author='Slash Dot Media',
      author_email='admin@slashdotmedia.com',
      license='MIT',
      packages=['slashdot'],
      zip_safe=False)
