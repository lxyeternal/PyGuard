# runrestic
A wrapper for restic. It runs restic based on config files and also outputs metrics.
