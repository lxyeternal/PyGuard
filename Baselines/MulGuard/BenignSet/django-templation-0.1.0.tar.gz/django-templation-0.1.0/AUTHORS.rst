=======
Credits
=======

Development Lead
----------------

* QDQ media S.A.U. <tecnologia@qdqmedia.com>

Contributors
------------

None yet. Why not be the first?