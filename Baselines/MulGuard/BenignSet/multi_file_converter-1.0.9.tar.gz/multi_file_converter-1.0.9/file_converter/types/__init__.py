from .document import Document
from .image import Img, Imgs


__all__ = [
    'Img',
    'Imgs',
    'Document',
]
