# Packtivity Kubernetes Plugin

This plugin enables a native Kubernetes plugin for packtivity.

Necessary Features 

- [ ] CVMFS Resource Support
- [ ] Authentication Support
- [ ] interpolated Script / Cmd Support
- [ ] Dynamic Publisher Support
