from distutils.core import setup

setup(
    name='eager',
    packages=['eager'],
    version='0.0.1',
    licenwse='MIT',
    author='kelayamatoz',
    author_email='tianzhao@stanford.edu'
)

