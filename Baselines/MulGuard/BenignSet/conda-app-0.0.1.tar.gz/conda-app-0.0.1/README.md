# Install applications using conda
