name = "SpectDetect"
from SpectDetect import *
