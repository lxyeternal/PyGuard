class AWSEnv:
    def __init__(self, env_name, resources=[]):
        self.env_name = env_name
        self.resources = resources
