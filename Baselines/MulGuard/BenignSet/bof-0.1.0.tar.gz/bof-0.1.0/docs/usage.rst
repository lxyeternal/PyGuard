=====
Usage
=====

To use Bag of Factors in a project::

    import bof
