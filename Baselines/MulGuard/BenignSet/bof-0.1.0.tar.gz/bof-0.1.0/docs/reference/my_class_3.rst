MyClass3
--------

.. autoclass:: bof.MyClass3
    :members:
