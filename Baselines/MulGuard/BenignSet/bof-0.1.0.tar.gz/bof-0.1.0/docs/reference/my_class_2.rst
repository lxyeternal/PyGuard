MyClass2
--------

.. autoclass:: bof.MyClass2
    :members:
