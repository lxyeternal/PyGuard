MyClass1
--------

.. autoclass:: bof.MyClass1
    :members:
