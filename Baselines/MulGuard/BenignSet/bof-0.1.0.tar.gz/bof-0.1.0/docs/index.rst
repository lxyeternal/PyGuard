Welcome to Bag of Factors's documentation!
==========================================

.. toctree::
   :maxdepth: 2
   :caption: Contents:

   readme
   installation
   usage
   reference/index
   contributing
   authors
   history

Indices and tables
==================
* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`
