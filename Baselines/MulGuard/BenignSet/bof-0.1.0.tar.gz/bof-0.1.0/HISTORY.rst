=======
History
=======

---------------------------------
0.1.0 (2020-12-12): First release
---------------------------------

* First release on PyPI.
* Core FactorTree class added.
