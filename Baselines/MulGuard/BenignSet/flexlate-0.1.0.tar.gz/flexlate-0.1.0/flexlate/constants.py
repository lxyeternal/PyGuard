DEFAULT_MERGED_BRANCH_NAME = "flexlate-output"
DEFAULT_TEMPLATE_BRANCH_NAME = "flexlate-templates"