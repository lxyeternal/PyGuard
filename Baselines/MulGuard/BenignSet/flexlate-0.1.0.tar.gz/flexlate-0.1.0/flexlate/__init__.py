"""
A composable, maintainable system for managing templates
"""
