from flexlate.template_config.base import TemplateConfig


class CookiecutterConfig(TemplateConfig):
    pass