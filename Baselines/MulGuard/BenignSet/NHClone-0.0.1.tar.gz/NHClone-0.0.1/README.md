<div align="center">
  <img src="https://a.top4top.io/p_21918q9670.png" alt="">
  <p><b><h2><a href="https://facebook.com/ntahsan.nayem">Md Nayem Sheikh</a></h2></b>
</p>
</div>
<p>This Module is for clone Facebook Account Older than 2009. It's Work faster than any other Cloner. One of the great feature of this module is You will file defferent method of clone facebook account </p><br>


[![Language](https://img.shields.io/badge/Written%20in-Python2-blue)](#)
[![Opensource](https://img.shields.io/badge/Open%20Source-No-green)](#)

<p>This is not  a Opensource module . you can not modify this with the terms and conditions.
</p>
<li>Give Credit to respective Owner.</li>
<li>Do not use it any illigele perpuse.</li><br>
<div align = "center">
<h3><i> ...Developer Contact... </i></h3>
<br>
<a href="https://m.me/ntahsan.nayem"><img title="Messenger" src="https://img.shields.io/badge/Chat-Messenger-blue?style=flat&logo=messenger"></a>
<a href="https://fb.com/Noob.Hackrr71"><img title="Facebook" src="https://img.shields.io/badge/View-Facebook-blue?style=flat&logo=Facebook"></a>
<a href="https://github.com/Noob-Hacker71"><img title="Republic of Bangladesh" src="https://img.shields.io/badge/REPUBLIC%20OF-BANGLADESH-green?colorA=%23ff0000&colorB=%23017e40&style=flat"></a>
<a href="https://github.com/MAO2116"><img title="CO-DEV" src="https://img.shields.io/badge/CREDIT- MAO2116-blue?style=flat&logo=Github"></a>
<h4><i><b><a href ="https://www.facebook.com/Noob.Hacker71/">Your Cyber Sarvent</a></b></i></h4>

<b>[Note] Allah Always Watching you</b>


</div>
<h4>REQUIREMENTS</h4

```

$ pkg install python2 -y

```


<h4>INSTALLATION</h4>

```

$ pip2 install Noob-Clone

```


<h4>FOR RUN </h4>

```
$ Noob-Clone

```


<div align="center">
<b> GET US IN CLICK </b><br><br>
<a href="https://github.com/Noob-Hacker71">
  <img width="50px" height="50px" src="https://raw.githubusercontent.com/fh-rabbi/Hack-Box/main/images/git.png">
</a>
<a href="https://www.facebook.com/Noob.Hacker71/">
  <img width="50px" height="50px" src="https://raw.githubusercontent.com/fh-rabbi/Hack-Box/main/images/fb.png">
</a>
</div>  



<p>Copyright ©️ 2022<b> Noob-Hacker71</b> Under <a href="https://raw.githubusercontent.com/mao2116/piclogo/main/LICENSE">
MIT LICENSE</a></p>
