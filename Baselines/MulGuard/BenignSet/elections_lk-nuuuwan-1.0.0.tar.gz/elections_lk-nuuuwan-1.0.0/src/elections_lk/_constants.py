"""Constants."""

CACHE_NAME = 'elections_lk'
CACHE_TIMEOUT = 3600
