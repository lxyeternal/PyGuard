"""Utils."""

import logging
logging.basicConfig(level=logging.INFO)
log = logging.getLogger('elections_lk')
