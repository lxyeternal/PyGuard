Changelog
=========

Version 0.1.1 [2015-08-07]
------------------------

- setup.py install now installs requirements

Version 0.1 [2015-08-07]
------------------------

- First release
- Download and parse BORME PDF files
- Main parser is PyPDF2 
- Python 2 and 3 support
- Tests suite
