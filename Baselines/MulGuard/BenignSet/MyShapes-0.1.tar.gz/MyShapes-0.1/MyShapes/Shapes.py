


class Square:
	def __init__(self, sz):
		self.side = sz

	def area(self):
		return self.side * self.side
