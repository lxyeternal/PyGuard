``collective.jsonmigrator.statistics``
================================================

:TODO:
    need to fix statistic blueprint so it doesn't depend on other blueprints
    to report and add statistic data.

    Also reporting should not only be written to ``stdout``.

Parameters
----------

Example
-------

