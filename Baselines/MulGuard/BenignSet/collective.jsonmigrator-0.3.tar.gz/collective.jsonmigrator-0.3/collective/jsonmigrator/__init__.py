# -*- coding: utf-8 -*-
from zope.i18nmessageid import MessageFactory

import logging

logger = logging.getLogger("collective.jsonmigrator")
msgFact = MessageFactory('collective.jsonmigrator')
