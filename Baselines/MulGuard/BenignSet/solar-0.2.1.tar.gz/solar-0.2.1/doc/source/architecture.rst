.. _architecture:

===========================
Solar Internal Architecture
===========================

.. image:: _static/solar_internal_architecture.png
