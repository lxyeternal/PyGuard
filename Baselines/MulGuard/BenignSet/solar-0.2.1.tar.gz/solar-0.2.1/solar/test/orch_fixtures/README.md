# Orchestration fixtures
Current fixtures later will be used for functional tests

* Create plan from fixture
```
solar o create solar/solar/test/orch_fixtures/simple.yaml
simple:ebd342cb-b770-4795-9f4c-04cb41c81169
```

* Run this plan
```
solar o run-once simple:ebd342cb-b770-4795-9f4c-04cb41c81169
```

* Report progress
```
solar o report simple:ebd342cb-b770-4795-9f4c-04cb41c81169
```