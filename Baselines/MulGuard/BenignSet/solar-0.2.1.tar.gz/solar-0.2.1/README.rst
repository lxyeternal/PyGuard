Solar README
=====================

Solar is a resource manager and orchestration engine for distributed systems.

Please read the `Documentation <http://solar.readthedocs.org/en/latest>`_ to see how to install and use Solar. For start checkout our `Wordpress tutorial <http://solar.readthedocs.org/en/latest/tutorials/wordpress.html>`_
