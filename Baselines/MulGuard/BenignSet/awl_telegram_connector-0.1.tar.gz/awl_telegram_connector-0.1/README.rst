

awl-telegram-connector
===============
This is an awl-telegram-connector project

Installing
============

.. code-block:: bash

    pip install awl-telegram-connector

Usage
=====

.. code-block:: bash

    python awltelcon --token 0123456789012344567890
