"""Create graphene ObjectType based on the type annotations."""
from .graphanno import graph_annotations  # noqa

__version__ = '1.0.0'
