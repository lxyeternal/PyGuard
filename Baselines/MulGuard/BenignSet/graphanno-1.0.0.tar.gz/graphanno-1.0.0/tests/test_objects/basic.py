"""Basic class definition"""


class Basic:
    """Class annotated with the most basic types."""
    number: int
    string: str
    boolean: bool
