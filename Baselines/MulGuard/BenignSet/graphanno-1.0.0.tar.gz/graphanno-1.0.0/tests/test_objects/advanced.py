"""Advanced class definition."""
from typing import List


class Advanced:
    """Class with advanced data types."""
    array: List[str]
