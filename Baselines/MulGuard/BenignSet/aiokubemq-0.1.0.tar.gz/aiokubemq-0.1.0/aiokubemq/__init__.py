#!/usr/bin/python3
# -*- coding: utf-8 -*-
from aiokubemq.client import KubeMQClient

__version__ = "0.1.0"
__all__ = ["KubeMQClient"]
