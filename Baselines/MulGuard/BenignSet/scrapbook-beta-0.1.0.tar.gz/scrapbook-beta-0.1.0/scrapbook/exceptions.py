# -*- coding: utf-8 -*-


class ScrapbookException(ValueError):
    """Raised when an exception is encountered when operating on a notebook."""
