Installation
============

Installing the application
--------------------------

From the command line:

.. code-block:: bash

   pip install scrapbook
