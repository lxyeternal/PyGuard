from django.apps import AppConfig


class CaliperTrackingConfig(AppConfig):
    name = 'openedx_caliper_tracking'
    verbose_name = "Open edX Caliper Tracking"
