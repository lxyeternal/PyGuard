# Pacifica Template Repository
![PyPi](https://img.shields.io/pypi/v/pacifica-namespace.svg)

This repository serves to capture the Pacifica namespace and
associated files. This only contains the namespace and not
any dependencies of other services.
