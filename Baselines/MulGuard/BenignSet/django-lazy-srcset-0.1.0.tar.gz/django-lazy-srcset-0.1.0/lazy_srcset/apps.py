from django.apps import AppConfig


class LazySrcsetConfig(AppConfig):
    name = "lazy_srcset"
