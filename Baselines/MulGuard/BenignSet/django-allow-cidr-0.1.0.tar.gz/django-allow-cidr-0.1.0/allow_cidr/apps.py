# -*- coding: utf-8
from django.apps import AppConfig


class AllowCidrConfig(AppConfig):
    name = 'allow_cidr'
