.. :changelog:

History
-------

0.1.0 (2018-02-16)
++++++++++++++++++

* First release on PyPI.
