# This Package is a collection of Christmas related packages.
## Authors : Christmas
## Maintainer : Christmas

To install this package, run:

    pip install baysalt
or

    pip3 install baysalt
