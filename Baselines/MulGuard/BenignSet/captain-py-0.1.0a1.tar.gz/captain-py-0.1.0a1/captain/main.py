import click


@click.command()
def captain():
    """Captain

    A modern deploy tool.
    """
    print("let's start coding...")
    pass


if __name__ == '__main__':
    captain()
    pass
