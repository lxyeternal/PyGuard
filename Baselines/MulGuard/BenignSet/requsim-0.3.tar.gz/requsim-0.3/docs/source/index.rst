.. requsim documentation master file, created by
   sphinx-quickstart on Tue Nov  2 17:43:45 2021.
   You can adapt this file completely to your liking, but it should at least
   contain the root ``toctree`` directive.

================================
Welcome to requsim documentation
================================


User Manual
===================================

.. toctree::
   :maxdepth: 1

   examples
   api

Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`
