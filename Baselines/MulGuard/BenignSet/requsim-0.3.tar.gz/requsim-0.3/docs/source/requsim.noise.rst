requsim.noise module
--------------------

.. automodule:: requsim.noise
   :members:
   :undoc-members:
   :show-inheritance:
