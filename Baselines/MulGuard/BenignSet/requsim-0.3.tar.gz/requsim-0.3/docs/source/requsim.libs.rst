requsim.libs package
====================

.. automodule:: requsim.libs
   :members:
   :undoc-members:
   :show-inheritance:


requsim.libs.aux\_functions module
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

.. automodule:: requsim.libs.aux_functions
   :members:
   :undoc-members:
   :show-inheritance:

requsim.libs.epp module
~~~~~~~~~~~~~~~~~~~~~~~

.. automodule:: requsim.libs.epp
   :members:
   :undoc-members:
   :show-inheritance:

requsim.libs.matrix module
~~~~~~~~~~~~~~~~~~~~~~~~~~

.. automodule:: requsim.libs.matrix
   :members:
   :undoc-members:
   :show-inheritance:
