from setuptools import setup

setup(name='gaussian_binomial_distributions_FT',
      version='0.1',
      description='gaussian_binomial_distributions',
      packages=['gaussian_binomial_distributions_FT'],
      author = 'Funing Tian',
      zip_safe=False)
