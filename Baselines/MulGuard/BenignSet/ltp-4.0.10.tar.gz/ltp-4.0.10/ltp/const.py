#! /usr/bin/env python
# -*- coding: utf-8 -*_
# Author: Yunlong Feng <ylfeng@ir.hit.edu.cn>
checkpoint = 'checkpoint.pt.tar'

UNK = '<unk>'
PAD = '<pad>'
BOS = '<bos>'
EOS = '<eos>'
