#! /usr/bin/env python
# -*- coding: utf-8 -*_
# Author: Yunlong Feng <ylfeng@ir.hit.edu.cn>

"""
文本预处理工具
"""
from .iobes import IOBES, IOB2
