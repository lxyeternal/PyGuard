Release History
===============

0.1.1 (2014-03-09)
----------------
 - add HISTORY.rst on MANIFEST.in

0.1 (2014-03-09)
----------------
- french translation
- english manpage
- AUTHORS.rst and HISTORY.rst file
