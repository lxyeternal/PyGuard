# -*- coding: utf-8 -*-

__title__ = 'coincheck'
__version__ = '0.1.10'
__author__ = 'Shohei Kamon'
__license__ = 'MIT license'
__copyright__ = 'Copyright 2015 Shohei Kamon'

