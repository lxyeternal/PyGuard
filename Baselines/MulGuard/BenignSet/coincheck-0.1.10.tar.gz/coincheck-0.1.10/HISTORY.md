## 0.1.10 (2016-11-11)

- Fix some bugs

## 0.1.9 (2016-11-11)

- Change domain (from coincheck.jp to coincheck.com).

## 0.1.8 (2015-12-18)

- Add test code for order
- Change return type of order instance.

## 0.1.7 (2015-12-03)

- Add test codes
- Modify Nounce value from UNIX time (sec) to UNIX time (micro sec) * 1000000000
- Fix some bugs

## 0.0.1 (2015-04-06)

- Birth!
