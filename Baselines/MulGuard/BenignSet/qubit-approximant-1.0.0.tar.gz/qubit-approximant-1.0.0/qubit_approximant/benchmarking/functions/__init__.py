from .functions import gaussian, step, poly, relu, tanh, lorentzian, sine, cos2_sin2
