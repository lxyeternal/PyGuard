from .metrics import l1_norm, l2_norm, inf_norm, infidelity
from .metric_results import metric_results
