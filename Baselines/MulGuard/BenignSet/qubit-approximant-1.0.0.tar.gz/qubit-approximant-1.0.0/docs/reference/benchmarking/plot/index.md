::: qubit_approximant.benchmarking.plot
	handler: python
	options:
		show_root_heading: true
		show_source: true
