::: qubit_approximant.benchmarking.seeds.seeds
	handler: python
	options:
		show_root_heading: true
		show_source: true
