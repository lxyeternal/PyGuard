::: qubit_approximant.benchmarking.metrics.metrics
	handler: python
	options:
		show_root_heading: true
		show_source: true
