::: qubit_approximant.benchmarking.metrics.metric_results
	handler: python
	options:
		show_root_heading: true
		show_source: true
