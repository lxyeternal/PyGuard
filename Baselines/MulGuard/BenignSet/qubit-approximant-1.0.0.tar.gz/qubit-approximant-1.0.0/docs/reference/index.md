::: qubit_approximant
	handler: python
	options:
		show_root_heading: true
		show_source: true
