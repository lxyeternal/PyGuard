::: qubit_approximant.core.optimizer.optimizer
	handler: python
	options:
		show_root_heading: true
		show_source: true
