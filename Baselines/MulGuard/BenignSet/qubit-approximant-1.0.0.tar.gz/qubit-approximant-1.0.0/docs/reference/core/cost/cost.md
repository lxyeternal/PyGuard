::: qubit_approximant.core.cost.cost
	handler: python
	options:
		show_root_heading: true
		show_source: true
