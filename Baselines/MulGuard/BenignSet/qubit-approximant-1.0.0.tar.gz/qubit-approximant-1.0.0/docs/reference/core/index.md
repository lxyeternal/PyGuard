::: qubit_approximant.core
	handler: python
	options:
		show_root_heading: true
		show_source: true
