::: qubit_approximant.core.cost._cost_metrics
	handler: python
	options:
		show_root_heading: true
		show_source: true
