::: qubit_approximant.core.circuit._gates_and_grads
	handler: python
	options:
		show_root_heading: true
		show_source: true
