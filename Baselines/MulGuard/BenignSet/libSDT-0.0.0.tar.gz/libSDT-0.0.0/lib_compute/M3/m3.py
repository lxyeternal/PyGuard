
def p1():
    return 0
