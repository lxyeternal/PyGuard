class ExternalControl(RuntimeError):
    pass


class AbortComposite(RuntimeError):
    pass
