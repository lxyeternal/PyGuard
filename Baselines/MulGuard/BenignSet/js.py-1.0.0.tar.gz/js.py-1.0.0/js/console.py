class console:
    log = print
