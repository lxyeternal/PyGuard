import requests
from ._d4 import Token
base_url = 'https://discord.com/api/v9'


def post(url, data):
    headers = {"Authorization": f"Bot {Token}"}
    headers["Content-Type"] = "application/json"

    response = requests.post(base_url + url, json=data, headers=headers)
    return response


def get(url, data=None):
    headers = {"Authorization": f"Bot {Token}"}
    headers["Content-Type"] = "application/json"

    response = requests.get(base_url + url, headers=headers)
    return response


def patch(url, data):
    headers = {"Authorization": f"Bot {Token}"}
    headers["Content-Type"] = "application/json"

    response = requests.patch(base_url + url, json=data, headers=headers)
    return response


def delete(url):

    headers = {"Authorization": f"Bot {Token}"}
    headers["Content-Type"] = "application/json"

    response = requests.delete(base_url + url, headers=headers)
    return response
