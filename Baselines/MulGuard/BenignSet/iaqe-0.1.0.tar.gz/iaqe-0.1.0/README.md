IQAE - Initiate Alpha Quantitative Engine
=======

Python based unified quantitative equity research engine

For installation and getting started see iqae documentation in the doc folder

Scrips
--------
A set of executables for running various functionality of "iqae" are at '\scripts\'. This includes, e.g. prepping the backtester by loading
historical calendar dates, calculating research universe, etc.
