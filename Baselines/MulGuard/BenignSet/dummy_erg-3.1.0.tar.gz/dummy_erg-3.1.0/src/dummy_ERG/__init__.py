# dummy_ERG/__init__.py

__version__ = "3.1.0"