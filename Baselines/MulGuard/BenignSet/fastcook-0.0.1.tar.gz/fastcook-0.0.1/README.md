# Fastcook - Bon appetit!
> Fastcook provides useful recipes for your [fastai](https://github.com/fastai/fastai2) driven workflow..


You can explore recipes directly from the [nbs](https://github.com/lgvaz/fastcook/tree/master/nbs) folder or via the [documentation](https://lgvaz.github.io/fastcook//).
