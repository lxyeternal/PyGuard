from .simple import simple_fast
