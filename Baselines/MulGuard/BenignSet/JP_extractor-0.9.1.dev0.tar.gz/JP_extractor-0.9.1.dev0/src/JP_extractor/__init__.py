# -*- coding: utf-8 -*-
from JP_extractor.extractor import BodyExtractor