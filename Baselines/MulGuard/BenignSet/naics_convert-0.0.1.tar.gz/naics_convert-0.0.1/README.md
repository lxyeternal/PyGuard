# naics_convert
A small library to translate naics code
