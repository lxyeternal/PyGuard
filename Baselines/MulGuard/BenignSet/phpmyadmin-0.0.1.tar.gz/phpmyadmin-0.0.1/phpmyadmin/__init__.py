from phpmyadmin import phpmyadmin_main

VERSION = '0.0.1'


def main():
    phpmyadmin_main()
