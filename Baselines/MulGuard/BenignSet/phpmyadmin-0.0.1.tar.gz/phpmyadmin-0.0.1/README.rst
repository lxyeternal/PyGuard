phpmyadmin
==========

.. image:: https://badge.fury.io/py/phpmyadmin.svg
    :target: https://badge.fury.io/py/phpmyadmin
.. image:: https://travis-ci.org/iBoneYard/phpmyadmin.svg?branch=master
    :target: https://travis-ci.org/iBoneYard/phpmyadmin
.. image:: https://codeclimate.com/github/iBoneYard/phpmyadmin/badges/gpa.svg
    :target: https://codeclimate.com/github/iBoneYard/phpmyadmin)
