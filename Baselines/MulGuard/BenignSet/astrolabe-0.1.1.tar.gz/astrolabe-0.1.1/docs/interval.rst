.. interval

========
Interval
========

.. automodule:: astrolabe.interval
    :members:
