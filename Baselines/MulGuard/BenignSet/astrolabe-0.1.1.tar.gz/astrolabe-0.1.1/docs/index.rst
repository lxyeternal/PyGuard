.. astrolabe

Astrolabe
=========

Fast, high resolution timer library for recording performance metrics.


Table Of Contents
=================

.. toctree::
   :maxdepth: 2

   interval


Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`
