=========
Astrolabe
=========

Fast, high resolution timer library for recording performance metrics.

Installation
============

To install atomic, use pip : ::

    pip install astrolabe


Acknowledgement
===============

This is heavily inspired by `hitimes <https://github.com/copiousfreetime/hitimes/>`_.
