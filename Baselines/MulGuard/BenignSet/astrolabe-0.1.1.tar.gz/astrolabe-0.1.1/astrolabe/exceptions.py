

class AstrolabeException(Exception):
    pass


class IntervalException(AstrolabeException):
    pass
