from time import time

CONVERSION_FACTOR = 1


def instant():
    return time()
