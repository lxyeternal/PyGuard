# depthai-shared

Shared code and data between device and host side of DepthAI

