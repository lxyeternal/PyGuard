Sphinx epytext support
======================

Basic support for epytext docstrings.

- Replaces '@' in docstrings with ':' for epydoc fields
- Replaces L{..} and C{..} with :py:obj:`..`
- Removes U{..} from around links

