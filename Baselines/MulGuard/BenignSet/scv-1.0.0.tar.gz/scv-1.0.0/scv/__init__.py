# -*- coding: UTF-8 -*-
name = 'SCV'
__version__ = '1.0.0'