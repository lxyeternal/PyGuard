# Synapse-admin-api-python
A Python wrapper for Matrix Synapse admin API

This library is now support up to Synapse 1.25.0, any Admin API introduced after 1.25.0 may not be included in this version. However, newer chnages of Admin API are planned to be included in this library. For planned update, see [TODO.md](TODO.md). In the future, the version numbering convention will follow the version this library up to, for example, if this library is support up to 1.26.0, then the version number of this library will be 1.26.0.
## Please note that some methods are not tested yet

## Get Started
Todo. 
## Contribution
If you want to help me to improve the quality of this project, you can submit an issue.

If you want to collaborate with us, feel free to Fork this project and open a pull request.
### What can you do?
* For Issue
  * Report any Error.
  * Request new features based on the Synapse Admin API
  * Ask questions if you do not understand something.

* For Pull request
  * Add comments to source code.
  * Add new features based on the Synapse Admin API
  * Correct any Error.
