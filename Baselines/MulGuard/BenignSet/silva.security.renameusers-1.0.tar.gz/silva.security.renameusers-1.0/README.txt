==========================
silva.security.renameusers
==========================

This `Silva`_ extension provides you with a form in ZMI on the service
``service_extensions`` named ``manage_renameUsers`` that let you in
one time rename references to a lot of Silva users across all the
Silva site.

To do this, you upload in this form a CSV file that contains a mapping
from the new user identifier to the old one.

Code repository
===============

The code for this extension can be found in Git:
https://github.com/silvacms/silva.security.renameusers

.. _Silva: http://silvacms.org
