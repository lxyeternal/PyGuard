
[github](https://github.com/eaybek/content-manager/)  
[PyPi](https://pypi.org/project/content-manager/)  

content-manager reserved for self usage purpose

