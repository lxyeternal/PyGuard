/// <reference path="../typings/npm-registry-client/npm-registry-client.d.ts"/>
