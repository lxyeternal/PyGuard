# -*- coding: utf-8 -*-


def send(host, port, user, token, data):
    print("cambrain is in developing")
