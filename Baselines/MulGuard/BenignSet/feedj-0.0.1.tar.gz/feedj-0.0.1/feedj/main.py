def main():
	print("Hello")
