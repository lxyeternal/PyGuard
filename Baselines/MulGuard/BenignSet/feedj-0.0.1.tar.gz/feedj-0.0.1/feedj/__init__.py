# flake8: noqa
from feedj._version import __version__
from feedj._version import __author__
