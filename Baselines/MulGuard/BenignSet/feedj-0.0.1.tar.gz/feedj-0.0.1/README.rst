================================================================================
feedj
================================================================================

.. image:: https://api.travis-ci.org/mlcristina/feedj.svg
   :target: http://travis-ci.org/mlcristina/feedj

.. image:: https://codecov.io/github/mlcristina/feedj/coverage.png
   :target: https://codecov.io/github/mlcristina/feedj


.. image:: https://readthedocs.org/projects/feedj/badge/?version=latest
   :target: http://feedj.readthedocs.org/en/latest/


Installation
================================================================================

You can get it:

.. code-block:: bash

    $ git clone https://github.com/mlcristina/feedj.git
    $ cd feedj
    $ python setup.py install
