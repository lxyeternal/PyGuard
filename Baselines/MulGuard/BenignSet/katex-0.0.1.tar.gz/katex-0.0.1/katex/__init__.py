# -*- coding: UTF-8 -*-
from __future__ import unicode_literals

from .core import *
from .models import *

# Remember to update this in setup.py as well
__version__ = "0.0.1"
__author__ = "Mads Marquart"
__author_email__ = "madsmtm@gmail.com"
__copyright__ = "Copyright 2018 by Mads Marquart"
__license__ = "BSD 3-Clause"
