*This project is a fork of gocept.sequence (http://pypi.python.org/pypi/gocept.sequence/)
originally created by Daniel Havlik and Sebastian Wehrmann.*
