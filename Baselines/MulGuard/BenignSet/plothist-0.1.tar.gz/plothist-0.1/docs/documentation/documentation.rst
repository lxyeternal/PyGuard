.. _documentation-label:

=====================
Package documentation
=====================


plotters.py
-----------

.. automodule:: plothist.plotters
   :members:

hep_examples.py
---------------

.. automodule:: plothist.hep_plotters
   :members:
