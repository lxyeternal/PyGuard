class SC2ReplayParser(object):
    def __init__(self):
        pass

    def return_hello(self):
        return 'hello'
