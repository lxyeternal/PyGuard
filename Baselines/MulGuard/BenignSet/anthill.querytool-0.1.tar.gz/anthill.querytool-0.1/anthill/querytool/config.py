
PRODUCTNAME = 'anthill.querytool'
TOOL_ID = TOOLNAME = 'query_tool'
META_TYPE = TOOLTYPE = 'QueryTool'

# if setting this to true then all queries
# will be expanded with Eq('Language', <selectedlang>)
# if LinguaPlone is installed - look at patches.py
IMPLICIT_LANGUAGE_FILTER = False
