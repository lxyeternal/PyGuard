from setuptools import setup, find_packages
setup(
    name="code-astro_nstarorbits_project",
    version="0.1",
    packages=find_packages(),
)
