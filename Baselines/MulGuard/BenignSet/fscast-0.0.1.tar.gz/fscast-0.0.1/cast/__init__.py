import logging.config

import cast.logconf

logging.config.dictConfig(cast.logconf.CONFIG)

