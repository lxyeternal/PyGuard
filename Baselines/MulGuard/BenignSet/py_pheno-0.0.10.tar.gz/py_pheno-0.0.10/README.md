# py_pheno
This is a simple package for py_pheno analysis.
You can see more details from https://github.com/spjace/py_pheno/
