# coding: utf-8

# $Id: $


# Django Views for Async APIs


VERSION = '0.13.0'
