PyBREAKOUT
==========

Yet another Breakout game written in Python.

.. image:: https://raw.githubusercontent.com/julianolf/pybreakout/master/screenshot.png
    :width: 640px
    :alt: game play screenshot

Requirements
------------

* Python >= 3.7, < 3.8

Installing
----------

Use ``pip`` to download and install the game. ::

    $ pip install pybreakout

Running
-------

Just type ``pybreakout`` to run the game. ::

    $ pybreakout

Controls
--------

Use the arrow keys to control the paddle.
