# monomorphic
Conversion utility to address libraries that do not support polymorphism for python builtin types

See: [README.ipynb] for details
