import sys
import importlib
importlib.reload(sys)
sys.setdefaultencoding('utf-8')