pmxbot Haiku
============
A ``pmxbot`` plugin that provides MongoDB collections for handling haiku poems.
