
# jsonbp

**jsonbp** (JSON BluePrint) is a library to validate and deserialize JSON into Python based on a schema.  
jsonbp uses its own  domain language to define a schema.
