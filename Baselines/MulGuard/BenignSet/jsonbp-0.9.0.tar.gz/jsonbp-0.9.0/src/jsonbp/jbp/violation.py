
class JsonViolation(Exception):
	pass

