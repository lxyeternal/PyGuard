from setuptools import setup

setup(name='Lev_Distributions',
      version='0.1',
      description='Gaussian and Binomial Distributions',
      packages=['Lev_Distributions'],
      zip_safe=False)
