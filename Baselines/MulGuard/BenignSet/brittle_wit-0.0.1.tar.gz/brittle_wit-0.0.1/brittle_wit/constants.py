import logging


FIFTEEN_MINUTES = 15 * 60

LOGGER = logging.getLogger('brittle_wit')
