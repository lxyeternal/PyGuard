``pyramid_zcml``
================

``pyramid_zcml`` is a package which provides ZCML (Zope Configuration Markup
Language) directives for all "configurator" methods available in the `Pyramid
<http://docs.pylonsproject.org>`_ web framework.

See `http://docs.pylonsproject.org/projects/pyramid_tutorials/dev/
<http://docs.pylonsproject.org/projects/pyramid_tutorials/dev/>`_ for
detailed documentation.
