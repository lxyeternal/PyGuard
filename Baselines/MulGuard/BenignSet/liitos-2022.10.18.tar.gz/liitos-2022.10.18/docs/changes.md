# Changes

## 2022.10.18

* Added YAML format readers for approvals and changes

## 2022.9.18

* Added command line verification script
* Added documentation
* Added PyYAML dependency

## 2022.8.1

* Initial release on PyPI
