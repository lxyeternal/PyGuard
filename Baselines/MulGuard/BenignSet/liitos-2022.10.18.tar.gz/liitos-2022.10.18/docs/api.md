# API

Use the python help command to learn about the API.

Something like:

```python
>>> import liitos.gather as api
>>> help(api)
```
