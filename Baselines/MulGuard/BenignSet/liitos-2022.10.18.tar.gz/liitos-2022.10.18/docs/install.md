# Installation

Preferred way to install is as usual (for testing or in isolation):

```console
❯ pipx install liitos
```

For production use (well, ahem, ...) or within a virtual python env:

```console
❯ pip install liitos
```

