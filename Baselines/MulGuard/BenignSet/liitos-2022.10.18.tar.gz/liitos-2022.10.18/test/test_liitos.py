from liitos.liitos import parse


def test_parse():
    assert parse() is NotImplemented
