---
setting: special opq value
