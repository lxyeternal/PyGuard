"""
    Jupyter kernel provisioner for Ignition
"""

__version__ = 'v0.7.2'