# Bot By https://t.me/DKBOTZ || https://t.me/DK_BOTZ || https://t.me/DKBOTZHELP
# Creadit To My Friend https://t.me/Bot_Magic_World


START_MESSAGE = """
👋Hello {mention}..!
It's Power Full [{name}](t.me/{username}) Here 😎
Add Me To Your Group And Make Sure I'm an Admin There..!
And Enjoy My Pever Show..! 🤪"""

HELP_MESSAGE = """
𝙷𝙴𝙻𝙻𝙾 {mention}
𝙸 𝙲𝙰𝙽 𝙶𝚄𝙸𝙳𝙴 𝚈𝙾𝚄 𝚃𝙷𝚁𝙾𝚄𝙶𝙷 𝙰𝙻𝙻 𝙾𝙵𝙵 [{name}](https://t.me/{username})', 𝙲𝙾𝙾𝙻 𝙵𝙴𝙰𝚃𝚄𝚁𝙴𝚂 𝙰𝙽𝙳 𝙷𝙾𝚆 𝚃𝙾 𝙿𝚁𝙾𝙿𝙴𝚁𝙻𝚈 𝚄𝚂𝙴 𝚃𝙷𝙴𝙼. 𝚃𝙷𝙴 𝙱𝚄𝚃𝚃𝙾𝙽𝚂 𝙱𝙴𝙻𝙾𝚆 𝚃𝙾 𝙽𝙰𝚅𝙸𝙶𝙰𝚃𝙴 𝚃𝙷𝙴𝙾𝚄𝙶𝙷 𝙰𝙻𝙻 𝙾𝙵 𝚃𝙷𝙴 𝙼𝙾𝙳𝚄𝙻𝙴𝚂
"""

ABOUT_MESSAGE = """
𝙱𝙾𝚃 𝚃𝚈𝙿𝙴 : -
𝙱𝙾𝚃 𝙱𝚁𝙰𝙽𝙲𝙷 : -
𝙳𝙴𝚅𝙴𝙻𝙾𝙿𝙴𝚁 : -
𝙲𝚁𝙴𝙰𝚃𝙾𝚁 : [{name}](https://t.me/{username})
𝙻𝙰𝙽𝙶𝚄𝙰𝙶𝙴 : 𝙿𝚈𝚃𝙷𝙾𝙽3 : {py3_version}
𝙻𝙸𝙱𝚁𝙰𝚁𝚈 : 𝙿𝚈𝚁𝙾𝙶𝚁𝙰𝙼 : {pyro_version}
𝚅𝙴𝚁𝚂𝙸𝙾𝙽 : {version}
𝚂𝙾𝚄𝚁𝙲𝙴 : -
"""

SETTINGS_MESSAGE = """
**𝙲𝙷𝙰𝙽𝙶𝙴 𝚈𝙾𝚄𝚁 𝚂𝙴𝚃𝚃𝙸𝙽𝙶𝚂 𝙵𝙾𝚁 Change {title} 𝙰𝚂 𝚈𝙾𝚄𝚁 𝚆𝙸𝚂𝙷.⚙"""

CHAT_LOGS_MESSAGE = """
• **{title}**\n• `{id}`\n• **{join}**"""

SPELLMODE_MESSAGE = """
**__Hello 👋 {mention}**__
**__Couldn't Find {query} ?  Please Click Your Request Name**__"""

REQUEST_MESSAGE = """
**Requested By:** {mention}\n**Requested Name:** {query}\n™ {group_name}"""

WELCOME_MESSAGE = """
𝙷𝙴𝙻𝙻𝙾 {mention} 𝚆𝙴𝙻𝙲𝙾𝙼𝙴 𝚃𝙾 {group_name}"""

FILECAPTION_MESSAGE = """
• `{file_name}` \n 𝙹𝙾𝙸𝙽 : @DKBOTZ"""

ADMIN_CMD_MESSAGE = """
𝙰𝙳𝙼𝙸𝙽𝚂 𝙲𝙾𝙼𝙼𝙰𝙽𝙳𝚂 :-
\n • /broadcast : 𝚁𝙴𝙿𝙻𝚈 𝙰𝙽𝚃 𝙼𝙴𝙳𝙸𝙰/𝙼𝚂𝙶\n • /total : 𝙶𝙴𝚃 𝙵𝙸𝙻𝙴𝚂 𝙲𝙾𝚄𝙽𝚃\n • /delete : 𝙳𝙴𝙻𝙴𝚃𝙴 𝚂𝙸𝙽𝙶𝙻𝙴 𝙵𝙸𝙻𝙴𝚂\n • /delall : 𝙳𝙴𝙻𝙴𝚃𝙴 𝙰𝙻𝙻 𝙵𝙸𝙻𝙴𝚂\n • /logs : 𝙶𝙴𝚃 𝙱𝙾𝚃 𝙻𝙾𝙶𝚂"""

STATUS_MESSAGE = """
× {bot_name} 𝚂𝚃𝙰𝚃𝚄𝚂 :-
× 𝚃𝙾𝚃𝙰𝙻 𝚄𝚂𝙴𝚁𝚂 : {users}\n× 𝚃𝙾𝚃𝙰𝙻 𝙵𝙸𝙻𝙴𝚂 : {files}\n× 𝚃𝙾𝚃𝙰𝙻 𝙲𝙷𝙰𝚃𝚂 : {chats}"""

GETFILE_TEXT = """
𝙷𝙴𝚈 {mention} 𝚈𝙾𝚄𝚁 𝙵𝙸𝙻𝙴 𝙸𝚂 𝚁𝙴𝙰𝙳𝚈
\n𝙵𝙸𝙻𝙴𝙽𝙰𝙼𝙴 : `{file_name}`\n\n𝙵𝙸𝙻𝙴𝚂𝙸𝚉𝙴 : {file_size}"""

NOT_SUB = """
𝙸 𝙻𝙸𝙺𝙴 𝚈𝙾𝚄𝚁 𝚂𝙼𝙰𝚁𝚃𝙽𝙴𝚂𝚂, 𝙱𝚄𝚃 𝙳𝙾𝙽'𝚃 𝙱𝙴 𝙾𝚅𝙴𝚁𝚂𝙼𝙰𝚁𝚃 😤.\n 𝙵𝚒𝚛𝚜𝚝 𝚂𝚞𝚋𝚜𝚌𝚛𝚒𝚋𝚎 𝙼𝚢 𝙲𝚑𝚊𝚗𝚗𝚎𝚕 😕"""              

USAGE_MESSAGE = """
🤠 🄷🄾🅆 🅃🄾 🅄🅂🄴

-

× 𝚃𝙷𝙸𝚂 𝙱𝙾𝚃 𝙳𝙴𝙿𝙻𝙾𝚈𝙴𝙳 𝙱𝚈
  - [{}](t.me/{})"""



