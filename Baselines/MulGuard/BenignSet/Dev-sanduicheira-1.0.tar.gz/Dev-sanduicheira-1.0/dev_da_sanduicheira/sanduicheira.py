def ligar():
    print('Ligando sanduicheira')
    
def desligar():
    print('Desligando sanduicheira')