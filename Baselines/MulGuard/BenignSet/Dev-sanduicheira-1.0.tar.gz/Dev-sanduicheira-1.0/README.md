# Dev Sanduicheira

Este pacote foi criado apenas para praticar meus conhecimentos em python

* passos para instalção
* Outras informações relevantes(autores, empresa, contato)