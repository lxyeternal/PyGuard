SDK
===

.. image:: https://img.shields.io/pypi/v/bill.svg
    :target: https://pypi.python.org/pypi/bill/
    :alt: Latest Version

.. image:: https://img.shields.io/pypi/wheel/bill.svg
    :target: https://pypi.python.org/pypi/bill/

.. image:: https://img.shields.io/pypi/pyversions/bill.svg
    :target: https://pypi.python.org/pypi/bill/

.. image:: https://img.shields.io/pypi/l/bill.svg
    :target: https://pypi.python.org/pypi/bill/



SDK.


Installing
----------

Install and update using `pip`_:

.. code-block:: text

    pip install -U bill



.. _pip: https://pip.pypa.io/en/stable/quickstart/
