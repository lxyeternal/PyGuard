__author__ = 'Tommaso Barbugli'
__copyright__ = 'Copyright 2013, Tommaso Barbugli'
__credits__ = []


__license__ = 'BSD'
__version__ = '0.1'
__maintainer__ = 'Tommaso Barbugli'
__email__ = 'tbarbugli@gmail.com'
__status__ = 'Production'

from datadog import DataDogPeriodicPusher
