# NoLog

A propositional logic implementation in Python, to be used as a rule engine.gi