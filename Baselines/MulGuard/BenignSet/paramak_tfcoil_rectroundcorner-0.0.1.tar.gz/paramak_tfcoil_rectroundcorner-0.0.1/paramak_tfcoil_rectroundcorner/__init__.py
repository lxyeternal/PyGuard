from .core import ToroidalFieldCoilRectangleRoundCorners
from .test_module import surface_area
from .test_module import volume