# paramak_tfcoil_rectroundcorner

This package contains a new rectangle Toroidal Field coil class for the Paramak,
with rounded corners.

To install:
```bash
pip install paramak_tfcoil_rectroundcorner
```
