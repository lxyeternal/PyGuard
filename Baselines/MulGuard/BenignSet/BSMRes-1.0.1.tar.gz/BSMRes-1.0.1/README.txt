Welcome to my MRes task exploring Goal Conflict using the Reinforcement Sensitivity Theory. 

This work is in its infancy, but intends to be explored in greater depth in further studies. 