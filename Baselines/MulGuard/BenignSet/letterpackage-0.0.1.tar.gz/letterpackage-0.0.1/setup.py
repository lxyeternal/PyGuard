from setuptools import setup

setup(
    name='letterpackage',
    version='0.0.1',
    license='MIT',
    description='Paquete DATA SCIENCE FEB23 EDEM',
    author='Alumnos DATA SCIENCE FEB23 EDEM',
    install_requires=['os','cv2','nunpy','pandas','sklearn','keras','matplotlib','xgboost','sklearn']
)