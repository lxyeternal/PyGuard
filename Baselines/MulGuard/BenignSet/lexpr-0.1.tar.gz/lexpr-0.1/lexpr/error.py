class LexprError(Exception):
  pass

class LexprParserError(LexprError):
  pass

