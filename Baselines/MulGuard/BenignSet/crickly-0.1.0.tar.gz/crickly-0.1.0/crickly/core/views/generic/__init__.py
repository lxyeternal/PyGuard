# -*- coding: utf-8 -*-
from __future__ import unicode_literals
from crickly.core.views.generic.argument_view import View as ArgumentView

__all__ = [
    'ArgumentView'
]
