<h1 align="center">Salvador_info</h1>
<p align="center">It's a Usefull Project for Developers ... TO GET USERNAME INFO </p>

<p align="center"> • DevVlopered The Lib BY ALAA7X- salvador• </p>


## Installing :
```
pip install CLAFX
```
INFO:  TO GET USERNAME rest 
```