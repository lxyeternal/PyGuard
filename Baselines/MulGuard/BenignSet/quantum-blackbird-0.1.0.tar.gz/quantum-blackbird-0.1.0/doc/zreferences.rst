References and further reading
==============================


References
----------

.. bibliography:: references.bib
	:cited:
	:style: unsrt
	:labelprefix: R


