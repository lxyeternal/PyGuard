"""Get metadata of SD Files in a lightweight way."""
"""
The `sendoff` library provides lightweight tools for inspecting the metadata
of chemical SD Files.  It strives to do as little modification of the input
files as possible.
"""
__version__ = "0.1.0"
