from django.apps import AppConfig


class ConfigBackupConfig(AppConfig):
    name = 'config_backup'
