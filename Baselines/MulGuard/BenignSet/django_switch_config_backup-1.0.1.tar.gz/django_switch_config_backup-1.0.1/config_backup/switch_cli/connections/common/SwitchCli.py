class SwitchCli:
    connection = None
    connection_type = None

    def connect(self, ip, username=None, password=None):
        pass

    def command(self, command, expected_response):
        pass

    def login(self, ip, username, password, enable_password):
        pass
