.. {packagename} documentation master file, created by python-git-package.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

{packagename_underline}

:Release:  |version|
:Date:  |today|

{description}

Contents:

.. toctree::
   :maxdepth: 2

   {packagename_file}
   
Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`

