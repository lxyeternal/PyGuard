{packagename_underline}

.. automodule:: {packagename_file}.{packagename_file}
   :members: