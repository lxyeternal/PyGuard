{packagename}
------------
{description}

Installation
============

Prequisites
^^^^^^^^^^^
* 

Setup
^^^^^
* download the latest `release <{url}/releases>`_
* unzip and cd to the folder
* run ``python setup.py install``

Examples
========
To get started, check the `examples <{url}/tree/master/examples/>`_ folder
