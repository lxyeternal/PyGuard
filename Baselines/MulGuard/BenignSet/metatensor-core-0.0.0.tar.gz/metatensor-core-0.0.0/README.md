# Metatensor-core

This project is not yet fully released on PyPI, please install it from source
for now: https://github.com/lab-cosmo/equistore
