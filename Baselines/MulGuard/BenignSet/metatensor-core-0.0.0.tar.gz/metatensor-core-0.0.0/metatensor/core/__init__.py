raise ImportError(
    "this project is not yet fully released on PyPI, please install it from source"
)
