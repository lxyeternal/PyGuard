def calcularR(edad, porcentaje):
    rendimiento_cardiaco = (220 - edad) * (porcentaje / 100)
    return rendimiento_cardiaco

