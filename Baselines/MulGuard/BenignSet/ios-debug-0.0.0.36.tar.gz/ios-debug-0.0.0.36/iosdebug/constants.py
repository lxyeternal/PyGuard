DATA_FILE = ".ios-debug_data.pkl"
IGNORE_FILE = ".ios-debug.yml"

KEY_MOCK_IMPLEMENTATIONS = "mock_implementations"

RUN_SCRIPT_PHASE_ID = "BBF071DD2631DA3900DF13DA"
