# punting ![tests](https://github.com/microprediction/punting/workflows/tests_39/badge.svg)
Basic utilities
