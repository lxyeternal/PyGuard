# rdme-cli

## Install

```bash
$ pip install rdme-cli
```

```bash
$ rdme-cli spec --path ../doc.yml --id 123
```
