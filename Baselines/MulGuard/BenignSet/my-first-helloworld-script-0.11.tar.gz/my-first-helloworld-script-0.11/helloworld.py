print("Hello World!")
print("My first pip application!")