"""Polygons clipping based on algorithm by F. Martinez et al."""

__version__ = '0.0.0'
