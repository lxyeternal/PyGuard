"""
Tests for the SAML 2.0 Service Provider.
"""
