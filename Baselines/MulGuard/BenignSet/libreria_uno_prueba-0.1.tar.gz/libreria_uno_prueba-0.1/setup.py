from setuptools import find_namespace_packages, setup

setup(
name='libreria_uno_prueba',
version='0.1',
packages=find_namespace_packages(),
py_modules=['libreria_uno_prueba']
)