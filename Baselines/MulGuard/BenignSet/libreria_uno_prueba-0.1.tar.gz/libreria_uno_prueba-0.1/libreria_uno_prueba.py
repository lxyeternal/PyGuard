def suma(x, y):
    res = x + y 
    return res

def say_hello():
    print('hello')