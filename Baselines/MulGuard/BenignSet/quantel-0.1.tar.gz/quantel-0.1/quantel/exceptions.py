class InvalidAPIKey(Exception):
    pass


class GatewayError(Exception):
    pass
