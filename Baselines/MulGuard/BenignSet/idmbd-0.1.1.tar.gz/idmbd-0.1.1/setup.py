from setuptools import setup

setup(name='idmbd',
      version='0.1.1',
      description='Innovando el Desarrollo de Modelos a traves del Big Data',
      url='http://github.com/cpazsantos/ciffmbd2016pldmcp',
      author='Paola Lopez, Diego Martin, Carlos Paz',
      author_email='cpazsantos@gmail.com',
      packages=['idmbd'],
      zip_safe=False)
