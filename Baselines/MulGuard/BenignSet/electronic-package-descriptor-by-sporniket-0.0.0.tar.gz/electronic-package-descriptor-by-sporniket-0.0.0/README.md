# electronic-package-descriptor
An abstract model to describe electronic components for my generator of symbols for Kicad
