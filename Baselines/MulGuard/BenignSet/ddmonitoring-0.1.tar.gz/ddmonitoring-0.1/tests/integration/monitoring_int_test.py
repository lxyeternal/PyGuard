def dummy():
    assert 1==1