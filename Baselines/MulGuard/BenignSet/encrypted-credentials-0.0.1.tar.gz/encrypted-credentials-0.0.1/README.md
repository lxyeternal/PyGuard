
**encrypted-credentials** is an app which encrypts credentials to allow them to be securely added to git repositories.

It can import encrypted settings into Django defined in a json file.