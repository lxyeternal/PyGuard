from distutils.core import setup

setup(
	name = 'listviewer',
	version = '1.0.0',
	py_modules = ['listviewer'],
	author = 'saif',
	author_email = 'saifsmailbox98@yahoo.in',
	url = 'http://saifurrahman.tk',
	description = 'A simple printer of nested lists'
)
