from setuptools import setup

setup(name='RASP',
      version='1.0.0',
      description='Runtime application self-protection',
      url='https://www.python.org/',
      packages=['rasp_util'],
      #install_requires=['re>=2.2.1'],#, 'urllib.request>=3.6'
      python_requires='>=3'
     )