from .models import Proxy
from .fetcher import ProxyFetcher