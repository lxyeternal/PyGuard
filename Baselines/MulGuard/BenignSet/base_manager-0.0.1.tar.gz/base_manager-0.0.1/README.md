# base_manager
Use this little library for save your object in sqlite3.db with use two simple commadns: post, get.
