# Download animes

Download any anime from the web with only one command in your PC