DEFAULT = {
    "site":"animefenix",
    "player": "your_upload"
}
