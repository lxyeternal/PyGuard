API_ROOT = "https://api.bittrex.com/v3"
