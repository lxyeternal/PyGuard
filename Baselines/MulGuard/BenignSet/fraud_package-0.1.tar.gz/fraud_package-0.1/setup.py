from setuptools import setup

setup(name='fraud_package',
      version='0.1',
      description='Fraud detection Feature Engineering Packages',
      packages=['fraud_package'],
      zip_safe=False)
