from django.apps import AppConfig


class DjangoChurchDataConfig(AppConfig):
    name = 'djangochurch_data'
