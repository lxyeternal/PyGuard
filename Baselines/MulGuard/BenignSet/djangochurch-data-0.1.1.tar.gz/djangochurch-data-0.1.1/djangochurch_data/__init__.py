
default_app_config = 'djangochurch_data.apps.DjangoChurchDataConfig'
