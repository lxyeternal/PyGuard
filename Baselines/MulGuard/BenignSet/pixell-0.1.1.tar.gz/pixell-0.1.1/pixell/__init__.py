# -*- coding: utf-8 -*-

"""Top-level package for pixell."""

__author__ = """Simons Observatory Collaboration Analysis Library Task Force"""
__email__ = ''
__version__ = '0.1.1'
