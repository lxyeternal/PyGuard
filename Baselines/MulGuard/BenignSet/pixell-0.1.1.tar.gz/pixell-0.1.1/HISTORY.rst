=======
History
=======

0.1.0 (2018-06-15)
------------------

* First release on PyPI.
