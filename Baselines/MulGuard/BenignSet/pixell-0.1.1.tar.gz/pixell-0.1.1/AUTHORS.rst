=======
Credits
=======

Development Lead
----------------

* Simons Observatory Collaboration Analysis Library Task Force <>

Contributors
------------

* Sigurd Naess (@amaurea)
* Mathew Madhavacheril (@msyriac)
