from . import diagnostics, eda, linear_model
