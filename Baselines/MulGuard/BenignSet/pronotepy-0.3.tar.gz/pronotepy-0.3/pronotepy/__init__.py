from .pronoteAPI import ClientStudent, ClientTeacher
from .dataClasses import *
