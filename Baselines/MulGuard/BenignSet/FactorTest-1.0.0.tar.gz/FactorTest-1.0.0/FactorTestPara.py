
#根目录
rootpath='D:\\DataBase\\'

#数据存储目录——因子测试相关
#杂项
filepathtestdata=rootpath+'factortest\\'


#数据更新文件位置
DataInfopath = rootpath+'DataInfo.xlsx'
FactorInfopath = rootpath+'FactorInfo.xlsx'

Datapath=rootpath+'DataBase/'
Factorpath=rootpath+'FactorDB/'
compresspath=rootpath+'压缩文件/'

Temppath=rootpath+'temp/'

g_starttime=19000101
g_endtime=21000101


#存储因子名单

#因子目录文件
