=======
glinski
=======

Overview
--------

Gliński's chess.

Installation
------------

To install glinski, you can use `pip`. Open your terminal and run:

.. code-block:: bash

    pip install glinski

License
-------

This project is licensed under the MIT License.

Links
-----

* `Download <https://pypi.org/project/glinski/#files>`_
* `Source <https://github.com/johannes-programming/glinski>`_

Credits
-------
- Author: Johannes
- Email: johannes-programming@posteo.org

Thank you for using glinski!
