# -*- coding: utf-8 -*-

"""Top-level package for resseg."""

__author__ = """Fernando Perez-Garcia"""
__email__ = 'fernando.perezgarcia.17@ucl.ac.uk'
__version__ = '0.1.0'

from .resseg import resseg
