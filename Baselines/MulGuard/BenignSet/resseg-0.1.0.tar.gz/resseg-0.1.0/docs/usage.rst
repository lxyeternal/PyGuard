=====
Usage
=====

To use resseg in a project::

    import resseg
