======
resseg
======


.. image:: https://img.shields.io/pypi/v/resseg.svg
        :target: https://pypi.python.org/pypi/resseg

.. image:: https://img.shields.io/travis/fepegar/resseg.svg
        :target: https://travis-ci.org/fepegar/resseg

.. image:: https://readthedocs.org/projects/resseg/badge/?version=latest
        :target: https://resseg.readthedocs.io/en/latest/?badge=latest
        :alt: Documentation Status


.. image:: https://pyup.io/repos/github/fepegar/resseg/shield.svg
     :target: https://pyup.io/repos/github/fepegar/resseg/
     :alt: Updates



Automatic segmentation of epilepsy neurosurgery resection cavity.


* Free software: MIT license
* Documentation: https://resseg.readthedocs.io.


Features
--------

* TODO

Credits
-------

This package was created with Cookiecutter_ and the `audreyr/cookiecutter-pypackage`_ project template.

.. _Cookiecutter: https://github.com/audreyr/cookiecutter
.. _`audreyr/cookiecutter-pypackage`: https://github.com/audreyr/cookiecutter-pypackage
