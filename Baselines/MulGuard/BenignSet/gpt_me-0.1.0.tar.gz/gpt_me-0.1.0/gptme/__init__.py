"""An experiment to replicate a fully self-sufficient, human-like chatbot that imitates you using various artificial intelligence models."""

__version__ = "0.1.0"
