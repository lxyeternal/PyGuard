from _discord import DiscordAdapter
