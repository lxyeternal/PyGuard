API_BASE_URL = "https://www.thebluealliance.com/api/v3"
API_STATUS_URL = API_BASE_URL + "/status"

API_TEAM_URL = "/team/{}"
API_EVENT_URL = "/event/{}"
