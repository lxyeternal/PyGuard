async_tba
---
[![Build Status](https://travis-ci.org/c-x-berger/async_tba.svg?branch=master)](https://travis-ci.org/c-x-berger/async_tba) [![Code style: black](https://img.shields.io/badge/code%20style-black-000000.svg)](https://github.com/ambv/black)

📊 aiohttp based Python API for [The Blue Alliance](https://www.thebluealliance.com/)
