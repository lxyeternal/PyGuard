# pydemo
## PyPA
[Python Packaging User Guide](https://packaging.python.org/)
## Build
`python setup.py build`
## Install
`python setup.py install`
## Usage
```
import pydemo
pydemo.init('testdemo')
```
