__title__ = 'nexus-stats-api'
__author__ = 'Orangutan'
__license__ = 'MIT'
__version__ = '0.1'

from .api import Requester as Client
from .profile import Profile