# gibiga Distributions

Gaussian and Binomial Distribution Classes

### Installing

```
pip install gibiga_distributions
```
## License

This project is licensed under the MIT License - see the [LICENSE.md](LICENSE.md) file for details
