from authro.gateways.connect import ConnectionGateway


def connect():
    return ConnectionGateway()