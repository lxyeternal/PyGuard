from setuptools import setup

setup(
   name='authro',
   version='0.0.1',
   description='An identity platform',
   author='Muthu',
   author_email='contact@muthupandian.in',
   packages=['authro'],  #same as name
   install_requires=[], #external packages as dependencies
)