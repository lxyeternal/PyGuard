def printName_a2():
    print("我是package_a里面的module_a2")