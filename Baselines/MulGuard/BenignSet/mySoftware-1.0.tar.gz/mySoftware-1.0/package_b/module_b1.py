from package_a.module_a1 import printName_a1


def printName_b1():
    print("我是package_b里面的module_b1")

printName_a1()