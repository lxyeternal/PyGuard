from distutils.core import setup
setup(
     name="mySoftware",
     version="1.0",
     description="itheima belongs to vivi",
     author="vivi",
     py_modules=['package_a.module_a1', 'package_a.module_a2', 'package_b.module_b1'],

)
