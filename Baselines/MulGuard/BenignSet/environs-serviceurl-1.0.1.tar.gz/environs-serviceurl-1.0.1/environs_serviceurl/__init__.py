from .parser import service_url

__version__ = '1.0.1'

__all__ = ['service_url', '__version__']
