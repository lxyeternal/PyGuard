[![PyPi Release](https://img.shields.io/pypi/v/maestral-cocoa.svg)](https://pypi.org/project/maestral-cocoa/)
[![Pyversions](https://img.shields.io/pypi/pyversions/maestral-cocoa.svg)](https://pypi.org/pypi/maestral-cocoa/)

# Maestral Cocoa <img src="https://raw.githubusercontent.com/SamSchott/maestral-dropbox/master/maestral/gui/resources/maestral.png" align="right" title="Maestral" width="110" height="110">

A Cocoa user interface for the [Maestral Daemon](https://www.github.com/samschott/maestral-dropbox).
