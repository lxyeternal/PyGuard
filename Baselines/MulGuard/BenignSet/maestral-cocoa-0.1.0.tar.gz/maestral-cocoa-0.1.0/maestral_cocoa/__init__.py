__author__ = 'Sam Schott'
__version__ = '0.1.0'
__url__ = 'https://github.com/SamSchott/maestral'
