#!/usr/bin/python3

from .quantumdiceware import main
main()