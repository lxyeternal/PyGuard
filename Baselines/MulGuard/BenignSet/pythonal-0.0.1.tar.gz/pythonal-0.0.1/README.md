# pythonal
Functional Python Library
