from zope.i18n import MessageFactory
AbstractGallerifficMessageFactory = MessageFactory('Products.galleriffic')
# 
def initialize(context):
    """Initializer called when used as a Zope 2 product."""
    pass