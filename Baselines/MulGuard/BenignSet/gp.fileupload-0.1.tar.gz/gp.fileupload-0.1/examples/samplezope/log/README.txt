This directory contains logs such as the event log.
