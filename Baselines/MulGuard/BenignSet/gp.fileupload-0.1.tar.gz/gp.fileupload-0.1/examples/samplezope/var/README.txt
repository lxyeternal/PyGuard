This directory contains files for Zope's object database (ZODB)
storage.  You can change where these files are stored by editing
the zope.conf configuration file.
