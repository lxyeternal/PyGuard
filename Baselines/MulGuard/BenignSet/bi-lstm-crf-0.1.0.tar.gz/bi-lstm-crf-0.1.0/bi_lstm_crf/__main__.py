from .app.train import main

main()
