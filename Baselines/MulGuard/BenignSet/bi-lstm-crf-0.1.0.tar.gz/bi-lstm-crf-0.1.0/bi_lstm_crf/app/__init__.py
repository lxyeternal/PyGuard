from .predict import WordsTagger
from .train import train
