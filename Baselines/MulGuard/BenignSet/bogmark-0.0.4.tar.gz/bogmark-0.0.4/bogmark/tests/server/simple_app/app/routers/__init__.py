from .v1.app import compiled_routers as v1_app

apps = [v1_app]

__all__ = ["apps"]
