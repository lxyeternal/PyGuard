# As I import the .py module from inside a package
# that's why I need to use '.plt_rdf'
# '.' means this path
from .plt_rdf import rdf
