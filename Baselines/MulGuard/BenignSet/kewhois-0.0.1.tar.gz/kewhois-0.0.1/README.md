A Kenyan whois lookup client.
Uses whois.kenic.or.ke as the server.