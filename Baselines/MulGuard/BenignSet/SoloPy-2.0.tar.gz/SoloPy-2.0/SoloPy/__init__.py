from SoloPy.solo_motor_controller import SoloMotorController
import SoloPy.constant 
