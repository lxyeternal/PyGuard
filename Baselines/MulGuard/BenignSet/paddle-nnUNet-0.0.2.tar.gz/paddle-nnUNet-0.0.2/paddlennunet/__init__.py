# !/usr/bin/env python
# -*- coding:utf-8 -*-
# author: jeremy.zhang(szujeremy@gmail.com, Shenzhen University, China)

print('Hello from the paddle-nnUNet. https://paddle-nnunet.readthedocs.io')


