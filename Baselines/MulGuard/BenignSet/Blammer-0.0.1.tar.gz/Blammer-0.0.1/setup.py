from setuptools import setup


setup(
    name="Blammer",
    version="0.0.1",
    description="Must have a helper with you",
    author="Coder100",
    author_email="jacobhason86@gmail.com"
)