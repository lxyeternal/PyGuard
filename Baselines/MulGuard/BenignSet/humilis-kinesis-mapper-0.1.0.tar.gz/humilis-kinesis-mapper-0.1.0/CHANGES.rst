Changelog
=========

0.1.0
-----

- Major refactoring to simplify and clean the code (germangh)


0.0.1
-----

- Initial release
