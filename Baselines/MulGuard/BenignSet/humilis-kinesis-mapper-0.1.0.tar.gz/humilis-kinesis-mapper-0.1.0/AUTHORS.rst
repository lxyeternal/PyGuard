Authors
=======

`Anatoly Bubenkov <bubenkoff@gmail.com>`_
    original idea and implementation
    
These people have contributed to `humilis-kinesis-mapper`, in alphabetical order:

* `German Gomez-Herrero <german.gomezherrero@gmail.com>`_
