# -*- coding: utf-8 -*-


class KinesisError(Exception):
    pass


class FirehoseError(Exception):
    pass
