from distutils.core import setup

setup(
      name='nester_tiler',
      version='1.0.0',
      py_modules=['nester'],
      author='tiler',
      author_email='ligutong@aliyun.com',
      url='http://xxx.com',
      description='A simple printer of nested lists',
    )
