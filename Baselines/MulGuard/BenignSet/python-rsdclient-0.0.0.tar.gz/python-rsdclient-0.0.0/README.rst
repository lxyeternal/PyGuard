===============================
python-rsdclient
===============================

OpenStack client plugin for Rack Scale Design

Please fill here a long description which must be at least 3 lines wrapped on
80 cols, so that distribution package maintainers can use it in their packages.
Note that this is a hard requirement.

* Free software: Apache license
* Documentation: http://docs.openstack.org/developer/python-rsdclient
* Source: http://git.openstack.org/cgit/openstack/python-rsdclient
* Bugs: http://bugs.launchpad.net/https://launchpad.net/python-rsdclient

Features
--------

* TODO
