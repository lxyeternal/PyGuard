==================
Installation guide
==================

At the command line::

    $ pip install python-rsdclient
