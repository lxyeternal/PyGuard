eeve
====

.. image:: https://img.shields.io/pypi/v/eeve.svg
    :target: https://pypi.python.org/pypi/eeve
    :alt: Latest PyPI version

.. image::  .png
   :target:  
   :alt: Latest Travis CI build status

A flexible, powerfull and simple event trigger

Usage
-----

Installation
------------

Requirements
^^^^^^^^^^^^

Compatibility
-------------

Licence
-------

Authors
-------

`eeve` was written by `Victor Marcelino <victor.fmarcelino@gmail.com>`_.
