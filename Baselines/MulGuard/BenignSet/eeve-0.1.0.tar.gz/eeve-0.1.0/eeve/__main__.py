from . import main
main()