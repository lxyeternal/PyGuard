from setuptools import find_packages, setup

setup(
    name="frf-fig2pptx",
    description="Reserved Python package",
    author="FRF",
    version="0.0.1",
    packages=find_packages(),
    keywords="frf-fig2pptx",
    long_description="Reserved Python package",
    long_description_content_type="text/markdown",
    url="https://pypi.org/",
)
