"""standard init file."""

__version__ = "0.1.0"