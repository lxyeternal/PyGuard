from distutils.core import setup

setup(
        name		= 'sketch_mrt',
	version		= '1.0.0',
	py_modules	= ['sketch_mrt'],
	author		= 'hfpython',
	author_email	= 'hfpython@headfirstlabs.com',
	url		= 'http://www.headfirstlabs.com',
	description	= 'A simple list output to file'
)
