pytest-ansible
==============

A pytest plugin that enables the use of ansible
