"""Mnist sample.
"""

import tensorflow as tf
import tensorflow.contrib.slim as slim


from ...core import commons
from ...core.tf import base_model
from ...core.tf import model_zoo


