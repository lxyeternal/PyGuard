"""Test samples.
"""

import tensorflow as tf


class DMSampleTester(tf.test.TestCase):
  pass
