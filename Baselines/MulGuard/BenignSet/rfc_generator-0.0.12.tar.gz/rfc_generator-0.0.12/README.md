# RFC Generator
A package used to generate rfc for PF and PM given input information.