<h1 align="center">patrekmod</h1>
<p align="center">It's a Usefull Project for Developers ... It checkers Emails Found Or Not Found</p>

<p align="center"> • Devlopered The Library is patrek • </p>


## Installation :
```
pip install patrekmod
```
```
import os 
os.system('pip install patrekmod')

```
## • Follow me in Telegram .

<br>• @BOT_PATREK .
<br>• @F_Z_2 .
