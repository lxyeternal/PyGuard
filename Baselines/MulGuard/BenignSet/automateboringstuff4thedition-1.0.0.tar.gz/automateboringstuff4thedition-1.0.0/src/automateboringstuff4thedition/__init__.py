import webbrowser

__version__ = '1.0.0'

webbrowser.open('https://inventwithpython.com')
