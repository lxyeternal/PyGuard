#!/usr/bin/env python
# -*- coding: utf-8 -*-
__all__ = ('__version__',)
__version__ = "v0.10"
