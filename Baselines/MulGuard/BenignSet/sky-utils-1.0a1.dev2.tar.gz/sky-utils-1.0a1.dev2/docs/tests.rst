tests package
=============

Submodules
----------

tests.test_base_util module
---------------------------

.. automodule:: tests.test_base_util
    :members:
    :undoc-members:
    :show-inheritance:

tests.test_text_util module
---------------------------

.. automodule:: tests.test_text_util
    :members:
    :undoc-members:
    :show-inheritance:


Module contents
---------------

.. automodule:: tests
    :members:
    :undoc-members:
    :show-inheritance:
