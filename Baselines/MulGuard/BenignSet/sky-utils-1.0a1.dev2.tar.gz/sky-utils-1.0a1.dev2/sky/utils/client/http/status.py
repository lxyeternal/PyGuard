# -*- coding: utf-8 -*-

SUCCEEDED = frozenset(['200'])
FAILED = frozenset(['404'])
