class MCAnitexgenException(Exception):
	pass