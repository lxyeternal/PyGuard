""":mod:`kinsumer.__main__` --- Alias for kinsumer.cli
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
"""

if __name__ == '__main__':
    from .cli import main

    main(as_module=True)
