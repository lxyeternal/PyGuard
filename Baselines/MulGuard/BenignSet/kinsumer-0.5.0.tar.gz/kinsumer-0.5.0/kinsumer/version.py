""":mod:`kinsumer.version` --- Version information
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

"""
VERSION_INFO = (0, 5, 0)
VERSION = '{}.{}.{}'.format(*VERSION_INFO)

if __name__ == '__main__':
    print(VERSION)
