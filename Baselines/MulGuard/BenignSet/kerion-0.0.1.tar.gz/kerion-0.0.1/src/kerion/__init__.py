# -*- encoding: utf-8 -*-
"""
main package
"""

__version__ = '0.0.1'  # also change in setup.py

