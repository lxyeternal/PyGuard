"""
Package containing general purpose utility code - basically the stuff that is used in every project

---

Library URL: git@lemon.com:pylib/lfs
"""

__author__ = 'Stephen Brown (Little Fish Solutions LTD)'

from .pager import Pager

