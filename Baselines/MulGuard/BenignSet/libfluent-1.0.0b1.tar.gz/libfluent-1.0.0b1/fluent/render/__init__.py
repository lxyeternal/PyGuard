from fluent.render.window import Window
from fluent.render.font import manager

from sdl2.sdlgfx import *   # Graphics render library


window = Window()  # Application window
