from fluent.widget.core import GenericWidget


class Spacer(GenericWidget):
    def __init__(self, size):
        super(Spacer, self).__init__(size=size)
