This package is used to calculate the distance between two points or a list of points in the curved surface using distance.
Using the HSV_distance the distance between two HSV colour code can be calculated.
    [H,S,V] where H refers to Hue ranges from o to 360, S represents saturation and V represents value that ranges from 0 to 100.