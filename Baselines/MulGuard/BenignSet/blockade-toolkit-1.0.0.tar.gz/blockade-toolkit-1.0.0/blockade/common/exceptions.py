"""Common exceptions shared across the tool."""


class INVALID_INDICATORS(Exception):
    """No indicators were passed."""
    pass
