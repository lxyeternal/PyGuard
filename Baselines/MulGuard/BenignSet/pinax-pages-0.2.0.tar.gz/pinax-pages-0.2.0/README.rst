This app was developed as part of the Pinax ecosystem but is just a Django app
and can be used independently of other Pinax apps. To learn more about Pinax,
see http://pinaxproject.com/

pinax-pages
=========

.. image:: https://img.shields.io/travis/pinax/pinax-pages.svg
    :target: https://travis-ci.org/pinax/pinax-pages

.. image:: https://img.shields.io/coveralls/pinax/pinax-pages.svg
    :target: https://coveralls.io/r/pinax/pinax-pages

.. image:: https://img.shields.io/pypi/dm/pinax-pages.svg
    :target:  https://pypi.python.org/pypi/pinax-pages/

.. image:: https://img.shields.io/pypi/v/pinax-pages.svg
    :target:  https://pypi.python.org/pypi/pinax-pages/

.. image:: https://img.shields.io/badge/license-MIT-blue.svg
    :target:  https://pypi.python.org/pypi/pinax-pages/


Welcome to the documentation for pinax-pages!


Running the Tests
------------------------------------

::

    $ pip install detox
    $ detox
