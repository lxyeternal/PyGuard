# oneNueronPypi_New

oneNueronPypi_New

# Reference

[official pythin docs](https://packaging.python.org/en/latest/tutorials/packaging-projects/)

[github docs for github actions](https://docs.github.com/en/actions/automating-builds-and-tests/building-and-testing-python#publishing-to-package-registries)