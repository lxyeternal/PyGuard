import dataclasses


@dataclasses.dataclass
class SPConfiguration:
    entity_id: str
    acs_url: str
