A library for generating secure randomised passwords
