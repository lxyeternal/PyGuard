Executable scripts in this directory will automatically be added to the PATH
of any system that installs the `logrus` package.
