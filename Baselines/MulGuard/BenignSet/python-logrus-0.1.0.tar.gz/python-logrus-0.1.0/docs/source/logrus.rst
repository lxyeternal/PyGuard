logrus package
==============

.. automodule:: logrus
   :members:
   :undoc-members:
   :show-inheritance:
