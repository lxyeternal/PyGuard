.. logrus

Welcome to logrus's documentation!
==================================

Better logging made easy with support for structlog and the standard logging module.

.. toctree::
   :maxdepth: -1
   :caption: Table of Contents

    API Reference <modules>
    Changelog <changelog>
    Development Guide <contributing>
    README <readme>


Indices and Tables
==================

* :ref:`genindex`
* :ref:`modindex`
