Add any paths that contain templates here.
