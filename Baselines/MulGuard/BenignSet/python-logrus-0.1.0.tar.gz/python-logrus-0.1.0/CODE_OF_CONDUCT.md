Everyone participating in this project, and in particular in the issue tracker,
pull requests, and social media activity, is expected to treat other people
with respect and more generally to follow the guidelines articulated in the
[Python Community Code of Conduct][1].

[1]: https://www.python.org/psf/conduct/
