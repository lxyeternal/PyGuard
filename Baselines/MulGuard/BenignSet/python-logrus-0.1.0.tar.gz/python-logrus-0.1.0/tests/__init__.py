"""Tests for the logrus package."""
