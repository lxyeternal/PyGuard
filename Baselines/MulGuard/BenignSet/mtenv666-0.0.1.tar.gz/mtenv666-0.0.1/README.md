# Mortisetenon Environment

用于Mortisetenon项目相关的运行环境配置。

包括：<br>

* 第三方账户配置
* 数据库端口


# 命令行支持

* 设置账户密码到环境变量:

data_support-->['tushare', 'ifind', 'jq', 'rq']

-->mtenv_set --data_support ifind --user bftz059 --password 165229
-->mtenv_set --data_support ts --token dasdw3sdwdasdwdas

