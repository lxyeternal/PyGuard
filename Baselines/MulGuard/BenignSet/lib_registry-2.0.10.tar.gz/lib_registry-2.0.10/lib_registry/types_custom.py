from typing import List, Union

RegData = Union[None, bytes, int, str, List[str]]
