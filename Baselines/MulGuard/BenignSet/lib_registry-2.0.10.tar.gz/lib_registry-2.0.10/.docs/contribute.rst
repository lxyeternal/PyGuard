I would love for you to fork and send me pull request for this project.
- `please Contribute <https://github.com/bitranox/lib_registry/blob/master/CONTRIBUTING.md>`_
