This software is licensed under the `MIT license <http://en.wikipedia.org/wiki/MIT_License>`_
