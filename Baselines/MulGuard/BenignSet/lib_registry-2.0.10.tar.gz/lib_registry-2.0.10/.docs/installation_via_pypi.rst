- to install the latest release from PyPi via pip (recommended):

.. code-block::

    python -m pip install --upgrade lib_registry


- to install the latest release from PyPi via pip, including test dependencies:

.. code-block::

    python -m pip install --upgrade lib_registry[test]

