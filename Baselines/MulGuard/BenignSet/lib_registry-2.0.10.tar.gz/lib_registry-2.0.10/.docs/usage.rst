python methods:

- Registry Object

.. include:: ../lib_registry/lib_registry.py
    :code: python
    :start-after: # Registry{{{
    :end-before: # Registry}}}

- create_key

.. include:: ../lib_registry/lib_registry.py
    :code: python
    :start-after: # create_key{{{
    :end-before: # create_key}}}

- delete_key

.. include:: ../lib_registry/lib_registry.py
    :code: python
    :start-after: # delete_key{{{
    :end-before: # delete_key}}}


- key_exists

.. include:: ../lib_registry/lib_registry.py
    :code: python
    :start-after: # key_exist{{{
    :end-before: # key_exist}}}

