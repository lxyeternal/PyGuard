.. code-block::

   Usage: lib_registry [OPTIONS] COMMAND [ARGS]...

     a more pythonic way to access the windows registry as winreg

   Options:
     --version                     Show the version and exit.
     --traceback / --no-traceback  return traceback information on cli
     -h, --help                    Show this message and exit.

   Commands:
     info  get program informations
