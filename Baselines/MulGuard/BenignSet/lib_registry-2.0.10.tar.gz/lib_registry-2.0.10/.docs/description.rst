a more pythonic way to access the windows registry as winreg

command line interface is prepared - if someone needs to use it via commandline, give me a note.
