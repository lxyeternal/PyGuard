STATUS_OK = "Everything's Chimpy!"
REGULAR_CAMPAIGN = 'regular'
PLAINTEXT_CAMPAIGN = 'plaintext'
ABSPLIT_CAMPAIGN = 'absplit'
RSS_CAMPAIGN = 'rss'
TRANS_CAMPAIGN = 'trans'
AUTO_CAMPAIGN = 'auto'
