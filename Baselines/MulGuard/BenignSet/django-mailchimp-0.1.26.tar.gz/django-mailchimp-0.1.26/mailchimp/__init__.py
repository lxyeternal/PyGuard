"""
Note about version numbers:

All versions with an uneven minor version number are unstable! Versions with
even minor version numbers are considered stable.
"""
__version__ = '0.1.26'
