# -*- coding: utf-8 -*-

__version__ = '0.1'

CONF_BASE_PATH = 'link/model'
