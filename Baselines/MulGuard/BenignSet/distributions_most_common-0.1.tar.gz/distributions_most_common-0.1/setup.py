from setuptools import setup

setup(name='distributions_most_common',
      version='0.1',
      description='Gaussian distributions',
      packages=['distributions_most_common'],
      zip_safe=False)
