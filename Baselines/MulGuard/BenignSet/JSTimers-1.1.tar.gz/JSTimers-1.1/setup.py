from setuptools import setup, find_packages
setup(name='JSTimers',
      version='1.1',
      description='Javascript Timer functions for Python',
      author='Shashwat Chandra',
      author_email='chandras.2013@iitkalumni.org',
      url='https://github.com/Shashwat986/jstimers',
      packages=find_packages()
      )
