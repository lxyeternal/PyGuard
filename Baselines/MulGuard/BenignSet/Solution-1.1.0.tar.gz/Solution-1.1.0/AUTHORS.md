# Authors

**Solution** is written and maintained by the Lúcuma labs team:

Project Leader / Developer:

-   Juan-Pablo Scaletti <juanpablo@lucumalabs.com>

