from django.apps import AppConfig


class SsoServerConfig(AppConfig):
    name = 'sso_server'
