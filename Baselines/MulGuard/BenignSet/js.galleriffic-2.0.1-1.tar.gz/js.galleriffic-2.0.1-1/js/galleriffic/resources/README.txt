Copy the library resources here and register them in __init__.py.
