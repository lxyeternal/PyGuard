SG_PREFIX = 'bcli-'
KEYPAIR_PREFIX = 'bcli-'

IMAGES = {
    'us-west-1': 'ami-4aa04129',
    'ap-southeast-1': 'ami-51a7aa2d',
}
