git-style command line interface (main program, commands, sub-commands, sub-sub-...) AND shell-like interface, with prompt etc.
Cf ViDE.

From command line
    program options command options sub-command options [...]

From interactive shell
    +option
    -option
    command options sub-command options [...]

Help
    options grouping
    commands grouping

Short and long option names
