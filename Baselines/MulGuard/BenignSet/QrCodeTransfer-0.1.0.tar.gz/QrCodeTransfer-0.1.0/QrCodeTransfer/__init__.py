
'''
To send and receive data transmitted by QR code.
It's maybe useful where no internet connection is available.
'''

__version__ = '0.1.0'