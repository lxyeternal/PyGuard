# -*- coding: utf-8 -*-
"""
State tracking functionality for django models
"""

