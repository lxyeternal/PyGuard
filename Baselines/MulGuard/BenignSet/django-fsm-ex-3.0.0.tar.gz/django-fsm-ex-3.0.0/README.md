# Django friendly finite state machine support

django-fsm-ex 基于 [django-fsm](https://github.com/kmmbvnr/django-fsm). 不过由于 django-fsm 基本停止开发了,
本项目在原项目的基础上调整结构,去掉了部分兼容代码.
调整了结构,增加了类型信息, 优化了错误信息(主要针对中文项目)
