#!/usr/bin/python3
# -*- coding: utf-8 -*-

from setuptools import setup

setup(
    name='predict-ds-params',
    version='0.0.1',
    description='PyPi package created by Schibsted\'s Product & Application Security team.',
    long_description='',
    url='https://schibsted.com',
    author='Alexander Kjäll',
    author_email='alexander.kjaell@schibsted.com',
    packages=[],
    classifiers=['Development Status :: 1 - Planning'],
)
