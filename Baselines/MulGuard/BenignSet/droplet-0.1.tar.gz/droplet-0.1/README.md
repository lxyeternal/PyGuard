droplet
=======
[ ![Codeship Status for exekias/droplet](https://www.codeship.io/projects/902f35b0-f1ba-0131-c61d-66e817b8cbcb/status?branch=master)](https://www.codeship.io/projects/27634)
