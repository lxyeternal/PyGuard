Snake
-----
An interactive CLI Snake game in Python3.

![Applications list view](https://github.com/jakehadar/py-snake/blob/master/screenshots/screenshot@half.png)

Usage
-----

Run from the command line.

``` {.sourceCode .bash}
 cd path/to/repo
 python snake.py
```
