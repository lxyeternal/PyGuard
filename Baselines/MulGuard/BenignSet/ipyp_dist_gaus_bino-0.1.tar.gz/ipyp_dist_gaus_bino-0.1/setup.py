from setuptools import setup

setup(name='ipyp_dist_gaus_bino',
      version='0.1',
      description='Gaussian and Binomial distributions',
      packages=['ipyp_dist_gaus_bino'],
      zip_safe=False)
