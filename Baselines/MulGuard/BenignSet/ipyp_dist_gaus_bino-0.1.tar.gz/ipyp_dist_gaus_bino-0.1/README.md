This package used for student practice, so don't expect too much.
It has Gaussioan and Binomial Distrubution-Class drived from a general distribution class.
and use for practicing pip install.