# ellipse

A parametrized dataset of pictures of ellipses, for Neural Network experimentation.