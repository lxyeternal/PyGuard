# python omnibot receiver

This is compatible with Python 2.7 and Python 3.4+. 

## Features

This library provides tools to effectively handle messages received from omnibot and to easily respond back to omnibot. Currently it provides an OmnibotRouter class that provides a Flask-like method of routing omnibot messages to functions in your code.

See [docs](https://lyft.github.io/python-omnibot-receiver) for usage, installation, and more detailed API info.
