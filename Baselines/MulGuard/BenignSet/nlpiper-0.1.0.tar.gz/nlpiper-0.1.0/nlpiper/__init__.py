"""NLPiper."""
