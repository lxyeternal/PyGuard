"""Core Module."""
from nlpiper.core.document import Document
