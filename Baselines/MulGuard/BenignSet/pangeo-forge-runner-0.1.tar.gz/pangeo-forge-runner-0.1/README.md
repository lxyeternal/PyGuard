# pangeo-forge-runner

![Tests passing](https://github.com/yuvipanda/pangeo-forge-runner/actions/workflows/unit-test.yml/badge.svg)
[![codecov](https://codecov.io/gh/yuvipanda/pangeo-forge-runner/branch/main/graph/badge.svg?token=TN5SO7X9LU)](https://codecov.io/gh/yuvipanda/pangeo-forge-runner)
[![PyPI version](https://badge.fury.io/py/pangeo-forge-runner.svg)](https://badge.fury.io/py/pangeo-forge-runner)

Commandline tool to manage [pangeo-forge](https://pangeo-forge.readthedocs.io/en/latest/)
feedstocks
