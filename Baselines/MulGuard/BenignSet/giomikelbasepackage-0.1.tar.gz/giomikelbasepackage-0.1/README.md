Task 1 of Assignment 1
