# pyvilb

Python library for computer graphics/vision.
