from extractreq.partof_modul1 import partOf
from extractreq.partof_modul2 import wsd_partof
from extractreq.partof_modul2a import ukur_partOf_alternatif

from extractreq.usecase_modul1 import xmlParser
from extractreq.usecase_modul2 import parsingRequirement
from extractreq.usecase_modul3 import ucdReq

