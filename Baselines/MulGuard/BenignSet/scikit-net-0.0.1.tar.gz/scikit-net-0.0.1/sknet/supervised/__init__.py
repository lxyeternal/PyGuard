# flake8: noqa
from .ease_of_access import EaseOfAccessClassifier
from .ease_of_access import EaseOfAccessRegressor
from .high_level_classification import HighLevelClassifier
