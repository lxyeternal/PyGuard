# flake8: noqa
from .modularity_label_propagation import ModularityLabelPropagation
