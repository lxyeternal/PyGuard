This app was developed as part of the Pinax ecosystem but is just a Django app
and can be used independently of other Pinax apps. To learn more about Pinax,
see http://pinaxproject.com/

===============
pinax-documents
===============

.. image:: http://slack.pinaxproject.com/badge.svg
   :target: http://slack.pinaxproject.com/

.. image:: https://img.shields.io/travis/pinax/pinax-documents.svg
    :target: https://travis-ci.org/pinax/pinax-documents

.. image:: https://img.shields.io/coveralls/pinax/pinax-documents.svg
    :target: https://coveralls.io/r/pinax/pinax-documents

.. image:: https://img.shields.io/pypi/dm/pinax-documents.svg
    :target:  https://pypi.python.org/pypi/pinax-documents/

.. image:: https://img.shields.io/pypi/v/pinax-documents.svg
    :target:  https://pypi.python.org/pypi/pinax-documents/

.. image:: https://img.shields.io/badge/license-MIT-blue.svg
    :target:  https://pypi.python.org/pypi/pinax-documents/


Welcome to the documentation for pinax-documents!


Running the Tests
------------------------------------

::

    $ pip install detox
    $ detox
