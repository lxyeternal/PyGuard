
class Right:
	USER = 'usr'
	INSTALLER = 'istl'
