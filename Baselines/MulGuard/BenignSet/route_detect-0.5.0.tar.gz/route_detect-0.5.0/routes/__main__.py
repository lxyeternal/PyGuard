import sys

from routes.main import main


sys.exit(main())
