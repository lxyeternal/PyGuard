import pathlib


CURDIR = pathlib.Path(__file__).parent
ROUTES_HTML_TEMPLATE = CURDIR / "routes.tmpl.html"
ROUTES_HTML = "routes.html"
