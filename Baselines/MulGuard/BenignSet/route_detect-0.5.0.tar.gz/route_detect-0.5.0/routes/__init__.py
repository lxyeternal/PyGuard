from . import commands  # noqa: F401
from . import rules  # noqa: F401
from . import templates  # noqa: F401


# Move to "importlib.metadata.version" when we only support Python 3.8+
__version__ = "0.5.0"
