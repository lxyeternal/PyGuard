from keyserver import generator

if __name__ == "__main__":
	c = generator.generator()
	c.usage()