__VERSION__ 	= "1.0"
__AUTHOR__  	= "licface"
__EMAIL__		= "licface@yahoo.com"
__BUILD__		= "2.7"
__TEST__		= "0.3"
__PLATFORM__	= "all"

from . import generator