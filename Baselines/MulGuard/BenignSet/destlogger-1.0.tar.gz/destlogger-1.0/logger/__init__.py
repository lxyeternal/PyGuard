__title__ = "destlogger"
__author__ = 'Dest0re'
__version__ = '1.0'

from .logger import Logger
