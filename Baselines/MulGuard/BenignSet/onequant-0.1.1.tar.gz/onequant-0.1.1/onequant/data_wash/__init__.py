"""Data washing module."""
