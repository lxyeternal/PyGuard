"""Top-level package for onequant."""

__author__ = """recluse"""
__email__ = '853641471@qq.com'
__version__ = '0.1.1'

import pathlib
import sys

sys.path.append(str(pathlib.Path(__file__).parent))
