"""Uitility function for Onequant."""
