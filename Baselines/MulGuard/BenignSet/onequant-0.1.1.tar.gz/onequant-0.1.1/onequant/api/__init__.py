"""Onequant api using for get information from C++ system."""
