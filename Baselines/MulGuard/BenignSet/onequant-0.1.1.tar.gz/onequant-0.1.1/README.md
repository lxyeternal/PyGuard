# onequant


[![pypi](https://img.shields.io/pypi/v/onequant.svg)](https://pypi.org/project/onequant/)
[![python](https://img.shields.io/pypi/pyversions/onequant.svg)](https://pypi.org/project/onequant/)
[![Build Status](https://github.com/xunzhimeng/onequant/actions/workflows/dev.yml/badge.svg)](https://github.com/xunzhimeng/onequant/actions/workflows/dev.yml)
[![codecov](https://codecov.io/gh/xunzhimeng/onequant/branch/main/graphs/badge.svg)](https://codecov.io/github/xunzhimeng/onequant)



python package for quant trading and ai learning


* Documentation: <https://xunzhimeng.github.io/onequant>
* GitHub: <https://github.com/xunzhimeng/onequant>
* PyPI: <https://pypi.org/project/onequant/>
* Free software: Apache-2.0


## Features

* TODO

## Credits

This package was created with [Cookiecutter](https://github.com/audreyr/cookiecutter) and the [DarkDemiurg/cookiecutter-pypackage](https://github.com/DarkDemiurg/cookiecutter-pypackage) project template.
