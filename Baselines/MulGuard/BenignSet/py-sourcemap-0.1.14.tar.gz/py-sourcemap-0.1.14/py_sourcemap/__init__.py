from .py_sourcemap import SourcemapParser

name = 'py_sourcemap'

__all__ = ["SourcemapParser"]
