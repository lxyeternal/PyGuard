# py-sourcemap

A tiny [source-map-mappings](https://github.com/fitzgen/source-map-mappings) bindings for python using [PyO3](https://github.com/PyO3/pyo3)
