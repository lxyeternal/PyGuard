LEGO dev library

This library will assist competitors to do certain tasks quickly and efficiently.
Tasks such as basic movements, color detection, choosing paths can be easily done using this library

