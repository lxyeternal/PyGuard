from firehole.algorithms.flashtext.keyword import KeywordProcessor
