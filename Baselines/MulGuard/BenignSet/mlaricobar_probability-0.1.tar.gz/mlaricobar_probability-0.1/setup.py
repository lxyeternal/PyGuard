from setuptools import setup

setup(name='mlaricobar_probability',
      version='0.1',
      description='Gaussian and binomial distribution',
      packages=['mlaricobar_probability'],
      author = "Michael Larico Barzola",
      author_email = "mlaricobar@gmail.com",
      zip_safe=False
     )
