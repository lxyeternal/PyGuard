NumPy NPZ backend
=================

.. automodule:: dsch.backends.npz
    :show-inheritance:
