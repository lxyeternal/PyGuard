Schema specification
====================

.. automodule:: dsch.schema
