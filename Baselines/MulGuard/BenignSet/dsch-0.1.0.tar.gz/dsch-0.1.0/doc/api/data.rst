Data management
===============

.. automodule:: dsch.data
