MAT-file backend
================

.. automodule:: dsch.backends.mat
    :show-inheritance:
