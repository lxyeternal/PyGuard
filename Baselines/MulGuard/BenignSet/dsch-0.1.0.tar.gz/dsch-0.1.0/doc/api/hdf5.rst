HDF5 backend
============

.. automodule:: dsch.backends.hdf5
    :show-inheritance:
