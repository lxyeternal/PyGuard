from setuptools import setup

setup(
    name='k4sproff',
    version='v1.0',
    description='for profile',
    py_modules=['k4sproff'],
    author='upuuuuuu',
    author_email='2226548059@qq.com',
    url='https://github.com/upuuuuuu',
    requires=['os', 'time', 'torch', 'logging', 'pandas', 'torchstat'],
    license='MIT'
)