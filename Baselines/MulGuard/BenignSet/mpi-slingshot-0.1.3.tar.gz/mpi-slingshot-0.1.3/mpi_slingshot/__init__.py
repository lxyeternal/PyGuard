"""SLINGSHOT: Python wrapper for MPI to "slingshot" a small Python or R function against the Goliath of Big Data"""

__version__ = '0.1'

from .slingshot import *
