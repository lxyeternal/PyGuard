import setuptools
setuptools.setup(
    name="Guru",
    version="1.0.0",
    author="Guru",
    author_email="g.s.a.999@gmail.com",
    description="packt example package",
    long_description="This is the longer description and will appear in the web.",
    package=setuptools.find_packages(),
    classifiers=[
        "Programming Language :: Python :: 3",
        "Operating System :: OS Independent",
    ],
)