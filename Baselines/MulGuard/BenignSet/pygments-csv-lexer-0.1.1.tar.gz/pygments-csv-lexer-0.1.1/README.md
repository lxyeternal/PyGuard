![CSV lexer demonstration](https://i.imgur.com/kAfT7so.png)

CSV [**custom lexer**](http://pygments.org/docs/lexerdevelopment/) for [**pygments**](http://pygments.org/).

Code based on [**Adobe answer**](https://stackoverflow.com/a/25508711/5951529).