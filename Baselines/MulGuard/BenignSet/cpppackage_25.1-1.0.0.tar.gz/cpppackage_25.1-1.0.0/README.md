# Django-Online-Library-Management-System
This is tutorial video from YouTube https://www.youtube.com/watch?v=HnBluva-Gx4


Project is developed under Django 3.17, so it you do not have Django version 3.x, make sure you install it. Then after run the commands below
python manage.py makemigrations
python manage.py migrate
python manage.py runserver



DJANGO BookApp
![alt text](https://github.com/MoTechStore/Django-Online-Library-Management-System/blob/main/thumb.png)
