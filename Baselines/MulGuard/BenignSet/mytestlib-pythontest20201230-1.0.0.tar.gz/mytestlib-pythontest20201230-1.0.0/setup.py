from setuptools import setup, find_packages

setup(
    name='mytestlib-pythontest20201230',
    version='1.0.0',
    # url='…',
    author='ikegami',
    author_email='takanori.ikegami@gmail.com',
    description='My Test Library.',
    packages=find_packages()
)
