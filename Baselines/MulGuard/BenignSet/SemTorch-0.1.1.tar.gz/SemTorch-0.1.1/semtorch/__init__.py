__version__ = "0.1.1"

from .learner import get_segmentation_learner