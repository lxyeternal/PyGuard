
# THIS FILE IS GENERATED FROM SETUP.PY
short_version = '1.0.0'
version = '1.0.0'
full_version = '1.0.0.dev0+c0c5800'
git_revision = 'c0c5800eb717ed99724d7de25a54089901c991ac'
release = False

if not release:
    version = full_version
    short_version += ".dev"
