
from django.apps import AppConfig


class ActionV1Config(AppConfig):
    name = "adjutant.actions.v1"
    label = 'actions_v1'
