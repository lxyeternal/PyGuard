default_app_config = 'adjutant.startup.checks.StartUpConfig'
