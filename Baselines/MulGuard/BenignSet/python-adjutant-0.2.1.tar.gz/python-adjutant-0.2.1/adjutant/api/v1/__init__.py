default_app_config = 'adjutant.api.v1.app.APIV1Config'
