from django.apps import AppConfig


class APIV1Config(AppConfig):
    name = "adjutant.api.v1"
    label = 'api_v1'
