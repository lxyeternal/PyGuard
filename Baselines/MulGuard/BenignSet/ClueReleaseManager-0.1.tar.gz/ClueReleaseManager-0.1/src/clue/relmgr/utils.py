import logging

logger = logging.getLogger('clue.relmgr')
logger.setLevel(level=logging.INFO)
