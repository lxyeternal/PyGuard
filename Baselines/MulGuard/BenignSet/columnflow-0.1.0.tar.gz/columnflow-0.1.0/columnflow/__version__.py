# coding: utf-8

"""
Package in development.
"""

__author__ = "Marcel Rieger"
__email__ = "github.riga@icloud.com"
__copyright__ = "Copyright 2022, Marcel Rieger"
__credits__ = ["Marcel Rieger"]
__contact__ = "https://github.com/riga/columnflow"
__license__ = "BSD-3-Clause"
__status__ = "Development"
__version__ = "0.1.0"
