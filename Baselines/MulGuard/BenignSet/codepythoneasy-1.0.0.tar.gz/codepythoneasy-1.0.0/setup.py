from setuptools import setup

setup(
    name='codepythoneasy',
    version='1.0.0',
    description='A simple Template for create python project',
    author='ks lim',
    author_email='kianseng.lim@sony.com',
    packages=['python'],
)
