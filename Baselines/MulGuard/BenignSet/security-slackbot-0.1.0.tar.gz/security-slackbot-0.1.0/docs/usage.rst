=====
Usage
=====

To use security_slackbot in a project::

	import security_slackbot
