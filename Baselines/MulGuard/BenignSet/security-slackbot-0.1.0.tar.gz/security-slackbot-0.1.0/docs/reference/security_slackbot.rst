security_slackbot
=================

.. testsetup::

    from security_slackbot import *

.. automodule:: security_slackbot
    :members:
