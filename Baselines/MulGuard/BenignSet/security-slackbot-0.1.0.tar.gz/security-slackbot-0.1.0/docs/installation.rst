============
Installation
============

At the command line::

    pip install security-slackbot
