
from security_slackbot.cli import main


def test_main():
    main([])
