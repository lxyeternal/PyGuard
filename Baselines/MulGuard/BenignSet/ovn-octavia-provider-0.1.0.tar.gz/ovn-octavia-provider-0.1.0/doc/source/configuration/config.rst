=======================
Configuration Reference
=======================

This section provides a list of all configuration options for OVN Octavia
provider. These are auto-generated from OVN Octavia provider code when
this documentation is built.

Configuration filenames used below are filenames usually used, but there
is no restriction on configuration filename and you can use
arbitrary file names.

.. show-options::
   :config-file: etc/oslo-config-generator/ovn.conf
