Configure logs dir to be accessible for ``stack`` user.

**Role Variables**

.. zuul:rolevar:: logdir
   :default: /opt/stack/logs

   Name of the directory where logs will be stored.
