"""
EnvConfig ⚙️
"""

__title__ = "py-envconfig"
__description__ = "Managing environment config data"
__version__ = "0.2.0"
__dependencies__ = ["toolz", "python-dotenv"]
