A GCP Secrets Manager Connector library.

In order to update library in PyPI, we must update the version in `setup.py` and `git push`.