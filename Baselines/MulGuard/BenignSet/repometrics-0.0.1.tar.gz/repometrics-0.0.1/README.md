# RepoMetrics
***
CLI to display current repository files path and languages.
