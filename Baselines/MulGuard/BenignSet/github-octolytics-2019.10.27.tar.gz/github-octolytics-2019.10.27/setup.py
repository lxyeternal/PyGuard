from setuptools import setup

setup(
    name='github-octolytics',
    version='2019.10.27',
    install_requires=[
        'Requests',
        'public',
        'setuptools',
    ],
    packages=[
        'github_octolytics',
    ],
)
