# imapmail
Python module for IMAP Email stuff
