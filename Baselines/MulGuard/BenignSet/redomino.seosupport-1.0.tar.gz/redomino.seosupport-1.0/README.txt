redomino.seosupport
===================

By installing this plugin you will get a Plone site with the sitemap.xml.gz enabled by default.

redomino.seosupport depends on googlesitemap.common that provides an optimized sitemap.xml.gz view.

Authors
-------

* Davide Moro, main author <davide.moro@redomino.com>


