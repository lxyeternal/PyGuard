"""-m level entry point"""
from mand import mand

if __name__ == "__main__":
    mand()
