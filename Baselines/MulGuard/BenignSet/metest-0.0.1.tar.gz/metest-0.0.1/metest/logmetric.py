#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""Master module for metest.logmetric
"""
import sys
import argparse

class logmetric:

    def __init__(self, args) -> None:
        """Init function for logmetric
        """

        print(args)
        return