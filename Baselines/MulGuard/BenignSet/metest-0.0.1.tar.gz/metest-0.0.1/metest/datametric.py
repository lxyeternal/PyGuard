#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""Master module for metest.datametric
"""

class datametric:

    def __init__(self) -> None:
        """Init function for datametric
        """
        return