import os
import sys
sys.path.insert(0, os.path.abspath('./metest/'))

from .logmetric import logmetric
from .datametric import datametric