
#  If you need to have certain functions (modules) available on the scale of the package then do this
#  So you get: from invoicing import generate ; Instead of: from invoicing.invoice import generate
from .invoice import generate
