class ArgumentError(Exception):
    pass


class CommandNotFound(Exception):
    pass
