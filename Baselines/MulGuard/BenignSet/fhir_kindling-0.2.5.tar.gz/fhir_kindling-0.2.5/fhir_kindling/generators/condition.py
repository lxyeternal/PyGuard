if __name__ == '__main__':
    code_system = "http://hl7.org/fhir/sid/icd-10"
    condition_codes = ["I63.0", "I63.1", "I63.2", "I63.3", "I63.4", "I63.5", "I63.6", "I63.7", "I63.8", "I63.9"]
