from typing import Callable, Union, List


def update_resources(query: str, update: Union[Callable, dict]):
    pass
