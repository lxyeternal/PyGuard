"Some extensions for redis-limpyd, a redis orm (sort of) in python"
VERSION = (0, 0, 1)

__author__ = 'Stephane "Twidi" Angel'
__contact__ = "s.angel@twidi.com"
__homepage__ = "https://github.com/twidi/redis-limpyd-extensions"
__version__ = ".".join(map(str, VERSION))
