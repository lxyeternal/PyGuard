"""
Utilities for handling `Siemens <https://new.siemens.com/global/en.html>`_ DICOM data.

"""
