WRONG_DEFINITION_TYPE = (
    "Sequence definition must be a dict, a list, or a tuple, not {definition_type}!"
)

