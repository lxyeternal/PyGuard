from dicom_parser.utils.read_file import read_file
