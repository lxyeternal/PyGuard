/* pg_stat_statements_reset discards statistics gathered so far by pg_stat_statements */
SELECT pg_stat_statements_reset();