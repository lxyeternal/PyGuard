/* Check if SSL connection is used */
SELECT ssl_is_used();