/* Available and installed extensions */
SELECT *
FROM pg_available_extensions
ORDER BY installed_version;