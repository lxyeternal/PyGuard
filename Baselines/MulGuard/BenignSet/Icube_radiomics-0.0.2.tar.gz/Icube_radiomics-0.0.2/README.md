# BQ_radiomics
radiomics standalone for BQ - created by Kyle Drover. 


