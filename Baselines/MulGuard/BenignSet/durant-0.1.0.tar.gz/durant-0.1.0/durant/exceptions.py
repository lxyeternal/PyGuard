class DependencyError(EnvironmentError):
    pass


class ConfigError(IOError):
    pass


class DeployError(IOError):
    pass
