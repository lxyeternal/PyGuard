# -*- coding: utf-8 -*-


from dp_tornado.engine.helper import Helper as dpHelper


class I18nHelper(dpHelper):
    pass
