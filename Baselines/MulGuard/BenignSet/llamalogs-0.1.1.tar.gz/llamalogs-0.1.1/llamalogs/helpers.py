from datetime import datetime

ms_time = lambda :int(datetime.now().timestamp() * 1000)