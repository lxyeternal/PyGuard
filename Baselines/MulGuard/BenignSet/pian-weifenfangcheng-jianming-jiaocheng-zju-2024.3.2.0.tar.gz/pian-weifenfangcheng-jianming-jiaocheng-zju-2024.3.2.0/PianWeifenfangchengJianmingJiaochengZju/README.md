# 偏微分方程简明教程（ZJU）

## 下载

### Docker

```
docker pull apachecn0/pian-weifenfangcheng-jianming-jiaocheng-zju
docker run -tid -p <port>:80 apachecn0/pian-weifenfangcheng-jianming-jiaocheng-zju
# 访问 http://localhost:{port} 查看文档
```

### PYPI

```
pip install pian-weifenfangcheng-jianming-jiaocheng-zju
pian-weifenfangcheng-jianming-jiaocheng-zju <port>
# 访问 http://localhost:{port} 查看文档
```

### NPM

```
npm install -g pian-weifenfangcheng-jianming-jiaocheng-zju
pian-weifenfangcheng-jianming-jiaocheng-zju <port>
# 访问 http://localhost:{port} 查看文档
```