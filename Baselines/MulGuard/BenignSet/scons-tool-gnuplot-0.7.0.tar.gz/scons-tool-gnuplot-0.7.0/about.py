# -*- coding: utf-8 -*-
"""Version information, etc."""

#  DskLayout version info
__version__ = '0.7.0'
"""Package version as a string."""

# Local Variables:
# tab-width:4
# indent-tabs-mode:nil
# End:
# vim: set ft=python et ts=4 sw=4:
