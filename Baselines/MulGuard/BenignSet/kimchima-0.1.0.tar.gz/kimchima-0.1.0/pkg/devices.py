from enum import Enum

class Devices(Enum):
    Silicon = 'mps'
    CPU = 'cpu'

    