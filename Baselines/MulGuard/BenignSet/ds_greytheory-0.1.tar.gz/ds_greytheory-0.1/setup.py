from setuptools import setup

setup(name='ds_greytheory',
      version='0.1',
      description='Grey Theory models and tools',
      packages=['ds_greytheory'],
      author = 'Gustavo Jorge Martins de Aguiar',
      author_email = 'gustavoaguiar@id.uff.br',
      zip_safe=False)