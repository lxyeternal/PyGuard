from models.grey_egm11 import GreyEGM_1_1

class GreyTheory:

    def __init__(self):
        self.egm11 = GreyEGM_1_1