default_app_config = 'cq.apps.CqConfig'
