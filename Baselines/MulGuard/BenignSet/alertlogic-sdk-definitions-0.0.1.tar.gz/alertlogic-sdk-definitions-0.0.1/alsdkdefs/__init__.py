import os


def get_apis_dir():
    return f"{os.path.dirname(__file__)}/apis"
