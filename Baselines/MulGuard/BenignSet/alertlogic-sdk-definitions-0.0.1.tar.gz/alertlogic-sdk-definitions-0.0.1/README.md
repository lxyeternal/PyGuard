# alertlogic-sdk-definitions
Alert Logic APIs definitions
