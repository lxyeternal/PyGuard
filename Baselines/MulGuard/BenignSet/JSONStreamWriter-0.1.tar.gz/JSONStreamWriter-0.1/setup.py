#!/usr/bin/env python

from distutils.core import setup

setup(name="JSONStreamWriter",
      version="0.1",
      description="stream json-serializable python objects to an array in a file",
      author="doug shawhan",
      author_email="doug.shawhan@gmail.com",
      packages=["JSONStreamWriter"],
     )
