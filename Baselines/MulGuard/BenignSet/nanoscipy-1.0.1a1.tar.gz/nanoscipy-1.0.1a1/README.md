# nanoscipy

nanoscipy has been made, to ease the more heavy data-handling, -processing, and - analysis. 
This package is being readily updated at the moment, so be sure to keep up, as new and useful additions and fixens are very likely to be included.

## Installation and updating
Use the package manager [pip](https://pip.pypa.io/en/stable/) to install nanoscipy like below. 
Rerun this command to check for and install  updates .
```bash
pip install git+https://github.com/nicholas12392/nanoscipy
```
Note that if you're using anaconda, you might have to install git: 
```bash
conda install git
```
## Usage
Currently being updated.
