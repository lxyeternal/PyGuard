"""Common utility functions."""


class ModeKeys:
    """Standard names for modes."""

    TRAIN = "train"
    EVAL = "eval"
