import os

config_path = os.path.join(__path__[0], "conf", "config.yaml")
