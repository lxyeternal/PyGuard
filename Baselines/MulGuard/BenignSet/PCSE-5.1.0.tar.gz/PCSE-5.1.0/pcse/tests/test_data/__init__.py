#!/usr/bin/env python
from frostol_testdata import frostol_testdata
from evapotranspiration_testdata import pot_evtra_testdata, \
     wl_evtra_testdata1, wl_parvalue_dict1,\
     wl_evtra_testdata2, wl_parvalue_dict2
from respiration_testdata import respiration_testdata