# -*- coding: utf-8 -*-
# Copyright (c) 2004-2014 Alterra, Wageningen-UR
# Allard de Wit (allard.dewit@wur.nl), April 2014

import pcse
import cgms9
import cgms11
from nasapower import NASAPowerWeatherDataProvider
