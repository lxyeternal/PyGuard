# -*- coding: utf-8 -*-
# Copyright (c) 2004-2014 Alterra, Wageningen-UR
# Allard de Wit (allard.dewit@wur.nl), April 2014
"""Tools for reading  weather data and parameters from a CGMS9 database
"""
from ..pcse.db_input import GridWeatherDataProvider