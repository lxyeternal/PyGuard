# SDGPT
ChatBot for NoneBot : 链接 ChatGPT / Bing / Stable-Diffusion  : ChatGPT Bing聊天, gpt解析自然语言转Stable-Diffusion生成图像
