#  Copyright (c) 2023. OCX Consortium https://3docx.org. See the LICENSE
from loguru import logger
logger.disable(__name__)
__version__= '2.0.0'
__app_name__ = "ocx_databinding"
