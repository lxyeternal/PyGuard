#  Copyright (c) 2023. OCX Consortium https://3docx.org. See the LICENSE
from loguru import logger
logger.disable(__name__)