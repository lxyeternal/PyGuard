# Olympia Odos Pass

Calculate Tolls on Olympia Odos when using the O-pass.

## Prerequisites

* Python 3
* TKinter
* Pillow
* TTK Themes
* numpy

To install all prerequisites please run the following command

```pip install --user opass```

## Run

`opass`
