"""
In Habitica, the term 'stable' is used to describe the collection
of pets. However, 'stable' can be confused with the programming
term stable, so we're using zoo here.
"""
