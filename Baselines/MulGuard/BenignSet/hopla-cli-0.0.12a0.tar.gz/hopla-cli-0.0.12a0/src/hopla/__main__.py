#!/usr/bin/env python3
"""
Module that calls the entry command
"""
from . import entry_cmd

if __name__ == "__main__":
    entry_cmd()
