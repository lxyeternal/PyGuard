================
Gaumin Irakurlea
================

Proiektu honetan eusko jaurlaritzako euskara sailburuordetzaren laguntza
jaso dugu.
