GauminIpuinReader
=================

(English below)

Ipuin interaktiboak irakurtzeko aplikazioa. '.ipuin' formatuko fitxategiak
irakurri ditzake, `GauminIpuinWriter`_ tresnarekin sortutakoak.


.. _GauminIpuiinWriter: https://pypi.python.org/pypi/GauminIpuinWriter
