from setuptools import setup

setup(name='kav_distributions',
      version='1',
      description='Gaussian distributions practice of package upload',
      packages=['kav_distributions'],
      author = 'kavya',
      author_email = 'kushnoor.kk@gmail.com',
      zip_safe=False)
