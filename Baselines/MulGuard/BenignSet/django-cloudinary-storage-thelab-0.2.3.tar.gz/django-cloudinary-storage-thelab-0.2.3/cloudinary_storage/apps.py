from django.apps import AppConfig


class CloudinaryStorageConfig(AppConfig):
    name = 'cloudinary_storage'
