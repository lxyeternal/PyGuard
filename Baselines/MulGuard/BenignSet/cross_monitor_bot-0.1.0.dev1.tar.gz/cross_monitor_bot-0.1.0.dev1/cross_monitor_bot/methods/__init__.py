from .abc import ABCMethod
from .get import GetMethod
from .ping import PingMethod
