The chopsticks game
You hit the opponents hand
until it is 0 (mod 5)
you can also split your own hand
