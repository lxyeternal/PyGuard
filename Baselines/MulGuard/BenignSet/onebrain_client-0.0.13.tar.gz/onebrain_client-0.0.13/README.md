## sdk cli
提供包括数据集、训练任务等的cli
## 安装
      pip  install pyyaml
      pip install click
      pip install setuptools twine
##  打包上传
      python setup.py sdist build
      python -m twine upload dist/*
          