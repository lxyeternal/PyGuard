class SimpleBackupsError(Exception):
    """Generic exception for simple_backups package."""
