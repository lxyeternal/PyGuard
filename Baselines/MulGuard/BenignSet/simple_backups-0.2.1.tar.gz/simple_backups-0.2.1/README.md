# Simple Backups


[![pypi](https://img.shields.io/pypi/v/simple-backups.svg)](https://pypi.org/project/simple-backups/)
[![python](https://img.shields.io/pypi/pyversions/simple-backups.svg)](https://pypi.org/project/simple-backups/)
[![Build Status](https://github.com/luiscberrocal/simple-backups/actions/workflows/dev.yml/badge.svg)](https://github.com/luiscberrocal/simple-backups/actions/workflows/dev.yml)
[![codecov](https://codecov.io/gh/luiscberrocal/simple-backups/branch/main/graphs/badge.svg)](https://codecov.io/github/luiscberrocal/simple-backups)



Simple backups library


* Documentation: <https://luiscberrocal.github.io/simple-backups>
* GitHub: <https://github.com/luiscberrocal/simple-backups>
* PyPI: <https://pypi.org/project/simple-backups/>
* Free software: MIT


## Features

* Create a copy of a file into a backup folder with a dated filename.

## Credits

This package was created with [Cookiecutter](https://github.com/audreyr/cookiecutter) and the [waynerv/cookiecutter-pypackage](https://github.com/waynerv/cookiecutter-pypackage) project template.
