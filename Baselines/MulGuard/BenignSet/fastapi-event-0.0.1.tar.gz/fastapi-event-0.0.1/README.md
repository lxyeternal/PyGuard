# fastapi-event
[![license]](/LICENSE)
[![pypi]](https://pypi.org/project/fastapi-event/)
[![pyversions]](http://pypi.python.org/pypi/fastapi-event)
![badge](https://action-badges.now.sh/teamhide/fastapi-event)
[![Downloads](https://pepy.tech/badge/pythondi)](https://pepy.tech/project/fastapi-event)

---

fastapi-event is event dispatcher for FastAPI framework.

## Installation

```python
pip3 install fastapi-event
```