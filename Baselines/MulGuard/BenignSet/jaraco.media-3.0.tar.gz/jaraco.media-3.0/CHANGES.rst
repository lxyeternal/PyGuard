3.0
===

Moved ISAPI script to package. Invoke with
``python -m jaraco.media.isapiapp``.

Switch to `pkgutil namespace technique
<https://packaging.python.org/guides/packaging-namespace-packages/#pkgutil-style-namespace-packages>`_
for the ``jaraco`` namespace.

Drop support for Python 3.5 and earlier.

2.7
===

Moved hosting to Github.

2.5
===

Improved support on OS X.
