from jaraco.media import index

if __name__ == '__main__':
	__ExtensionFactory__ = index.__ExtensionFactory__
	index.handle_isapi()
