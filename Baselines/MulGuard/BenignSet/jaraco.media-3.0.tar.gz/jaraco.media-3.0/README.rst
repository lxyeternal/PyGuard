.. image:: https://img.shields.io/pypi/v/jaraco.media.svg
   :target: https://pypi.org/project/jaraco.media

.. image:: https://img.shields.io/pypi/pyversions/jaraco.media.svg

.. image:: https://img.shields.io/travis/jaraco/jaraco.media/master.svg
   :target: https://travis-ci.org/jaraco/jaraco.media

.. .. image:: https://img.shields.io/appveyor/ci/jaraco/jaraco-media/master.svg
..    :target: https://ci.appveyor.com/project/jaraco/jaraco-media/branch/master

.. .. image:: https://readthedocs.org/projects/jaracomedia/badge/?version=latest
..    :target: https://jaracomedia.readthedocs.io/en/latest/?badge=latest

Troubleshooting
---------------

If you see "libaacs not initialized!" or "aacs_open() failed",
remember that you have to re-register with the latest
beta key each month.

See `this blog
<http://drbobtechblog.com/handbrake-can-use-makemkv-to-automatically-process-blu-ray-discs-heres-how/>`_
for details.
