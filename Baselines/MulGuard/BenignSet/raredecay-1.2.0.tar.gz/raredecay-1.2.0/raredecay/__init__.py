"""Initialization of raredecay
"""
from __future__ import division, absolute_import

__author__ = "Jonas Eschle 'Mayou36'"
__version__ = '1.2.0'
