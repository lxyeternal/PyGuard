BGR = 0
GRAY = 1
HSV = 2

RED = (0, 0, 255)
GREEN = (0, 255, 0)
BLUE = (255, 0, 0)
PURP = (255, 0, 255)
WHITE = (255,) * 3
BLACK = (0,) * 3