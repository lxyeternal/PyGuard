from pyhydroquebec.client import HydroQuebecClient, REQUESTS_TIMEOUT  # NOQA
