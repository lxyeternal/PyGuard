# dbtenv-dbt-alias

dbtenv, but additionally installs a 'dbt' executable that is functionally equivalent to aliasing the dbt command to 'dbtenv execute --'.
