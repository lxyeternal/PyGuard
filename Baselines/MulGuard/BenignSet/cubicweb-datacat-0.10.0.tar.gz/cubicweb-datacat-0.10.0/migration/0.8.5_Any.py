add_attribute('ResourceFeed', 'processes_to_keep')
