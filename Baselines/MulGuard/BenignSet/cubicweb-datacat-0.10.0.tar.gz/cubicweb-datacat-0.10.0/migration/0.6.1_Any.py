sync_schema_props_perms('SKOSSource', syncprops=False)
