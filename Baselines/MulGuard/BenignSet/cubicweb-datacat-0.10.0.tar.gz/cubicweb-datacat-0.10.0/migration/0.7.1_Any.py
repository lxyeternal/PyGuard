sync_schema_props_perms('dataset_frequency', syncperms=False)
sync_schema_props_perms('license_type', syncperms=False)
sync_schema_props_perms('publisher_type', syncperms=False)
sync_schema_props_perms('scheme_relation', syncperms=False)
