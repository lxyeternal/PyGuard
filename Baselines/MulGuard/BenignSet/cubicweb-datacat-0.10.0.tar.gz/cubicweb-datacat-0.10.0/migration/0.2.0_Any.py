drop_attribute('Dataset', 'ckan_dataset_id')
drop_attribute('Dataset', 'ckan_organization')
drop_attribute('Dataset', 'ckan_organization')
drop_attribute('File', 'ckan_resource_id')
