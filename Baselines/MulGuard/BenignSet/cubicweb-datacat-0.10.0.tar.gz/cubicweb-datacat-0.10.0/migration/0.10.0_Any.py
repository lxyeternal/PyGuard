add_relation_type('catalog_license')
