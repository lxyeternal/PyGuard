# pylint: disable=W0622
"""cubicweb-datacat application packaging information"""

from os import listdir as _listdir
from os.path import join, isdir
from glob import glob


modname = 'datacat'
distname = 'cubicweb-datacat'

numversion = (0, 10, 0)
version = '.'.join(str(num) for num in numversion)

license = 'LGPL'
author = 'LOGILAB S.A. (Paris, FRANCE)'
author_email = 'contact@logilab.fr'
description = 'Data catalog'
web = 'http://www.cubicweb.org/project/%s' % distname

__depends__ = {
    'cubicweb': '>= 3.24.4',
    'cubicweb-file': None,
    'cubicweb-relationwidget': None,
    'requests': None,
    'rdflib': '>= 4.1',
    'cubicweb-skos': '>= 1.0.0',
    'cubicweb-squareui': None,
    'cubicweb-dataprocessing': '>= 0.2.0',
    'cubicweb-postgis': '>= 0.3.1',
    'cubicweb-leaflet': '>= 0.4.1',
    'psycopg2': None,
    'shapely': None,
}
__recommends__ = {}

classifiers = [
    'Environment :: Web Environment',
    'Framework :: CubicWeb',
    'Programming Language :: Python',
    'Programming Language :: JavaScript',
]

THIS_CUBE_DIR = join('share', 'cubicweb', 'cubes', modname)


def listdir(dirpath):
    return [join(dirpath, fname) for fname in _listdir(dirpath)
            if fname[0] != '.' and not fname.endswith('.pyc') and
            not fname.endswith('~') and
            not isdir(join(dirpath, fname))]


data_files = [
    # common files
    [THIS_CUBE_DIR, [fname for fname in glob('*.py') if fname != 'setup.py']],
]
# check for possible extended cube layout
for dname in ('entities', 'views', 'sobjects', 'hooks', 'schema', 'data', 'wdoc', 'i18n',
              'migration', 'test'):
    if isdir(dname):
        data_files.append([join(THIS_CUBE_DIR, dname), listdir(dname)])
# Note: here, you'll need to add subdirectories if you want
# them to be included in the debian package

_IMPORT_DATADIR = join('migration', 'data')
if isdir(_IMPORT_DATADIR):
    data_files.append(
        [join(THIS_CUBE_DIR, _IMPORT_DATADIR),
         [join(_IMPORT_DATADIR, f) for f in _listdir(_IMPORT_DATADIR)]])
