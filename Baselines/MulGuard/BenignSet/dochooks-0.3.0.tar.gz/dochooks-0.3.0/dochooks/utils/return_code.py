from __future__ import annotations

PASS = 0
FAIL = 1

ReturnCode = int
