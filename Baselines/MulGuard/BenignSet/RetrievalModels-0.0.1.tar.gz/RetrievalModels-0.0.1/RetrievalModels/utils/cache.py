# Copyright (c) 2022, hrwX
# MIT License. See license.txt

class Cache(dict):
	pass

