def exponent(number, power):
    """Returns number to the power od the parameter power"""
    return number**power


def sq(number):
    """Returns the square of a number"""
    return number**2


def cu(number):
    """Returns a number cubed"""
    return number**3
