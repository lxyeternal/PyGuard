def remainder(a, b):
    return str(a//b) + "r" + str(a % b)


def fraction(a, b):
    return str(a//b) + " 1/" + str(a % b)


def string_division(a, b):
    """Returns the answer in the form of the string"""
    return str(a / b)

