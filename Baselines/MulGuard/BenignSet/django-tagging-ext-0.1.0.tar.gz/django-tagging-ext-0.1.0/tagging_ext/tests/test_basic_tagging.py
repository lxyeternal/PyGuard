"""
Tests basic django-tagging-ext functions

"""

from django.test import TestCase
from django.test.client import Client

class TestSynonyms(TestCase):
    
    def setUp(self):
        pass
 
    def tearDown(self):
        pass

    def test_synonym_creation(self):
        pass