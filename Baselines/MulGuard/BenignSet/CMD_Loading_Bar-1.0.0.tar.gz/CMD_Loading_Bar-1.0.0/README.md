# python-cmd-loading-bar
A simple yet elegant and feature rich cmd-line (stdout) loading bar.
