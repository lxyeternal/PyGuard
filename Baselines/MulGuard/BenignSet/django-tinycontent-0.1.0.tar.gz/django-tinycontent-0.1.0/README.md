A simple Django app for managing re-usable blocks of tiny content.
