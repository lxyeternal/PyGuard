from siren_pytorch.siren_pytorch import Siren, SirenNet
