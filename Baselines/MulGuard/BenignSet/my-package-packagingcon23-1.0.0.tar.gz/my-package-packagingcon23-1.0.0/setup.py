from setuptools import setup

setup(
    name='my-package-packagingcon23',
    version="1.0.0",
    description='my-package-packagingcon23',
    long_description="",
    long_description_content_type='text/markdown',
)