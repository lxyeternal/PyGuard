# crwlr

This package is a data mining application for scientific puplications
in the field of Tunnel information modelling. It queries several
scientific citation databases for publications in the field of
interest and stores it to a provided database.
