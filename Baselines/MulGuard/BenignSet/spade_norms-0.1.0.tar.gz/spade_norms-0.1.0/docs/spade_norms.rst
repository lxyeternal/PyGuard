spade\_norms package
====================

Submodules
----------

spade\_norms.spade\_norms module
--------------------------------

.. automodule:: spade_norms.spade_norms
    :members:
    :undoc-members:
    :show-inheritance:


Module contents
---------------

.. automodule:: spade_norms
    :members:
    :undoc-members:
    :show-inheritance:
