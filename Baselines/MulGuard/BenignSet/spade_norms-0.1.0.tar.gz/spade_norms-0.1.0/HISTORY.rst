=======
History
=======

0.1.0 (2023-07-12)
------------------

* First release on PyPI.
