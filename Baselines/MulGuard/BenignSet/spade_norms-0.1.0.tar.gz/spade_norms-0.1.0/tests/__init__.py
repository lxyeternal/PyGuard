"""Unit test package for spade_norms."""
