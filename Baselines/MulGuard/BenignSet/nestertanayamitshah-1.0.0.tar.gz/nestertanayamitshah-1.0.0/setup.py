from distutils.core import setup

setup(
    name="nestertanayamitshah",
    version="1.0.0",
    py_modules=["nestertanayamitshah"],
    author="tanayamitshah",
    author_email="tanayamitshah@gmail.com",
    url="www.football365.com",
    description="test"
    )
    
