# coding=utf-8
"""
oyou, tensorflow graph utility for training
"""
from .model import Model
