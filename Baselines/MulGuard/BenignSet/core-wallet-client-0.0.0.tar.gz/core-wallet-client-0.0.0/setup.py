from setuptools import setup


setup(name='core-wallet-client',
      version='0.0.0',
      description='Foo',
      url='https://squadrone@bitbucket.org/bar/foo.git',
      author='Squadrone',
      author_email='foo@bar.com',
      packages=['foo'],
      zip_safe=False)
