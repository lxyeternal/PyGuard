import setuptools

setuptools.setup(
    name="klyqa_ctl",
    version="1.0.1",
    author="Frederick Stallmeyer",
    description="Control the Klyqa Smart Devices.",
    packages=["klyqa_ctl"],
    
)