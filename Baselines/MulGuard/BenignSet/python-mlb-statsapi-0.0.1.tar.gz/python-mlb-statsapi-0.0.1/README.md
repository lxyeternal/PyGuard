python-mlb-statsapi is in development

This is a educational project no commercial use. 

Copyright Notice
This package and its authors are not affiliated with MLB or any MLB team. This API wrapper interfaces with MLB's Stats API. Use of MLB data is subject to the notice posted at http://gdx.mlb.com/components/copyright.txt.


