﻿class TheMlbStatsApiException(Exception):
    pass