﻿from dataclasses import dataclass, field
from typing import Optional, Union

from .stats import Stats