# -*- encoding: utf-8 -*-
from .paraformer_bin import Paraformer
