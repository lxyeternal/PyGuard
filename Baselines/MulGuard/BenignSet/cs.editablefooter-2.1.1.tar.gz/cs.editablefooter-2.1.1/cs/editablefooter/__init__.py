
from zope.i18nmessageid import MessageFactory

EditableFooterMessageFactory = MessageFactory('cs.editablefooter')
