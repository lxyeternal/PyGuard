# Change Log

All notable changes to this project will be documented in this file.

This project adheres to [Semantic Versioning](http://semver.org/).


## [1.0.0a0] - 2016-07-22

### Added
- Set up project (from @justjasongreen)


[1.0.0a0]: https://github.com/justjasongreen/predictive_punter/tree/1.0.0a0
