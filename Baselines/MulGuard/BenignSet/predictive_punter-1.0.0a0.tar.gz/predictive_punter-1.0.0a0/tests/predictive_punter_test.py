import predictive_punter


def test_version():
    """predictive_punter.__version__ should return the correct version string"""

    assert predictive_punter.__version__ == '1.0.0a0'
