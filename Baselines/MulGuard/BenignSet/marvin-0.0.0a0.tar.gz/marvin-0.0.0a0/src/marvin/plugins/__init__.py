from .base import Plugin
from . import web, google, duckduckgo, math, chroma
