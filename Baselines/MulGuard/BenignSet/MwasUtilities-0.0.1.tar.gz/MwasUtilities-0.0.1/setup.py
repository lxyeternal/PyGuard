__author__ = 'Mwaaas'
__email__ = 'francismwangi152@gmail.com'
__phone_number__ = '+254702729654'


from distutils.core import setup

setup(
    name='MwasUtilities',
    version='0.0.1',
    packages=[''],
    url='',
    license='',
    author='mwas',
    author_email='francismwangi152@gmail.com',
    description='it is used to get object from dict recusively for with get method'
)

