# silvr-client

A Python client for brokers to send new application.

See [demo.py](demo.py) to see how to use the API.
