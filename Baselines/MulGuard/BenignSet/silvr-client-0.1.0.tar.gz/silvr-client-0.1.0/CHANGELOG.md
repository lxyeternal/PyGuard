# CHANGELOG

This document describes changes between each  past release.

## 0.1.0 (2023-11-13)

- Allow broker login
- Allow sending applications
