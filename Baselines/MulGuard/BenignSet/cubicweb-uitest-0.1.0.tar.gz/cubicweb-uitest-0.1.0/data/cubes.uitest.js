$(document).ready(function() {
  $('a[rel=tooltip]').tooltip();
 });