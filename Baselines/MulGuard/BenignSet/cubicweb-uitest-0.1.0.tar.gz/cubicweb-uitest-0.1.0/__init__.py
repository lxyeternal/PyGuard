"""cubicweb-uitest application package

 test and documentation cube
"""
