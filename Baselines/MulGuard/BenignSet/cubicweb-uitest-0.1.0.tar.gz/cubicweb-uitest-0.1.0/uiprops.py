STYLESHEETS.extend([data('cubes.uitest.css')]
                   )
JAVASCRIPTS.extend([data('cubes.uitest.js')])
