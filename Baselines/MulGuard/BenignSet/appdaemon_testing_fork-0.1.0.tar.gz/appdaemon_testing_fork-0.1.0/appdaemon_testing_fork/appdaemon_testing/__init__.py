"""
.. include:: ../README.md
"""
from .hass_driver import HassDriver

__all__ = ["HassDriver"]
__version__ = "0.0.0-dev"
