#!/usr/bin/env python3

"""

The constructor for pymoth package.

.. moduleauthor:: Adam P. Jones <ajones173@gmail.com>

"""

from .main import MothNet

# from ..examples import experiment as sample_experiment
