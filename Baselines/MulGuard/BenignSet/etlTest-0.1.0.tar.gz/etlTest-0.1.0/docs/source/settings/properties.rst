etlTest User Properties Settings
================================
