Test Templates
==============


.. toctree::
   :maxdepth: 2

   Test Suite Template <test_suite>
   Test Template <test>