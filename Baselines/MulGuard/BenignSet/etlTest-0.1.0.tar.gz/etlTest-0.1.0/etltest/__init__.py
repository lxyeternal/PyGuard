__author__ = 'ameadows'
__version__ = '0.1.0'