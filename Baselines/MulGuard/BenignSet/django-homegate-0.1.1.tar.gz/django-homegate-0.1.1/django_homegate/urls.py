"""URLs for the django_homegate app."""
# from django.conf.urls.defaults import patterns, url

# from . import views


# urlpatterns = patterns(
#     '',
#     url(r'^$',
#         views.YourView.as_view(),
#         name='django_homegate_default'),
# )
