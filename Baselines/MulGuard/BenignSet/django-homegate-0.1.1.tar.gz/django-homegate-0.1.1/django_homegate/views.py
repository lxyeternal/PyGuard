"""Views for the django_homegate app."""
# from django.views.generic import TemplateView

# from . import models


# class YourView(TemplateView):
#    template_name = 'django_homegate/default.html'
