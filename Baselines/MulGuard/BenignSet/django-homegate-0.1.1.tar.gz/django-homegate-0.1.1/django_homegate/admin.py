"""Admin classes for the django_homegate app."""
# from django.contrib import admin

# from . import models


# class YourModelAdmin(admin.ModelAdmin):
#    list_display = ['some', 'fields', ]
#    search_fields = ['some', 'fieds', ]

# admin.site.register(models.YourModel, YourModelAdmin)
