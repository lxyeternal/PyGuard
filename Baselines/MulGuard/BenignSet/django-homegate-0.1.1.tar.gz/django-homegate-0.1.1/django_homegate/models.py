"""Just an empty models file to let the testrunner recognize this as app."""
# from django.db import models
# from django.utils.translation import ugettext_lazy as _


#READY_TO_PUSH_PUBLISH = 10
#class RealEstateManager(models.Manager):
#    def ready_to_push(self):
#        return self.filter(status=READY_TO_PUSH_PUBLISH)

#class RealEstate(models.Model):
#    ...
#    status = ...
#    objects = RealEstateManager()
#   
#    def published_idx_record(self):
#        self.status = self.PUBLISHED
#        self.save()
#
#    def get_idx_record(self):
#        from homegate import IdxRecord
#        rec = IdxRecord()
#        rec.update({...})
#        return rec


