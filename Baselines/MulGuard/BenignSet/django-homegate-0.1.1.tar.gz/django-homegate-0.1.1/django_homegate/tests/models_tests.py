"""Tests for the models of the django_homegate app."""
from django.test import TestCase

# from .factories import YourModelFactory


class DummyTestCase(TestCase):
    """Sample test case to show that `python setup.py test` works."""
    def test_something(self):
        self.assertTrue(True)
