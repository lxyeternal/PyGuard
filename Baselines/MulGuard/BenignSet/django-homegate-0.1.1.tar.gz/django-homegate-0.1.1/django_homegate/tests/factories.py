"""Factories for the django_homegate app."""
# import factory

# from ..models import YourModel
