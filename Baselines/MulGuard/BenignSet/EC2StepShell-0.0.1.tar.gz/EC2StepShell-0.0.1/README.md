# EC2StepShell

EC2StepShell is an AWS post-exploitation tool for getting reverse shells in public or private EC2 instances

## Usage

```bash
EC2StepShell -h
```

## Installation

```bash
python -m pip install EC2StepShell
```
