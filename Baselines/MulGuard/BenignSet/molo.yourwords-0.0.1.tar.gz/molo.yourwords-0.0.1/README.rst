# molo.yourwords
A molo module that enables user generated content competitions
