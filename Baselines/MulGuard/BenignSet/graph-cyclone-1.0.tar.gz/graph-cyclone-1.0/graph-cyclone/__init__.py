"""
The graph-cyclone package, containing only the graph-cyclone module.
Thus, this has been configured so that graph-cyclone.graph-cyclone can
be imported simpy as `import graph-cyclone`.
"""

from .graph-cyclone import *
