# graphcyclone
Utilities for powers of cycle graphs
