# Sigma Coding Python Library

## Table of Contents

- [Overview](#overview)
- [Setup](#setup)
- [Usage](#usage)
- [Support These Projects](#support-these-projects)

## Overview

## Setup

Setup text 
```console
pip install *include the pip install path here* .
```
or if on Freia
'''console
pip3 install ****** --user
'''

## Usage

Describe using the loading in data stuff here somehow.
