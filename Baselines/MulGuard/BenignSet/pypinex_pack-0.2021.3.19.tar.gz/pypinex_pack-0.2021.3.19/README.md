pypinex_pack
==========

Introduction
------------

PyPine extension that supports various ways of compressing/uncompressing files: gzip, bzip2, xz, tar and uploadpack.

Information about this module can be found here:

* [github.org](https://github.com/jkpubsrc/pypinex-pack)
* [pypi.python.org](https://pypi.python.org/pypi/pypinex-pack)

Documentation
----------------

(TODO)

Author
-------------------

List of Authors:

* Jürgen Knauth: pubsrc@binary-overflow.de

License
-------

This software is provided under the following license:

* Apache Software License 2.0



