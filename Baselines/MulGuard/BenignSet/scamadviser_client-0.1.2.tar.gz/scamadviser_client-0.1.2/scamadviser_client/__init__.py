__version__ = "0.1.2"

from scamadviser_client.feed_api import FeedAPI

__all__ = ["FeedAPI"]
