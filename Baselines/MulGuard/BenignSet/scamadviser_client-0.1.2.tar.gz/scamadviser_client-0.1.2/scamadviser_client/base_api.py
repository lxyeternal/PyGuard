class BaseAPI:
    def __init__(self, apikey: str):
        self.apikey = apikey
