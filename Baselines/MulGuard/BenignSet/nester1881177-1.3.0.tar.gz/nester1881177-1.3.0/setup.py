from distutils.core import setup

setup(
        name = 'nester1881177',
        version = '1.3.0',
        py_modules = ['nester1881177'],
        author = 'AllenYt',
        author_email = 'welink@163.com',
        url        = 'http://www.headfirstlabs.com',
        description = 'A simple printer of nested lists',


    )
