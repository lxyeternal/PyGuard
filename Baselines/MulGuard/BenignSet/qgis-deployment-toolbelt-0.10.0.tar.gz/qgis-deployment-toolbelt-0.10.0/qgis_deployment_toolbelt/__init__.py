#! python3  # noqa: E265

# submodules
from .__about__ import __version__  # noqa: F401
from .utils.journalizer import LogManager  # noqa: E402 F401
