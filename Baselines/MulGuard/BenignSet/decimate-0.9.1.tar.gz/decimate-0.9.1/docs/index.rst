Welcome to Decimate's documentation!
====================================

.. image:: images/healing_workflow.png


.. _user-docs:

.. toctree::
   :maxdepth: 3
   :caption: User Documentation

   what_is_decimate
   use
   workflows
   parameters
   options
   
.. _dev-docs:

.. toctree::
   :maxdepth: 3
   :caption: Developer Documentation

   install


