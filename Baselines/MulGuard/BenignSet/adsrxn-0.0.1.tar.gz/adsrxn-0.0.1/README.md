# python package for adsorption-reaction process

This is a simple package to run adsorption-reaction process simulation.
