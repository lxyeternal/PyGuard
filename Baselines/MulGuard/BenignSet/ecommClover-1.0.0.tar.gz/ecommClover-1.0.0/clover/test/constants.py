DEFAULT_REQUEST_DELAY_SECS = 0.1


# Sandbox Credentials
SANDBOX_ACCESS_TOKEN = None
SANDBOX_API_KEY = None
SANDBOX_MERCHANTUUID = None
SANDBOX_MID = None

REQUESTS_PATH = 'clover.http_client.requests'

CARD = {
    'number': '4111111111111111',
    'brand': 'VISA',
    'exp_month': '12',
    'exp_year': '2030',
    'cvv': '123',
}
