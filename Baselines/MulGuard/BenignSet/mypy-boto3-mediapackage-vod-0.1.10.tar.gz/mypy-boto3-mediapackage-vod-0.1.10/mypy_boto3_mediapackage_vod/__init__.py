"Main interface for mediapackage-vod service"

from mypy_boto3_mediapackage_vod.client import Client

__all__ = ("Client",)
