
#ifdef _MSC_VER

typedef unsigned __int64 uint64_t;
typedef unsigned __int32 uint32_t;
typedef unsigned __int8 uint8_t;

#else
#include <stdint.h>
#endif
