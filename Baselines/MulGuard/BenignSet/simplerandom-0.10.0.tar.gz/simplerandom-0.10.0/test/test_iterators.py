#!/usr/bin/env python

import unittest

import simplerandom.iterators.test

unittest.main(module=simplerandom.iterators.test)
