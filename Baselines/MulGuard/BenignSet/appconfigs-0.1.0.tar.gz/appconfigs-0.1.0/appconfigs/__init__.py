# -*- coding: utf-8 -*-
# -----------------------------------------------------------------------------
# Copyright © Spyder Project Contributors
#
# This file is a derivative work of codes from the Spyder project,
# licensed under the terms of the MIT License
# (see spyder/__init__.py for details)
# -----------------------------------------------------------------------------

version_info = (0, 1, 0)
__version__ = '.'.join(map(str, version_info))
__date__ = '08/01/2018'
__project_url__ = "https://github.com/jnsebgosselin/appconfigs"
