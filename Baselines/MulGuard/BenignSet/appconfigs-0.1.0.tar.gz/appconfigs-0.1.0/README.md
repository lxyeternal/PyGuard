# appconfigs
[![Build status](https://ci.appveyor.com/api/projects/status/d5vg8c704m1el8pc/branch/master?svg=true)](https://ci.appveyor.com/project/jnsebgosselin/appconfigs/branch/master)
[![codecov](https://codecov.io/gh/jnsebgosselin/appconfigs/branch/master/graph/badge.svg)](https://codecov.io/gh/jnsebgosselin/appconfigs)

**appconfigs** is a small Python module that provides user configuration file management features for Python applications. It is based on the config module of [Spyder](https://www.spyder-ide.org/), the scientific Python development environment.
