from setuptools import setup, find_packages

setup(
    name="bugle",
    version="0.1",
    packages=find_packages(),
    install_requires=[],
    author="htm",
    author_email="hari2608@gmail.com",
    description="A simple investing package",
    long_description="A simple investing package with basic operations.",
    long_description_content_type="text/markdown"
)
