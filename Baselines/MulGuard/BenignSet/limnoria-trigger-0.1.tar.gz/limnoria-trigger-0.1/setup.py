from supybot.setup import plugin_setup

plugin_setup(
    'Trigger',
)
