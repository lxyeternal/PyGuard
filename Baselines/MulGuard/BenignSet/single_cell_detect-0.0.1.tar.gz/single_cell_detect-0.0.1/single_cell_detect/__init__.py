from .single_cell_detect import watershed_edge

__version__ = '0.0.3'
