PROJECTNAME = 'PloneGazette'

product_globals = globals()

PG_CATALOG = 'subscribers_catalog'
