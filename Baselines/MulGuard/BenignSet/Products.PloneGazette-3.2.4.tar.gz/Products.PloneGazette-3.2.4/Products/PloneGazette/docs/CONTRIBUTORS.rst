Contributors
------------

* Morten W. Petersen <info at nidelven-it.no>, The current maintainer
* Kai Lautaportti <kai.lautaportti at hexagonit.fi>
* Taito Horiuchi <taito.horiuchi at hexagonit.fi>

Translators
===========

Thanks to translators for their precious help.

* Ricardo Kirkner for Spanish,
* Tiziano Fogliata and Paolo Melchiorre for Italian,
* Klaus Raasch for Deutsch,
* Luciano De Fazio and  Rafahela Garcia Bazzanella for Portugues do Brasil (viva brasil !!),
* Anton Stonor for Danish.
