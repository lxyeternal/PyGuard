Credits
-------

PloneGazette was originally developed by PilotSystems:
http://www.pilotsystems.net

Sponsored by Adesium. Jerome
Sandarnaud for the product development.

Maintaner from November 2007 to January 2012-01-28 was Radim Novotny
(naro) <novotny.radim at gmail.com>
