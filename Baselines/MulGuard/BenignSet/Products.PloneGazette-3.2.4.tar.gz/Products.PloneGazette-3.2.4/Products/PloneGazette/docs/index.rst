.. include:: README.rst

Contents:

.. toctree::
    :maxdepth: 2

    INSTALL.rst
    UPGRADE.rst
    TODO.rst
    HISTORY.rst
    CONTRIBUTORS.rst
    CREDITS.rst
    LICENSE.rst

Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`
