ToDo
----

- fix "Delete" object action on Newsletter object. Currently fails on AttributeError: @@plone_lock_info
  Workaround: Delete Newsletter object from NewsletterTheme folder_contents view.
