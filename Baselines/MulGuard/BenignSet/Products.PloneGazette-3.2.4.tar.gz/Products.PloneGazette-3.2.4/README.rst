See `Products/PloneGazette/docs/README.rst <https://github.com/collective/Products.PloneGazette/blob/master/Products/PloneGazette/docs/README.rst>`_

Tests
=====

This add-on is tested using Travis CI. The current status of the add-on is :

.. image:: https://secure.travis-ci.org/collective/Products.PloneGazette.png
    :target: http://travis-ci.org/collective/Products.PloneGazette
