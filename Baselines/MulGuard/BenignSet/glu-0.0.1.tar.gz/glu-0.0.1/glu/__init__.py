from glu.core import reset_scope, load_scope, glued
