# Authors: Loïc Van Hoorebeeck
# License: MIT

__version__ = '0.1'

def main():
    """Entry point for the application script"""
    print("Call your main application code here")
