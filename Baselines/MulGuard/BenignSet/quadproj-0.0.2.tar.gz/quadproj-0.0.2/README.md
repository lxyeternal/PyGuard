# proj_ellipsoid

## Dependencies

imageio

gifsicle

