class NotConfiguredYet(Exception):
    pass

class ValidationError(Exception):
    pass
