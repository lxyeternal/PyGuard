from __future__ import absolute_import

# this is required for setup.py to work
try:
    from .utils import *
except ImportError:
    pass


VERSION = (0, 5, 1,)
