MkNxGn Sparkfun OpenScale Helper - Serial

This module allows users to use the OpenScale programatically or interactively.


Module:
https://www.sparkfun.com/products/13261