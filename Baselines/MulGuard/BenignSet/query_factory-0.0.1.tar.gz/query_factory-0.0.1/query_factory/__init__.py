from .factory import SQLQueryFactory


__version__ = "0.0.1"
