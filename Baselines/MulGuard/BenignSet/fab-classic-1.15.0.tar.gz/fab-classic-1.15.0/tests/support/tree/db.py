from fabric.api import task


@task
def migrate():
    pass
