from fabric.decorators import task

@task
def foo():
    """
    Foos!
    """
    pass
