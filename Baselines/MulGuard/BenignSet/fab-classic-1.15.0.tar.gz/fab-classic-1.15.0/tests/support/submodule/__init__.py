from support.submodule import subsubmodule

def classic_task():
    pass
