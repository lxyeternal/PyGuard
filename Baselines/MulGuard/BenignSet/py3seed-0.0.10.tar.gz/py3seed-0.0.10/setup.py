# -*- coding: utf-8 -*-
"""
    setup
    ~~~~~~~~~~~~~~

    Dynamic metadata.

    :copyright: (c) 2021 by weiminfeng.
    :date: 2021/8/11
"""

from setuptools import setup, find_packages

setup(name="py3seed", packages=find_packages())
