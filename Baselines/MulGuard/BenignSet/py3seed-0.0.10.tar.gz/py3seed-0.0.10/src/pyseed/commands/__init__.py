# -*- coding: utf-8 -*-
"""
    __init__.py
    ~~~~~~~~~~~~~~

    Commands package.

    :copyright: (c) 2021 by weiminfeng.
    :date: 2021/9/1
"""
