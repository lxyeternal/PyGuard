# pyseed

A package that bootstraps your project by simple data models definition and auto api and user interface generation.

Including:
* simple data models definition, by typing
* built-in database support, including mongodb, etc
* auto api generation
* auto user interface generation
