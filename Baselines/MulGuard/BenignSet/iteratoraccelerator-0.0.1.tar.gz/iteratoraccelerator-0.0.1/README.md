# Binary Iterator Accelerator
