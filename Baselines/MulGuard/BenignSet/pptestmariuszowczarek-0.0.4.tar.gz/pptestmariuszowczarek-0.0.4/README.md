# `pptestmariuszowczarek` - My simple project on PyPI

* Op1
* Op2
* Op3

# install

```python
pip install pptestmariuszowczarek
```

# usage
```python
from pptestmariuszowczarek.m_mod_pptest import name as n

>>> n('Name', "Surname")
Witaj: Name Surname

>>> get_np_arr([1,2,3,4,5])
[1 2 3 4 5]
```