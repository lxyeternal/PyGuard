def exibir_hello_world():
    print("Hello, World!")
