=====
Usage
=====

To use General Repytivity in a project::

    import generalrepytivity
