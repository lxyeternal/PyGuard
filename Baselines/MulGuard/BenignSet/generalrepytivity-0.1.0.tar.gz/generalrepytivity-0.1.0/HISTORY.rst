=======
History
=======

0.1.0 (2018-01-06)
------------------

* First release on PyPI.
