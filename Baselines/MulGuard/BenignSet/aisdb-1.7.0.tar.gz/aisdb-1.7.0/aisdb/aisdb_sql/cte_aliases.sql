dynamic_{} AS ( {}
),
static_{} AS ( {}
),
