"""
Init for package
"""

print "I'm here!"
