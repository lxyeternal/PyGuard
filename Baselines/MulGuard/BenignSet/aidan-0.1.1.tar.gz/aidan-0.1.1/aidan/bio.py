"""
The Aidan package for Aidan things
"""

def bio():
    """lets you know what's up"""
    print "hi, I'm Aidan McLaughlin. Talking to you through the tubes."

if "__name__" == "__main__":
    bio()
