from distribute_setup import use_setuptools
use_setuptools()

from setuptools import setup


setup(
    name='aidan',
    version='0.1.1',
    author='',
    author_email='',
    packages=['aidan'],
    url='',
    license='See LICENSE.txt',
    description='',
    long_description=open('README.txt').read(),
)
