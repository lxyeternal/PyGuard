=====
aidan
=====

This is a living package that I'll update with information about me, helper functions, and other fun stuff.

At the moment this is my "hello world" of a pypi package so my apologies for how barren it is.
