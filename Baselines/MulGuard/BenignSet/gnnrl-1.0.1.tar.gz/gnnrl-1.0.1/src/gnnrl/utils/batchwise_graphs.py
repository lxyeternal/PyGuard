
def get_next_graph_batch(data_loader):

    return next(iter(data_loader))