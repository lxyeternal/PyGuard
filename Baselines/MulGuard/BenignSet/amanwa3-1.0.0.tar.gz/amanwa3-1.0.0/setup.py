from distutils.core import setup

setup(
    name='amanwa3',
    version='1.0.0',
    packages=['amanwa3'],
    url='https://github.com/checkitout/a1',
    license='',
    author='aman',
    author_email='angrish_aman@yahoo.com',
    description='testing pypi'
)

