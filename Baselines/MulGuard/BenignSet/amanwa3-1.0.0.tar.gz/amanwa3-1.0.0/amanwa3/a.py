
def hi():
	print('hi')
