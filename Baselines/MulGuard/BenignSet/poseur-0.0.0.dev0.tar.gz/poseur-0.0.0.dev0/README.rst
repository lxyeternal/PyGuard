======
poseur
======

    Write *positional-only parameters* in Python 3.8 flavour, and let ``poseur`` worry about back-port issues :beer:
