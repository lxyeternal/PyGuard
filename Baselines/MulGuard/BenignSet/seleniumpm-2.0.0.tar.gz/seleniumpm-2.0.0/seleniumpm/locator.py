class Locator(object):

    def __init__(self, by, value):
        self.by = by
        self.value = value
