Release History
===============


### 2.0.0 (2017-01-10)

**New Features**

- First release of seleniumpm for the world
- Contains minimum proof-of-concept for testing search on Google
