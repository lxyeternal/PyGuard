from setuptools import setup

setup(name='distributions_SH',
      version='0.1',
      description='General distribution, Gaussian distributions, and Binomial distribution ',
      packages=['distributions_SH'],
      author='Scarlett Huang',
      author_email='scarlett0413@outlook.com',
      zip_safe=False)
