from cblack.runner import Runner

__all__ = ["Runner"]


def main():
    exit(Runner().run())
