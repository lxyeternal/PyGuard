# Shamsi

Convert a Shamsi (Jalali) date to Gregorian date and vice versa


https://gitlab.com/samic130/shamsi





For developers:
to update, change the VERSION file and run the release.py
