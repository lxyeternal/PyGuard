from simple_site_crawler.site_crawler import SiteCrawler  # noqa


__version__ = '0.1.0'
