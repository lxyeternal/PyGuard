# Add more resources if needed
AAD_RESOURCE_NAME_TO_ID = {
    'databricks': '2ff814a6-3304-4ab8-85cb-cd0e6f879c1d',
}
