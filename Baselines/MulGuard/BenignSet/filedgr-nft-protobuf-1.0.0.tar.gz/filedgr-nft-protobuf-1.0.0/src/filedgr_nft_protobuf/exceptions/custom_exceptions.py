class SerializationException(Exception):
    pass


class DeserializationException(Exception):
    pass
