SDK
===

.. image:: https://img.shields.io/pypi/v/credit.svg
    :target: https://pypi.python.org/pypi/credit/
    :alt: Latest Version

.. image:: https://img.shields.io/pypi/wheel/credit.svg
    :target: https://pypi.python.org/pypi/credit/

.. image:: https://img.shields.io/pypi/pyversions/credit.svg
    :target: https://pypi.python.org/pypi/credit/

.. image:: https://img.shields.io/pypi/l/credit.svg
    :target: https://pypi.python.org/pypi/credit/



SDK.


Installing
----------

Install and update using `pip`_:

.. code-block:: text

    pip install -U credit



.. _pip: https://pip.pypa.io/en/stable/quickstart/
