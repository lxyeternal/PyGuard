from setuptools import setup

setup(
    name="QElephant",
    version="1.0.1",
    description="",
    author="Didictateur",
    author_email="decosse.adrien@gmail.com",
    packages=["QElephant"],
    install_requires=[],
)
