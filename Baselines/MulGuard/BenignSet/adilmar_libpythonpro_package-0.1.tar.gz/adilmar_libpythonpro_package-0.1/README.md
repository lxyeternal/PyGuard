# libpythonpro

Suporta versão 3 do python

Para instalar:
``` Console
python3 -m venv .venv
.venv/scripts/activate.bat
pip install -r requirements-dev.txt
```

Para conferir a qualidade do código:

```Console
flake8
```

Exercicios aula pytools
