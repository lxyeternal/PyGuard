# __init__.py
from .check_parallel import check_parallel