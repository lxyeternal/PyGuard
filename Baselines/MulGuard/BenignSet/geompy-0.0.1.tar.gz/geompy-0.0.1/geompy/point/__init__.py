# __init__.py
from .on_line import on_line
from .on_plane import on_plane