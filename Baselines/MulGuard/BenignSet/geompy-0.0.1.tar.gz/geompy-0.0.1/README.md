# geompy
A Python package for practical geometry algorithms.
