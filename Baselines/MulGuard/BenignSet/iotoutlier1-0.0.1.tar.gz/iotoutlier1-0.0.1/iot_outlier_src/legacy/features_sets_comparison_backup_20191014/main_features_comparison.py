# Authors: kun.bj@outlook.com
#
# License: xxx
""" Main function for feature set comparison.
    Measure metrics: ROC amd AUC

"""
import pickle
from collections import Counter
from inspect import signature
from random import shuffle

import matplotlib.pyplot as plt
from scipy.spatial import distance
from sklearn import metrics
from sklearn.metrics import roc_curve
from sklearn.preprocessing import MinMaxScaler, StandardScaler
from sklearn.utils import shuffle

from _config import *
from detector.gmm_class import GMMDetector
from detector.ocsvm_class import OCSVMDetector
from legacy.utils.dataset import stat_data


class Dataset():

    def __init__(self, input_file=''):
        self.input_file = input_file
        self.fids, self.features, self.labels = self.load_pickled_data(input_file=self.input_file)

    def load_pickled_data(self, input_file):
        """ Especially for loading multi-objects stored in a file.

           :param input_file:
           :return:
           """

        fids = []
        features = []
        labels = []
        with open(input_file, 'rb') as in_hdl:
            while True:
                try:
                    fids_, features_, labels_ = pickle.load(in_hdl)
                    fids.extend(fids_)
                    features.extend(features_)
                    labels.extend(labels_)
                except EOFError:
                    break

        return fids, features, labels

    def split_train_test(self, features='', labels='', shuffle_flg=True, random_state=42):

        X_normal = []
        y_normal = []
        X_anomaly = []
        y_anomaly = []
        none_num = 0

        for i, value in enumerate(labels):
            feat = list(features[i])
            if value.upper() in ['NORMAL', 'BENIGN']:
                X_normal.append(feat)
                y_normal.append(0)
            elif value.upper() in ['BOT']:
                X_anomaly.append(feat)
                y_anomaly.append(1)
            else:
                none_num += 1
        print(f'{none_num} flows appear in pcap, however, don\'t appear in labels.csv')
        print(f'0: NORMAL, 1: Anomaly')

        if shuffle_flg:  # random select a part of normal flows from normal flows
            c = list(zip(X_normal, y_normal))
            X_normal, y_normal = zip(*shuffle(c, random_state=random_state))

        X_normal = np.array(X_normal, dtype=float)
        y_normal = np.array(y_normal, dtype=int)
        X_anomaly = np.array(X_anomaly, dtype=float)
        y_anomaly = np.array(y_anomaly, dtype=int)

        if len(y_anomaly) == 0:
            print(f'no anomaly data in this data_process')
            train_size = len(y_normal) - 100  # use 100 normal flows as test set.
            X_train = X_normal[:train_size, :]
            y_train = y_normal[:train_size]
            X_test = X_normal[:100, :]
            y_test = y_normal[:100]
        else:
            train_size = len(y_normal) - len(y_anomaly)
            X_train = X_normal[:train_size, :]
            y_train = y_normal[:train_size]
            X_test = np.concatenate([X_normal[train_size:, :], X_anomaly], axis=0)
            y_test = np.concatenate([y_normal[train_size:], y_anomaly], axis=0)

        print(f'--- train set and test set --'
              f'\nX_train:{X_train.shape}, y_train:{Counter(y_train)}'
              f'\nX_test :{X_test.shape}, y_test :{Counter(y_test)}, in which, 0: normals and 1: anomalies.')
        stat_data(X_train, name='X_train')
        stat_data(X_test, name='X_test')

        return X_train, y_train, X_test, y_test


def print_func_args(func):
    sig = signature(func)
    for key, value in sig.parameters.items():
        print(f'{key}, {value}')


class Experiment:

    def __init__(self, input_file, feat_set='', norm_method='std', data_aug=False, shuffle_flg=True, random_state=42):

        print_values(input_file=input_file, feat_set=feat_set, norm_method=norm_method,
                     data_aug=data_aug,
                     shuffle_flg=shuffle_flg, random_state=random_state)
        print('1) load data and split train and test set')
        self.data_inst = Dataset(input_file)
        self.X_train, self.y_train, self.X_test, self.y_test = self.data_inst.split_train_test(
            features=self.data_inst.features,
            labels=self.data_inst.labels,
            shuffle_flg=shuffle_flg,
            random_state=random_state)

        self.norm_method = norm_method
        print(f'2) normalization ({norm_method})')
        self.X_train, self.X_test = self.normalise_data(self.X_train, self.X_test, norm_method=self.norm_method)

        self.data_aug = data_aug

        # print_func_args(self.__init__)

    def run(self, detector_name='OCSVM', X_train='', y_train='', X_test='', y_test=''):
        print(f'3) train and test using {detector_name}')
        roc_dict = {}
        auc_dict = {}

        # gmm = GMMDetector(n_components=3)
        # gmm.train(X_train)
        # # dump(pca, 'output_data/models_dumping/gmm_' + case + '.joblib')
        # # model = load('output_data/models_dumping/gmm_' + case + '.joblib')
        # gmm.test(X_test, y_test)
        # roc_dict['gmm'] = {'y_true': y_test, 'y_scores': gmm.y_scores}
        # auc_dict['gmm']=gmm.auc

        # knn = KNNDetector()
        # knn.train(X_train)
        # # dump(pca, 'output_data/models_dumping/knn_' + case + '.joblib')
        # # model = load('output_data/models_dumping/knn_' + case + '.joblib')
        # knn.test(X_test, y_test)
        # roc_dict['knn'] = {'y_true': y_test, 'y_scores': knn.y_scores}
        # auc_dict['knn'] = knn.auc
        # knn.visualize(X_train[:,:2], y_train, X_test[:,:2], y_test, knn.knn.predict(X_train), knn.knn.predict(X_test), show_figure=True)

        # pca = PCADetector()
        # pca.train(X_train)
        # # dump(pca, 'output_data/models_dumping/pca_' + case + '.joblib')
        # # model = load('output_data/models_dumping/pca_' + case + '.joblib')
        # pca.test(X_test, y_test)
        # roc_dict['pca'] = {'y_true': y_test, 'y_scores': pca.y_scores}
        # auc_dict['pca'] = pca.auc

        if detector_name.upper() == 'OCSVM':
            distances = distance.pdist(X_train, metric='euclidean')
            stat_data(distances.reshape(-1, 1), name='distances')
            q = 0.3
            print('without grid search cv')
            sigma = np.quantile(distances, q=q)
            gamma = 1 / (sigma ** 2)
            # print(f'gamma:{gamma}, q:{q}, sigma:{sigma}, Counter(distances):{sorted(Counter(distances).items(), key=lambda item: item[0])}')
            print(f'gamma:{gamma}, q:{q}, sigma:{sigma}')
            detector = OCSVMDetector(gamma=gamma)

        elif detector_name.upper() == 'GMM':
            detector = GMMDetector(n_components=1, covariance_type='diag')

        detector.fit(X_train)
        detector.test(X_test, y_test)

        key = detector_name
        roc_dict[key] = {'y_true': y_test, 'y_scores': detector.y_scores}
        auc_dict[key] = detector.auc

        # ocsvm = OCSVMDetector()
        # ocsvm.train(X_train)
        # # dump(ocsvm, 'output_data/models_dumping/ocsvm_' + case + '.joblib')
        # # model = load('output_data/models_dumping/ocsvm_' + case + '.joblib')
        # ocsvm.test(X_test, y_test)
        # roc_dict['ocsvm'] = {'y_true': y_test, 'y_scores': ocsvm.y_scores}
        # auc_dict['ocsvm'] = ocsvm.auc

        # iforest = IForestDetector()
        # iforest.train(X_train)
        # # dump(ocsvm, 'output_data/models_dumping/iforest_' + case + '.joblib')
        # # model = load('output_data/models_dumping/iforest_' + case + '.joblib')
        # iforest.test(X_test, y_test)
        # roc_dict['iforest'] = {'y_true': y_test, 'y_scores': iforest.y_scores}
        # auc_dict['iforest'] = iforest.auc

        return roc_dict, auc_dict

    def normalise_data(self, X_train, X_test, norm_method='std'):

        if norm_method in ['min-max', 'std']:
            if norm_method == 'min-max':
                train_scaler = MinMaxScaler()
            if norm_method == 'std':
                train_scaler = StandardScaler()
            train_scaler.fit(X_train)
            X_train = train_scaler.transform(X_train)
            X_test = train_scaler.transform(X_test)

            print('after normalization: X_train distribution:')
            stat_data(X_train)
            print('after normalization:X_test distribution:')
            stat_data(X_test)

            return X_train, X_test

        elif norm_method == 'none':
            print('without normalization')
            return X_train, X_test
        else:
            print('not implemented.')
            return -1

    def plot(self):
        pass


#
#
# def run_experiment(experiment=(), srcIP_lst=[], norm_method='std', data_aug=False):
#     exper, case = experiment  # # case1:(IAT VS Baseline),  case 2 (FFT VS Baseline)
#     print(f'exper: {exper}, case: {case}')
#
#     if exper == 'demo':
#         srcIP = srcIP_lst[0]
#         print(f'demo_srcIP: {srcIP}')
#         main_for_roc(srcIP, experiment=experiment, norm_method=norm_method, data_aug=data_aug)
#
#     elif exper == 'individual':
#         for i, srcIP in enumerate(srcIP_lst):
#             print(f'indiv_srcIP: {srcIP}')
#             main_for_roc(srcIP, experiment=experiment, norm_method=norm_method, data_aug=data_aug)
#
#     elif exper == 'mix':
#         # mix multi devices' data
#         feat_set = case.split()[0]
#         files_lst = [obtain_file_path(srcIP, feat_set=feat_set) for srcIP in srcIP_lst]
#         merged_file = obtain_file_path(srcIP='-'.join(srcIP_lst), feat_set=feat_set)
#         merged_file = merge_multifiles_to_one(files_lst=files_lst, merged_file=merged_file)
#
#         print(f'merged_file: {merged_file}')
#         main_for_roc(srcIP='-'.join(srcIP_lst), experiment=experiment, data_aug=data_aug)
#     else:
#         print('not implement')
#

#
#
#
#
#
#
# def load_and_split_data(input_file='', case='', shuffle_flg=True, random_state=random_state):
#     print('1) load data and split it to train set and test set, normal and anormaly in test set with ratio: 1:1')
#     fids, features, labels = load_pickled_data(input_file)
#
#     feat_set = case.split()[0]
#     if feat_set in ['IAT', 'FFT']:
#         feat_len_arr = [len(v) for v in features]
#         fft_bins = int(np.quantile(feat_len_arr, q=0.9))
#     else:  # for baseline_set, no need fft_bins
#         fft_bins = 0
#     print(f'feat_set: {feat_set}, fft_bins:{fft_bins}')
#
#     X_normal = []
#     y_normal = []
#     X_anomaly = []
#     y_anomaly = []
#     for i, value in enumerate(labels):
#         feat = list(features[i])  # (fid, IAT)
#         if feat_set == 'FFT' or feat_set == 'IAT':
#             if len(feat) > fft_bins:
#                 feat = feat[:fft_bins]
#             else:
#                 feat += [0] * (fft_bins - len(feat))
#         else:  # baseline_set
#             # nothing need to do
#             pass
#         if value.upper() in ['NORMAL', 'BENIGN']:
#             X_normal.append(feat)
#             y_normal.append(0)
#         else:
#             X_anomaly.append(feat)
#             y_anomaly.append(1)
#
#     if shuffle_flg:
#         c = list(zip(X_normal, y_normal))
#         shuffle(c, random_state=random_state)
#         X_normal, y_normal = zip(*c)
#
#     X_normal = np.array(list(X_normal), dtype=float)
#     y_normal = np.array(y_normal, dtype=int)
#     X_anomaly = np.array(X_anomaly, dtype=float)
#     y_anomaly = np.array(y_anomaly, dtype=int)
#
#     train_size = len(y_normal) - len(y_anomaly)
#     X_train = X_normal[:train_size, :]
#     y_train = y_normal[:train_size]
#     if len(y_anomaly) == 0:
#         X_test = X_normal[:100, :]
#         y_test = y_normal[:100]
#     else:
#         X_test = np.concatenate([X_normal[train_size:, :], X_anomaly], axis=0)
#         y_test = np.concatenate([y_normal[train_size:], y_anomaly], axis=0)
#
#     return X_train, y_train, X_test, y_test, fft_bins
#


#
#
# def grid_search_cv():
#     Cs = [0.001, 0.01, 0.1, 1, 10]
#     gammas = [0.001, 0.01, 0.1, 1]
#     param_grid = {'C': Cs, 'gamma': gammas}
#     grid_search = GridSearchCV(svm.SVC(kernel='rbf'), param_grid, cv=nfolds)
#     grid_search.fit(X, y)
#
#     return grid_search.best_params_

#
# def main_for_each_feature_set(input_file='', case='', random_state=42, norm_method='std'):
#     """
#
#     :param norm_file:
#     :param anomaly_file:
#     :param test_size:
#     :param random_state:
#     :return:
#     """
#     X_train, y_train, X_test, y_test, fft_bins = load_and_split_data(input_file=input_file, case=case, shuffle_flg=True,
#                                                                      random_state=random_state)
#     print(f'--- train set and test set --'
#           f'\nX_train:{X_train.shape}, y_train:{Counter(y_train)}'
#           f'\nX_test :{X_test.shape}, y_test :{Counter(y_test)}, in which, 0: normals and 1: anomalies.')
#     stat_data(X_train)
#     stat_data(X_test)
#
#     X_train, X_test = normalise_data(X_train, X_test, norm_method=norm_method)
#
#     print('\n3) train and test different models')
#     roc_dict = {}
#     auc_dict = {}
#
#     # gmm = GMMDetector(n_components=3)
#     # gmm.train(X_train)
#     # # dump(pca, 'output_data/models_dumping/gmm_' + case + '.joblib')
#     # # model = load('output_data/models_dumping/gmm_' + case + '.joblib')
#     # gmm.test(X_test, y_test)
#     # roc_dict['gmm'] = {'y_true': y_test, 'y_scores': gmm.y_scores}
#     # auc_dict['gmm']=gmm.auc
#
#     # knn = KNNDetector()
#     # knn.train(X_train)
#     # # dump(pca, 'output_data/models_dumping/knn_' + case + '.joblib')
#     # # model = load('output_data/models_dumping/knn_' + case + '.joblib')
#     # knn.test(X_test, y_test)
#     # roc_dict['knn'] = {'y_true': y_test, 'y_scores': knn.y_scores}
#     # auc_dict['knn'] = knn.auc
#     # knn.visualize(X_train[:,:2], y_train, X_test[:,:2], y_test, knn.knn.predict(X_train), knn.knn.predict(X_test), show_figure=True)
#
#     # pca = PCADetector()
#     # pca.train(X_train)
#     # # dump(pca, 'output_data/models_dumping/pca_' + case + '.joblib')
#     # # model = load('output_data/models_dumping/pca_' + case + '.joblib')
#     # pca.test(X_test, y_test)
#     # roc_dict['pca'] = {'y_true': y_test, 'y_scores': pca.y_scores}
#     # auc_dict['pca'] = pca.auc
#
#     ocsvm = OCSVMDetector()
#     ocsvm.train(X_train)
#     # dump(ocsvm, 'output_data/models_dumping/ocsvm_' + case + '.joblib')
#     # model = load('output_data/models_dumping/ocsvm_' + case + '.joblib')
#     ocsvm.test(X_test, y_test)
#     roc_dict['ocsvm'] = {'y_true': y_test, 'y_scores': ocsvm.y_scores}
#     auc_dict['ocsvm'] = ocsvm.auc
#
#     # iforest = IForestDetector()
#     # iforest.train(X_train)
#     # # dump(ocsvm, 'output_data/models_dumping/iforest_' + case + '.joblib')
#     # # model = load('output_data/models_dumping/iforest_' + case + '.joblib')
#     # iforest.test(X_test, y_test)
#     # roc_dict['iforest'] = {'y_true': y_test, 'y_scores': iforest.y_scores}
#     # auc_dict['iforest'] = iforest.auc
#
#     return roc_dict, auc_dict
#
#
# def seperate_normal_anomaly_file(merged_file=''):
#     with open(merged_file, 'rb') as in_hdl:
#         features, labels = pickle.load(in_hdl)
#
#     return features, labels


#
# def main_for_roc(srcIP, experiment='', data_aug=False, norm_method='none'):
#     """
#         "test_size, random_state and so on", all of them come from _config.py.
#     :return:
#     """
#
#     experi, case = experiment
#
#     feat_set = case.split()[0]
#     if experi == 'demo':
#         files_dict = OrderedDict(
#             {
#                 'proposed_set': f'input_data/data/test.pcap_{feat_set}.dat',
#                 'baseline_set': f'input_data/data/test.pcap_Baseline.dat'
#             })
#     else:
#         files_dict = OrderedDict(
#             {
#                 'proposed_set': f'input_data/CICIDS2017/srcIP_{srcIP}/Friday-WorkingHours/srcIP_{srcIP}.pcap_{feat_set}.dat',
#                 'baseline_set': f'input_data/CICIDS2017/srcIP_{srcIP}/Friday-WorkingHours/srcIP_{srcIP}.pcap_Baseline.dat'
#             })
#         if data_aug:
#             files_aug_dict = OrderedDict(
#                 {
#                     'proposed_set': f'input_data/CICIDS2017/srcIP_{srcIP}/Monday-WorkingHours/srcIP_{srcIP}.pcap_{feat_set}.dat',
#                     'baseline_set': f'input_data/CICIDS2017/srcIP_{srcIP}/Monday-WorkingHours/srcIP_{srcIP}..pcap_Baseline.dat'
#                 })
#             for i, (key, value) in enumerate(files_dict.items()):
#                 files_lst = [value, files_aug_dict[key]]
#                 merged_file = value + '_augmented.dat'
#                 files_dict[key] = merge_multifiles_to_one(files_lst=files_lst, merged_file=merged_file)
#
#     roc_dicts_lst = []
#     auc_dicts_lst = []
#     for idx, (key, file_path) in enumerate(files_dict.items()):
#         print(f'\n{idx}: evaluation on feat_set:{feat_set}, key:{key}')
#
#         roc_dict, auc_dict = main_for_each_feature_set(input_file=file_path, case=case,
#                                                        random_state=random_state,
#                                                        norm_method=norm_method)
#
#         roc_dicts_lst.append([key, roc_dict])
#         auc_dicts_lst.append([key, auc_dict])
#
#     print('\n3: plot roc.')
#     plot_roc(roc_dicts_lst=roc_dicts_lst, title=f'srcIP: {srcIP}, {case}')
#     # plot_auc_and_strength_of_outiler(auc_dicts_lst=auc_dicts_lst)
#
#
# def merge_multifiles_to_one(files_lst=[], output_file=''):
#     # os.chdir("/mydir")
#     # extension = 'csv'
#     # all_filenames = [i for i in glob.glob('*.{}'.format(extension))]
#     # # combine all files in the list
#     # combined_csv = pd.concat([pd.read_csv(f) for f in files_lst])  # different lines
#     # # export to csv
#     # combined_csv.to_csv(output_file, index=False, encoding='utf-8-sig')
#
#     # with open(output_file, 'w') as out_hdl:
#     #     for file in files_lst:
#     #         with open(file, 'r') as in_hdl:
#     #             line = in_hdl.readline()
#     #             while line:
#     #                 out_hdl.write(line)
#     #                 line = in_hdl.readline()
#
#     with open(output_file, 'wb') as out_hdl:
#         # pickle.dump(len(files_lst), out_hdl)
#         for file in files_lst:
#             print(f'file:{file}')
#             with open(file, 'rb') as in_hdl:
#                 fids, features, labels = pickle.load(in_hdl)
#                 pickle.dump((fids, features, labels), out_hdl)
#
#     return output_file


#
# def load_pickled_data(input_file=''):
#     """ Especially for loading multi-objects stored in a file.
#
#     :param input_file:
#     :return:
#     """
#
#     fids = []
#     features = []
#     labels = []
#     with open(input_file, 'rb') as in_hdl:
#         while True:
#             try:
#                 fids_, features_, labels_ = pickle.load(in_hdl)
#                 fids.extend(fids_)
#                 features.extend(features_)
#                 labels.extend(labels_)
#             except EOFError:
#                 break
#     return fids, features, labels

#
# def obtain_fft_bins(features, q=0.9):
#     # with open(v1_file, 'r') as in_hdl:
#     #     line = in_hdl.readline()
#     #     while line:
#     #         arr = line.strip().split(',')
#     #         features.append(arr[:-1])
#     #         line = in_hdl.readline()
#     flows_len_arr = [len(value) for value in features]
#     fft_bins = int(np.quantile(flows_len_arr, q=q))
#     print(f'choose quantile = {q} and get fft_bins: {fft_bins}.')
#     print(f'len(flows_len_arr): {len(flows_len_arr)}, {sorted(set(flows_len_arr))}, {Counter(flows_len_arr)}')
#     stat_data(np.array(flows_len_arr).reshape(-1, 1))
#
#     return fft_bins
#
#
# def obtain_normal_data(pcap_file, label=['Benign']):
#     pcap_file = f'input_data/CICIDS2017/Merged-WorkingHours/5_bots_20170707-09_00-12_00-srcIP_{srcIP}.pcap'
#     dir = os.path.dirname(pcap_file)
#     if not os.path.exists(dir):
#         os.makedirs(dir)
#     if not os.path.exists(pcap_file):
#         # input_file = 'input_data/CICIDS2017/Merged-WorkingHours-Morning_5_bots_20170707-09_40-11_30.pcap'
#         input_file = 'input_data/CICIDS2017/Friday-WorkingHours@5_Bots_SrcIPs-20170707-09_00-12_00.pcap'
#         cmd = f"tshark -r {input_file} -w {pcap_file} ip.src=={srcIP}"
#         print(f'{cmd}')
#         result = subprocess.run(cmd, stdout=subprocess.PIPE, shell=True).stdout.decode('utf-8')


#
# def obtain_file_path(srcIP, feat_set='IAT'):
#     file_path = f'input_data/CICIDS2017/Merged-WorkingHours/5_bots_20170707-09_00-12_00-srcIP_{srcIP}.pcap_{feat_set}.dat'  # (fid, features), label
#     # v1_files = [IAT_file.format(srcIP) for srcIP in srcIP_lst]
#     # v1_megerd_file = IAT_file.format()
#     return file_path


def seperate_normal_anomaly_file(merged_file=''):
    with open(merged_file, 'rb') as in_hdl:
        features, labels = pickle.load(in_hdl)

    return features, labels


def plot_roc_auc(roc_dict_lst, auc_dict_lst, out_file='output_data/figures/roc_of_different_algorithms.pdf',
                 title='ROC'):
    """

    :param roc_list: [[key, roc_dict], [key, roc_dict], ... ]
    :param out_file:
    :param title:
    :return:
    """
    # with plt.style.context(('ggplot')):
    fig, ax = plt.subplots()

    colors_lst = ['r', 'm', 'b', 'g', 'y', 'c', '#0072BD', '#A2142F', '#EDB120', 'k', '#D95319', '#4DBEEE',
                  'C1']  # add more color values: https://www.mathworks.com/help/matlab/ref/plot.html
    # required_colors_num = len(roc_dicts_lst) * len(roc_dicts_lst[0][-1])  # roc_dicts_list[0] = [key, roc_dict]
    # if len(colors_lst) < required_colors_num:
    #     print(
    #         f'the number of colors we has ({len(colors_lst)}) does not meet the required number of colors (required_colors_num).')
    # else:
    #     print(f'required colors number ({required_colors_num}) <= colors number ({len(colors_lst)}).')

    # colors_dict['ocsvm'.upper()] =
    for idx, (feature_set_key, roc_dict) in enumerate(roc_dict_lst):
        # colors_dict[feature_set_key] = {'AE': 'r', 'DT': 'm', 'PCA': 'C1', 'IF': 'b', 'OCSVM': 'g'}
        for i, (key, value_dict) in enumerate(roc_dict.items()):
            key = key.upper()
            y_true = value_dict['y_true']
            y_scores = value_dict['y_scores']
            fpr, tpr, thres = roc_curve(y_true=y_true, y_score=y_scores)
            # IMPORTANT: first argument is true values, second argument is predicted probabilities (i.e., y_scores)
            # auc = "%.5f" % metrics.auc(fpr, tpr)
            auc = f'{metrics.auc(fpr, tpr):.4f}'
            print(f'key={key}:{feature_set_key}, auc={auc}, fpr={fpr}, tpr={tpr}')
            if key == 'PCA':
                lw = 3
            else:
                lw = 2

            ax.plot(fpr, tpr, colors_lst.pop(0), label=f'{feature_set_key}. AUC:{auc}', lw=lw, alpha=1, linestyle='-')

    ax.plot([0, 1], [0, 1], 'k--', label='', alpha=0.9)
    plt.xlim([0.0, 1.0])
    plt.ylim([0., 1.05])
    plt.xlabel('False Positive Rate')
    plt.ylabel('True Positive Rate')
    plt.legend(loc='lower right')

    # title = insert_newlines(title)
    plt.title(title)

    # sub_dir = os.path.split(input_file)[0]
    # output_pre_path = os.path.split(input_file)[-1].split('.')[0]
    # out_file = os.path.join(sub_dir, output_pre_path + '_ROC.pdf')
    print(f'ROC:{out_file}')
    plt.savefig(out_file)  # should use before plt.show()

    plt.show()


def print_values(**kwargs):
    for idx, (key, value) in enumerate(kwargs.items()):
        if idx == len(kwargs.keys()) - 1:
            print(f'{key}: {value}')
        else:
            print(f'{key}: {value}, ', end='')


def main():
    srcIP_lst = ['192.168.10.5', '192.168.10.8', '192.168.10.9', '192.168.10.14', '192.168.10.15']
    fft_bin_lst = [16, 19, 19, 21, 18]  # obtain from pcap2features, quantile = 0.9
    norm_method = 'none'  # none: without normalization, otherwise, 'min-max' or 'std'
    data_aug = False  # data_augmentation: if add more normal flows.
    random_state = 42
    detector_name = 'GMM'  # 'OCSVM', 'GMM'
    print_values(detector_name=detector_name, norm_method=norm_method, data_aug=data_aug, random_state=random_state)

    for idx, (srcIP, fft_bin) in enumerate(zip(srcIP_lst, fft_bin_lst)):
        print(f'\n*index: {idx}, srcIP: {srcIP}, fft_bin: {fft_bin}')

        roc_dict_lst = []
        auc_dict_lst = []

        prop_set = 'IAT'  # IAT or FFT
        prop_file = f'input_data/CICIDS2017/srcIP_{srcIP}/Friday-WorkingHours/srcIP_{srcIP}.pcap_{prop_set}_dimension_{fft_bin}.dat'  # proposed features file
        prop = Experiment(input_file=prop_file, feat_set=prop_set, norm_method=norm_method, random_state=random_state)
        roc_dict, auc_dict = prop.run(detector_name=detector_name,
                                      X_train=prop.X_train, y_train=prop.y_train,
                                      X_test=prop.X_test, y_test=prop.y_test)
        roc_dict_lst.append((prop_set, roc_dict))
        auc_dict_lst.append((prop_set, auc_dict))

        base_set = 'Baseline'
        base_file = f'input_data/CICIDS2017/srcIP_{srcIP}/Friday-WorkingHours/srcIP_{srcIP}.pcap_{base_set}_dimension_10.dat'  # baseline features file
        base = Experiment(input_file=base_file, feat_set=base_set, norm_method=norm_method, random_state=random_state)
        roc_dict, auc_dict = base.run(detector_name=detector_name,
                                      X_train=base.X_train, y_train=base.y_train,
                                      X_test=base.X_test, y_test=base.y_test)
        roc_dict_lst.append((base_set, roc_dict))
        auc_dict_lst.append((base_set, auc_dict))

        print(f'idx: {idx}, srcIP: {srcIP}, auc_lst: {auc_dict_lst}')
        plot_roc_auc(roc_dict_lst, auc_dict_lst, title=f'{detector_name}, srcIP:{srcIP}')

        break


if __name__ == '__main__':
    main()
