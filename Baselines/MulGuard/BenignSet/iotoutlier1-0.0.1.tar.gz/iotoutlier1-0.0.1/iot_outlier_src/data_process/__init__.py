from os import sys, path

sys.path.append(path.dirname(path.dirname(path.abspath(__file__))))
