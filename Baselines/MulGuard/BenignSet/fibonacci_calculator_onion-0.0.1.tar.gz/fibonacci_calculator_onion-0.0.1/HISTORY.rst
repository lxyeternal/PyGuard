=======
History
=======

0.0.1 (2020-12-04)
------------------

* First release on PyPI.
