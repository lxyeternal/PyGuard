=====
Usage
=====

To use Python Fibonacci Calculator Onion in a project::

    import fibonacci_calculator_onion
