"""Top-level package for Python Fibonacci Calculator Onion."""

__author__ = """Maarten Uijen"""
__email__ = 'maarten.uijen@ordina.nl'
__version__ = '0.0.1'
