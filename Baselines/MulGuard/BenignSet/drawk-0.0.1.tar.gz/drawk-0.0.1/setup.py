from setuptools import setup
requires=['pandas','mpl_finance','numpy','matplotlib']
setup(name='drawk',
      version='0.0.1',
      description='drak k .',
      url='https://github.com/jungamer/drawk',
      author='jungamer',
      author_email='624621566@qq.com',
      license='MIT',
      packages=['drawk'],
      install_requires=requires,
      zip_safe=False)

