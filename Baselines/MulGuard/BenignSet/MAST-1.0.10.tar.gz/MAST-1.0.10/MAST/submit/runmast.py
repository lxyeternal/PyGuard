#!/usr/bin/env python
##############################################################
# This code is part of the MAterials Simulation Toolkit (MAST)
# 
# Maintainer: Tam Mayeshiba
# Last updated: 2014-04-25
##############################################################
from MAST.mastmon import MASTmon

mastmon = MASTmon()
#mastmon.run(1) #Use 0 for non-verbose
