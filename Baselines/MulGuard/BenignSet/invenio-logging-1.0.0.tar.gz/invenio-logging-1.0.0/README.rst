..
    This file is part of Invenio.
    Copyright (C) 2015-2018 CERN.

    Invenio is free software; you can redistribute it and/or modify it
    under the terms of the MIT License; see LICENSE file for more details.

=================
 Invenio-Logging
=================

.. image:: https://img.shields.io/travis/inveniosoftware/invenio-logging.svg
        :target: https://travis-ci.org/inveniosoftware/invenio-logging

.. image:: https://img.shields.io/coveralls/inveniosoftware/invenio-logging.svg
        :target: https://coveralls.io/r/inveniosoftware/invenio-logging

.. image:: https://img.shields.io/pypi/v/invenio-logging.svg
        :target: https://pypi.org/pypi/invenio-logging


Invenio-Logging is a core component of Invenio responsible for configuring
the Flask application logger.

Further documentation at: https://invenio-logging.readthedocs.io/
