..
    This file is part of Invenio.
    Copyright (C) 2015-2018 CERN.

    Invenio is free software; you can redistribute it and/or modify it
    under the terms of the MIT License; see LICENSE file for more details.

API Docs
========

Console
-------

.. automodule:: invenio_logging.console
   :members:

File System
-----------

.. automodule:: invenio_logging.fs
   :members:

Sentry
------

.. automodule:: invenio_logging.sentry6
   :members:

.. automodule:: invenio_logging.sentry
   :members:
