"""
█▓▒▒░░░ discord-interactions-styled ░░░▒▒▓█

Simple set of tools to write easier code using discord-py-interactions

copyright: (c) 2021-present gammx
license: MIT
"""

from . import slash
from . import permissions
from . import buttons