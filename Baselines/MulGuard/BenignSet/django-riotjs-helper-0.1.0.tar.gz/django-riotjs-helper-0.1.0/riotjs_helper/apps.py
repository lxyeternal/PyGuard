from django.apps import AppConfig


class RiotjsHelperConfig(AppConfig):
    name = 'riotjs_helper'
