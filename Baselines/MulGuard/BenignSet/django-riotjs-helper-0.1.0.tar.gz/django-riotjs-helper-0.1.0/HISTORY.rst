.. :changelog:

History
-------

0.1.0 (2018-09-23)
++++++++++++++++++

* First release on PyPI.
