# FRAKE
Frake is a set of functions for visualizing results from Anura3D simulations. Currently, FRAKE reads an A3D folder and orders the outputs files in a special variable type. There are mainly plotting functions, but in the future, the plan is to add a python preprocessing, processing monitoring, and postprocessing for Anura3D.
