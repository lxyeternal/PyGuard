from multiprocessing import cpu_count

from mpire.pool import tqdm, WorkerPool
