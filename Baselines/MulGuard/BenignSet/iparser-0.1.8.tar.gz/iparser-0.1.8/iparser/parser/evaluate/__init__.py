# -*- coding:utf-8 -*-
# Filename: __init__.py.py
# Author：hankcs
# Date: 2018-02-28 12:28
from .evaluate import evaluate_official_script
