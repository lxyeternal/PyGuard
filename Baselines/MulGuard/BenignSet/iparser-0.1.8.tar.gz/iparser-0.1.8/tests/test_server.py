# -*- coding:utf-8 -*-
# Filename: test_server.py
# Author：hankcs
# Date: 2018-03-04 下午4:28
from iparser.server import run

if __name__ == '__main__':
    run()
