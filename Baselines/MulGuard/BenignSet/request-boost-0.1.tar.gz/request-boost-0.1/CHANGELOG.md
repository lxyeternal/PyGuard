CHANGE LOG
==============================

0.1 (16/09/2021)
------------------------
- Released first version(stable) of request-boost.