import lovely-logger as log
log.init('test.log')
log.i('test')
