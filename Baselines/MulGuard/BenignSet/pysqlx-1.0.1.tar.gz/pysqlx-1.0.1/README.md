# pysqlx

![Publish](https://github.com/pysqlx/pysqlx/workflows/Publish/badge.svg)
![Test](https://github.com/pysqlx/pysqlx/workflows/Test/badge.svg)
[![Downloads](https://static.pepy.tech/personalized-badge/pysqlx?period=week&units=international_system&left_color=black&right_color=orange&left_text=Last%20Week)](https://pepy.tech/project/pysqlx)
[![Downloads](https://static.pepy.tech/personalized-badge/pysqlx?period=month&units=international_system&left_color=black&right_color=orange&left_text=Month)](https://pepy.tech/project/pysqlx)
[![Downloads](https://static.pepy.tech/personalized-badge/pysqlx?period=total&units=international_system&left_color=black&right_color=orange&left_text=Total)](https://pepy.tech/project/pysqlx)

## Introduction

A generic SQL driver package.

## Install

    pip install pysqlx

## Usage

## Known Issues and Limitations (KIL)

## Notes
