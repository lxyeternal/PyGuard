"""Common configuration constants
"""

PROJECTNAME = 'collective.ots'

ADD_PERMISSIONS = {
    # -*- extra stuff goes here -*-
}
