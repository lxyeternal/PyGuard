def someFunction():
	return True
