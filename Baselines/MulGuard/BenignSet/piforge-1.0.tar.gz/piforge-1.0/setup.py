from setuptools import setup

setup (name='piforge',
	version='1.0',
	description='iforge for rPi server component',
	url='',
	author='Trevor Shaw',
	author_email='shawt@genlrn.com',
	license='MIT',
	packages=['piforge'],
	zip_safe=False)
