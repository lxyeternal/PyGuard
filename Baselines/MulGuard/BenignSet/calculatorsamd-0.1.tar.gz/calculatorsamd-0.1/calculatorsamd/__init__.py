def add_num(a,b):
    return(a+b)

def sub_num(a,b):
    return(a-b)

def mul_num(a,b):
    return(a*b)
    
def div_num(a,b):
    return(a/b)