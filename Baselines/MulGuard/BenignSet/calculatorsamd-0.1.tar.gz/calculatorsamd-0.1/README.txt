This is a very basic calculator for addition,subtraction,multiplication and division.
The commands are operation_num(a,b).
operations== add_num(a,b)
    sub_num(a,b)
    mul_num(a,b)
    div_num(a,b)