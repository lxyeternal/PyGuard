import setuptools
setuptools.setup(
 name='calculatorsamd', 
 version='0.1',
 author="Aadil Nazir",
 author_email="daraadi4@gmail.com",
 description="very basic calculator",
 packages=setuptools.find_packages(),
 classifiers=[
 "Programming Language :: Python :: 3",
 "License :: OSI Approved :: MIT License",
 "Operating System :: OS Independent",
 ],
)