Release Notes
-------------

**1.0.0 (2018-04-12)**

* Initial release
