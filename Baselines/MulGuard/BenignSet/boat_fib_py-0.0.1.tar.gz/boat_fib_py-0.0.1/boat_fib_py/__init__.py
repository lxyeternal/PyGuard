def say_hello() -> None:
    print("the boat Fib module is saying hello")