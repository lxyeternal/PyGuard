# pyjoepegs

python api client for [joepegs](https://joepegs.dev/api)

## Install 

```bash
pip install pyjoepegs
```

## Quick start

```
TO BE ADDED
```
