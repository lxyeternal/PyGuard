"""
Constants of services that can be discovered.
"""

BELKIN_WEMO = "belkin_wemo"
DLNA = "DLNA"
GOOGLE_CAST = "google_cast"
PHILIPS_HUE = "philips_hue"
