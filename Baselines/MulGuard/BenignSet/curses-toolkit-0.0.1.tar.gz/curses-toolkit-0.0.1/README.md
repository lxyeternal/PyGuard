# curses-toolkit [![pipeline status](https://gitlab.com/OldIronHorse/curses-toolkit/badges/main/pipeline.svg)](https://gitlab.com/OldIronHorse/curses-toolkit/-/commits/main)  [![coverage report](https://gitlab.com/OldIronHorse/curses-toolkit/badges/main/coverage.svg)](https://gitlab.com/OldIronHorse/curses-toolkit/-/commits/main)  [![Latest Release](https://gitlab.com/OldIronHorse/curses-toolkit/-/badges/release.svg)](https://gitlab.com/OldIronHorse/curses-toolkit/-/releases)


Some simple UI elements for curses TUIs

## Installation

```
% pip install curses-toolkit
```

## Usage
