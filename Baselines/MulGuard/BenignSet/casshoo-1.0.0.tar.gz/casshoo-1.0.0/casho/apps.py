from django.apps import AppConfig


class MyAppConfiguration(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'casho.casho'
