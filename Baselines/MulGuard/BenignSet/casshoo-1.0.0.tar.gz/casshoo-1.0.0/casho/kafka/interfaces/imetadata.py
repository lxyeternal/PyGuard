class IMetadata:
    def __init__(self, topic: str):
        self.topic = topic
