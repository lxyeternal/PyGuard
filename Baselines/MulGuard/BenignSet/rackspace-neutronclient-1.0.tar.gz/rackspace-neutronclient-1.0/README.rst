=======================
rackspace-neutronclient
=======================


Metapackage to install rackspace-python-neutronclient and Rackspace extensions


Install
=======

::

  pip install rackspace-neutronclient


Usage
=====

This metapackage will ensure that rackspace-python-neutronclient and these
extensions are installed that are compatible with the Rackspace cloud:

- rackspace-auth-neutronclientext
