from setuptools import setup
from setuptools.command.install import install
import subprocess, os, sys


class CustomInstallCommand(install):
	"""Customized setuptools install command - prints a friendly greeting."""
	def run(self):
		print("Running bgpstreamm install script")
		
		#process = subprocess.Popen(["sudo sh bgpstream_install.sh"], shell=True)
		#process.wait()
		print("bgpstreamm install done")
		
		process = subprocess.Popen(["pip install Cython cmake"], shell=True)
		process.wait()
		
		process = subprocess.Popen(["pip install -r requirements.txt"], shell=True)
		process.wait()

		install.run(self)

setup(
	name='BML-bgp',
	version='1.0',
	author='Kevin Hoarau',
	author_email='kevin.hoarau@univ-reunion.fr',
	packages=['BML'],
	description='BML: An Efficient and Versatile Tool for BGP Dataset Collection',
    cmdclass={
        'install': CustomInstallCommand,
    })