co<i>py</i><b>AI</b>d
=====================

Perform copyediting and proofreading with the OpenAI (GPT) API from the command line.

Visit [copyaid.it](https://copyaid.it) for documentation.

Documentation is built from the `copyaid.it` branch.
