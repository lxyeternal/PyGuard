# AVSS - A Very Simple web-Server
Objective: Deploy a python-web app with minimal effort.

## How-to
```
$ pip install avss
$ sudo webserver init
```
This places config in: /etc/avss

