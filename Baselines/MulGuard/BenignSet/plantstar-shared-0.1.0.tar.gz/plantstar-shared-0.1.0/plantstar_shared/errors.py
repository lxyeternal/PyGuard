class InvalidApiRequest(Exception):
    pass


class SysconProgrammingError(Exception):
    pass
