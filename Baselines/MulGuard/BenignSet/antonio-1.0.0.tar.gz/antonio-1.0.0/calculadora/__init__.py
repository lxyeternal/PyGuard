from .calculos import somar, multiplicar

__all__ = ["somar", "multiplicar"]
