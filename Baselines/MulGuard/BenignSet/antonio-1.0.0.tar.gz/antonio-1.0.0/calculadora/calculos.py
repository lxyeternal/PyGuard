def somar(numero1: int, numero2: int) -> int:
    return numero1 + numero2


def multiplicar(numero1: int, numero2: int) -> int:
    return numero1 * numero2
