from setuptools import setup

setup(
    name='c4-junitxml',
    description='c4.junitxml',
    author='QA Automation',
    version='0.0.1',
    packages=['c4.junitxml'],
    classifiers=['Programming Language :: Python :: 3'],
)
