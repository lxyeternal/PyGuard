"""
JUnit XML handling for C4 test automation framework

    import c4.junitxml
"""

print("Placeholder for c4.junitxml project to be opensourced soon")
