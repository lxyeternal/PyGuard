__version__ = '0.1.0'

from .qdrant_client import QdrantClient
