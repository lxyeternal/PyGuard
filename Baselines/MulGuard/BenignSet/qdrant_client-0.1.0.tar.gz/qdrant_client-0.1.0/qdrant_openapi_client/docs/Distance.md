# Distance

Type of internal tags, build from payload Distance function types used to compare vectors
## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**value** | **str** | Type of internal tags, build from payload Distance function types used to compare vectors |  must be one of ["Cosine", "Euclid", "Dot", ]

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


