# UpdateResult

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**operation_id** | **int** | Sequential number of the operation | 
**status** | [**UpdateStatus**](UpdateStatus.md) |  | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


