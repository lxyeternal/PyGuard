# PointStruct

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **int** | Point id | 
**vector** | **[float]** | Vector | 
**payload** | [**{str: (PayloadInterface,)}, none_type**](PayloadInterface.md) | Payload values (optional) | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


