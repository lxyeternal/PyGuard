# AliasOperationsAnyOf

Create alternative name for a collection. Collection will be available under both names for search, retrieve,
## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**create_alias** | [**AliasOperationsAnyOfCreateAlias**](AliasOperationsAnyOfCreateAlias.md) |  | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


