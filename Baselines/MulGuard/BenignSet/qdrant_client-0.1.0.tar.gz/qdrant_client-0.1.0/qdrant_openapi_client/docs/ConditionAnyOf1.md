# ConditionAnyOf1

Check if point has field with a given value
## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**match** | [**Match**](Match.md) |  | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


