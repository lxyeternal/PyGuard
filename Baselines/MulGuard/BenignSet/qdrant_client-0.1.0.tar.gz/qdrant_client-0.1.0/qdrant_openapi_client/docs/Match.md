# Match

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**key** | **str** | Name of the field to match with | 
**integer** | **int, none_type** | Integer value to match | [optional] 
**keyword** | **str, none_type** | Keyword value to match | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


