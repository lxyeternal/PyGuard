# StorageOpsAnyOf

Create new collection and (optionally) specify index params
## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**create_collection** | [**StorageOpsAnyOfCreateCollection**](StorageOpsAnyOfCreateCollection.md) |  | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


