# SearchParamsAnyOfHnsw

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**ef** | **int** | Size of the beam in a beam-search. Larger the value - more accurate the result, more time required for search. | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


