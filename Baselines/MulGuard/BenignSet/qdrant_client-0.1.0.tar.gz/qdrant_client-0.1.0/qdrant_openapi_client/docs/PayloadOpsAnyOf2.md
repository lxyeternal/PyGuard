# PayloadOpsAnyOf2

Drops all Payload values associated with given points.
## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**clear_payload** | [**PayloadOpsAnyOf2ClearPayload**](PayloadOpsAnyOf2ClearPayload.md) |  | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


