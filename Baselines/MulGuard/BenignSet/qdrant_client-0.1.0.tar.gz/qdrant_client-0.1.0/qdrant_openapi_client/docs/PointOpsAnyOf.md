# PointOpsAnyOf

Insert or update points
## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**upsert_points** | [**PointInsertOps**](PointInsertOps.md) |  | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


