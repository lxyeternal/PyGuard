# ConditionAnyOf3

Check if points geo location lies in a given area
## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**geo_bounding_box** | [**GeoBoundingBox**](GeoBoundingBox.md) |  | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


