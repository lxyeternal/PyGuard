# IndexesAnyOf1Options

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**ef_construct** | **int** | Number of neighbours to consider during the index building. Larger the value - more accurate the search, more time required to build index. | 
**m** | **int** | Number of edges per node in the index graph. Larger the value - more accurate the search, more space required. | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


