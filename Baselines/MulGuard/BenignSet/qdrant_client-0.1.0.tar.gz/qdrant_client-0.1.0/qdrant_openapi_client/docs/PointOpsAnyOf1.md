# PointOpsAnyOf1

Delete point if exists
## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**delete_points** | [**PointOpsAnyOf1DeletePoints**](PointOpsAnyOf1DeletePoints.md) |  | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


