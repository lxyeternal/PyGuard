# PayloadOpsAnyOf

Set payload value, overrides if it is already exists
## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**set_payload** | [**PayloadOpsAnyOfSetPayload**](PayloadOpsAnyOfSetPayload.md) |  | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


