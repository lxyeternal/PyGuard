# PayloadOpsAnyOf1DeletePayload

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**keys** | **[str]** |  | 
**points** | **[int]** | Deletes values from each point in this list | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


