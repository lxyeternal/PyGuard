# Range

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**key** | **str** | Name of the field to match with | 
**gt** | **float, none_type** | point.key &gt; range.gt | [optional] 
**gte** | **float, none_type** | point.key &gt;&#x3D; range.gte | [optional] 
**lt** | **float, none_type** | point.key &lt; range.lt | [optional] 
**lte** | **float, none_type** | point.key &lt;&#x3D; range.lte | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


