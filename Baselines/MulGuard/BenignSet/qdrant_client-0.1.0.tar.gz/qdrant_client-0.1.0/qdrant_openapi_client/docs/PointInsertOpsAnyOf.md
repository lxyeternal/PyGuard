# PointInsertOpsAnyOf

Inset points from a batch.
## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**batch** | [**PointInsertOpsAnyOfBatch**](PointInsertOpsAnyOfBatch.md) |  | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


