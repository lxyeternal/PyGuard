# GeoRadius

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**center** | [**GeoPoint**](GeoPoint.md) |  | 
**key** | **str** | Name of the field to match with | 
**radius** | **float** | Radius of the area in meters | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


