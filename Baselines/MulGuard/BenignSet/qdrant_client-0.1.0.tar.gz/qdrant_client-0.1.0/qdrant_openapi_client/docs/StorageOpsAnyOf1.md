# StorageOpsAnyOf1

Delete collection with given name
## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**delete_collection** | **str** |  | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


