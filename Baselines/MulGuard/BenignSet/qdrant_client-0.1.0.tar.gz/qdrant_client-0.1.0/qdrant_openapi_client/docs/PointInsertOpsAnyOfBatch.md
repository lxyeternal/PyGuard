# PointInsertOpsAnyOfBatch

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**ids** | **[int]** |  | 
**vectors** | **[[float]]** |  | 
**payloads** | [**[{str: (PayloadInterface,)}, none_type], none_type**](PayloadInterface.md) |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


