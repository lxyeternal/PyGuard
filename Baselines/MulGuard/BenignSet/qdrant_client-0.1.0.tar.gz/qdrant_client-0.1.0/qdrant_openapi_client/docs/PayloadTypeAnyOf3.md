# PayloadTypeAnyOf3

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**value** | [**[GeoPoint]**](GeoPoint.md) |  | 
**type** | **str** |  | defaults to "geo"

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


