# GeoBoundingBox

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**bottom_right** | [**GeoPoint**](GeoPoint.md) |  | 
**key** | **str** | Name of the field to match with | 
**top_left** | [**GeoPoint**](GeoPoint.md) |  | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


