# PayloadOpsAnyOf1

Deletes specified payload values if they are assigned
## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**delete_payload** | [**PayloadOpsAnyOf1DeletePayload**](PayloadOpsAnyOf1DeletePayload.md) |  | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


