# PayloadTypeAnyOf

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**value** | **[str]** |  | 
**type** | **str** |  | defaults to "keyword"

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


