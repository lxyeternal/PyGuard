# AliasOperationsAnyOf2

Change alias to a new one
## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**rename_alias** | [**AliasOperationsAnyOf2RenameAlias**](AliasOperationsAnyOf2RenameAlias.md) |  | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


