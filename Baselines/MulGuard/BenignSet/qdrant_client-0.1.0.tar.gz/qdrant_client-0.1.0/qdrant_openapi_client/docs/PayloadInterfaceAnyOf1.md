# PayloadInterfaceAnyOf1

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**value** | [**PayloadVariantForInt64**](PayloadVariantForInt64.md) |  | 
**type** | **str** |  | defaults to "integer"

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


