# Filter

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**must** | [**[Condition], none_type**](Condition.md) | All conditions must match | [optional] 
**must_not** | [**[Condition], none_type**](Condition.md) | All conditions must NOT match | [optional] 
**should** | [**[Condition], none_type**](Condition.md) | At least one of thous conditions should match | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


