# PayloadOpsAnyOfSetPayload

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**payload** | [**{str: (PayloadInterface,)}**](PayloadInterface.md) |  | 
**points** | **[int]** | Assigns payload to each point in this list | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


