# SegmentConfig

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**distance** | [**Distance**](Distance.md) |  | 
**index** | [**Indexes**](Indexes.md) |  | 
**storage_type** | [**StorageType**](StorageType.md) |  | 
**vector_size** | **int** | Size of a vectors used | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


