# StorageTypeAnyOf1

Use memmap to store vectors, a little slower than `InMemory`, but requires little RAM
## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**type** | **str** |  | defaults to "mmap"

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


