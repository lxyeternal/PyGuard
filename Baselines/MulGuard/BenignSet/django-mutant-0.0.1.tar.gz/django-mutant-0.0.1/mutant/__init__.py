import logging

__version__ = VERSION = (0, 0, 1)

logger = logging.getLogger('mutant')
