
from mutant.contrib.boolean.tests import *
from mutant.contrib.datetime.tests import *
from mutant.contrib.file.tests import *
from mutant.contrib.numeric.tests import *
from mutant.contrib.related.tests import *
from mutant.contrib.text.tests import *
from mutant.contrib.web.tests import *
