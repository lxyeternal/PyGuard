
from django.conf import settings

MIXINS_CLASSES = getattr(settings, 'mutant_MIXINS_CLASSES', ())