
from django.core.exceptions import ValidationError

class ObsoleteDefinitionError(ValidationError):
    pass