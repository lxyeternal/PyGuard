'''
This is a math Module
Do Some thing
'''


def add(a=0, b=0):
    return a + b;


def minus(a=0, b=0):
    return a - b;


def multy(a=1, b=1):
    return a * b;

