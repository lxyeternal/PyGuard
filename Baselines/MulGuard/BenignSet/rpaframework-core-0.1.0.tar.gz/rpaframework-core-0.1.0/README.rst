rpaframework-core
=================

This package is a set of core functionality and utilities used
by `RPA Framework`_. It is not intended to be installed directly, but
as a dependency to other projects.

.. _RPA Framework: https://rpaframework.org
