# PurePress

**PurePress** is a very simple static blog generator.
