SITE_INFO = {
    "title": "My Blog",
    "subtitle": "Here is my blog.",
    "author": "My Name",
    "timezone": "Asia/Shanghai",
}
POSTS_PER_PAGE_ON_INDEX = 5
