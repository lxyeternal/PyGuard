# hlp

Python help from the command-line.

# Features

* Autocomplete
* Type fewer characters compared to `python -c "import ...; help(...)"`
