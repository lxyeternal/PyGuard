This is a basic device factory for aws
