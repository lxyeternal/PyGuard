# Changelog

## 0.0.1 (Unreleased)

Initial release of pypsexec, it contains the following features

* INSERT FEATURES HERE
