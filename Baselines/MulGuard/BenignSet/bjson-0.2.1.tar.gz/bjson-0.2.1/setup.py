from setuptools import setup

setup(
    name='bjson',
    version='0.2.1',
    description='Alternative way to send Python3 object by binary.',
    author='namuyan',
    author_email='thhjuu@yahoo.co.jp',
    url='https://github.com/namuyan/bin-json',
    py_modules=['bjson'],
    license="MIT"
)