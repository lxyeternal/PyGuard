:github_url: https://github.com/tasts-robots/qpmpc/tree/main/doc/src/installation.rst

************
Installation
************

.. code:: bash

    pip install qpmpc
