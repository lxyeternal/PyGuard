import os

def readSshConfig(path=os.path.expanduser('~/.ssh/config')):
    return None
