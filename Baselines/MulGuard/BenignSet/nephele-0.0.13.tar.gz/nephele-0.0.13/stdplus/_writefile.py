def writefile(filename,contents):
    f = open(filename,'w')
    f.write(contents)
    f.close()
