class SilentException(Exception):
    def __init__(self):
        Exception.__init__(self)
