WRONG_TYPE: str = 'StrictSmartWrapper prohibits getting values ' \
                  'whose types are different from one it was bound to.'
WRONG_DIMENSION: str = 'Dimensions must be >= 1'
