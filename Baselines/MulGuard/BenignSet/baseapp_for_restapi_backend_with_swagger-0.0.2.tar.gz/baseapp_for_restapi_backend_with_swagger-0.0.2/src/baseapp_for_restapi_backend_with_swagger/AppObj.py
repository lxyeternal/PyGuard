

class AppObj():
  def ttt(self):
    print('Hello World')

