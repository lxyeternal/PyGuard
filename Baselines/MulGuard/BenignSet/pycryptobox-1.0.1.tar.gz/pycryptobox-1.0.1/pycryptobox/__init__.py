from .decryption import decrypt_file, decrypt_dir
from .encryption import encrypt_dir, encrpt_file

__version__ = '1.0.0'
