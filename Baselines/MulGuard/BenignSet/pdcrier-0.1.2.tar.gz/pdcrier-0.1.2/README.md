# pdcrier

Create PagerDuty alerts from the command line.

## Dependencies

- `pdpyras`
- `pyyaml`