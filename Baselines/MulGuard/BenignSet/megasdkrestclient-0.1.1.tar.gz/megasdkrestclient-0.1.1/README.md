# MegaSDKRestClient
A Python wrapper for my [megasdkrest](https://github.com/jaskaranSM/megasdkrest) project