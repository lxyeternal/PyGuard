# Example Package

This is a simple client API for SlideTemplater.com