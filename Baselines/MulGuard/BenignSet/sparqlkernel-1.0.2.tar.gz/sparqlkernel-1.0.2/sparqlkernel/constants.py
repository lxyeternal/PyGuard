
__version__ = '1.0.2'

KERNEL_NAME = 'sparql'
LANGUAGE = 'sparql'
DISPLAY_NAME= 'SPARQL'

DEFAULT_TEXT_LANG = [ 'en', 'es', 'fr', 'de', 'it' ]
