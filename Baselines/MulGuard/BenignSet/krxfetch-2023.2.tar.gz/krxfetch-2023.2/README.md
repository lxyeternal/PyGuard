# KRXFetch

KRXFetch is a core library for scraping financial data from the KRX(Korea Exchange) Market Data System.
