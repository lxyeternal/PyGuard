# -*- coding: utf-8 -*-
from __future__ import absolute_import
from solidspy.solids_GUI import solids_GUI

solids_GUI()