=======
Credits
=======

Principal developers
--------------------

* Nicolas Guarin-Zapata (`@nicoguaro`)
* Juan Gómez (`@jgomezc1`)


Contributions
-------------

* Edward Villegas Pulgarin (`@cosmoscalibur`)
* Guillaume Huet (`@guillaumehuet`)
* Marc Gehring (`mg494`)


