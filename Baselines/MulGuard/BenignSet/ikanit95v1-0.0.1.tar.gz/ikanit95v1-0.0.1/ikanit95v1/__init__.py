from ikanit95v1.pyoopbyikanit95 import Vehicle
from ikanit95v1.pyoopbyikanit95 import ElectricVehicle

