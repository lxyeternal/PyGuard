filename = 'testaviread.avi'
import movies
avi = movies.Avi(filename)
