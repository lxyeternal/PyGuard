"""Ctrax

The Caltech Multiple Fly Tracker.

Caltech ethomics project, 2007-2008
"""

from Ctrax import main, CtraxApp, __version__
