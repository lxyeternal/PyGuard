__version__ = "0.1"

DEBUG = False
