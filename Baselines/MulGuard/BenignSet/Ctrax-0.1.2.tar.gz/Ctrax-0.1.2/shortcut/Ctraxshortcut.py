# Ctraxshortcut.py
# KMB 11/06/2008

from Ctrax import main

main()
