#!/usr/bin/env python
# setup.py
# KMB 11/06/2008

from distutils.core import setup

setup(name='CtraxShortcut',
      py_modules=['Ctraxshortcut'],
      scripts=['Ctraxpostinstall.py'],
      )
