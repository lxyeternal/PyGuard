function printmatrix(M)

fprintf('[');
disp(M);
fprintf(']');