%% define special character codes for use with get current character
CHARS.LEFTARROW = 28;
CHARS.RIGHTARROW = 29;
CHARS.UPARROW = 30;
CHARS.DOWNARROW = 31;
CHARS.ENTER = 13;
CHARS.BACKSPACE = 8;
CHARS.TAB = 9;