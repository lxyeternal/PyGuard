# chi-square-saranya
It takes a dataframe with categorical columns for input as well as output , input categorical column, output categorical column

## Installation
```pip install chi-square-saranya```

## How to use it?
Use this function in your chi-square dataset chi_squ(dataframe,input_column,output_column)

## License

© 2021 Saranya Sekar

This repository is licensed under the MIT license. See LICENSE for details.
