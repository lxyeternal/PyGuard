from simplecmr import utils
from simplecmr.query import Query
