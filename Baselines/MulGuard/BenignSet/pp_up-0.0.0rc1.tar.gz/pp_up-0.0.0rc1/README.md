pp-up
=====

Overview
--------
Script to update your dependencies by checking if there are new versions
available on pypi.
