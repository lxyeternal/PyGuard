def sum_it(a , b):
    return a + b