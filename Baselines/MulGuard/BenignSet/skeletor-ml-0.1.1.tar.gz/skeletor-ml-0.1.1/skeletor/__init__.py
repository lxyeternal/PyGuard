"""Top-level structure for skeletor """
name = 'skeletor-ml'

from .launcher import supply_args, execute
