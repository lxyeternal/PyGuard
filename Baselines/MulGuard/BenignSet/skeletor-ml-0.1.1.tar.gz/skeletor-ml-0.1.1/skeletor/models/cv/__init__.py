""" cv package init """
from . import resnet
from . import vgg
