# -*- coding: utf-8 -*-
"""Unit test package for ce_detector."""
