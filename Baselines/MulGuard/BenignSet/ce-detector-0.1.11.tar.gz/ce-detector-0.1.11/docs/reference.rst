Reference
=========

.. contents::
   :local:
   :backlinks: none

ce_detector.detector
--------------------

.. automodule:: ce_detector.detector
   :members:

ce_detector.annotator
---------------------

.. automodule:: ce_detector.annotator
   :members:

ce_detector.scanner
-------------------

.. automodule:: ce_detector.scanner
   :members:
