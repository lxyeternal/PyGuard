=====
Usage
=====

.. click:: ce_detector.cli:cli
   :prog: cli
   :nested: full
