# pymugi
A pure python3 implementation of Hitachi's MUGI PRNG

Based upon: http://www.hitachi.com/rd/yrl/crypto/mugi/mugi_spe.pdf
