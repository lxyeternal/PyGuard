
__title__ = 'hallgrim'
__version__ = '0.3.2'
__author__ = 'Jan Maximilian Michal'
__license__ = 'MIT'
__copyright__ = 'Copyright 2016 Jan Maximilian Michal'

# for the executable
from .hallgrim import parseme
