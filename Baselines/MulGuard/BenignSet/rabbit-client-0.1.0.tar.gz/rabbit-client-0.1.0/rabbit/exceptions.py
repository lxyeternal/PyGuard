class AttributeNotInitialized(Exception):
    pass


class OperationError(Exception):
    pass
