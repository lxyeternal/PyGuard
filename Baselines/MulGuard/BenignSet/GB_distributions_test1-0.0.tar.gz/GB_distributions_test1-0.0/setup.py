from setuptools import setup

setup(name='GB_distributions_test1',
      version='0.0',
      description='Gaussian and Bionomial distributions',
      packages=['GB_distributions_test1'],
      author = 'Ayyoub Rezaeian',
      author_email = 'ayyoub.rezaeian@gmail.com',
      zip_safe=False)
