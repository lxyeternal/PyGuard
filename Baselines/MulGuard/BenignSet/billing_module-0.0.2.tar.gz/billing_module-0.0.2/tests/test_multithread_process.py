import unittest


class TestsThreadBillingProcess(unittest.TestCase):

    def test_thread_make_invoices(self):
        pass
