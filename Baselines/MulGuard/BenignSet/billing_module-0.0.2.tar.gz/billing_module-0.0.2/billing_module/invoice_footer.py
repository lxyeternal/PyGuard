class InvoiceFooter:

    def __init__(self, total, vat_total):
        self.total = total
        self.vat_total = vat_total
