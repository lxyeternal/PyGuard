class CreditNoteFooter:

    def __init__(self, total):
        self.total = total
