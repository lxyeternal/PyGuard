class Client:

    def __init__(self, client_number, address, tax_condition, identity_type, identity_number):
        self.client_number = client_number
        self.address = address
        self.tax_condition = tax_condition
        self.identity_type = identity_type
        self.identity_number = identity_number
