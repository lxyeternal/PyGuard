
# version of comotion-sdk. Used for doc building and code building.
__version__ = '0.0.4'
__projectname__ = 'comotion-sdk'
__author__ = "Tim Vieyra"
