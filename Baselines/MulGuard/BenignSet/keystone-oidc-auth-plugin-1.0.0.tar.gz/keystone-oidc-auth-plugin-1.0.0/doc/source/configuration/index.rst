=============
Configuration
=============

Configuration of keystone-oidc-auth-plugin.
