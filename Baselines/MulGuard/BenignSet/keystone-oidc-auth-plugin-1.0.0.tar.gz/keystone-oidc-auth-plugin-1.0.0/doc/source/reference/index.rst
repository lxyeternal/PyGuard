==========
References
==========

References of keystone-oidc-auth-plugin.
