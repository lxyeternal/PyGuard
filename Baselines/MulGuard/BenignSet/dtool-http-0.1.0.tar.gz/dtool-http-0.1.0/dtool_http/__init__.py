"""dtool_http package."""

import logging

__version__ = "0.1.0"

logger = logging.getLogger(__name__)
