'''Simple library to check if a hostname belongs to AWS IP space.'''

__version__ = '0.0.11'
