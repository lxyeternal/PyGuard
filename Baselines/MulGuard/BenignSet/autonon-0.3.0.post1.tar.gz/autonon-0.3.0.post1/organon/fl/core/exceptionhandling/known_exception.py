"""
This module keeps KnownException class.
"""


class KnownException(Exception):
    """
    Inherits from Exception class for customizing exceptions.
    """
