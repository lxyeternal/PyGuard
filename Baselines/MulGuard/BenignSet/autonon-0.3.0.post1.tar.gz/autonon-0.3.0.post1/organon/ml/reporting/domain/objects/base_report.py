"""Includes BaseReport class."""


class BaseReport:
    """Base class for reports of all modelling types"""
