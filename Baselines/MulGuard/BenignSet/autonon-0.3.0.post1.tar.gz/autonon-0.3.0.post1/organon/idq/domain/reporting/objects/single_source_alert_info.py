"""Includes SingleSourceAlertInfo class"""
from organon.idq.domain.reporting.objects.base_alert_info import BaseAlertInfo


class SingleSourceAlertInfo(BaseAlertInfo):
    """Alert Info for SingleSource """
