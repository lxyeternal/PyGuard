"""todo"""


class StatsOutputService:
    """todo"""

    def write_table_stats(self):
        """todo"""

    def write_sample_stats(self):
        """todo"""

    def write_population_stats(self):
        """todo"""
