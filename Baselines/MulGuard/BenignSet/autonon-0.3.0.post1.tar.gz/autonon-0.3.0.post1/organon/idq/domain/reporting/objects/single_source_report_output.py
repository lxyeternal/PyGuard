"""Includes SingleSourceOutputReport class."""
from organon.idq.domain.reporting.objects.base_dq_output_report import BaseDqOutputReport


class SingleSourceOutputReport(BaseDqOutputReport):
    """Output report for DQ execution."""
