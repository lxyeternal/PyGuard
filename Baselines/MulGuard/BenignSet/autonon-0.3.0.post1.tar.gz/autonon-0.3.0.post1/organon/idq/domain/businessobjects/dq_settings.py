"""todo"""


class DqSettings:
    """todo"""

    # execution settings
    # algorithm settings
    # data source settings
    def __init__(self):
        pass
