"""todo"""
from organon.idq.domain.services.output.calculation.stats_output_service import StatsOutputService


class DbSourceStatsOutputService(StatsOutputService):
    """todo"""
