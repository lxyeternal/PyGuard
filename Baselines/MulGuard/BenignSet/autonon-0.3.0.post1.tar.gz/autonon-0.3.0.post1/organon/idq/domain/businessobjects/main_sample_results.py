"""todo"""
from typing import List

from organon.idq.domain.businessobjects.dq_comparison_result import DqComparisonResult


class MainSampleResults:
    """todo"""

    def __init__(self):
        self.comparison_results: List[DqComparisonResult] = None
