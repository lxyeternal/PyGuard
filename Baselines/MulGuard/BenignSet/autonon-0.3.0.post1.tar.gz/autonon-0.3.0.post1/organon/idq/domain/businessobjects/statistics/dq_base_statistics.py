"""todo"""
from typing import Optional


class DqBaseStatistics:
    """todo"""
    def __init__(self):
        self.n_val: Optional[float] = None
        self.n_miss: Optional[float] = None
        self.cardinality: Optional[float] = None
