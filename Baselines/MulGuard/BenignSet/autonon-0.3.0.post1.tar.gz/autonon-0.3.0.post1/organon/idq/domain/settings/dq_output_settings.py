"""Includes DqOutputSettings class."""


class DqOutputSettings:
    """Output settings for DQ execution."""

    def __init__(self):
        self.write_output_stats: bool = None
