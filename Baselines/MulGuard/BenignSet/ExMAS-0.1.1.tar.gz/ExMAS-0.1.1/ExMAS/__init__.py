from ExMAS.main import main
from ExMAS.utils import get_config, load_G, generate_demand