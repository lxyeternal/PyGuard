# Setupy

[gitignore.io](https://gitignore.io/) for `setup.py`

[![CircleCI](https://circleci.com/gh/aweidner/setupy.svg?style=svg)](https://circleci.com/gh/aweidner/setupy)
<a href="https://codeclimate.com/github/aweidner/setupy/maintainability"><img src="https://api.codeclimate.com/v1/badges/793ffd5227374861b68f/maintainability" /></a>
<a href="https://codeclimate.com/github/aweidner/setupy/test_coverage"><img src="https://api.codeclimate.com/v1/badges/793ffd5227374861b68f/test_coverage" /></a>
