
from pydevmgr_ua import UaNode

class VltNode(UaNode):
    pass
