def despedir():
    print("Adiós, me despido desde despedidas.despedir()")

class Despedida:
    def __init__(self):
        print("Adios, me despido desde Despedida.__init__()")