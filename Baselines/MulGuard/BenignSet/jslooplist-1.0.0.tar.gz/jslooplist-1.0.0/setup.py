from distutils.core import setup

setup (
		name		= 'jslooplist',
		version		= '1.0.0',
		py_modules	= ['jslooplist'],
		author		= 'jorseng',
		author_email= 'jorseng@testmail.com',
		url			= 'http://www.jstestpackageurl.com',
		description	= 'testing package',
)