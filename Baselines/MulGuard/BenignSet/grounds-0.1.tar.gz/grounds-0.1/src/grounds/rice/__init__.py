from .rice_ext import print_ok
