from grounds import rice


def main():
    rice.print_ok()


if __name__ == '__main__':
    main()
