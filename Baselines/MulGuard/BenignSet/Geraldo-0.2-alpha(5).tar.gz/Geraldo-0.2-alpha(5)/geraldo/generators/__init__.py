from base import ReportGenerator
from html import HTMLGenerator
from xmlstruct import XMLStructGenerator
from pdf import PDFGenerator
