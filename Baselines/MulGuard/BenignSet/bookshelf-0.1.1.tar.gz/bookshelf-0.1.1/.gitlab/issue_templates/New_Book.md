<!-- Use this template to propose a new Book -->

## Describe the book

<!-- What would this add? -->

### Data source

<!-- Which data version? -->

<!-- Any relevant links? -->

## Implementation Checklist
<!--
Add details for required items and delete others.
-->
 - [ ] Data provided under a suitable licence
 - [ ] Determine unique book name
 - [ ] Create new notebook in `notebooks/`
 - [ ] Add appropriate metadata
 - [ ] Publish (Currently only @lewisjarednz can do this)
 - [ ] Rerun CI after publishing to verify reproducibility

/label ~"New Book"
