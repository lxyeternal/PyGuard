### kapow


A python application launch framework with a punch! Kapow!

**This alpha software currently under active development**
