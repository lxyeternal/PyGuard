from rich.console import Console

console = Console()
