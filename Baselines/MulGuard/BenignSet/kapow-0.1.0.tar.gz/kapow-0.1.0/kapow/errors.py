class LaunchError(Exception):
    pass
