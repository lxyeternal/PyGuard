from .blueprint import Blueprint, BaseEntity

name = "py_factorio_blueprints"
