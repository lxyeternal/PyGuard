# python-factorio-blueprints

A python package for importing and editing factorio blueprint strings

Definitely not finished, but most basic blueprint functionality is supported.
