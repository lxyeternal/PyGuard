class MissingMandatoryValue(Exception):
    pass


class UnsupportedDataclassType(Exception):
    pass
