BASE_GRAPH_URL = "https://graph.microsoft.com/v1.0"
SIMPLE_UPLOAD_MAX_SIZE = 4000000  # 4MB
CHUNK_UPLOAD_MAX_SIZE = 3276800  # ~3MB must be divisible by 327680 bytes
SDK_VERSION = "0.0.1"
