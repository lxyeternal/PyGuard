from setuptools import setup

setup(name='snakepy',
      version='0.0.1',
      description='rapid api development framework in python',
      url='https://snakepy.com',
      author='oxbits',
      author_email='alex@oxbits.com',
      packages=['snakepy'],
      zip_safe=False)

