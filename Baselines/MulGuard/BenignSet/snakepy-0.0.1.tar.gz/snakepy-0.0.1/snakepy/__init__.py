def snakepy():
    return (u'snakepy')

