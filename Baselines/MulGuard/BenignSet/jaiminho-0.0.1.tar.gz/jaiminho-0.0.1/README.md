# jaiminho
Evitando a fadiga para facilitar o envio de e-mails em Python através das principais ferramentas e bibliotecas disponíveis
