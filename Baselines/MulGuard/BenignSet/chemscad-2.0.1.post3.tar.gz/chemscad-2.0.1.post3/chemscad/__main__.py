from chemscad.main import main
