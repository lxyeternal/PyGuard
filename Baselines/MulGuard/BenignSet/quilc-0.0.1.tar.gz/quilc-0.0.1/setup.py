#!/usr/bin/env python

from setuptools import setup

setup(
    name="quilc",
    version="0.0.1"
)
