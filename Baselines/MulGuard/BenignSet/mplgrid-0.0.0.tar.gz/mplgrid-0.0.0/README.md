# mplgrid

mplgrid is a Python library for creating a grid of axes in Matplotlib
