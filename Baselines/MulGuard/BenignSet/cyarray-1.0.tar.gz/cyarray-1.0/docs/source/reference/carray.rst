Module carray
===============

.. automodule:: cyarray.carray
   :members:
   :undoc-members:
