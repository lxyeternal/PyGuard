# AutoTrader (coming soon)
AutoTrader is a Python-based platform for developing, optimising and deploying automated trading systems.

## Features
- backtesting
- live trading
- parameter optimisation

