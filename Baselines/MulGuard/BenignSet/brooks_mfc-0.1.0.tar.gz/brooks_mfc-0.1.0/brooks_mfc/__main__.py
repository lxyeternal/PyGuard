from brooks_mfc import command_line

command_line()
