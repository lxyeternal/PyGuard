

def __init__():
	print('')
