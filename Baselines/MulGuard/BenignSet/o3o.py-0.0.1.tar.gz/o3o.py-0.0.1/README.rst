===============
o3o
===============

A python emoticon CLI tool.
