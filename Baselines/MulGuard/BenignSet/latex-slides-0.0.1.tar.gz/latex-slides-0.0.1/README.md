
# LaTeX Slide Maker
This python code provides a simple python code to make LaTeX slides.
It would be useful to put your qualitaive results in a slides automatically, when you have many examples to show. 

```python
from latex_slides.classes import *
```

Some scripts are provided as examples of how to use it.

***
_Copyright &copy; 2020 [Saeid Hosseinipoor](https://saeid-h.github.io/). Released under the [MIT License](LICENSE)._