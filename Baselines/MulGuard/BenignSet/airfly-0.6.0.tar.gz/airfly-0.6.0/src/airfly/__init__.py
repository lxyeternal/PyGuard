from ._meta import authors, version

__authors__ = authors
__version__ = version

__all__ = ["__authors__", "__version__"]
