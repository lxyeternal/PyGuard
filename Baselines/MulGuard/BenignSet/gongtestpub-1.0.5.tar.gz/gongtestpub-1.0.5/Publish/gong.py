import datetime


def first_pub():
    print(f'this time is {datetime.datetime.today()}')


if __name__ == '__main__':
    first_pub()



