# from njupt.models.aolan import Aolan
from njupt.models.card import Card
from njupt.models.zhengfang import Zhengfang