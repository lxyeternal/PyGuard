from njupt.utils.aolan.aolan_captcha import AolanCaptcha
from njupt.utils.card.card_captcha import CardCaptcha
from njupt.utils.zhengfang.zhengfang_captcha import ZhengfangCaptcha

