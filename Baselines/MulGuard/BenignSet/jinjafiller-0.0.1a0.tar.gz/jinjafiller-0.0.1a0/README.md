# jinjafiller

Configurable jinja compiler

## Usage:

```bash
jinfiller -c <path to config file> -t <path to template> -o <output file path>
```

## Note:

Config file should always be a JSON file.