# easylearn package 
This project is designed for machine learning in resting-state fMRI field.   

Our mission is to enable everyone who wants to apply machine learning to their research field to apply machine learning in the simplest way.  

Our goal is to develop a graphical interface so that researchers who are not familiar with programming can easily apply machine learning to their fields.  

## At present, the project is in the development stage  

** We hope you can join us! **

maintainer = Chao Li; Mengshi Dong; Shaoqiang Han; Ning Yang; Peng Zhang; Lili Tang
maintainer_email = lichao19870617@gmail.com; dongmengshi1990@163.com; 867727390@qq.com; 1157663200@qq.com; 1597403028@qq.com; lilyseyo@gmail.com,

# Demo
The simplest demo is in the eslearn/examples.