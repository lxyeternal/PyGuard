"Main interface for devicefarm service"

from mypy_boto3_devicefarm.client import Client

__all__ = ("Client",)
