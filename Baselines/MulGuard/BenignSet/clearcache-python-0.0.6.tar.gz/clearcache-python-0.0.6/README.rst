===========
clear-cache
===========

Simple module that clears cache from varnish servers using python module requests. The basic use of this module is to give it a set of varnish nodes and urls in order to clear the cache.
