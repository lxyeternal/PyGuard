#
# Copyright (c) 2006-2012, Prometheus Research, LLC
#


from htsql.core.tr.signature import ConnectiveSig


class RowNumberSig(ConnectiveSig):
    pass


