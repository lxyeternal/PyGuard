#!/usr/bin/env python2

# This file is exec'd by setup.py, so don't put anything in here that would 
# depend on the package actually being installed.

__version__ = '1.0.0'
__author__ = 'Kale Kundert'
__email__ = 'kale.kundert@ucsf.edu'
