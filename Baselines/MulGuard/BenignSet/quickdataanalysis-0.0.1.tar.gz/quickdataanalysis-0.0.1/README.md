# quick data analysis
This packages allows you to kick start your data analysis and make faster insights of the data.

# Requirements
* pandas >=1.0.1
