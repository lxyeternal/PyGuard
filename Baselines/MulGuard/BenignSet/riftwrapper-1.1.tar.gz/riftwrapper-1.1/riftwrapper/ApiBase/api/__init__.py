from .LeagueApi import LolAPI
from .LorApi import LorAPI
from .Error import APIKeyError, RegionError
