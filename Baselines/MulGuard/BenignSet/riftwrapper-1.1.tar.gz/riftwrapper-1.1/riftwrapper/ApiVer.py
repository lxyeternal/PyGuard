lol = {
    "account" : 'v1',
    "champion_mastery" : 'v4',
    "champion" : 'v3',
    "clash" : 'v1',
    "league_exp" : 'v4',
    "league" : 'v4',
    "lol_status" : 'v3',
    "match" : 'v4',
    "spectator" : 'v4',
    "summoner" : 'v4'
}

lor = {
    "ranked" : 'v1'
}

tft = {
    "league" : 'v1'
}