class CorruptPacket(ValueError):
    pass


class InvalidPayload(ValueError):
    pass