API
===

.. automodule:: dodal

    ``dodal``
    -----------------------------------

This is the internal API reference for dodal

.. data:: dodal.__version__
    :type: str

    Version number as calculated by https://github.com/pypa/setuptools_scm
