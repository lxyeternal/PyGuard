#!/usr/bin/env python
# -*- coding: utf-8 -*-


"""
Module with dummy functionality that isn't tested, to show a gap
in the code coverage.
"""


class Baz(object):
    """
    A class with many lines that don't get tested
    """

    a: int = 123
    b: int = 123
    c: int = 123
    d: int = 123
    e: int = 123
    f: int = 123
    g: int = 123
    h: int = 123
    i: int = 123
    j: int = 123
    k: int = 123
    m: int = 123
    n: int = 123
    o: int = 123
    p: int = 123
    q: int = 123
    r: int = 123
