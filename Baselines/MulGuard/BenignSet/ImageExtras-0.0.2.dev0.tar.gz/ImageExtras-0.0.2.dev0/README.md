# ImageExtras

Utilities and compiled algorithms to make Image Processing easier

## Getting started

To install it, you can either clone the repository:
```bash
cd ImageExtras
pip install .
```

Or you can install it through the official PyPI repository
```bash
pip install ImageExtras
```