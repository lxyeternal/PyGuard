# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['pca9632']

package_data = \
{'': ['*']}

install_requires = \
['smbus2>=0.3.0,<0.4.0']

setup_kwargs = {
    'name': 'pca9632',
    'version': '0.1.0',
    'description': 'PCA9632 driver',
    'long_description': None,
    'author': 'Josh Veitch-Michaelis',
    'author_email': 'j.veitchmichaelis@gmail.com',
    'maintainer': None,
    'maintainer_email': None,
    'url': 'https://github.com/jveitchmichaelis/pca9632',
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'python_requires': '>=2.7, !=3.0.*, !=3.1.*, !=3.2.*, !=3.3.*, !=3.4.*',
}


setup(**setup_kwargs)
