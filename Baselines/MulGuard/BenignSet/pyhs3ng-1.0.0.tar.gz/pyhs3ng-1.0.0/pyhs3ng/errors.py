"""HomeSeer errors"""


class HomeSeerError(Exception):
    pass


class HomeSeerASCIIConnectionError(HomeSeerError):
    pass
