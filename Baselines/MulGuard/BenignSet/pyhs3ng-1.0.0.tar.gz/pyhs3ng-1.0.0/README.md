# pyhs3

## Python3 async library for interacting with HomeSeer HS3

*Requirements:* python3, asyncio, aiohttp

Install pyhs3 with `python3 -m pip install pyhs3`.