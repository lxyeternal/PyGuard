from distutils.core import setup

setup(
      name        = 'datasssssplit',
      version     = '1.0.0',
      py_modules  =['datasssssplit'],
      author      ='veryshine',
      author_email='263059108@qq.com',
      url         ='http://url',
      description ='data split by ":"',
     )
