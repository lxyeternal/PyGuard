from django.apps import AppConfig


class RestValidatorConfig(AppConfig):
    name = 'captcha_rest_validator'
