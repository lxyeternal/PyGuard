from comicslicer import ComicSlicer
