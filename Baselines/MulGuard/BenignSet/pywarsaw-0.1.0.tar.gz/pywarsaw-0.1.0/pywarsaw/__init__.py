from .pywarsaw import Mermaid

__title__ = "pywarsaw"
__author__ = "brozen"
__doc__ = "Unofficial wrapper for Warsaw Open Data - api.um.warszawa.pl"
__version__ = "0.1.0"

__all__ = ["Mermaid"]
