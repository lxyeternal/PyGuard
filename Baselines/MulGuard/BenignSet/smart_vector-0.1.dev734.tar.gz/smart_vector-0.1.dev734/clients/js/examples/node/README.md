## Demo in node

1. `yarn dev`
2. visit `localhost:3000`
