def convert():
    print("converting the pdf to image")