import setuptools

with open("README.md", "r") as fh:
    long_description = fh.read()

with open("VERSION", "r") as fh:
    version = fh.read().strip()

setuptools.setup(
    name="fenjing",
    version=version,
    author="Marven11",
    author_email="marven11@example.com",
    description="A Jinja2 SSTI cracker for CTF competitions",
    long_description=long_description,
    long_description_content_type="text/markdown",
    url="https://github.com/marven11/fenjing",
    packages=setuptools.find_packages(),
    classifiers=[
        "Programming Language :: Python :: 3.9",
        "License :: OSI Approved :: Mozilla Public License 2.0 (MPL 2.0)",
        "Operating System :: OS Independent",
    ],
)
