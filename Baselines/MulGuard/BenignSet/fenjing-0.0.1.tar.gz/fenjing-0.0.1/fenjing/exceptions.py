class NotTested(Exception):
    pass