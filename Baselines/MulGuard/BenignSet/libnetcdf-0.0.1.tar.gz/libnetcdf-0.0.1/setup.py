from setuptools import setup

setup(
    name='libnetcdf',
    version="1.0.0",
    description='libnetcdf - listed by Cycode to prevent confusion',
    long_description="libnetcdf",
    long_description_content_type='text/markdown',
)
