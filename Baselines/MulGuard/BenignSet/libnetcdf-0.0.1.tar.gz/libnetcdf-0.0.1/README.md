# libnetcdf
libnetcdf - listed by Cycode to prevent dependency confusion.
Please contact us if you are the owner of this package.
research@cycode.com
