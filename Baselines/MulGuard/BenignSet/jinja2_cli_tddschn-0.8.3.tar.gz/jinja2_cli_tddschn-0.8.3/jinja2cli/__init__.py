"""
jinja2-cli
==========

License: BSD, see LICENSE for more details.
"""

__author__ = "Matt Robenolt, Teddy Xinyuan Chen"
__version__ = "0.8.3"

from .cli import main  # NOQA
