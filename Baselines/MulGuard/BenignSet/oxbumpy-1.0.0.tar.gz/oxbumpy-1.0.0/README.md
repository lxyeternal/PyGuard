# Oxbumpy
Analyse Oxford bumps data, simulate races, and predict fantasy bumps crews
