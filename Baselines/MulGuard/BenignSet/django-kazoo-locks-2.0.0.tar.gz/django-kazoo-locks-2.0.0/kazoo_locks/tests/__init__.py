"""Tests for locks utilities."""
