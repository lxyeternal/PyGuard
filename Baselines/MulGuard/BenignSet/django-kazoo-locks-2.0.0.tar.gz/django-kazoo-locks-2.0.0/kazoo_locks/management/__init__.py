"""Management for kazoo_locks app."""
