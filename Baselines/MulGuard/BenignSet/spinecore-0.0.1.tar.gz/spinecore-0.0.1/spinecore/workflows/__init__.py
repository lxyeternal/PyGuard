from spinecore.workflows.dag_workflow import DagWorkflow
