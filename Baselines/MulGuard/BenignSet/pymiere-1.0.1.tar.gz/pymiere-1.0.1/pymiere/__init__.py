from pymiere.objects.premiere_objects import *
from pymiere.objects.start_vars import StartVars
objects = StartVars()  # entry point to the root level ExtendScript objects available
