anouman
======

A django wrapper designed to setup project so they are easily deployable with nginx
