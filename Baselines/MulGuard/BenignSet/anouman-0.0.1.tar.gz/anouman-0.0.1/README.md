anouman
======

A django wrapper designed to setup django project so they are easily deployable with nginx/gunicorn
