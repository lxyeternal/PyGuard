Thanks
======

Thanks are due to Andrey Novoseltsev for reviewing earlier versions of
parts of this code and for reviewing the changes to Novoseltsev’s code
``interactive_simplex_method`` in SageMath, making helpful changes to
that code, and providing many valuable comments and suggestions.

Thanks are also due to several other reviewers on related SageMath
tickets: Nathann Cohen, Vincent Delecroix, Dima Pasechnik.

Thanks to Isuru Fernando for help with conda-forge.

Peijun Xiao, Zeyi Wang, and Yuan Zhou were partially supported by the
National Science Foundation through grant DMS-1320051, awarded to
Matthias Koeppe.
