poetry build
pip uninstall presyence --yes
pip install ../dist/presyence-0.1.0-py3-none-any.whl
presyence

