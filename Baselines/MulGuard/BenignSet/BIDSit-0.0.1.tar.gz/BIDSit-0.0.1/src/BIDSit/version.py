#============================================================================#
# Script Name: version.py                                                    #
#                                                                            #
# Description: specifies version for BIDSit                                  #
#                                                                            #
# Author:      Jen Burrell (April 17th, 2023)                                #
#============================================================================#

__version__ = '0.0.1'
