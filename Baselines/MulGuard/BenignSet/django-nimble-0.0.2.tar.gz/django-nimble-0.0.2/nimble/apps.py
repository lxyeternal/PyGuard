from django.apps import AppConfig


class NimbleConfig(AppConfig):
    name = 'nimble'
