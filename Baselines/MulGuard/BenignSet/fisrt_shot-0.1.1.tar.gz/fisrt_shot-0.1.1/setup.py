from setuptools import setup

setup(name='fisrt_shot',
      version='0.1.1',
      description='Gaussian distributions',
      packages=['fisrt_shot'],
      zip_safe=False)


