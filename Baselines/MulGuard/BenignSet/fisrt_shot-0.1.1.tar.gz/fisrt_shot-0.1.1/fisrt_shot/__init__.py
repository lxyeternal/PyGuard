from fisrt_shot.main import kiritrain_function

if __name__ == '__main__':
    kiritrain_function()