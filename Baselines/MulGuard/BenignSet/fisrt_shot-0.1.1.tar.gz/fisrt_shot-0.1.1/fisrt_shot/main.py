from fisrt_shot.sub_1 import helper , fun_1_1
from fisrt_shot.sub_2 import mod_2

def kiritrain_function ():
    print ('kiritaring function is just started ')
    print ('kos e nane ramin moosavi ')
    print ('++++calling helper form sub 1 helper ')
    helper()
    print('+++++helper is doen ')
    print('+++++ calling func1-1 from sub 1 mod 1 ')
    fun_1_1()
    print('++++++ just done finc 1 1 ')
    print('+++++ calling func 1- 2 from sub 2 mod 2 ')
    fun_1_1()
    print('++++++ just done finc 1 2')
    print ('***** KOSE NANE RAMIN MOUSAVI *****')


if __name__ == '__main__':
    kiritrain_function()
