from __future__ import division, absolute_import

import ispyb.common.driver

__version__ = "0.10"

get_driver = ispyb.common.driver.get_driver
Backend = ispyb.common.driver.Backend
