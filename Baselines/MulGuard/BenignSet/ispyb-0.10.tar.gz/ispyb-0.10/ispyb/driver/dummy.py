from __future__ import absolute_import, division

import ispyb.api.main

class ISPyBDummyDriver(ispyb.api.main.API):
  pass
