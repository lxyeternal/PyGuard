from __future__ import absolute_import, division

class API(object):
  '''Functions in this object are added to the main ISPyB API object.'''

  def get_datacollection_id(self, dcid):
    '''Here is some explanation of this method.
       It takes one parameter.
       It returns a dictionary of everything stored in the database.'''
    self._notimplemented()

  def get_datacollection_template(self, dcid):
    '''Here is some explanation of this method.
       It takes one parameter.
       It returns the image template file name including the full path.'''
    self._notimplemented()
