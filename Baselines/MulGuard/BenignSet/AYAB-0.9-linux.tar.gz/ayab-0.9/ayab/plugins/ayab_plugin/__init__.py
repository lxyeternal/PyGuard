from . import ayab_control

# This adds ayab_control.AyabControl to the upper namespace of the module.
AyabPluginControl = ayab_control.AyabPluginControl
