<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS><TS version="2.0" language="en_US" sourcelanguage="">
<context>
    <name>DockWidget</name>
    <message>
        <location filename="ayab_options.ui" line="134"/>
        <source>Colors</source>
        <translation></translation>
    </message>
    <message>
        <location filename="ayab_options.ui" line="157"/>
        <source>Start Line</source>
        <translation></translation>
    </message>
    <message>
        <location filename="ayab_options.ui" line="173"/>
        <source>line </source>
        <translation></translation>
    </message>
    <message>
        <location filename="ayab_options.ui" line="205"/>
        <source>Start Needle</source>
        <translation></translation>
    </message>
    <message>
        <location filename="ayab_options.ui" line="260"/>
        <source>Stop Needle</source>
        <translation></translation>
    </message>
    <message>
        <location filename="ayab_options.ui" line="341"/>
        <source>Alignment</source>
        <translation></translation>
    </message>
    <message>
        <location filename="ayab_options.ui" line="360"/>
        <source>left</source>
        <translation></translation>
    </message>
    <message>
        <location filename="ayab_options.ui" line="355"/>
        <source>center</source>
        <translation></translation>
    </message>
    <message>
        <location filename="ayab_options.ui" line="365"/>
        <source>right</source>
        <translation></translation>
    </message>
    <message>
        <location filename="ayab_options.ui" line="309"/>
        <source>Machine Type</source>
        <translation></translation>
    </message>
    <message>
        <location filename="ayab_options.ui" line="323"/>
        <source>single</source>
        <translation></translation>
    </message>
    <message>
        <location filename="ayab_options.ui" line="328"/>
        <source>ribber</source>
        <translation></translation>
    </message>
    <message>
        <location filename="ayab_options.ui" line="69"/>
        <source>Port Selection</source>
        <translation></translation>
    </message>
    <message>
        <location filename="ayab_options.ui" line="192"/>
        <source>Infinite Repeat</source>
        <translation></translation>
    </message>
    <message>
        <location filename="ayab_options.ui" line="278"/>
        <source>orange</source>
        <translation></translation>
    </message>
    <message>
        <location filename="ayab_options.ui" line="273"/>
        <source>green</source>
        <translation></translation>
    </message>
    <message>
        <location filename="ayab_options.ui" line="471"/>
        <source>2. Configure</source>
        <translation></translation>
    </message>
    <message>
        <location filename="ayab_options.ui" line="78"/>
        <source>Refresh</source>
        <translation></translation>
    </message>
    <message>
        <location filename="ayab_options.ui" line="116"/>
        <source>Knit</source>
        <translation></translation>
    </message>
    <message>
        <location filename="ayab_options.ui" line="393"/>
        <source>Hall Left</source>
        <translation></translation>
    </message>
    <message>
        <location filename="ayab_options.ui" line="432"/>
        <source>%p%</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ayab_options.ui" line="416"/>
        <source>Hall Right</source>
        <translation></translation>
    </message>
    <message>
        <location filename="ayab_options.ui" line="439"/>
        <source>Position</source>
        <translation></translation>
    </message>
    <message>
        <location filename="ayab_options.ui" line="459"/>
        <source>No carriage detected</source>
        <translation></translation>
    </message>
    <message>
        <location filename="ayab_options.ui" line="375"/>
        <source>Test</source>
        <translation></translation>
    </message>
    <message>
        <location filename="ayab_options.ui" line="333"/>
        <source>circular</source>
        <translation type="unfinished"></translation>
    </message>
</context>
</TS>
