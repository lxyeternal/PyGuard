<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS><TS version="2.0" language="de_DE" sourcelanguage="en_US">
<context>
    <name>DockWidget</name>
    <message>
        <location filename="ayab_options.py" line="232"/>
        <source>AYAB</source>
        <translation type="obsolete">AYAB</translation>
    </message>
    <message>
        <location filename="ayab_options.ui" line="69"/>
        <source>Port Selection</source>
        <translation>Port wählen</translation>
    </message>
    <message>
        <location filename="ayab_options.py" line="136"/>
        <source>Refresh Ports</source>
        <translation type="obsolete">aktualisieren</translation>
    </message>
    <message>
        <location filename="ayab_options.ui" line="134"/>
        <source>Colors</source>
        <translation>Farben</translation>
    </message>
    <message>
        <location filename="ayab_options.ui" line="157"/>
        <source>Start Line</source>
        <translation>Startzeile</translation>
    </message>
    <message>
        <location filename="ayab_options.ui" line="173"/>
        <source>line </source>
        <translation>Zeile </translation>
    </message>
    <message>
        <location filename="ayab_options.ui" line="192"/>
        <source>Infinite Repeat</source>
        <translation>Unendlich wiederholen</translation>
    </message>
    <message>
        <location filename="ayab_options.ui" line="205"/>
        <source>Start Needle</source>
        <translation>Startnadel</translation>
    </message>
    <message>
        <location filename="ayab_options.ui" line="278"/>
        <source>orange</source>
        <translation>orange</translation>
    </message>
    <message>
        <location filename="ayab_options.ui" line="273"/>
        <source>green</source>
        <translation>grün</translation>
    </message>
    <message>
        <location filename="ayab_options.ui" line="260"/>
        <source>Stop Needle</source>
        <translation>Stopnadel</translation>
    </message>
    <message>
        <location filename="ayab_options.ui" line="341"/>
        <source>Alignment</source>
        <translation>Ausrichtung</translation>
    </message>
    <message>
        <location filename="ayab_options.ui" line="355"/>
        <source>center</source>
        <translation>mittig</translation>
    </message>
    <message>
        <location filename="ayab_options.ui" line="360"/>
        <source>left</source>
        <translation>links</translation>
    </message>
    <message>
        <location filename="ayab_options.ui" line="365"/>
        <source>right</source>
        <translation>rechts</translation>
    </message>
    <message>
        <location filename="ayab_options.ui" line="309"/>
        <source>Machine Type</source>
        <translation>Strickmodus</translation>
    </message>
    <message>
        <location filename="ayab_options.ui" line="323"/>
        <source>single</source>
        <translation>single</translation>
    </message>
    <message>
        <location filename="ayab_options.ui" line="328"/>
        <source>ribber</source>
        <translation>ribber</translation>
    </message>
    <message>
        <location filename="ayab_options.ui" line="471"/>
        <source>2. Configure</source>
        <translation>2. Konfigurieren</translation>
    </message>
    <message>
        <location filename="ayab_options.ui" line="78"/>
        <source>Refresh</source>
        <translation>Aktualisieren</translation>
    </message>
    <message>
        <location filename="ayab_options.ui" line="116"/>
        <source>Knit</source>
        <translation>Stricken</translation>
    </message>
    <message>
        <location filename="ayab_options.ui" line="393"/>
        <source>Hall Left</source>
        <translation>Hall links</translation>
    </message>
    <message>
        <location filename="ayab_options.ui" line="432"/>
        <source>%p%</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ayab_options.ui" line="416"/>
        <source>Hall Right</source>
        <translation>Hall rechts</translation>
    </message>
    <message>
        <location filename="ayab_options.ui" line="439"/>
        <source>Position</source>
        <translation>Position</translation>
    </message>
    <message>
        <location filename="ayab_options.ui" line="459"/>
        <source>No carriage detected</source>
        <translation>Kein Schlitten erkannt</translation>
    </message>
    <message>
        <location filename="ayab_options.ui" line="375"/>
        <source>Test</source>
        <translation>Test</translation>
    </message>
    <message>
        <location filename="ayab_options.ui" line="333"/>
        <source>circular</source>
        <translation type="unfinished"></translation>
    </message>
</context>
</TS>
