from . import dummy_plugin

# This adds test_knitting_plugin.TestingKnittingPlugin to the upper namespace of the module.
DummyKnittingPlugin = dummy_plugin.DummyKnittingPlugin
