# Add your module to file so PyInstaller can load dependencies.

from . import ayab_plugin
from . import dummy_knitting_plugin
