
def run():
    from .ayab import run
    run()
