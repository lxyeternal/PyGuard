__version__ = '0.1.0'

from .lzon import loads