"""
`detadict` is a Python package for working with the `Deta Base` as a native python dictionary.
"""

from .detadict import detadict

__all__ = ["detadict"]
