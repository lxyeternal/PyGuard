`book.isbn` is a package for book ISBN.

======
setup
======

easy_install
=============

.. code-block:: bash

   $ easy_install book.isbn

pip
====

.. code-block:: bash

   $ pip install book.isbn
